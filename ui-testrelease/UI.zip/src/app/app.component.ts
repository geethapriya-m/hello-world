import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController, NavController, Platform } from '@ionic/angular';
import { WelcomePage } from './welcome/welcome.page';
import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
// import { InAppBrowser , InAppBrowserOptions } from '@ionic-native/in-app-browser';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  existingScreenOrientation: string;
  constructor(private platform: Platform,
    public navCtrl: NavController,
    private so: ScreenOrientation,
    public modalCtrl: ModalController,
    public router:Router) {
    // this.initializeApp();
    // var myScreenOrientation = screen.orientation;
    // myScreenOrientation.lock("portrait")

    // this.lockToPortrait()

    this.modalCtrl.create({
      component: WelcomePage
    })
  }
  ngOnInit(){


// var ref = cordova.InAppBrowser.open('http://straightlines.io', '_blank', 'location=yes');
// this.so.onChange().subscribe(()=>{
//   this.so.lock(this.so.ORIENTATIONS.PORTRAIT_PRIMARY)
//   // alert(this.so.type)
// }
//   )
  // if(this.platform.is('cordova') ||  this.platform.is('android') || this.platform.is('ios') || this.platform.is('mobile') || this.platform.is('iphone') || this.platform.is('mobileweb') ){
  //     this.platform.ready().then(()=>{
  //     this.so.unlock();
  //     this.so.lock(this.so.ORIENTATIONS.PORTRAIT_PRIMARY)


  //     })
  //   }

  }
  lockToPortrait(){
    this.so.lock(this.so.ORIENTATIONS.PORTRAIT);
  }
}
