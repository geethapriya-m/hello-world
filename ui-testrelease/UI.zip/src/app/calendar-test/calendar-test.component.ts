import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MenuController, NavController, NavParams } from '@ionic/angular';
import { CalendarMode, Step } from 'ionic2-calendar/calendar';
import { HeaderTitleService } from '../dashboard/nav-bar-footer/header-title.service';
import straightlines_io_apis from 'src/app/json/apis.json';
@Component({
  selector: 'app-calendar-test',
  templateUrl: './calendar-test.component.html',
  styleUrls: ['./calendar-test.component.scss'],
})
export class CalendarTestComponent implements OnInit {

  touchtime=0
  eventSource;
  viewTitle;
  clickCount=0
  isToday:boolean;
  calendar = {
      mode: 'month' as CalendarMode,
      step: 30 as Step,
      currentDate: new Date(),
      settings:{
        colors:[{background: '#d6e81e1a',}]
      },
      dateFormatter: {
          formatMonthViewDay: function(date:Date) {
              return date.getDate().toString()
          },
          formatMonthViewDayHeader: function(date:Date) {
              return 'MonMH';
          },
          formatMonthViewTitle: function(date:Date) {
              return 'testMT';
          },
          formatWeekViewDayHeader: function(date:Date) {
              return 'MonWH';
          },
          formatWeekViewTitle: function(date:Date) {
              return 'testWT';
          },
          formatWeekViewHourColumn: function(date:Date) {
              return 'testWH';
          },
          formatDayViewHourColumn: function(date:Date) {
              return 'testDH';
          },
          formatDayViewTitle: function(date:Date) {
              return 'testDT';
          }
      }
  };
  popup: any;
  selectedDate: any[];
  popupSlot: any;
  clickName: any;
  currentSelectedDate: any;
  tempSelectedDate: any;

  constructor(private menu: MenuController,
    private headerTitleService: HeaderTitleService,
    private formBuilder: FormBuilder,public navCtrl: NavController,private route: ActivatedRoute, private router: Router,public navParams: NavParams,) {

  }

  openFirst() {
    this.menu.enable(true, 'first');
    this.menu.open('first');
  }

  openEnd() {
    this.menu.open('end');
  }
  async openMenu() {
    await this.menu.open();
  }
  openCustom() {
    this.menu.enable(true, 'custom');
    this.menu.open('custom');
  }
  loadEvents() {
      this.eventSource = this.createRandomEvents();
//01/01/2021
//05/14/2021  WT

//09/04/2021 SS
//12/31/2021
var temp=[]
var start_date=new Date('01/01/2021')
    var end_date=new Date('05/16/2021')
    var Difference_In_Time = end_date.getTime() - start_date.getTime();
    var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
    var nextDay = new Date('09/04/2021');
    var t
    var days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    this.eventSource=[]
    var temp1=[]
    for(var i=0;i<Difference_In_Days;i++){
      t=new Date(new Date('01/01/2021').setDate(new Date('01/01/2021').getDate() + i));
      var dayName = days[new Date(t).getDay()];
      if(dayName=='Wed' || dayName=='Thu'){
        var te=String(t.toLocaleDateString());
        this.eventSource.push( {"title": "WT",
        "startTime":new Date(te),
        "endTime":new Date(te),
        "allDay": true,
        "emp":[],
        "slot":2,
        })
      }else{
        var te=String(t.toLocaleDateString());
        this.eventSource.push( {"title": "",
        "startTime":new Date(te),
        "endTime":new Date(te),
        "allDay": true,
        "emp":[],
        "slot":0,
        })
       }
    }

      // for(var i=0;i<temp.length;i++){
      //   var te=String(temp[i].toLocaleDateString());
      //   this.eventSource.push( {"title": "WT",
      //   "startTime":new Date(te),
      //   "endTime":new Date(te),
      //   "allDay": true,
      //   "slot":2,
      //   "emp":[],
      //   'color': 'danger'
      //   })
      //   // console.log(te)
      // }
    start_date=new Date('05/15/2021')
    end_date=new Date('09/04/2021')
    Difference_In_Time = end_date.getTime() - start_date.getTime();
    Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
    temp=[]
   for(var i=1;i<Difference_In_Days;i++){
     t=new Date(new Date('05/15/2021').setDate(new Date('05/15/2021').getDate() + i));
     var dayName = days[new Date(t).getDay()];
     if(dayName=='Mon' || dayName=='Tue'){
       var te=String(t.toLocaleDateString());
       this.eventSource.push( {"title": "MT",
       "startTime":new Date(te),
       "endTime":new Date(te),
       "allDay": true,
       "emp":[],
       "slot":2,
       })
     }else{
      var te=String(t.toLocaleDateString());
      this.eventSource.push( {"title": "",
      "startTime":new Date(te),
      "endTime":new Date(te),
      "allDay": true,
      "emp":[],
      "slot":0,
      })
     }
   }
   for(var i=0;i<temp.length;i++){
    var te=String(temp[i].toLocaleDateString());

    // console.log(te)
  }
     start_date=new Date('09/04/2021')
     end_date=new Date('12/31/2021')
     temp=[]
     Difference_In_Time = end_date.getTime() - start_date.getTime();
     Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
    for(var i=1;i<Difference_In_Days;i++){
      t=new Date(new Date('09/03/2021').setDate(new Date('09/03/2021').getDate() + i));
      var dayName = days[new Date(t).getDay()];
      if(dayName=='Sun' || dayName=='Sat'){

          var te=String(t.toLocaleDateString());
          this.eventSource.push( {"title": "SS",
          "startTime":new Date(te),
          "endTime":new Date(te),
          "emp":[],
          "allDay": true,
          "slot":2,
          })
        }else{
         var te=String(t.toLocaleDateString());
         this.eventSource.push( {"title": "",
         "startTime":new Date(te),
         "endTime":new Date(te),
         "allDay": true,
         "emp":["RA","VP"],
         "slot":0,
         })
        }



    // for(var i=0;i<temp.length;i++){
    //   var te=String(temp[i].toLocaleDateString());
    //   this.eventSource.push( {"title": "SS",
    //   "startTime":new Date(te),
    //   "endTime":new Date(te),
    //   "allDay": true,
    //   "slot":2,
    //   'color': 'danger'
    //   })
      // console.log(te)
    }
      console.log(this.eventSource)
  }

  onViewTitleChanged(title) {
      this.viewTitle = title;
      console.log(this.viewTitle)
  }

  onEventSelected(event) {
    console.log(event)

  }

  changeMode(mode) {
      this.calendar.mode = mode;
  }

  today() {
      this.calendar.currentDate = new Date();
  }

  onTimeSelected(ev) {
    // console.log(ev)
    // console.log("test")
      // console.log('Selected time: ' + ev.selectedTime + ', hasEvents: ' +
          // (ev.events !== undefined && ev.events.length !== 0) + ', disabled: ' + ev.disabled);
  }

  onCurrentDateChanged(event) {
      var today = new Date();
      today.setHours(0, 0, 0, 0);
      event.setHours(0, 0, 0, 0);
      this.isToday = today.getTime() === event.getTime();
  }

  createRandomEvents() {
      var events = [];
      for (var i = 0; i < 50; i += 1) {
          var date = new Date();
          var eventType = Math.floor(Math.random() * 2);
          var startDay = Math.floor(Math.random() * 90) - 45;
          var endDay = Math.floor(Math.random() * 2) + startDay;
          var startTime;
          var endTime;
          if (eventType === 0) {
              startTime = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate() + startDay));
              if (endDay === startDay) {
                  endDay += 1;
              }
              endTime = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate() + endDay));
              events.push({
                  title:
                  // 'All Day - '
                   + i,
                  startTime: startTime,
                  endTime: endTime,
                  allDay: true
              });
          } else {
              var startMinute = Math.floor(Math.random() * 24 * 60);
              var endMinute = Math.floor(Math.random() * 180) + startMinute;
              startTime = new Date(date.getFullYear(), date.getMonth(), date.getDate() + startDay, 0, date.getMinutes() + startMinute);
              endTime = new Date(date.getFullYear(), date.getMonth(), date.getDate() + endDay, 0, date.getMinutes() + endMinute);
              events.push({
                  title: 'Event - ' + i,
                  startTime: startTime,
                  endTime: endTime,
                  allDay: false
              });
          }
      }
      return events;
  }

  onRangeChanged(ev) {
      // console.log('range changed: startTime: ' + ev.startTime + ', endTime: ' + ev.endTime);
  }

  markDisabled = (date:Date) => {
      var current = new Date();
      current.setHours(0, 0, 0);
      return date < current;
  };
test(e){
  console.log(e)
}
  ngOnInit() {
    this.headerTitleService.setTitle('Calendar');
    this.headerTitleService.setDefaultHeader(true)
    this.headerTitleService.setBackUrl(straightlines_io_apis.apis.cal_test);
      this.headerTitleService.setForwardUrl(null);
    this.selectedDate=[]

    this.currentSelectedDate=null
this.loadEvents()
}
reloadSource(s){
console.log(s)
}
test2(){
console.log("test1")
}
test1(e){
  // console.log(e)

// console.log(this.currentSelectedDate)
  // this.selectedDate.push({"title":e.events[0].title})
  this.clickCount++;
  // console.log(this.clickCount)
  setTimeout(() => {
      if (this.clickCount === 1) {
           // single
           this.selectedDate=[]
           this.tempSelectedDate=e
           this.clickName='single'
           console.log("single")
      } else if (this.clickCount === 2) {
          // double
          this.currentSelectedDate=e
if(this.currentSelectedDate===this.tempSelectedDate){
  this.tempSelectedDate=''
}
          this.clickName='double'
          console.log("double")
          this.selectedDate=[]
            this.selectedDate.push({"event":e.events[0]})
      }
      this.clickCount = 0;
  }, 250)

}
tes(e) {
  // console.log(e)
  // this.currentSelectedDate=e
  var popup = <HTMLElement>document.getElementById("myPopup");
  popup.classList.toggle("show");
  this.popup=e.events[0].emp
  this.popupSlot=e.events[0].slot + - +e.events[0].emp.length
  // console.log(this.popup,this.popupSlot)
}
dismiss(e){
  // console.log(e)
this.currentSelectedDate=e
}
cssClassSingle(){
  // if(this.clickName=='single'){
    return 'single-click'
  // }
}
cssClassDouble(){
  // if(this.clickName=='double'){
    return 'double-click'
  // }
}
}
































































// eventSource;
// viewTitle;

// isToday:boolean;
// calendar = {
//     mode: 'month' as CalendarMode,
//     step: 30 as Step,
//     currentDate: new Date(),
//     settings:{
//       colors:[{background: '#d6e81e1a',}]
//     },
//     dateFormatter: {
//         formatMonthViewDay: function(date:Date) {
//             return date.getDate().toString()
//         },
//         formatMonthViewDayHeader: function(date:Date) {
//             return 'MonMH';
//         },
//         formatMonthViewTitle: function(date:Date) {
//             return 'testMT';
//         },
//         formatWeekViewDayHeader: function(date:Date) {
//             return 'MonWH';
//         },
//         formatWeekViewTitle: function(date:Date) {
//             return 'testWT';
//         },
//         formatWeekViewHourColumn: function(date:Date) {
//             return 'testWH';
//         },
//         formatDayViewHourColumn: function(date:Date) {
//             return 'testDH';
//         },
//         formatDayViewTitle: function(date:Date) {
//             return 'testDT';
//         }
//     }
// };

// constructor(private menu: MenuController,
//   private formBuilder: FormBuilder,public navCtrl: NavController,private route: ActivatedRoute, private router: Router,public navParams: NavParams,) {

// }

// openFirst() {
//   this.menu.enable(true, 'first');
//   this.menu.open('first');
// }

// openEnd() {
//   this.menu.open('end');
// }
// async openMenu() {
//   await this.menu.open();
// }
// openCustom() {
//   this.menu.enable(true, 'custom');
//   this.menu.open('custom');
// }
// loadEvents() {
//     this.eventSource = this.createRandomEvents();
// //01/01/2021
// //05/14/2021  WT

// //09/04/2021 SS
// //12/31/2021
// var temp=[]
// var start_date=new Date('01/01/2021')
//   var end_date=new Date('05/14/2021')
//   var Difference_In_Time = end_date.getTime() - start_date.getTime();
//   var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
//   var nextDay = new Date('09/04/2021');
//   var t
//   var days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
//   this.eventSource=[]
//   var temp1=[]
//   for(var i=0;i<Difference_In_Days;i++){
//     t=new Date(new Date('01/01/2021').setDate(new Date('01/01/2021').getDate() + i));
//     var dayName = days[new Date(t).getDay()];
//     if(dayName=='Wed' || dayName=='Thu'){
//       temp.push(t)
//     }
//   }

//     for(var i=0;i<temp.length;i++){
//       var te=String(temp[i].toLocaleDateString());
//       this.eventSource.push( {"title": "WT",
//       "startTime":new Date(te),
//       "endTime":new Date(te),
//       "allDay": true,
//       "slot":2,
//       'color': 'danger'
//       })
//       // console.log(te)
//     }
//   start_date=new Date('05/15/2021')
//   end_date=new Date('09/03/2021')
//   Difference_In_Time = end_date.getTime() - start_date.getTime();
//   Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
//   temp=[]
//  for(var i=1;i<Difference_In_Days;i++){
//    t=new Date(new Date('05/15/2021').setDate(new Date('05/15/2021').getDate() + i));
//    var dayName = days[new Date(t).getDay()];
//    if(dayName=='Mon' || dayName=='Tue'){
//      temp.push(t)
//    }
//  }
//  for(var i=0;i<temp.length;i++){
//   var te=String(temp[i].toLocaleDateString());
//   this.eventSource.push( {"title": "MT",
//   "startTime":new Date(te),
//   "endTime":new Date(te),
//   "allDay": true,
//   "slot":2,
//   'color': 'danger'
//   })
//   // console.log(te)
// }
//    start_date=new Date('09/04/2021')
//    end_date=new Date('12/31/2021')
//    temp=[]
//    Difference_In_Time = end_date.getTime() - start_date.getTime();
//    Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
//   for(var i=1;i<Difference_In_Days;i++){
//     t=new Date(new Date('09/03/2021').setDate(new Date('09/03/2021').getDate() + i));
//     var dayName = days[new Date(t).getDay()];
//     if(dayName=='Sun' || dayName=='Sat'){
//       temp.push(t)
//     }
//   }


//   for(var i=0;i<temp.length;i++){
//     var te=String(temp[i].toLocaleDateString());
//     this.eventSource.push( {"title": "SS",
//     "startTime":new Date(te),
//     "endTime":new Date(te),
//     "allDay": true,
//     "slot":2,
//     'color': 'danger'
//     })
//     // console.log(te)
//   }
//     console.log(this.eventSource)
// }

// onViewTitleChanged(title) {
//     this.viewTitle = title;
//     console.log(this.viewTitle)
// }

// onEventSelected(event) {
//   console.log(event)
//     console.log('Event selected:' + event.startTime + '-' + event.endTime + ',' + event.title);
// }

// changeMode(mode) {
//     this.calendar.mode = mode;
// }

// today() {
//     this.calendar.currentDate = new Date();
// }

// onTimeSelected(ev) {
//   console.log(ev)
//     console.log('Selected time: ' + ev.selectedTime + ', hasEvents: ' +
//         (ev.events !== undefined && ev.events.length !== 0) + ', disabled: ' + ev.disabled);
// }

// onCurrentDateChanged(event) {
//     var today = new Date();
//     today.setHours(0, 0, 0, 0);
//     event.setHours(0, 0, 0, 0);
//     this.isToday = today.getTime() === event.getTime();
// }

// createRandomEvents() {
//     var events = [];
//     for (var i = 0; i < 50; i += 1) {
//         var date = new Date();
//         var eventType = Math.floor(Math.random() * 2);
//         var startDay = Math.floor(Math.random() * 90) - 45;
//         var endDay = Math.floor(Math.random() * 2) + startDay;
//         var startTime;
//         var endTime;
//         if (eventType === 0) {
//             startTime = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate() + startDay));
//             if (endDay === startDay) {
//                 endDay += 1;
//             }
//             endTime = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate() + endDay));
//             events.push({
//                 title:
//                 // 'All Day - '
//                  + i,
//                 startTime: startTime,
//                 endTime: endTime,
//                 allDay: true
//             });
//         } else {
//             var startMinute = Math.floor(Math.random() * 24 * 60);
//             var endMinute = Math.floor(Math.random() * 180) + startMinute;
//             startTime = new Date(date.getFullYear(), date.getMonth(), date.getDate() + startDay, 0, date.getMinutes() + startMinute);
//             endTime = new Date(date.getFullYear(), date.getMonth(), date.getDate() + endDay, 0, date.getMinutes() + endMinute);
//             events.push({
//                 title: 'Event - ' + i,
//                 startTime: startTime,
//                 endTime: endTime,
//                 allDay: false
//             });
//         }
//     }
//     return events;
// }

// onRangeChanged(ev) {
//     console.log('range changed: startTime: ' + ev.startTime + ', endTime: ' + ev.endTime);
// }

// markDisabled = (date:Date) => {
//     var current = new Date();
//     current.setHours(0, 0, 0);
//     return date < current;
// };
// test(e){
// console.log(e)
// }
// ngOnInit() {
// this.loadEvents()
// }
