import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { NavController, NavParams } from '@ionic/angular';
import { ForgotPasswordService } from 'src/app/services/forgot-password.service';
import straightlines_io_apis from 'src/app/json/apis.json';
import { LoginService } from 'src/app/services/login.service';
@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.page.html',
  styleUrls: ['./reset-password.page.scss'],
})
export class ResetPasswordPage implements OnInit {
  errorMsg: any;
  forgotPassword: FormGroup;
  hidePassword=true
  hideConfirmPassword=true
  classId=0
  confirmClassId=0
  emailValid
  url_token
  email_id_for_reset_password
  token_for_reset_password
  email_is_verfied: any;
  // userDetails: import("v:/Mercurius/straightline-io/src/app/model/checkUserDetails").CheckUserDetails[];
  constructor(public navCtrl: NavController,
    private fb:FormBuilder,
    private actRoute: ActivatedRoute,
    private loginSer:LoginService,
    private forgot_pass:ForgotPasswordService,) {

    }

  ngOnInit() {
    this.actRoute.paramMap.subscribe((params: ParamMap)=> {
      this.email_id_for_reset_password= (params.get('_email'))
      // this.email_id_for_reset_password="vrushang.patel@mercuriusinc.com"
      this.token_for_reset_password= (params.get('_code'))
      // console.log(this.email_id_for_reset_password);
      // console.log(this.token_for_reset_password);


    })
this.getUserData(this.email_id_for_reset_password)
// console.log(this.userDetails)
    this.forgotPassword = this.fb.group({
      email:new FormControl(this.email_id_for_reset_password,Validators.compose([Validators.required])),
      password:new FormControl('',Validators.compose([Validators.required,Validators.minLength(2),Validators.maxLength(64)])),
      confirm_password:new FormControl(),
    }, {
      validator: this.ConfirmedValidator('password', 'confirm_password')
    })


    this.forgot_pass.emailVerify(this.email_id_for_reset_password).subscribe(
      async (response)=>{
        // console.log(response)

      },
      (error: any)=>{

console.log(error)
        this.errorMsg=error.error.text;
        this.url_token=this.errorMsg
        // console.log(this.url_token)
        // console.log(String(this.url_token).substr(0,45))
        if(String(this.url_token)=="Invalid email id."){
          this.emailValid=true
          // console.log(this.url_token)
        }
        // if(String(this.url_token).substr(0,47)=="http://18.119.62.157:2020/reset-password?token="){

          if(String(this.url_token).substr(0,45)=="http://52.14.8.217:2020/reset-password?token="){
        // if(String(this.url_token).substr(0,45)=="http://3.13.254.87:2020/reset-password?token="){
          this.emailValid=false
          // console.log(this.emailValid)
          // console.log(this.url_token)
        }
      },
      async () => {

      }
    )
  }
  getUserData(email){
    var getUserData={"username":email}
    this.loginSer.getUserAllDetails(getUserData).subscribe(
       (respons)=>{
        // console.log(respons)
        // this.userDetails=
        if(respons){
        this.forgot_pass.verifyEmailForFP(this.token_for_reset_password).subscribe(
          async (res)=>{
            // console.log(res)
            this.email_is_verfied=res;
          if(this.email_is_verfied==false){
            this.navCtrl.navigateBack([straightlines_io_apis.apis.login_api])
          }
          },
          (error: any)=>{this.errorMsg=error;
          },
          async () => {

          }
        )}


          },
            (error: any)=>{this.errorMsg=error
            console.log(this.errorMsg)},
            ()=>{
            }
            );

  }
  ConfirmedValidator(controlName: string, matchingControlName: string){
    return (formGroup: FormGroup) => {
        const control = formGroup.controls[controlName];
        const matchingControl = formGroup.controls[matchingControlName];
        if (matchingControl.errors && !matchingControl.errors.confirmedValidator) {
            return;
        }
        if (control.value !== matchingControl.value) {
            matchingControl.setErrors({ confirmedValidator: true });
        } else {
            matchingControl.setErrors(null);
        }
    }
}
  get email(){
    return this.forgotPassword.get('email')
  }



  get password(){
    return this.forgotPassword.get('password')
  }
  get confirm_password(){
    return this.forgotPassword.get('confirm_password')
  }
  focusOut(){
// console.log(this.forgotPassword.value)
// console.log(this.forgotPassword.value.email)
  var email=this.forgotPassword.value.email
  this.forgot_pass.emailVerify(email).subscribe(
    async (response)=>{
      // console.log(response)
    },
    (error: any)=>{


      this.errorMsg=error.error.text;
      this.url_token=this.errorMsg
      // console.log(this.url_token)
      console.log(String(this.url_token).substr(0,45))
      if(String(this.url_token)=="Invalid email id."){
        this.emailValid=true
        // console.log(this.url_token)
      }
      if(String(this.url_token).substr(0,45)=="http://52.14.8.217:2020/reset-password?token="){
        this.emailValid=false
        // console.log(this.emailValid)
        // console.log(this.url_token)
      }
    },
    async () => {

    }
  )
}
changeEmailID(){
  if(this.emailValid==true){
    return this.emailValid=false
  }
}
passwordChanged(pass){

  // this.navCtrl.navigateForward('password-changed-message')
}
resetPass(pass){
  // console.log(this.forgotPassword.value.password)

this.forgot_pass.updatePass(this.url_token,this.forgotPassword.value.password).subscribe(
  async (response)=>{
    // console.log(response)
  },
  (error: any)=>{this.errorMsg=error;
    // console.log(this.errorMsg)
  },
  async () => {

  }
)
this.navCtrl.navigateForward('password-changed-message')
}
confirm_Password(){
  if(this.hideConfirmPassword==true){
     this.hideConfirmPassword=false,this.confirmClassId=1
  }else{
     this.hideConfirmPassword=true,this.confirmClassId=0
  }
  return this.hideConfirmPassword,this.confirmClassId
}
passWord(){
  if(this.hidePassword==true){
   return  this.hidePassword=false,this.classId=1
  }else{
    return this.hidePassword=true,this.classId=0
  }

}
passWordClass(cId){
  if(0==cId ) {
    return 'password  form-control app-font-primary-color ion-no-margin ion-no-padding';
  }else if(0!=cId ){
    return 'form-control app-font-primary-color ion-no-margin ion-no-padding';
  }

}
confirmPassWordClass(cId){
  if(0==cId ) {
    return 'password  form-control app-font-primary-color ion-no-margin ion-no-padding';
  }else if(0!=cId ){
    return 'form-control app-font-primary-color ion-no-margin ion-no-padding';
  }

}
}
