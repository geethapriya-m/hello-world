import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { AlertController, NavController } from '@ionic/angular';
import { EmailValidationService } from 'src/app/services/email-validation.service';
import { RegistrationService } from 'src/app/services/registration.service';
import Swal from 'sweetalert2';
import straightlines_io_apis from 'src/app/json/apis.json';
import { PhoneVerificationService } from 'src/app/services/phone-verification/phone-verification.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {
  registrationForm: FormGroup;
  errorMsg: any;
emailValid
phoneValid
hidePassword=true
hideConfirmPassword=true
classId=0
confirmClassId=0
  emailMessage: any;
  phoneMessage: any;
constructor(public navCtrl: NavController,
    private fb:FormBuilder,
    public alertCtrl: AlertController,
    private register:RegistrationService,
    private PV:PhoneVerificationService,
    private EV:EmailValidationService) { }

  ngOnInit() {
    this.registrationForm = this.fb.group({
      username:new FormControl(),
      fullname:new FormControl(),
      // phone:new FormControl('',Validators.compose([Validators.required,Validators.minLength(10),Validators.maxLength(10)])),
      // username:new FormControl('',Validators.compose([Validators.required,Validators.minLength(4),Validators.maxLength(8)])),
      // fullname:new FormControl('',Validators.compose([Validators.required,Validators.minLength(2),Validators.maxLength(64)])),
      phone:new FormControl('',Validators.compose([Validators.minLength(10),Validators.maxLength(10),Validators.pattern('^[0-9]*$')])),
      email:new FormControl('',Validators.compose([Validators.required,Validators.pattern('^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$'),Validators.minLength(6)])),
      password:new FormControl('',Validators.compose([Validators.required,Validators.minLength(2),Validators.maxLength(64)])),
      confirm_password:new FormControl(),
      facilityid:new FormControl('198'),
      // facilityid:new FormControl('21',Validators.compose([Validators.required])),
      // terms:[false, Validators.requiredTrue]
      // terms:[false, Validators.requiredTrue]
    }, {
      validator: this.ConfirmedValidator('password', 'confirm_password')
    })



  }

  get username(){
    return this.registrationForm.get('username')
  }

  get fullname(){
   return this.registrationForm.get('fullname')
 }

 get email(){
   return this.registrationForm.get('email')
 }

 get phone(){
   return this.registrationForm.get('phone')
 }

 get password(){
   return this.registrationForm.get('password')
 }
 get confirm_password(){
  return this.registrationForm.get('confirm_password')
}
 get facilityid(){
   return this.registrationForm.get('facilityid')
 }
  onSubmit(data){

    var registerData={
      "username":this.registrationForm.value.email,
      "password":this.registrationForm.value.password,

      "fullname":"",
      "email":"",
      "createdby":" ",
      "phone":this.registrationForm.value.phone,
      "facilityid":""

  }
  // console.log(registerData)
    this.register.registerNewUser(registerData).subscribe(
      async (response)=>{
        this.EV.emailVerification(this.registrationForm.value.email).subscribe(
          async (response)=>{


        Swal.fire({

          title: 'Success!',
          html: 'Your account is created!<br> A verification link has been sent to your email account.',
          icon: 'success',
          showCancelButton: false,
          imageHeight:'250px',
          heightAuto:false,
          confirmButtonText: 'Continue',
          confirmButtonColor: '#57818A',

        }).then((result) => {
          this.registrationForm.reset()
          if (result.isConfirmed) {
            this.navCtrl.navigateForward('login')
            // console.log('Clicked Yes, File deleted!');
          }
        })
      },(error)=>{
        Swal.fire({

          title: 'Error!',
          html: 'Something went wrong. Please try again later.',
          icon: 'error',
          showCancelButton: false,
          imageHeight:'250px',
          heightAuto:false,
          // confirmButtonText: 'Continue',
          confirmButtonColor: '#FF0000',

        }).then((result) => {
          this.registrationForm.reset()
        })
      })
      },
      (error: any)=>{this.errorMsg=error;console.log(this.errorMsg)
        Swal.fire({

          title: 'Error!',
          html: 'Something went wrong. Please try again later.',
          icon: 'error',
          showCancelButton: false,
          imageHeight:'250px',
          heightAuto:false,
          // confirmButtonText: 'Continue',
          confirmButtonColor: '#FF0000',

        }).then((result) => {
          this.registrationForm.reset()
        })},
      async () => {

      }
    )
  }
  test(){
    // Swal.fire('Congrats!', 'Your account is created!', 'success')
    Swal.fire({
      title: 'Success!',



      html: 'Your account is created!<br> A verification link has been sent to your email account.',
      icon: 'success',
      showCancelButton: false,
      imageHeight:'250px',
      heightAuto:false,
      confirmButtonText: 'Continue',
      confirmButtonColor: '#57818A',
      // buttonsStyling:false,
      // button
    }).then((result) => {
      if (result.isConfirmed) {
        // console.log('Clicked Yes, File deleted!');
      }
    })
    // console.log(this.registrationForm.value)
  }
  ConfirmedValidator(controlName: string, matchingControlName: string){
    return (formGroup: FormGroup) => {
        const control = formGroup.controls[controlName];
        const matchingControl = formGroup.controls[matchingControlName];
        if (matchingControl.errors && !matchingControl.errors.confirmedValidator) {
            return;
        }
        if (control.value !== matchingControl.value) {
            matchingControl.setErrors({ confirmedValidator: true });
        } else {
            matchingControl.setErrors(null);
        }
    }
}
  emailFocusOut(){
    var email={'username':this.registrationForm.value.email}
    this.EV.emailValidator(email).subscribe(
       (response)=>{
         this.emailMessage=response
        console.log(this.emailMessage.message)
        if(String(this.emailMessage.message)==="It's a new Email!"){

          return  this.emailValid=false
        }else if(String(this.emailMessage.message)==="Email Exists!" ){
          return  this.emailValid=true
        }
      })
  }
  phoneFocusOut(){
    var phone={'phone':this.registrationForm.value.phone}
    if(this.registrationForm.value.phone!==null || this.registrationForm.value.phone!==''){
      this.PV.phoneValidator(phone).subscribe(
        async (response)=>{
          this.phoneMessage=response
          if( String(this.phoneMessage.message)==="Phone no is null or empty" ){
            // console.log(phone)
            if(this.registrationForm.value.phone==null || this.registrationForm.value.phone==''){
              return  this.phoneValid=false
            }

          }else if(String(this.phoneMessage.message)==="Phone number Exists!"){
            // console.log(phone)
            return  this.phoneValid=false
          }
        })

    }

  }
  signIn(){
    this.navCtrl.navigateBack(straightlines_io_apis.apis.login_api)
  }
  confirm_Password(){
    if(this.hideConfirmPassword==true){
       this.hideConfirmPassword=false,this.confirmClassId=1
    }else{
       this.hideConfirmPassword=true,this.confirmClassId=0
    }
    return this.hideConfirmPassword,this.confirmClassId
  }
  passWord(){
    if(this.hidePassword==true){
     return  this.hidePassword=false,this.classId=1
    }else{
      return this.hidePassword=true,this.classId=0
    }

  }
  passWordClass(cId){
    if(0==cId ) {
      return 'password  form-control app-font-primary-color ion-no-margin ion-no-padding';
    }else if(0!=cId ){
      return 'form-control app-font-primary-color ion-no-margin ion-no-padding';
    }

  }
  confirmPassWordClass(cId){
    if(0==cId ) {
      return 'password  form-control app-font-primary-color ion-no-margin ion-no-padding';
    }else if(0!=cId ){
      return 'form-control app-font-primary-color ion-no-margin ion-no-padding';
    }

  }
}
