import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy, NavParams } from '@ionic/angular';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

import { PdfViewerModule } from 'ng2-pdf-viewer';
import { HttpClientModule } from '@angular/common/http';
import { ScreenOrientation } from '@ionic-native/screen-orientation/ngx';
import { ChartsModule } from 'ng2-charts';
import {MatDividerModule} from '@angular/material/divider';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatSelectModule} from '@angular/material/select';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CommonModule } from '@angular/common';
import { GeneratedSchedulesComponent } from './dashboard/generated_schedule/generated-schedules/generated-schedules.component';
import { ScheduleOneComponent } from './dashboard/generated_schedule/schedule/schedule-one/schedule-one.component';
import { ScheduleThreeComponent } from './dashboard/generated_schedule/schedule/schedule-three/schedule-three.component';
import { ScheduleTwoComponent } from './dashboard/generated_schedule/schedule/schedule-two/schedule-two.component';
import { BlankFooterComponent } from './dashboard/nav-bar-footer/footer/blank-footer/blank-footer.component';
import { FooterPageModule } from './dashboard/nav-bar-footer/footer/footer.module';
import { FooterComponent } from './dashboard/nav-bar-footer/footer/footer/footer.component';
import { BlankHeaderComponent } from './dashboard/nav-bar-footer/nav-bar/blank-header/blank-header.component';
import { NavBarPageModule } from './dashboard/nav-bar-footer/nav-bar/nav-bar.module';
import { EnterWorkLoadComponent } from './dashboard/work_load_data/enter-work-load/enter-work-load.component';
import { STLinesDashboardComponent } from './dashboard/s-t-lines-dashboard/s-t-lines-dashboard.component';
import { SelectOptionForWorkloadComponent } from './dashboard/select-option-for-workload/select-option-for-workload.component';
import { BiddingDashboardComponent } from './dashboard/bidding-dashboard/bidding-dashboard.component';
import { ManageBidScheduleComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/manage-bid-schedule.component';
import { ManageBidDashboardComponent } from './dashboard/bidding-dashboard/manage-bid-dashboard/manage-bid-dashboard.component';
import { MatIconModule } from '@angular/material/icon';
import { SetUpBidParametersComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/set-up-bid-parameters/set-up-bid-parameters.component';
import { SetUpBidParametersPartOneComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/set-up-bid-parameters/set-up-bid-parameters-part-one/set-up-bid-parameters-part-one.component';
import { SetUpBidParametersPartTwoComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/set-up-bid-parameters/set-up-bid-parameters-part-two/set-up-bid-parameters-part-two.component';
import { SetUpBidParametersPartThreeComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/set-up-bid-parameters/set-up-bid-parameters-part-three/set-up-bid-parameters-part-three.component';
import { SetUpBidParametersSectionTwoComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/set-up-bid-parameters/set-up-bid-parameters-part-two/set-up-bid-parameters-section-two/set-up-bid-parameters-section-two.component';
import { MyBiddingDashboardComponent } from './dashboard/bidding-dashboard/my-bidding-dashboard/my-bidding-dashboard.component';
import { MyBiddingStepOneShiftLineComponent } from './dashboard/bidding-dashboard/my-bidding-dashboard/my-bidding-step-one-shift-line/my-bidding-step-one-shift-line.component';
import { SelectShiftLineForBiddingComponent } from './dashboard/bidding-dashboard/my-bidding-dashboard/select-shift-line-for-bidding/select-shift-line-for-bidding.component';
import { ViewBidShiftlinesComponent } from './dashboard/bidding-dashboard/my-bidding-dashboard/view-bid-shiftlines/view-bid-shiftlines.component';
import { ManageShiftLineSchedulesComponent } from './dashboard/manage-shift-line-schedules/manage-shift-line-schedules.component';
import { GeneratedScheduleListComponent } from './dashboard/manage-shift-line-schedules/generated-schedule-list/generated-schedule-list.component';
import { PartOneStepTwoComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/set-up-bid-parameters/set-up-bid-parameters-part-one/part-one-step-two/part-one-step-two.component';
import { SaveScheduleComponent } from './dashboard/generated_schedule/generated-schedules/save-schedule/save-schedule.component';
import { EditScheduleComponent } from './dashboard/manage-shift-line-schedules/edit-schedule/edit-schedule.component';
import { EditShiftLineScheduleComponent } from './dashboard/manage-shift-line-schedules/edit-schedule/edit-shift-line-schedule/edit-shift-line-schedule.component';
import { ImportExcelSheetForScheduleComponent } from './dashboard/select-option-for-workload/import-excel-sheet-for-schedule/import-excel-sheet-for-schedule.component';
import { MidSummaryComponent } from './dashboard/manage-shift-line-schedules/edit-schedule/summary/mid-summary/mid-summary.component';
import { ChartComponent } from './dashboard/manage-shift-line-schedules/edit-schedule/summary/chart/chart.component';
import { DatePickerModule } from 'ionic4-date-picker';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import {DragDropModule} from '@angular/cdk/drag-drop';
import { NgCalendarModule  } from 'ionic2-calendar';
import { CalendarTestComponent } from './calendar-test/calendar-test.component';
import { CalendarTest1Component } from './calendar-test1/calendar-test1.component';
import { CalendarTest2Component } from './calendar-test2/calendar-test2.component';
import { AddNewEmployeeComponent } from './dashboard/add-new-employee/add-new-employee.component';
import { CustomDatePipe } from './services/manage-bid-schedule/custom-pipe/custom-date.pipe';
import { SelectEmployeeAlertComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/set-up-bid-parameters/set-up-bid-parameters-part-one/select-employee-alert/select-employee-alert.component';
import { CustomSchedulePopupComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/set-up-bid-parameters/set-up-bid-parameters-part-one/custom-schedule-popup/custom-schedule-popup.component';
import { SetUpBidParametersSummaryComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/set-up-bid-parameters/set-up-bid-parameters-summary/set-up-bid-parameters-summary.component';
import { SelectedEmployeeModalComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/selected-employee-modal/selected-employee-modal.component';
import { SelectedShiftlineScheduleModalComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/selected-shiftline-schedule-modal/selected-shiftline-schedule-modal.component';
import { ViewSeniorityListComponent } from './dashboard/bidding-dashboard/my-bidding-dashboard/view-seniority-list/view-seniority-list.component';

@NgModule({
  declarations: [AppComponent,
    EnterWorkLoadComponent,
    DashboardComponent,
    GeneratedSchedulesComponent,
    ScheduleTwoComponent,
    ScheduleThreeComponent,
    ScheduleOneComponent,
    STLinesDashboardComponent,
    SelectOptionForWorkloadComponent,
    BiddingDashboardComponent,
    ManageBidScheduleComponent,
    ManageBidDashboardComponent,
    SetUpBidParametersComponent,
    SetUpBidParametersPartOneComponent,
    SetUpBidParametersPartTwoComponent,
    SetUpBidParametersSectionTwoComponent,
    SetUpBidParametersPartThreeComponent,
    MyBiddingDashboardComponent,
    MyBiddingStepOneShiftLineComponent,
    SelectOptionForWorkloadComponent,
    SelectShiftLineForBiddingComponent,
    ViewBidShiftlinesComponent,
    ManageShiftLineSchedulesComponent,
    GeneratedScheduleListComponent,
    PartOneStepTwoComponent,
    SaveScheduleComponent,
    EditScheduleComponent,
    EditShiftLineScheduleComponent,
    MidSummaryComponent,
    ImportExcelSheetForScheduleComponent,
    ChartComponent,
    CalendarTestComponent,
    CalendarTest1Component,
    CalendarTest2Component,
    AddNewEmployeeComponent,
    CustomDatePipe,
    SelectEmployeeAlertComponent,
    CustomSchedulePopupComponent,
    SetUpBidParametersSummaryComponent,
    SelectedEmployeeModalComponent,
    SelectedShiftlineScheduleModalComponent,
    ViewSeniorityListComponent

  ],
  entryComponents: [],
  imports: [BrowserModule,
    FormsModule,

    CommonModule,
    HttpClientModule,
    MatDialogModule,
    IonicModule.forRoot(),
    AppRoutingModule,
    MatNativeDateModule ,
    NgCalendarModule,
    BrowserAnimationsModule,
    PdfViewerModule,
    MatDividerModule,
    MatIconModule,
    ChartsModule,
    ReactiveFormsModule,
    FooterPageModule,
    NavBarPageModule,
    MatDatepickerModule,
    DatePickerModule,
    MatSelectModule,
    DragDropModule
  ],
  providers: [ScreenOrientation,
    BlankHeaderComponent,
    FooterComponent,
    MatNativeDateModule ,
    BlankFooterComponent,
    NgCalendarModule,

    NavParams,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }],
  bootstrap: [AppComponent],
  schemas:      [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule {}
