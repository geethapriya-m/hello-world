
import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ActionSheetController, AlertController, IonSlides, LoadingController, ModalController, NavController, NavParams, PopoverController } from '@ionic/angular';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';
import straightlines_io_apis from 'src/app/json/apis.json';
// import  GeneratedScheduleData  from "V:/New folder (2)/work/stworks/Generated_Schedule.json";
import { HeaderTitleService } from 'src/app/dashboard/nav-bar-footer/header-title.service';
import { ViewSummaryDayCategoryWisePage } from 'src/app/dashboard/generated_schedule/summary/view-summary-day-category-wise/view-summary-day-category-wise.page';
import { ViewTotalEveShiftLinesDataPage } from 'src/app/dashboard/generated_schedule/summary/view-total-eve-shift-lines-data/view-total-eve-shift-lines-data.page';
import { ViewTotalDayShiftLinesDataPage } from 'src/app/dashboard/generated_schedule/summary/view-total-day-shift-lines-data/view-total-day-shift-lines-data.page';
import { ViewTotalMidShiftLinesDataPage } from 'src/app/dashboard/generated_schedule/summary/view-total-mid-shift-lines-data/view-total-mid-shift-lines-data.page';
import { AddNewShiftLinePage } from 'src/app/dashboard/generated_schedule/add-edit-shift-lines/add-new-shift-line/add-new-shift-line.page';
import { SaveScheduleComponent } from './save-schedule/save-schedule.component';

@Component({
  selector: 'app-generated-schedules',
  templateUrl: './generated-schedules.component.html',
  styleUrls: ['./generated-schedules.component.scss'],
})
export class GeneratedSchedulesComponent implements OnInit {

  @ViewChild(IonSlides) slides: IonSlides;
  // generatedScheduleData=GeneratedScheduleData
  // scheduleShift=scheduleShiftLines
  title = 'angular-app';
  fileName= 'Schedule Data.xlsx';
  hideSplitShiftMidDay=false
  hideSplitShiftDayEve=false
  hideSplitShiftEveMid=false
  result1:any=[];
  result2:any=[];
  gData:any=[]
  totalShiftLine:any=[]
  ishidden = true;
  countSunSat=0;countSunMon=0;countMonTue=0;countTueWed=0;countWedThu=0;countThuFri=0;countFriSat=0;
  SunSat=0;SunMon=0;MonTue=0;TueWed=0;WedThu=0;ThuFri=0;FriSat=0;
  coun: any;
  showRDOinfo=false
  excelHeaders:string[] = ["Id","Mon","Tue","Wed","Thu","Fri","Sat"];
  templateToExcel:string[][] = [this.excelHeaders,[]];
  totalCount: any;
  totalDefaultScheduleLine=0
  scheduleShift: any []=[]
  afterdeleteShiftLines:any []=[]
  deleteShiftLines:any []=[]
  defaultscheduleShift: any []=[]
  defaultScheduleShift: any []=[]
  gDatasun: any;
  gDatamon: any;
  gDatatue: any;
  gDatawed: any;
  gDatathu: any;
  gDatafri: any;
  gDatasat: any;
  gDataPattern: any;
  generatedComparisonData: any []=[]
  generatedShiftLines:any []=[]
  generatedScheduleData:any []=[]
  requiredEmpData:any
  generatedEmpData
  sun:any;SunDayRequired = [];SunDayGenerated = [];totalSundiff: any;totalSunGenerated: any;totalSunRequired: any;diffSunMid: any;diffSunDay: any;diffSunEve: any;diffSunMidDay: any;diffSunDayEve: any;diffSunEveMid: any;validSunMid: boolean;validSunDay: boolean;validSunEve: boolean;
  mon: any;MonDayRequired= [];MonDayGenerated= [];diffMonMid: any;diffMonDay: any;diffMonEve: any;totalMonRequired: any;totalMonGenerated: any;totalMondiff: any;diffMonMidDay: any;diffMonDayEve: any;diffMonEveMid: any;
  tue:any;TueDayRequired= [];TueDayGenerated= [];diffTueMid: any;diffTueDay: any;diffTueEve: any;totalTueRequired: any;totalTueGenerated: any;totalTuediff: any;diffTueMidDay: any;diffTueDayEve: any;diffTueEveMid: any;
  wed:any;WedDayRequired= [];WedDayGenerated= [];diffWedMid: any;diffWedDay: any;diffWedEve: any;totalWedRequired: any;totalWedGenerated: any;totalWeddiff: any;diffWedMidDay: any;diffWedDayEve: any;diffWedEveMid: any;
  thu:any;ThuDayRequired= [];ThuDayGenerated= [];diffThuMid: any;diffThuDay: any;diffThuEve: any;totalThuRequired: any;totalThuGenerated: any;totalThudiff: any;diffThuMidDay: any;diffThuDayEve: any;diffThuEveMid: any;
  fri:any;FriDayRequired= [];FriDayGenerated= [];diffFriMid: any;diffFriDay: any;diffFriEve: any;totalFriRequired: any;totalFriGenerated: any;totalFridiff: any;diffFriMidDay: any;diffFriDayEve: any;diffFriEveMid: any;
  sat:any;SatDayRequired= [];SatDayGenerated= [];diffSatMid: any;diffSatDay: any;diffSatEve: any;totalSatRequired: any;totalSatGenerated: any;totalSatdiff: any;diffSatMidDay: any;diffSatDayEve: any;diffSatEveMid: any;

  defaultSun: any;defaultSunDayRequired= [];defaultSunDayGenerated= [];defaultDiffSunMid: any;defaultDiffSunDay: any;defaultDiffSunEve: any;defaultTotalSunRequired: any;defaultTotalSunGenerated: any;defaultTotalSundiff: any;defaultDiffSunMidDay: any;defaultDiffSunDayEve: any;defaultDiffSunEveMid: any;
  defaultMon: any;defaultMonDayRequired= [];defaultMonDayGenerated= [];defaultDiffMonMid: any;defaultDiffMonDay: any;defaultDiffMonEve: any;defaultTotalMonRequired: any;defaultTotalMonGenerated: any;defaultTotalMondiff: any;defaultDiffMonMidDay: any;defaultDiffMonDayEve: any;defaultDiffMonEveMid: any;
  defaultTue: any;defaultTueDayRequired= [];defaultTueDayGenerated= [];defaultDiffTueMid: any;defaultDiffTueDay: any;defaultDiffTueEve: any;defaultTotalTueRequired: any;defaultTotalTueGenerated: any;defaultTotalTuediff: any;defaultDiffTueMidDay: any;defaultDiffTueDayEve: any;defaultDiffTueEveMid: any;
  defaultWed: any;defaultWedDayRequired= [];defaultWedDayGenerated= [];defaultDiffWedMid: any;defaultDiffWedDay: any;defaultDiffWedEve: any;defaultTotalWedRequired: any;defaultTotalWedGenerated: any;defaultTotalWeddiff: any;defaultDiffWedMidDay: any;defaultDiffWedDayEve: any;defaultDiffWedEveMid: any;
  defaultThu: any;defaultThuDayRequired= [];defaultThuDayGenerated= [];defaultDiffThuMid: any;defaultDiffThuDay: any;defaultDiffThuEve: any;defaultTotalThuRequired: any;defaultTotalThuGenerated: any;defaultTotalThudiff: any;defaultDiffThuMidDay: any;defaultDiffThuDayEve: any;defaultDiffThuEveMid: any;
  defaultFri: any;defaultFriDayRequired= [];defaultFriDayGenerated= [];defaultDiffFriMid: any;defaultDiffFriDay: any;defaultDiffFriEve: any;defaultTotalFriRequired: any;defaultTotalFriGenerated: any;defaultTotalFridiff: any;defaultDiffFriMidDay: any;defaultDiffFriDayEve: any;defaultDiffFriEveMid: any;
  defaultSat: any;defaultSatDayRequired= [];defaultSatDayGenerated= [];defaultDiffSatMid: any;defaultDiffSatDay: any;defaultDiffSatEve: any;defaultTotalSatRequired: any;defaultTotalSatGenerated: any;defaultTotalSatdiff: any;defaultDiffSatMidDay: any;defaultDiffSatDayEve: any;defaultDiffSatEveMid: any;

  exportData=[] as any
  exportScheduleData=[] as any
  sunDay=[] as any
  defscheduleShift: any;
  sundAy= [] as any;mondAy= [] as any;tuedAy= [] as any;weddAy= [] as any;thudAy= [] as any;fridAy= [] as any;satdAy= [] as any;
  def_sundAy= [] as any;def_mondAy= [] as any;def_tuedAy= [] as any;def_weddAy= [] as any;def_thudAy= [] as any;def_fridAy= [] as any;def_satdAy= [] as any;
  req: number=0;
  all_Schedule=[]
  // mon_1=0;mon_2=0;mon_3=0;mon_4=0;mon_5=0;
  // tue_1=0;tue_2=0;tue_3=0;tue_4=0;tue_5=0;
  // wed_1=0;wed_2=0;wed_3=0;wed_4=0;wed_5=0;
  // thu_1=0;thu_2=0;thu_3=0;thu_4=0;thu_5=0;
  // fri_1=0;fri_2=0;fri_3=0;fri_4=0;fri_5=0;
  // sat_1=0;sat_2=0;sat_3=0;sat_4=0;sat_5=0;
  // sun_1=0;sun_2=0;sun_3=0;sun_4=0;sun_5=0;
  // def_mon_1=0;def_mon_2=0;def_mon_3=0;def_mon_4=0;def_mon_5=0;
  // def_tue_1=0;def_tue_2=0;def_tue_3=0;def_tue_4=0;def_tue_5=0;
  // def_wed_1=0;def_wed_2=0;def_wed_3=0;def_wed_4=0;def_wed_5=0;
  // def_thu_1=0;def_thu_2=0;def_thu_3=0;def_thu_4=0;def_thu_5=0;
  // def_fri_1=0;def_fri_2=0;def_fri_3=0;def_fri_4=0;def_fri_5=0;
  // def_sat_1=0;def_sat_2=0;def_sat_3=0;def_sat_4=0;def_sat_5=0;
  // def_sun_1=0;def_sun_2=0;def_sun_3=0;def_sun_4=0;def_sun_5=0;
  sun_mid: number=0;sun_day: number=0;sun_eve: number=0;sun_mid_day: number=0;sun_day_eve: number=0;sun_eve_mid: number=0;
  mon_mid: number=0;mon_day: number=0;mon_eve: number=0;mon_mid_day: number=0;mon_day_eve: number=0;mon_eve_mid: number=0;
  tue_mid: number=0;tue_day: number=0;tue_eve: number=0;tue_mid_day: number=0;tue_day_eve: number=0;tue_eve_mid: number=0;
  wed_mid: number=0;wed_day: number=0;wed_eve: number=0;wed_mid_day: number=0;wed_day_eve: number=0;wed_eve_mid: number=0;
  thu_mid: number=0;thu_day: number=0;thu_eve: number=0;thu_mid_day: number=0;thu_day_eve: number=0;thu_eve_mid: number=0;
  fri_mid: number=0;fri_day: number=0;fri_eve: number=0;fri_mid_day: number=0;fri_day_eve: number=0;fri_eve_mid: number=0;
  sat_mid: number=0;sat_day: number=0;sat_eve: number=0;sat_mid_day: number=0;sat_day_eve: number=0;sat_eve_mid: number=0;

  def_sun_mid: number=0;def_sun_day: number=0;def_sun_eve: number=0;def_sun_mid_day: number=0;def_sun_day_eve: number=0;def_sun_eve_mid: number=0;
  def_mon_mid: number=0;def_mon_day: number=0;def_mon_eve: number=0;def_mon_mid_day: number=0;def_mon_day_eve: number=0;def_mon_eve_mid: number=0;
  def_tue_mid: number=0;def_tue_day: number=0;def_tue_eve: number=0;def_tue_mid_day: number=0;def_tue_day_eve: number=0;def_tue_eve_mid: number=0;
  def_wed_mid: number=0;def_wed_day: number=0;def_wed_eve: number=0;def_wed_mid_day: number=0;def_wed_day_eve: number=0;def_wed_eve_mid: number=0;
  def_thu_mid: number=0;def_thu_day: number=0;def_thu_eve: number=0;def_thu_mid_day: number=0;def_thu_day_eve: number=0;def_thu_eve_mid: number=0;
  def_fri_mid: number=0;def_fri_day: number=0;def_fri_eve: number=0;def_fri_mid_day: number=0;def_fri_day_eve: number=0;def_fri_eve_mid: number=0;
  def_sat_mid: number=0;def_sat_day: number=0;def_sat_eve: number=0;def_sat_mid_day: number=0;def_sat_day_eve: number=0;def_sat_eve_mid: number=0;


schedule_id


  workLoadData: any;
  shift: any;
  defRequiredData: any;
  defGeneratedData: any;
  ReqVsGeneTotalData;ReqVsGeneMidData: any;ReqVsGeneDayData: any;ReqVsGeneEveData: any;ReqVsGeneMidDayData: any;ReqVsGeneDayEveData: any;ReqVsGeneEveMidData: any;dayTitleforExcel:any;
  req_shift_1_data;req_shift_2_data;req_shift_3_data;req_shift_4_data;req_shift_5_data;
  gen_shift_1_data;gen_shift_2_data;gen_shift_3_data;gen_shift_4_data;gen_shift_5_data;
  defReqVsGeneTotalData;defReqVsGeneMidData: any;defReqVsGeneDayData: any;defReqVsGeneEveData: any;defReqVsGeneMidDayData: any;defReqVsGeneDayEveData: any;defReqVsGeneEveMidData: any;
  def_gen_shift_1_data;def_gen_shift_2_data;def_gen_shift_3_data;def_gen_shift_4_data;def_gen_shift_5_data
  required_title: any;
  generated_title:any;
  required_vs_generated_title: any;
  customizeScheduleShiftLines=[] as any
  totalCustomizeShiftLine: any;
  customizeShiftData: any;
  testing: any;

  reqData=[] as any
  genData=[] as any
  defGenData=[] as any
  t: string;
  defaultValue=0
  da=[] as any
  updateDefscheduleShiftId: {};
  updatedDefScheduleShiftLines=[] as any
  def=[];defSun=[];defMon=[];defTue=[];defWed=[];defThu=[];defFri=[];defSat=[]
  customized=[];customizedSun=[];customizedMon=[];customizedTue=[];customizedWed=[];customizedThu=[];customizedFri=[];customizedSat=[]
  reqDataShiftTime=[];reqDataSun=[];reqDataMon=[];reqDataTue=[];reqDataWed=[];reqDataThu=[];reqDataFri=[];reqDataSat=[]
  reqvsgenDefDataShiftTime=[];reqvsgenDefDataSun=[];reqvsgenDefDataMon=[];reqvsgenDefDataTue=[];reqvsgenDefDataWed=[];reqvsgenDefDataThu=[];reqvsgenDefDataFri=[];reqvsgenDefDataSat=[]
  reqvsgenDataShiftTime=[];reqvsgenDataSun=[];reqvsgenDataMon=[];reqvsgenDataTue=[];reqvsgenDataWed=[];reqvsgenDataThu=[];reqvsgenDataFri=[];reqvsgenDataSat=[]
  focusShiftLine
  allShiftData: any;
  allShiftName: any[];

  midData=[] as any
 dayData= [] as any
 demo=[] as any
 diffDay_23_sun: number;
 diffDay_23_tue: number;
 diffDay_23_mon: number;
 diffDay_23_wed: number;
 diffDay_23_thu: number;
 diffDay_23_fri: number;
 diffDay_23_sat: number;
 summary_days:any []=[{"id":0,"day":"Sun"},{"id":1,"day":"Mon"},{"id":2,"day":"Tue"},{"id":3,"day":"Wed"},{"id":4,"day":"Thu"},{"id":5,"day":"Fri"},{"id":6,"day":"Sat"}]
 default_value=0
 hide_BL_rules_Labels=false
 addShiftData: any
 gShift: any;
 schedule_title
 schedule_length
 one_generated_schedule
 three_generated_schedule
 nextslide=true
 slideOption={
  shortSwipes:false,
  longSwipes:true,
  longSwipesRatio:0.5,
  initialSlide: 0,
  spaceBetween: 200,

 }
//  generated_schedule_3=true
  // HighlightRow : Number;
  // ClickedRow:any;
  constructor(public modalCtrl: ModalController,
              private route:Router,
              public alertCtrl: AlertController,
              public loadingController: LoadingController,
              public popoverController: PopoverController,
              private headerTitleService: HeaderTitleService,
              private router: ActivatedRoute,public navParams: NavParams,
              public navCtrl: NavController,
              public actionsheetCtrl: ActionSheetController,
              ) {

          this.schedule_id=0

  }
  // ngAfterViewInit() {
  //   this.slides.lockSwipes(this.nextslide);

  // }

   ngOnInit() {
    this.headerTitleService.setTitle('');
    this.headerTitleService.setDefaultHeader(true)

if(straightlines_io_apis.apis.generated_schedule===String(this.route.url).substr(1)){
  this.headerTitleService.setForwardUrl(null);
  this.headerTitleService.setBackUrl(straightlines_io_apis.apis.enter_Work_load);
}else{
  this.headerTitleService.setBackUrl(straightlines_io_apis.apis.enter_Work_load_api);
  this.headerTitleService.setForwardUrl(null);
}

this.exportData=[]
this.customizeShiftData=[]
     this.customizeScheduleShiftLines=[]
this.defGeneratedData=JSON.parse(localStorage.getItem('requiredEmpData'))
this.defRequiredData=JSON.parse(localStorage.getItem('requiredEmpData'))
this.generatedEmpData=JSON.parse(localStorage.getItem('requiredEmpData'))
this.requiredEmpData=JSON.parse(localStorage.getItem('requiredEmpData'))
this.scheduleShift=JSON.parse(localStorage.getItem('customizedScheduleShiftLine'))
this.defscheduleShift=JSON.parse(localStorage.getItem('defaultScheduleShiftLine'))
// this.workLoadData=JSON.parse(localStorage.getItem('workLoadData'))
this.focusShiftLine=JSON.parse(localStorage.getItem('focusShiftLine'))
this.allShiftData=  JSON.parse(localStorage.getItem('allShiftRequiredData'))
// console.log(this.focusShiftLine)
// console.log(this.defRequiredData)
// console.log(this.defGeneratedData)
// console.log(this.scheduleShift)
if(this.scheduleShift.length<2){
   this.one_generated_schedule=true,this.three_generated_schedule=false
   this.schedule_title='Schedule Generated !'
}
if(this.scheduleShift.length>2){
  this.schedule_title='3 - Possible Schedules Generated !'
   this.one_generated_schedule=false,this.three_generated_schedule=true
   this.slideOption={
    shortSwipes:false,
    longSwipes:true,
    longSwipesRatio:0.5,
    initialSlide: this.focusShiftLine.schedule_id,
    spaceBetween: 150
   }
}
this.schedule_length=this.scheduleShift.length
for(var i=0;i<this.allShiftData.length;i++){
  if( Number(this.allShiftData[i].shiftCategory)==4){
     this.hideSplitShiftMidDay=true
  }
  else if( Number(this.allShiftData[i].shiftCategory)==5){
    this.hideSplitShiftDayEve=true
  }
  else if( Number(this.allShiftData[i].shiftCategory)==6){
     this.hideSplitShiftEveMid=true
  }
}

this.allShiftName=[]
this.allShiftName.push({"shiftName":'X',"shiftCategory":'X'})
for(var i=0;i<this.allShiftData.length;i++){
  this.allShiftName.push({"shiftName":this.allShiftData[i].shiftName,"shiftCategory":this.allShiftData[i].shiftCategory,"shiftTime":this.allShiftData[i].startTime})
}




this.shift=['M',6,7,1,3]
this.defscheduleShift=this.defscheduleShift[this.schedule_id]
this.scheduleShift=this.scheduleShift[this.schedule_id]
// console.log(this.defscheduleShift)
// console.log(this.scheduleShift)
this.updatedDefScheduleShiftLines=[]
for(var i=0;i<this.defscheduleShift.length;i++){
  this.updateDefscheduleShiftId=[this.defscheduleShift[i].id+1,this.defscheduleShift[i].Sun,this.defscheduleShift[i].Mon,this.defscheduleShift[i].Tue,this.defscheduleShift[i].Wed,this.defscheduleShift[i].Thu,this.defscheduleShift[i].Fri,this.defscheduleShift[i].Sat,this.defscheduleShift[i].Pattern]
  this.updatedDefScheduleShiftLines.push(this.updateDefscheduleShiftId)
}
this.customizeScheduleShiftLines=[]
for(var i=0;i<this.scheduleShift.length;i++){
  if(this.scheduleShift[i]?.SL  == 'SS' || this.scheduleShift[i]?.SL  == 'SS-A'){
    if(this.scheduleShift[i]?.SL  == 'SS-A'){
      this.customizeShiftData=['SS'+(this.scheduleShift[i].id+ + + 1 )+'-A',this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
    }
    else if(this.scheduleShift[i]?.SL  == 'SS'){
      this.customizeShiftData=['SS'+(this.scheduleShift[i].id+ + + 1 ),this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
    }
  }
  else if(this.scheduleShift[i]?.SL  == 'SM' || this.scheduleShift[i]?.SL  == 'SM-A'){
    if(this.scheduleShift[i]?.SL  == 'SM-A'){
      this.customizeShiftData=['SM'+(this.scheduleShift[i].id+ + + 1 )+'-A',this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
      // console.log(this.gData)
    }
    else if(this.scheduleShift[i]?.SL  == 'SM'){
      this.customizeShiftData=['SM'+(this.scheduleShift[i].id+ + + 1 ),this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
    // console.log(this.gData)
    }
  }
  if(this.scheduleShift[i]?.SL  == 'MT' || this.scheduleShift[i]?.SL  == 'MT-A'){
    if(this.scheduleShift[i]?.SL  == 'MT-A'){
      this.customizeShiftData=['MT'+(this.scheduleShift[i].id+ + + 1 )+'-A',this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
      // console.log(this.gData)
    }
    else if(this.scheduleShift[i]?.SL  == 'MT'){
      this.customizeShiftData=['MT'+(this.scheduleShift[i].id+ + + 1 ),this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
    // console.log(this.gData)
    }
  }
  if(this.scheduleShift[i]?.SL  == 'TW' || this.scheduleShift[i]?.SL  == 'TW-A'){
    if(this.scheduleShift[i]?.SL  == 'TW-A'){
      this.customizeShiftData=['TW'+(this.scheduleShift[i].id+ + + 1 )+'-A',this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
      // console.log(this.gData)
    }
    else if(this.scheduleShift[i]?.SL  == 'TW'){
      this.customizeShiftData=['TW'+(this.scheduleShift[i].id+ + + 1 ),this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
    // console.log(this.gData)
    }
  }
  if(this.scheduleShift[i]?.SL  == 'WT' || this.scheduleShift[i]?.SL  == 'WT-A'){
    if(this.scheduleShift[i]?.SL  == 'WT-A'){
      this.customizeShiftData=['WT'+(this.scheduleShift[i].id+ + + 1 )+'-A',this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
      // console.log(this.gData)
    }
    else if(this.scheduleShift[i]?.SL  == 'WT'){
      this.customizeShiftData=['WT'+(this.scheduleShift[i].id+ + + 1 ),this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
    // console.log(this.gData)
    }
  }
  if(this.scheduleShift[i]?.SL  == 'TF' || this.scheduleShift[i]?.SL  == 'TF-A'){
    if(this.scheduleShift[i]?.SL  == 'TF-A'){
      this.customizeShiftData=['TF'+(this.scheduleShift[i].id+ + + 1 )+'-A',this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
      // console.log(this.gData)
    }
    else if(this.scheduleShift[i]?.SL  == 'TF'){
      this.customizeShiftData=['TF'+(this.scheduleShift[i].id+ + + 1 ),this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
    // console.log(this.gData)
    }
  }
  if(this.scheduleShift[i]?.SL  == 'FS' || this.scheduleShift[i]?.SL  == 'FS-A'){
    if(this.scheduleShift[i]?.SL  == 'FS-A'){
      this.customizeShiftData=['FS'+(this.scheduleShift[i].id+ + + 1 )+'-A',this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
      // console.log(this.gData)
    }
    else if(this.scheduleShift[i]?.SL  == 'FS'){
      this.customizeShiftData=['FS'+(this.scheduleShift[i].id+ + + 1 ),this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
    // console.log(this.gData)
    }
  }
  this.customizeScheduleShiftLines.push(this.customizeShiftData)

}
this.sundAy=[]
this.mondAy=[]
this.tuedAy=[]
this.weddAy=[]
this.thudAy=[]
this.fridAy=[]
this.satdAy=[]
for(var i=0;i<this.scheduleShift.length;i++){
  this.sundAy.push(this.scheduleShift[i].Sun)
  this.mondAy.push(this.scheduleShift[i].Mon)
  this.tuedAy.push(this.scheduleShift[i].Tue)
  this.weddAy.push(this.scheduleShift[i].Wed)
  this.thudAy.push(this.scheduleShift[i].Thu)
  this.fridAy.push(this.scheduleShift[i].Fri)
  this.satdAy.push(this.scheduleShift[i].Sat)

}

const countsCustomizedSunDay = {};
this.sundAy.forEach(function (x) { countsCustomizedSunDay[x] = (countsCustomizedSunDay[x] || 0) + 1; });

const countsCustomizedMonDay = {};
this.mondAy.forEach(function (x) { countsCustomizedMonDay[x] = (countsCustomizedMonDay[x] || 0) + 1; });

const countsCustomizedTueDay = {}
this.tuedAy.forEach(function (x) { countsCustomizedTueDay[x] = (countsCustomizedTueDay[x] || 0) + 1; });

const countsCustomizedWedDay = {};
this.weddAy.forEach(function (x) { countsCustomizedWedDay[x] = (countsCustomizedWedDay[x] || 0) + 1; });

const countsCustomizedThuDay = {};
this.thudAy.forEach(function (x) { countsCustomizedThuDay[x] = (countsCustomizedThuDay[x] || 0) + 1; });

const countsCustomizedFriDay = {};
this.fridAy.forEach(function (x) { countsCustomizedFriDay[x] = (countsCustomizedFriDay[x] || 0) + 1; });

const countsCustomizedSatDay = {};
this.satdAy.forEach(function (x) { countsCustomizedSatDay[x] = (countsCustomizedSatDay[x] || 0) + 1; });

let arrSun = [];let arrMon = [];let arrTue = [];let arrWed = [];let arrThu = [];let arrFri = [];let arrSat = [];

Object.keys(countsCustomizedSunDay).map(function(key){
  arrSun.push({"shiftName":[key],"totalEmp":countsCustomizedSunDay[key]})
  return arrSun;
});

Object.keys(countsCustomizedMonDay).map(function(key){
  arrMon.push({"shiftName":[key],"totalEmp":countsCustomizedMonDay[key]})
  return arrMon;
});


Object.keys(countsCustomizedTueDay).map(function(key){
  arrTue.push({"shiftName":[key],"totalEmp":countsCustomizedTueDay[key]})
  return arrTue;
});
Object.keys(countsCustomizedWedDay).map(function(key){
  arrWed.push({"shiftName":[key],"totalEmp":countsCustomizedWedDay[key]})
  return arrWed;
});
Object.keys(countsCustomizedThuDay).map(function(key){
  arrThu.push({"shiftName":[key],"totalEmp":countsCustomizedThuDay[key]})
  return arrThu;
});
Object.keys(countsCustomizedFriDay).map(function(key){
  arrFri.push({"shiftName":[key],"totalEmp":countsCustomizedFriDay[key]})
  return arrFri;
});
Object.keys(countsCustomizedSatDay).map(function(key){
  arrSat.push({"shiftName":[key],"totalEmp":countsCustomizedSatDay[key]})
  return arrSat;
});
let sunTotalEmp=[];let monTotalEmp=[];let tueTotalEmp=[];let wedTotalEmp=[];let thuTotalEmp=[];let friTotalEmp=[];let satTotalEmp=[]
for(var i=0;i<this.allShiftName.length;i++){
  for(var j=0;j<arrSun.length;j++){
    // console.log(arrTue[j].start)
    if(this.allShiftName[i].shiftName==arrSun[j].shiftName)
    {
      if(arrSun[j].shiftName!='X')
      {
      sunTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory ,"totalEmp":arrSun[j].totalEmp})
      }
    }
  }
  for(var j=0;j<arrMon.length;j++){
    // console.log(arrTue[j].start)
    if(this.allShiftName[i].shiftName==arrMon[j].shiftName)
    {
      if(arrMon[j].shiftName!='X')
      {
        monTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrMon[j].totalEmp})
      }


    }
  }
  for(var j=0;j<arrTue.length;j++){
    // console.log(arrTue[j].start)
    if(this.allShiftName[i].shiftName==arrTue[j].shiftName)
    {
      if(arrTue[j].shiftName!='X')
      {
      tueTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrTue[j].totalEmp})
      }
    }
  }
  for(var j=0;j<arrWed.length;j++){
    // console.log(arrTue[j].start)
    if(this.allShiftName[i].shiftName==arrWed[j].shiftName)
    {
      if(arrWed[j].shiftName!='X')
      {
      wedTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrWed[j].totalEmp})
      }
    }
  }
  for(var j=0;j<arrThu.length;j++){
    // console.log(arrTue[j].start)
    if(this.allShiftName[i].shiftName==arrThu[j].shiftName)
    {
      if(arrThu[j].shiftName!='X')
      {
      thuTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrThu[j].totalEmp})
      }
    }
  }
  for(var j=0;j<arrFri.length;j++){
    // console.log(arrTue[j].start)
    if(this.allShiftName[i].shiftName==arrFri[j].shiftName)
    {
      if(arrFri[j].shiftName!='X')
      {
      friTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrFri[j].totalEmp})
      }
    }
  }
  for(var j=0;j<arrSat.length;j++){
    // console.log(arrTue[j].start)
    if(this.allShiftName[i].shiftName==arrSat[j].shiftName)
    {
      if(arrSat[j].shiftName!='X')
      {
      satTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrSat[j].totalEmp})
      }
    }
  }
}
this.sun_mid=0;this.sun_day=0;this.sun_eve=0;this.sun_mid_day=0;this.sun_day_eve=0;this.sun_eve_mid=0;
this.mon_mid=0;this.mon_day=0;this.mon_eve=0;this.mon_mid_day=0;this.mon_day_eve=0;this.mon_eve_mid=0;
this.tue_mid=0;this.tue_day=0;this.tue_eve=0;this.tue_mid_day=0;this.tue_day_eve=0;this.tue_eve_mid=0;
this.wed_mid=0;this.wed_day=0;this.wed_eve=0;this.wed_mid_day=0;this.wed_day_eve=0;this.wed_eve_mid=0;
this.thu_mid=0;this.thu_day=0;this.thu_eve=0;this.thu_mid_day=0;this.thu_day_eve=0;this.thu_eve_mid=0;
this.fri_mid=0;this.fri_day=0;this.fri_eve=0;this.fri_mid_day=0;this.fri_day_eve=0;this.fri_eve_mid=0;
this.sat_mid=0;this.sat_day=0;this.sat_eve=0;this.sat_mid_day=0;this.sat_day_eve=0;this.sat_eve_mid=0;
for(var i=0;i<sunTotalEmp.length;i++){
  if(sunTotalEmp[i].shiftCategory=='1'){
    this.sun_mid=this.sun_mid+ + +sunTotalEmp[i].totalEmp
  }
  else if(sunTotalEmp[i].shiftCategory=='3'){
    this.sun_day=this.sun_day+ + +sunTotalEmp[i].totalEmp
  }
  else if(sunTotalEmp[i].shiftCategory=='2'){
    this.sun_eve=this.sun_eve+ + +sunTotalEmp[i].totalEmp
  }
  else if(sunTotalEmp[i].shiftCategory=='4'){
    this.sun_mid_day=this.sun_mid_day+ + +sunTotalEmp[i].totalEmp
  }
  else if(sunTotalEmp[i].shiftCategory=='5'){
    this.sun_day_eve=this.sun_day_eve+ + +sunTotalEmp[i].totalEmp
  }
  else if(sunTotalEmp[i].shiftCategory=='6'){
    this.sun_eve_mid=this.sun_eve_mid+ + +sunTotalEmp[i].totalEmp
  }
}

// Mon
for(var i=0;i<monTotalEmp.length;i++){
  if(monTotalEmp[i].shiftCategory=='1'){
    this.mon_mid=this.mon_mid+ + +monTotalEmp[i].totalEmp
  }
  else if(monTotalEmp[i].shiftCategory=='3'){
    this.mon_day=this.mon_day+ + +monTotalEmp[i].totalEmp
  }
  else if(monTotalEmp[i].shiftCategory=='2'){
    this.mon_eve=this.mon_eve+ + +monTotalEmp[i].totalEmp
  }
  else if(monTotalEmp[i].shiftCategory=='4'){
    this.mon_mid_day=this.mon_mid_day+ + +monTotalEmp[i].totalEmp
  }
  else if(monTotalEmp[i].shiftCategory=='5'){
    this.mon_day_eve=this.mon_day_eve+ + +monTotalEmp[i].totalEmp
  }
  else if(monTotalEmp[i].shiftCategory=='6'){
    this.mon_eve_mid=this.mon_eve_mid+ + +monTotalEmp[i].totalEmp
  }
}
// Tue
for(var i=0;i<tueTotalEmp.length;i++){
  if(tueTotalEmp[i].shiftCategory=='1'){
    this.tue_mid=this.tue_mid+ + +tueTotalEmp[i].totalEmp
  }
  else if(tueTotalEmp[i].shiftCategory=='3'){
    this.tue_day=this.tue_day+ + +tueTotalEmp[i].totalEmp
  }
  else if(tueTotalEmp[i].shiftCategory=='2'){
    this.tue_eve=this.tue_eve+ + +tueTotalEmp[i].totalEmp
  }
  else if(tueTotalEmp[i].shiftCategory=='4'){
    this.tue_mid_day=this.tue_mid_day+ + +tueTotalEmp[i].totalEmp
  }
  else if(tueTotalEmp[i].shiftCategory=='5'){
    this.tue_day_eve=this.tue_day_eve+ + +tueTotalEmp[i].totalEmp
  }
  else if(tueTotalEmp[i].shiftCategory=='6'){
    this.tue_eve_mid=this.tue_eve_mid+ + +tueTotalEmp[i].totalEmp
  }
}
// console.log(tueTotalEmp)
// console.log(this.tue_mid)
// Wed
for(var i=0;i<wedTotalEmp.length;i++){
  if(wedTotalEmp[i].shiftCategory=='1'){
    this.wed_mid=this.wed_mid+ + +wedTotalEmp[i].totalEmp
  }
  else if(wedTotalEmp[i].shiftCategory=='3'){
    this.wed_day=this.wed_day+ + +wedTotalEmp[i].totalEmp
  }
  else if(wedTotalEmp[i].shiftCategory=='2'){
    this.wed_eve=this.wed_eve+ + +wedTotalEmp[i].totalEmp
  }
  else if(wedTotalEmp[i].shiftCategory=='4'){
    this.wed_mid_day=this.wed_mid_day+ + +wedTotalEmp[i].totalEmp
  }
  else if(wedTotalEmp[i].shiftCategory=='5'){
    this.wed_day_eve=this.wed_day_eve+ + +wedTotalEmp[i].totalEmp
  }
  else if(wedTotalEmp[i].shiftCategory=='6'){
    this.wed_eve_mid=this.wed_eve_mid+ + +wedTotalEmp[i].totalEmp
  }
}

// Thu
for(var i=0;i<thuTotalEmp.length;i++){
  if(thuTotalEmp[i].shiftCategory=='1'){
    this.thu_mid=this.thu_mid+ + +thuTotalEmp[i].totalEmp
  }
  else if(thuTotalEmp[i].shiftCategory=='3'){
    this.thu_day=this.thu_day+ + +thuTotalEmp[i].totalEmp
  }
  else if(thuTotalEmp[i].shiftCategory=='2'){
    this.thu_eve=this.thu_eve+ + +thuTotalEmp[i].totalEmp
  }
  else if(thuTotalEmp[i].shiftCategory=='4'){
    this.thu_mid_day=this.thu_mid_day+ + +thuTotalEmp[i].totalEmp
  }
  else if(thuTotalEmp[i].shiftCategory=='5'){
    this.thu_day_eve=this.thu_day_eve+ + +thuTotalEmp[i].totalEmp
  }
  else if(thuTotalEmp[i].shiftCategory=='6'){
    this.thu_eve_mid=this.thu_eve_mid+ + +thuTotalEmp[i].totalEmp
  }
}

// Fri
for(var i=0;i<friTotalEmp.length;i++){
  if(friTotalEmp[i].shiftCategory=='1'){
    this.fri_mid=this.fri_mid+ + +friTotalEmp[i].totalEmp
  }
  else if(friTotalEmp[i].shiftCategory=='3'){
    this.fri_day=this.fri_day+ + +friTotalEmp[i].totalEmp
  }
  else if(friTotalEmp[i].shiftCategory=='2'){
    this.fri_eve=this.fri_eve+ + +friTotalEmp[i].totalEmp
  }
  else if(friTotalEmp[i].shiftCategory=='4'){
    this.fri_mid_day=this.fri_mid_day+ + +friTotalEmp[i].totalEmp
  }
  else if(friTotalEmp[i].shiftCategory=='5'){
    this.fri_day_eve=this.fri_day_eve+ + +friTotalEmp[i].totalEmp
  }
  else if(friTotalEmp[i].shiftCategory=='6'){
    this.fri_eve_mid=this.fri_eve_mid+ + +friTotalEmp[i].totalEmp
  }
}

//Sat
for(var i=0;i<satTotalEmp.length;i++){
  if(satTotalEmp[i].shiftCategory=='1'){
    this.sat_mid=this.sat_mid+ + +satTotalEmp[i].totalEmp
  }
  else if(satTotalEmp[i].shiftCategory=='3'){
    this.sat_day=this.sat_day+ + +satTotalEmp[i].totalEmp
  }
  else if(satTotalEmp[i].shiftCategory=='2'){
    this.sat_eve=this.sat_eve+ + +satTotalEmp[i].totalEmp
  }
  else if(satTotalEmp[i].shiftCategory=='4'){
    this.sat_mid_day=this.sat_mid_day+ + +satTotalEmp[i].totalEmp
  }
  else if(satTotalEmp[i].shiftCategory=='5'){
    this.sat_day_eve=this.sat_day_eve+ + +satTotalEmp[i].totalEmp
  }
  else if(satTotalEmp[i].shiftCategory=='6'){
    this.sat_eve_mid=this.sat_eve_mid+ + +satTotalEmp[i].totalEmp
  }
}







let allShift=[]
for(var i=0;i<this.allShiftName.length;i++){
  if(this.allShiftName[i].shiftName!='X'){
    allShift.push(this.allShiftName[i])
  }
}
    // Mon
    let allMidData1=[]
    let allSunData=[]
    let allMidData=[]
    let mon=[]; let monDay=[];let monEve=[];let monMid=[];let monMD=[];let monDE=[];let monEM=[];
    for(var i=0;i<monTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==monTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime)
            {
              if(monTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime && (monTotalEmp[i].totalEmp!=0 || monTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"}
                monMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
              }
              else if(monTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime){
                monMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
              }
              else if(monTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime && (monTotalEmp[i].totalEmp!=0 || monTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"}
                  monDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(monTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime){
                  monDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(monTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime && (monTotalEmp[i].totalEmp!=0 || monTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"}
                  monEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                  }
                  else if(monTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime){
                    monEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                  }
                  else if(monTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime && (monTotalEmp[i].totalEmp!=0 || monTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"}
                    monMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                    }
                    else if(monTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime){
                      monMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                    }
                    else if(monTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime && (monTotalEmp[i].totalEmp!=0 || monTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"}
                      monDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                      }
                      else if(monTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime){
                        monDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                      }
                      else if(monTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime && (monTotalEmp[i].totalEmp!=0 || monTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"}
                        monEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                        }
                        else if(monTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime){
                          monEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                        }
             }

        }

      }
      let allShiftMonMid=[];let allShiftMonDay=[];let allShiftMonEve=[]
      let allShiftMonMD=[];let allShiftMonDE=[];let allShiftMonEM=[]
      let finalMonMidData;let finalMonDayData;let finalMonEveData
      let finalMonMDData;let finalMonDEData;let finalMonEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          allShiftMonMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftMonMid.length;j++){
        this.addShiftData={"shiftTime":allShiftMonMid[j].shiftTime,"totalEmp":0,"day":"Mon"}
        monMid.push(this.addShiftData)
      }
      finalMonMidData=monMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          allShiftMonDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftMonDay.length;j++){
        this.addShiftData={"shiftTime":allShiftMonDay[j].shiftTime,"totalEmp":0,"day":"Mon"}
        monDay.push(this.addShiftData)
      }
      finalMonDayData=  monDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          allShiftMonEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftMonEve.length;j++){
        this.addShiftData={"shiftTime":allShiftMonEve[j].shiftTime,"totalEmp":0,"day":"Mon"}
        monEve.push(this.addShiftData)
      }
      finalMonEveData=monEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Day
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='4' ){
          allShiftMonMD.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftMonMD.length;j++){
        this.addShiftData={"shiftTime":allShiftMonMD[j].shiftTime,"totalEmp":0,"day":"Mon"}
        monMD.push(this.addShiftData)
      }
      finalMonMDData=monMD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Day-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='5' ){
          allShiftMonDE.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftMonDE.length;j++){
        this.addShiftData={"shiftTime":allShiftMonDE[j].shiftTime,"totalEmp":0,"day":"Mon"}
        monDE.push(this.addShiftData)
      }
      finalMonDEData=monDE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='6' ){
          allShiftMonEM.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftMonEM.length;j++){
        this.addShiftData={"shiftTime":allShiftMonEM[j].shiftTime,"totalEmp":0,"day":"Mon"}
        monEM.push(this.addShiftData)
      }
      finalMonEMData=monEM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

    // // Tue
    let tue=[]; let tueDay=[];let tueEve=[];let tueMid=[];let tueMD=[];let tueDE=[];let tueEM=[];
    for(var i=0;i<tueTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==tueTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime)
            {
              if(tueTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime && (tueTotalEmp[i].totalEmp!=0 || tueTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"}
                tueMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
              }
              else if(tueTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime){
                tueMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
              }
              else if(tueTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime && (tueTotalEmp[i].totalEmp!=0 || tueTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"}
                  tueDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(tueTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime){
                  tueDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(tueTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime && (tueTotalEmp[i].totalEmp!=0 || tueTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"}
                  tueEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                  }
                  else if(tueTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime){
                    tueEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                  }
                  else if(tueTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime && (tueTotalEmp[i].totalEmp!=0 || tueTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"}
                    tueMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                    }
                    else if(tueTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime){
                      tueMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                    }
                    else if(tueTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime && (tueTotalEmp[i].totalEmp!=0 || tueTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"}
                      tueDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                      }
                      else if(tueTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime){
                        tueDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                      }
                      else if(tueTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime && (tueTotalEmp[i].totalEmp!=0 || tueTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"}
                        tueEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                        }
                        else if(tueTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime){
                          tueEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                        }
             }

        }

      }
      let allShiftTueMid=[];let allShiftTueDay=[];let allShiftTueEve=[]
      let allShiftTueMD=[];let allShiftTueDE=[];let allShiftTueEM=[]
      let finalTueMidData;let finalTueDayData;let finalTueEveData
      let finalTueMDData;let finalTueDEData;let finalTueEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          allShiftTueMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftTueMid.length;j++){
        this.addShiftData={"shiftTime":allShiftTueMid[j].shiftTime,"totalEmp":0,"day":"Tue"}
        tueMid.push(this.addShiftData)
      }
      finalTueMidData=tueMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          allShiftTueDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftTueDay.length;j++){
        this.addShiftData={"shiftTime":allShiftTueDay[j].shiftTime,"totalEmp":0,"day":"Tue"}
        tueDay.push(this.addShiftData)
      }
      finalTueDayData=  tueDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          allShiftTueEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftTueEve.length;j++){
        this.addShiftData={"shiftTime":allShiftTueEve[j].shiftTime,"totalEmp":0,"day":"Tue"}
        tueEve.push(this.addShiftData)
      }
      finalTueEveData=tueEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Day
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='4' ){
          allShiftTueMD.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftTueMD.length;j++){
        this.addShiftData={"shiftTime":allShiftTueMD[j].shiftTime,"totalEmp":0,"day":"Tue"}
        tueMD.push(this.addShiftData)
      }
      finalTueMDData=tueMD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Day-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='5' ){
          allShiftTueDE.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftTueDE.length;j++){
        this.addShiftData={"shiftTime":allShiftTueDE[j].shiftTime,"totalEmp":0,"day":"Tue"}
        tueDE.push(this.addShiftData)
      }
      finalTueDEData=tueDE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='6' ){
          allShiftTueEM.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftTueEM.length;j++){
        this.addShiftData={"shiftTime":allShiftTueEM[j].shiftTime,"totalEmp":0,"day":"Tue"}
        tueEM.push(this.addShiftData)
      }
      finalTueEMData=tueEM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
    // //Wed
    let wed=[]; let wedDay=[];let wedEve=[];let wedMid=[];let wedMD=[];let wedDE=[];let wedEM=[];
    for(var i=0;i<wedTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==wedTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime)
            {
              if(wedTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime && (wedTotalEmp[i].totalEmp!=0 || wedTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"}
                wedMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
              }
              else if(wedTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime){
                wedMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
              }
              else if(wedTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime && (wedTotalEmp[i].totalEmp!=0 || wedTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"}
                  wedDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(wedTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime){
                  wedDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(wedTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime && (wedTotalEmp[i].totalEmp!=0 || wedTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"}
                  wedEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                  }
                  else if(wedTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime){
                    wedEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                  }
                  else if(wedTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime && (wedTotalEmp[i].totalEmp!=0 || wedTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"}
                    wedMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                    }
                    else if(wedTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime){
                      wedMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                    }
                    else if(wedTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime && (wedTotalEmp[i].totalEmp!=0 || wedTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"}
                      wedDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                      }
                      else if(wedTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime){
                        wedDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                      }
                      else if(wedTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime && (wedTotalEmp[i].totalEmp!=0 || wedTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"}
                        wedEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                        }
                        else if(wedTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime){
                          wedEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                        }
             }

        }

      }
      let allShiftWedMid=[];let allShiftWedDay=[];let allShiftWedEve=[]
      let allShiftWedMD=[];let allShiftWedDE=[];let allShiftWedEM=[]
      let finalWedMidData;let finalWedDayData;let finalWedEveData
      let finalWedMDData;let finalWedDEData;let finalWedEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          allShiftWedMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftWedMid.length;j++){
        this.addShiftData={"shiftTime":allShiftWedMid[j].shiftTime,"totalEmp":0,"day":"Wed"}
        wedMid.push(this.addShiftData)
      }
      finalWedMidData=wedMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          allShiftWedDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftWedDay.length;j++){
        this.addShiftData={"shiftTime":allShiftWedDay[j].shiftTime,"totalEmp":0,"day":"Wed"}
        wedDay.push(this.addShiftData)
      }
      finalWedDayData=  wedDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          allShiftWedEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftWedEve.length;j++){
        this.addShiftData={"shiftTime":allShiftWedEve[j].shiftTime,"totalEmp":0,"day":"Wed"}
        wedEve.push(this.addShiftData)
      }
      finalWedEveData=wedEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Day
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='4' ){
          allShiftWedMD.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftWedMD.length;j++){
        this.addShiftData={"shiftTime":allShiftWedMD[j].shiftTime,"totalEmp":0,"day":"Wed"}
        wedMD.push(this.addShiftData)
      }
      finalWedMDData=wedMD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Day-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='5' ){
          allShiftWedDE.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftWedDE.length;j++){
        this.addShiftData={"shiftTime":allShiftWedDE[j].shiftTime,"totalEmp":0,"day":"Wed"}
        wedDE.push(this.addShiftData)
      }
      finalWedDEData=wedDE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='6' ){
          allShiftWedEM.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftWedEM.length;j++){
        this.addShiftData={"shiftTime":allShiftWedEM[j].shiftTime,"totalEmp":0,"day":"Wed"}
        wedEM.push(this.addShiftData)
      }
      finalWedEMData=wedEM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

    // //Thu
    let thu=[]; let thuDay=[];let thuEve=[];let thuMid=[];let thuMD=[];let thuDE=[];let thuEM=[];
    for(var i=0;i<thuTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==thuTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime)
            {
              if(thuTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime && (thuTotalEmp[i].totalEmp!=0 || thuTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"}
                thuMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
              }
              else if(thuTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime){
                thuMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
              }
              else if(thuTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime && (thuTotalEmp[i].totalEmp!=0 || thuTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"}
                  thuDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(thuTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime){
                  thuDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(thuTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime && (thuTotalEmp[i].totalEmp!=0 || thuTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"}
                  thuEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                  }
                  else if(thuTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime){
                    thuEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                  }
                  else if(thuTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime && (thuTotalEmp[i].totalEmp!=0 || thuTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"}
                    thuMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                    }
                    else if(thuTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime){
                      thuMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                    }
                    else if(thuTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime && (thuTotalEmp[i].totalEmp!=0 || thuTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"}
                      thuDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                      }
                      else if(thuTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime){
                        thuDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                      }
                      else if(thuTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime && (thuTotalEmp[i].totalEmp!=0 || thuTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"}
                        thuEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                        }
                        else if(thuTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime){
                          thuEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                        }
             }

        }

      }
      let allShiftThuMid=[];let allShiftThuDay=[];let allShiftThuEve=[]
      let allShiftThuMD=[];let allShiftThuDE=[];let allShiftThuEM=[]
      let finalThuMidData;let finalThuDayData;let finalThuEveData
      let finalThuMDData;let finalThuDEData;let finalThuEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          allShiftThuMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftThuMid.length;j++){
        this.addShiftData={"shiftTime":allShiftThuMid[j].shiftTime,"totalEmp":0,"day":"Thu"}
        thuMid.push(this.addShiftData)
      }
      finalThuMidData=thuMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          allShiftThuDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftThuDay.length;j++){
        this.addShiftData={"shiftTime":allShiftThuDay[j].shiftTime,"totalEmp":0,"day":"Thu"}
        thuDay.push(this.addShiftData)
      }
      finalThuDayData=  thuDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          allShiftThuEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftThuEve.length;j++){
        this.addShiftData={"shiftTime":allShiftThuEve[j].shiftTime,"totalEmp":0,"day":"Thu"}
        thuEve.push(this.addShiftData)
      }
      finalThuEveData=thuEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Day
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='4' ){
          allShiftThuMD.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftThuMD.length;j++){
        this.addShiftData={"shiftTime":allShiftThuMD[j].shiftTime,"totalEmp":0,"day":"Thu"}
        thuMD.push(this.addShiftData)
      }
      finalThuMDData=thuMD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      //Day-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='5' ){
          allShiftThuDE.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftThuDE.length;j++){
        this.addShiftData={"shiftTime":allShiftThuDE[j].shiftTime,"totalEmp":0,"day":"Thu"}
        thuDE.push(this.addShiftData)
      }
      finalThuDEData=thuDE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      //Mid-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='6' ){
          allShiftThuEM.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftThuEM.length;j++){
        this.addShiftData={"shiftTime":allShiftThuEM[j].shiftTime,"totalEmp":0,"day":"Thu"}
        thuEM.push(this.addShiftData)
      }
      finalThuEMData=thuEM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

    // //Fri
    let fri=[]; let friDay=[];let friEve=[];let friMid=[];let friMD=[];let friDE=[];let friEM=[];
    for(var i=0;i<friTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==friTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime)
            {
              if(friTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime && (friTotalEmp[i].totalEmp!=0 || friTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"}
                friMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
              }
              else if(friTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime){
                friMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
              }
              else if(friTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime && (friTotalEmp[i].totalEmp!=0 || friTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"}
                  friDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(friTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime){
                  friDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(friTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime && (friTotalEmp[i].totalEmp!=0 || friTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"}
                  friEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                  }
                  else if(friTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime){
                    friEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                  }
                  else if(friTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime && (friTotalEmp[i].totalEmp!=0 || friTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"}
                    friMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                    }
                    else if(friTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime){
                      friMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                    }
                    else if(friTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime && (friTotalEmp[i].totalEmp!=0 || friTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"}
                      friDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                      }
                      else if(friTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime){
                        friDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                      }
                      else if(friTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime && (friTotalEmp[i].totalEmp!=0 || friTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"}
                        friEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                        }
                        else if(friTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime){
                          friEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                        }
             }

        }

      }
      let allShiftFriMid=[];let allShiftFriDay=[];let allShiftFriEve=[]
      let allShiftFriMD=[];let allShiftFriDE=[];let allShiftFriEM=[]
      let finalFriMidData;let finalFriDayData;let finalFriEveData
      let finalFriMDData;let finalFriDEData;let finalFriEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          allShiftFriMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftFriMid.length;j++){
        this.addShiftData={"shiftTime":allShiftFriMid[j].shiftTime,"totalEmp":0,"day":"Fri"}
        friMid.push(this.addShiftData)
      }
      finalFriMidData=friMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          allShiftFriDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftFriDay.length;j++){
        this.addShiftData={"shiftTime":allShiftFriDay[j].shiftTime,"totalEmp":0,"day":"Fri"}
        friDay.push(this.addShiftData)
      }
      finalFriDayData=  friDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          allShiftFriEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftFriEve.length;j++){
        this.addShiftData={"shiftTime":allShiftFriEve[j].shiftTime,"totalEmp":0,"day":"Fri"}
        friEve.push(this.addShiftData)
      }
      finalFriEveData=friEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Day
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='4' ){
          allShiftFriMD.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftFriMD.length;j++){
        this.addShiftData={"shiftTime":allShiftFriMD[j].shiftTime,"totalEmp":0,"day":"Fri"}
        friMD.push(this.addShiftData)
      }
      finalFriMDData=friMD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      //Day-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='5' ){
          allShiftFriDE.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftFriDE.length;j++){
        this.addShiftData={"shiftTime":allShiftFriDE[j].shiftTime,"totalEmp":0,"day":"Fri"}
        friDE.push(this.addShiftData)
      }
      finalFriDEData=friDE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      //Mid-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='6' ){
          allShiftFriEM.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftFriEM.length;j++){
        this.addShiftData={"shiftTime":allShiftFriEM[j].shiftTime,"totalEmp":0,"day":"Fri"}
        friEM.push(this.addShiftData)
      }
      finalFriEMData=friEM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

    // //Sat
    let sat=[]; let satDay=[];let satEve=[];let satMid=[];let satMD=[];let satDE=[];let satEM=[];
    for(var i=0;i<satTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==satTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime)
            {
              if(satTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime && (satTotalEmp[i].totalEmp!=0 || satTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"}
                satMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
              }
              else if(satTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime){
                satMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
              }
              else if(satTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime && (satTotalEmp[i].totalEmp!=0 || satTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"}
                  satDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(satTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime){
                  satDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(satTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime && (satTotalEmp[i].totalEmp!=0 || satTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"}
                  satEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                  }
                  else if(satTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime){
                    satEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                  }
                  else if(satTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime && (satTotalEmp[i].totalEmp!=0 || satTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"}
                    satMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                    }
                    else if(satTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime){
                      satMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                    }
                    else if(satTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime && (satTotalEmp[i].totalEmp!=0 || satTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"}
                      satDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                      }
                      else if(satTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime){
                        satDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                      }
                      else if(satTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime && (satTotalEmp[i].totalEmp!=0 || satTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"}
                        satEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                        }
                        else if(satTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime){
                          satEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                        }
             }

        }

      }

      let allShiftSatMid=[];let allShiftSatDay=[];let allShiftSatEve=[]
      let allShiftSatMD=[];let allShiftSatDE=[];let allShiftSatEM=[]
      let finalSatMidData;let finalSatDayData;let finalSatEveData
      let finalSatMDData;let finalSatDEData;let finalSatEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          allShiftSatMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSatMid.length;j++){
        this.addShiftData={"shiftTime":allShiftSatMid[j].shiftTime,"totalEmp":0,"day":"Sat"}
        satMid.push(this.addShiftData)
      }
      finalSatMidData=satMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          allShiftSatDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSatDay.length;j++){
        this.addShiftData={"shiftTime":allShiftSatDay[j].shiftTime,"totalEmp":0,"day":"Sat"}
        satDay.push(this.addShiftData)
      }
      finalSatDayData=  satDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          allShiftSatEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSatEve.length;j++){
        this.addShiftData={"shiftTime":allShiftSatEve[j].shiftTime,"totalEmp":0,"day":"Sat"}
        satEve.push(this.addShiftData)
      }
      finalSatEveData=satEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Day
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='4' ){
          allShiftSatMD.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSatMD.length;j++){
        this.addShiftData={"shiftTime":allShiftSatMD[j].shiftTime,"totalEmp":0,"day":"Sat"}
        satMD.push(this.addShiftData)
      }
      finalSatMDData=satMD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      //Day-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='5' ){
          allShiftSatDE.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSatDE.length;j++){
        this.addShiftData={"shiftTime":allShiftSatDE[j].shiftTime,"totalEmp":0,"day":"Sat"}
        satDE.push(this.addShiftData)
      }
      finalSatDEData=satDE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      //Mid-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='6' ){
          allShiftSatEM.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSatEM.length;j++){
        this.addShiftData={"shiftTime":allShiftSatEM[j].shiftTime,"totalEmp":0,"day":"Sat"}
        satEM.push(this.addShiftData)
      }
      finalSatEMData=satEM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

    // //Sun
    let sun=[]; let sunDay=[];let sunEve=[];let sunMid=[];let sunMD=[];let sunDE=[];let sunEM=[];
    for(var i=0;i<sunTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==sunTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime)
            {
              if(sunTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime && (sunTotalEmp[i].totalEmp!=0 || sunTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"}
                sunMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
              }
              else if(sunTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime){
                sunMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
              }
              else if(sunTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime && (sunTotalEmp[i].totalEmp!=0 || sunTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"}
                  sunDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(sunTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime){
                  sunDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(sunTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime && (sunTotalEmp[i].totalEmp!=0 || sunTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"}
                  sunEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                  }
                  else if(sunTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime){
                    sunEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                  }
                  else if(sunTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime && (sunTotalEmp[i].totalEmp!=0 || sunTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"}
                    sunMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                    }
                    else if(sunTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime){
                      sunMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                    }
                    else if(sunTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime && (sunTotalEmp[i].totalEmp!=0 || sunTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"}
                      sunDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                      }
                      else if(sunTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime){
                        sunDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                      }
                      else if(sunTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime && (sunTotalEmp[i].totalEmp!=0 || sunTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"}
                        sunEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                        }
                        else if(sunTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime){
                          sunEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                        }
             }

        }

      }
      let allShiftSunMid=[];let allShiftSunDay=[];let allShiftSunEve=[]
      let allShiftSunMD=[];let allShiftSunDE=[];let allShiftSunEM=[]
      let finalSunMidData;let finalSunDayData;let finalSunEveData
      let finalSunMDData;let finalSunDEData;let finalSunEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          allShiftSunMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSunMid.length;j++){
        this.addShiftData={"shiftTime":allShiftSunMid[j].shiftTime,"totalEmp":0,"day":"Sun"}
        sunMid.push(this.addShiftData)
      }
      finalSunMidData=sunMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          allShiftSunDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSunDay.length;j++){
        this.addShiftData={"shiftTime":allShiftSunDay[j].shiftTime,"totalEmp":0,"day":"Sun"}
        sunDay.push(this.addShiftData)
      }
      finalSunDayData=  sunDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          allShiftSunEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSunEve.length;j++){
        this.addShiftData={"shiftTime":allShiftSunEve[j].shiftTime,"totalEmp":0,"day":"Sun"}
        sunEve.push(this.addShiftData)
      }
      finalSunEveData=sunEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Day
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='4' ){
          allShiftSunMD.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSunMD.length;j++){
        this.addShiftData={"shiftTime":allShiftSunMD[j].shiftTime,"totalEmp":0,"day":"Sun"}
        sunMD.push(this.addShiftData)
      }
      finalSunMDData=sunMD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      //Day-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='5' ){
          allShiftSunDE.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSunDE.length;j++){
        this.addShiftData={"shiftTime":allShiftSunDE[j].shiftTime,"totalEmp":0,"day":"Sun"}
        sunDE.push(this.addShiftData)
      }
      finalSunDEData=sunDE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      //Mid-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='6' ){
          allShiftSunEM.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSunEM.length;j++){
        this.addShiftData={"shiftTime":allShiftSunEM[j].shiftTime,"totalEmp":0,"day":"Sun"}
        sunEM.push(this.addShiftData)
      }
      finalSunEMData=sunEM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)





// console.log(this.defscheduleShift)
this.def_sundAy=[];this.def_mondAy=[];this.def_tuedAy=[];this.def_weddAy=[];this.def_thudAy=[];this.def_fridAy=[];this.def_satdAy=[];
for(var i=0;i<this.defscheduleShift.length;i++){
  this.def_sundAy.push(this.defscheduleShift[i].Sun)
  this.def_mondAy.push(this.defscheduleShift[i].Mon)
  this.def_tuedAy.push(this.defscheduleShift[i].Tue)
  this.def_weddAy.push(this.defscheduleShift[i].Wed)
  this.def_thudAy.push(this.defscheduleShift[i].Thu)
  this.def_fridAy.push(this.defscheduleShift[i].Fri)
  this.def_satdAy.push(this.defscheduleShift[i].Sat)
}
const countsCustomizedDefSunDay = {};
this.def_sundAy.forEach(function (x) { countsCustomizedDefSunDay[x] = (countsCustomizedDefSunDay[x] || 0) + 1; });

const countsCustomizedDefMonDay = {};
this.def_mondAy.forEach(function (x) { countsCustomizedDefMonDay[x] = (countsCustomizedDefMonDay[x] || 0) + 1; });

const countsCustomizedDefTueDay = {}
this.def_tuedAy.forEach(function (x) { countsCustomizedDefTueDay[x] = (countsCustomizedDefTueDay[x] || 0) + 1; });

const countsCustomizedDefWedDay = {};
this.def_weddAy.forEach(function (x) { countsCustomizedDefWedDay[x] = (countsCustomizedDefWedDay[x] || 0) + 1; });

const countsCustomizedDefThuDay = {};
this.def_thudAy.forEach(function (x) { countsCustomizedDefThuDay[x] = (countsCustomizedDefThuDay[x] || 0) + 1; });

const countsCustomizedDefFriDay = {};
this.def_fridAy.forEach(function (x) { countsCustomizedDefFriDay[x] = (countsCustomizedDefFriDay[x] || 0) + 1; });

const countsCustomizedDefSatDay = {};
this.def_satdAy.forEach(function (x) { countsCustomizedDefSatDay[x] = (countsCustomizedDefSatDay[x] || 0) + 1; });

let arrDefSun = [];let arrDefMon = [];let arrDefTue = [];let arrDefWed = [];let arrDefThu = [];let arrDefFri = [];let arrDefSat = [];

Object.keys(countsCustomizedDefSunDay).map(function(key){
  arrDefSun.push({"shiftName":[key],"totalEmp":countsCustomizedDefSunDay[key]})
  return arrDefSun;
});

Object.keys(countsCustomizedDefMonDay).map(function(key){
  arrDefMon.push({"shiftName":[key],"totalEmp":countsCustomizedDefMonDay[key]})
  return arrDefMon;
});


Object.keys(countsCustomizedDefTueDay).map(function(key){
  arrDefTue.push({"shiftName":[key],"totalEmp":countsCustomizedDefTueDay[key]})
  return arrDefTue;
});
Object.keys(countsCustomizedDefWedDay).map(function(key){
  arrDefWed.push({"shiftName":[key],"totalEmp":countsCustomizedDefWedDay[key]})
  return arrDefWed;
});
Object.keys(countsCustomizedDefThuDay).map(function(key){
  arrDefThu.push({"shiftName":[key],"totalEmp":countsCustomizedDefThuDay[key]})
  return arrDefThu;
});
Object.keys(countsCustomizedDefFriDay).map(function(key){
  arrDefFri.push({"shiftName":[key],"totalEmp":countsCustomizedDefFriDay[key]})
  return arrDefFri;
});
Object.keys(countsCustomizedDefSatDay).map(function(key){
  arrDefSat.push({"shiftName":[key],"totalEmp":countsCustomizedDefSatDay[key]})
  return arrDefSat;
});
let def_sunTotalEmp=[];let def_monTotalEmp=[];let def_tueTotalEmp=[];let def_wedTotalEmp=[];let def_thuTotalEmp=[];let def_friTotalEmp=[];let def_satTotalEmp=[]
for(var i=0;i<this.allShiftName.length;i++){
  for(var j=0;j<arrDefSun.length;j++){
    // console.log(arrDefTue[j].start)
    if(this.allShiftName[i].shiftName==arrDefSun[j].shiftName)
    {
      if(arrDefSun[j].shiftName!='X')
      {
      def_sunTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory ,"totalEmp":arrDefSun[j].totalEmp})
      }
    }
  }
  for(var j=0;j<arrDefMon.length;j++){
    // console.log(arrDefTue[j].start)
    if(this.allShiftName[i].shiftName==arrDefMon[j].shiftName)
    {
      if(arrDefMon[j].shiftName!='X')
      {
        def_monTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrDefMon[j].totalEmp})
      }


    }
  }
  for(var j=0;j<arrDefTue.length;j++){
    // console.log(arrDefTue[j].start)
    if(this.allShiftName[i].shiftName==arrDefTue[j].shiftName)
    {
      if(arrDefTue[j].shiftName!='X')
      {
      def_tueTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrDefTue[j].totalEmp})
      }
    }
  }
  for(var j=0;j<arrDefWed.length;j++){
    // console.log(arrDefTue[j].start)
    if(this.allShiftName[i].shiftName==arrDefWed[j].shiftName)
    {
      if(arrDefWed[j].shiftName!='X')
      {
      def_wedTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrDefWed[j].totalEmp})
      }
    }
  }
  for(var j=0;j<arrDefThu.length;j++){
    // console.log(arrDefTue[j].start)
    if(this.allShiftName[i].shiftName==arrDefThu[j].shiftName)
    {
      if(arrDefThu[j].shiftName!='X')
      {
      def_thuTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrDefThu[j].totalEmp})
      }
    }
  }
  for(var j=0;j<arrDefFri.length;j++){
    // console.log(arrDefTue[j].start)
    if(this.allShiftName[i].shiftName==arrDefFri[j].shiftName)
    {
      if(arrDefFri[j].shiftName!='X')
      {
      def_friTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrDefFri[j].totalEmp})
      }
    }
  }
  for(var j=0;j<arrDefSat.length;j++){
    // console.log(arrDefTue[j].start)
    if(this.allShiftName[i].shiftName==arrDefSat[j].shiftName)
    {
      if(arrDefSat[j].shiftName!='X')
      {
      def_satTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrDefSat[j].totalEmp})
      }
    }
  }
}
this.def_sun_mid=0;this.def_sun_day=0;this.def_sun_eve=0;this.def_sun_mid_day=0;this.def_sun_day_eve=0;this.def_sun_eve_mid=0;
this.def_mon_mid=0;this.def_mon_day=0;this.def_mon_eve=0;this.def_mon_mid_day=0;this.def_mon_day_eve=0;this.def_mon_eve_mid=0;
this.def_tue_mid=0;this.def_tue_day=0;this.def_tue_eve=0;this.def_tue_mid_day=0;this.def_tue_day_eve=0;this.def_tue_eve_mid=0;
this.def_wed_mid=0;this.def_wed_day=0;this.def_wed_eve=0;this.def_wed_mid_day=0;this.def_wed_day_eve=0;this.def_wed_eve_mid=0;
this.def_thu_mid=0;this.def_thu_day=0;this.def_thu_eve=0;this.def_thu_mid_day=0;this.def_thu_day_eve=0;this.def_thu_eve_mid=0;
this.def_fri_mid=0;this.def_fri_day=0;this.def_fri_eve=0;this.def_fri_mid_day=0;this.def_fri_day_eve=0;this.def_fri_eve_mid=0;
this.def_sat_mid=0;this.def_sat_day=0;this.def_sat_eve=0;this.def_sat_mid_day=0;this.def_sat_day_eve=0;this.def_sat_eve_mid=0;
for(var i=0;i<def_sunTotalEmp.length;i++){
  if(def_sunTotalEmp[i].shiftCategory=='1'){
    this.def_sun_mid=this.def_sun_mid+ + +def_sunTotalEmp[i].totalEmp
  }
  else if(def_sunTotalEmp[i].shiftCategory=='3'){
    this.def_sun_day=this.def_sun_day+ + +def_sunTotalEmp[i].totalEmp
  }
  else if(def_sunTotalEmp[i].shiftCategory=='2'){
    this.def_sun_eve=this.def_sun_eve+ + +def_sunTotalEmp[i].totalEmp
  }
  else if(def_sunTotalEmp[i].shiftCategory=='4'){
    this.def_sun_mid_day=this.def_sun_mid_day+ + +def_sunTotalEmp[i].totalEmp
  }
  else if(def_sunTotalEmp[i].shiftCategory=='5'){
    this.def_sun_day_eve=this.def_sun_day_eve+ + +def_sunTotalEmp[i].totalEmp
  }
  else if(def_sunTotalEmp[i].shiftCategory=='6'){
    this.def_sun_eve_mid=this.def_sun_eve_mid+ + +def_sunTotalEmp[i].totalEmp
  }
}

// Mon
for(var i=0;i<def_monTotalEmp.length;i++){
  if(def_monTotalEmp[i].shiftCategory=='1'){
    this.def_mon_mid=this.def_mon_mid+ + +def_monTotalEmp[i].totalEmp
  }
  else if(def_monTotalEmp[i].shiftCategory=='3'){
    this.def_mon_day=this.def_mon_day+ + +def_monTotalEmp[i].totalEmp
  }
  else if(def_monTotalEmp[i].shiftCategory=='2'){
    this.def_mon_eve=this.def_mon_eve+ + +def_monTotalEmp[i].totalEmp
  }
  else if(def_monTotalEmp[i].shiftCategory=='4'){
    this.def_mon_mid_day=this.def_mon_mid_day+ + +def_monTotalEmp[i].totalEmp
  }
  else if(def_monTotalEmp[i].shiftCategory=='5'){
    this.def_mon_day_eve=this.def_mon_day_eve+ + +def_monTotalEmp[i].totalEmp
  }
  else if(def_monTotalEmp[i].shiftCategory=='6'){
    this.def_mon_eve_mid=this.def_mon_eve_mid+ + +def_monTotalEmp[i].totalEmp
  }
}
// Tue
for(var i=0;i<def_tueTotalEmp.length;i++){
  if(def_tueTotalEmp[i].shiftCategory=='1'){
    this.def_tue_mid=this.def_tue_mid+ + +def_tueTotalEmp[i].totalEmp
  }
  else if(def_tueTotalEmp[i].shiftCategory=='3'){
    this.def_tue_day=this.def_tue_day+ + +def_tueTotalEmp[i].totalEmp
  }
  else if(def_tueTotalEmp[i].shiftCategory=='2'){
    this.def_tue_eve=this.def_tue_eve+ + +def_tueTotalEmp[i].totalEmp
  }
  else if(def_tueTotalEmp[i].shiftCategory=='4'){
    this.def_tue_mid_day=this.def_tue_mid_day+ + +def_tueTotalEmp[i].totalEmp
  }
  else if(def_tueTotalEmp[i].shiftCategory=='5'){
    this.def_tue_day_eve=this.def_tue_day_eve+ + +def_tueTotalEmp[i].totalEmp
  }
  else if(def_tueTotalEmp[i].shiftCategory=='6'){
    this.def_tue_eve_mid=this.def_tue_eve_mid+ + +def_tueTotalEmp[i].totalEmp
  }
}
// console.log(def_tueTotalEmp)
// console.log(this.def_tue_mid)
// Wed
for(var i=0;i<def_wedTotalEmp.length;i++){
  if(def_wedTotalEmp[i].shiftCategory=='1'){
    this.def_wed_mid=this.def_wed_mid+ + +def_wedTotalEmp[i].totalEmp
  }
  else if(def_wedTotalEmp[i].shiftCategory=='3'){
    this.def_wed_day=this.def_wed_day+ + +def_wedTotalEmp[i].totalEmp
  }
  else if(def_wedTotalEmp[i].shiftCategory=='2'){
    this.def_wed_eve=this.def_wed_eve+ + +def_wedTotalEmp[i].totalEmp
  }
  else if(def_wedTotalEmp[i].shiftCategory=='4'){
    this.def_wed_mid_day=this.def_wed_mid_day+ + +def_wedTotalEmp[i].totalEmp
  }
  else if(def_wedTotalEmp[i].shiftCategory=='5'){
    this.def_wed_day_eve=this.def_wed_day_eve+ + +def_wedTotalEmp[i].totalEmp
  }
  else if(def_wedTotalEmp[i].shiftCategory=='6'){
    this.def_wed_eve_mid=this.def_wed_eve_mid+ + +def_wedTotalEmp[i].totalEmp
  }
}

// Thu
for(var i=0;i<def_thuTotalEmp.length;i++){
  if(def_thuTotalEmp[i].shiftCategory=='1'){
    this.def_thu_mid=this.def_thu_mid+ + +def_thuTotalEmp[i].totalEmp
  }
  else if(def_thuTotalEmp[i].shiftCategory=='3'){
    this.def_thu_day=this.def_thu_day+ + +def_thuTotalEmp[i].totalEmp
  }
  else if(def_thuTotalEmp[i].shiftCategory=='2'){
    this.def_thu_eve=this.def_thu_eve+ + +def_thuTotalEmp[i].totalEmp
  }
  else if(def_thuTotalEmp[i].shiftCategory=='4'){
    this.def_thu_mid_day=this.def_thu_mid_day+ + +def_thuTotalEmp[i].totalEmp
  }
  else if(def_thuTotalEmp[i].shiftCategory=='5'){
    this.def_thu_day_eve=this.def_thu_day_eve+ + +def_thuTotalEmp[i].totalEmp
  }
  else if(def_thuTotalEmp[i].shiftCategory=='6'){
    this.def_thu_eve_mid=this.def_thu_eve_mid+ + +def_thuTotalEmp[i].totalEmp
  }
}

// Fri
for(var i=0;i<def_friTotalEmp.length;i++){
  if(def_friTotalEmp[i].shiftCategory=='1'){
    this.def_fri_mid=this.def_fri_mid+ + +def_friTotalEmp[i].totalEmp
  }
  else if(def_friTotalEmp[i].shiftCategory=='3'){
    this.def_fri_day=this.def_fri_day+ + +def_friTotalEmp[i].totalEmp
  }
  else if(def_friTotalEmp[i].shiftCategory=='2'){
    this.def_fri_eve=this.def_fri_eve+ + +def_friTotalEmp[i].totalEmp
  }
  else if(def_friTotalEmp[i].shiftCategory=='4'){
    this.def_fri_mid_day=this.def_fri_mid_day+ + +def_friTotalEmp[i].totalEmp
  }
  else if(def_friTotalEmp[i].shiftCategory=='5'){
    this.def_fri_day_eve=this.def_fri_day_eve+ + +def_friTotalEmp[i].totalEmp
  }
  else if(def_friTotalEmp[i].shiftCategory=='6'){
    this.def_fri_eve_mid=this.def_fri_eve_mid+ + +def_friTotalEmp[i].totalEmp
  }
}

//Sat
for(var i=0;i<def_satTotalEmp.length;i++){
  if(def_satTotalEmp[i].shiftCategory=='1'){
    this.def_sat_mid=this.def_sat_mid+ + +def_satTotalEmp[i].totalEmp
  }
  else if(def_satTotalEmp[i].shiftCategory=='3'){
    this.def_sat_day=this.def_sat_day+ + +def_satTotalEmp[i].totalEmp
  }
  else if(def_satTotalEmp[i].shiftCategory=='2'){
    this.def_sat_eve=this.def_sat_eve+ + +def_satTotalEmp[i].totalEmp
  }
  else if(def_satTotalEmp[i].shiftCategory=='4'){
    this.def_sat_mid_day=this.def_sat_mid_day+ + +def_satTotalEmp[i].totalEmp
  }
  else if(def_satTotalEmp[i].shiftCategory=='5'){
    this.def_sat_day_eve=this.def_sat_day_eve+ + +def_satTotalEmp[i].totalEmp
  }
  else if(def_satTotalEmp[i].shiftCategory=='6'){
    this.def_sat_eve_mid=this.def_sat_eve_mid+ + +def_satTotalEmp[i].totalEmp
  }
}
allShift=[]
for(var i=0;i<this.allShiftName.length;i++){
  if(this.allShiftName[i].shiftName!='X'){
    allShift.push(this.allShiftName[i])
  }
}
    //Default Mon
    let def_mon=[]; let def_monDay=[];let def_monEve=[];let def_monMid=[]; let def_mon_MD=[];let def_mon_DE=[];let def_mon_EM=[]
    for(var i=0;i<def_monTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==def_monTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==def_monTotalEmp[i].shiftTime)
            {
              if(def_monTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==def_monTotalEmp[i].shiftTime && (def_monTotalEmp[i].totalEmp!=0 || def_monTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"}
                def_monMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"})
              }
              else if(def_monTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==def_monTotalEmp[i].shiftTime){
                def_monMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"})
              }
              else if(def_monTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==def_monTotalEmp[i].shiftTime && (def_monTotalEmp[i].totalEmp!=0 || def_monTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"}
                  def_monDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(def_monTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==def_monTotalEmp[i].shiftTime){
                  def_monDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(def_monTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==def_monTotalEmp[i].shiftTime && (def_monTotalEmp[i].totalEmp!=0 || def_monTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"}
                  def_monEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"})
                  }
                  else if(def_monTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==def_monTotalEmp[i].shiftTime){
                    def_monEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"})
                  }
                  else if(def_monTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==def_monTotalEmp[i].shiftTime && (def_monTotalEmp[i].totalEmp!=0 || def_monTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"}
                    def_mon_MD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"})
                    }
                    else if(def_monTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==def_monTotalEmp[i].shiftTime){
                      def_mon_MD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"})
                    }
                    else if(def_monTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==def_monTotalEmp[i].shiftTime && (def_monTotalEmp[i].totalEmp!=0 || def_monTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"}
                      def_mon_DE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"})
                        // allDayData1.push(this.addShiftData)
                      }
                      else if(def_monTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==def_monTotalEmp[i].shiftTime){
                        def_mon_DE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"})
                        // allDayData1.push(this.addShiftData)
                      }
                      else if(def_monTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==def_monTotalEmp[i].shiftTime && (def_monTotalEmp[i].totalEmp!=0 || def_monTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"}
                        def_mon_EM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"})
                        }
                        else if(def_monTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==def_monTotalEmp[i].shiftTime){
                          def_mon_EM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_monTotalEmp[i].totalEmp,"day":"Mon"})
                        }
             }

        }

      }

      let def_allShiftMonMid=[];let def_allShiftMonDay=[];let def_allShiftMonEve=[]
      let def_finalMonMidData;let def_finalMonDayData;let def_finalMonEveData
      let def_allShiftMonMD=[];let def_allShiftMonDE=[];let def_allShiftMonEM=[]
      let def_finalMonMDData;let def_finalMonDEData;let def_finalMonEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          def_allShiftMonMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftMonMid.length;j++){
        this.addShiftData={"shiftTime":def_allShiftMonMid[j].shiftTime,"totalEmp":0,"day":"Mon"}
        def_monMid.push(this.addShiftData)
      }
      def_finalMonMidData=def_monMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          def_allShiftMonDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftMonDay.length;j++){
        this.addShiftData={"shiftTime":def_allShiftMonDay[j].shiftTime,"totalEmp":0,"day":"Mon"}
        def_monDay.push(this.addShiftData)
      }
      def_finalMonDayData=  def_monDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          def_allShiftMonEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftMonEve.length;j++){
        this.addShiftData={"shiftTime":def_allShiftMonEve[j].shiftTime,"totalEmp":0,"day":"Mon"}
        def_monEve.push(this.addShiftData)
      }
      def_finalMonEveData=def_monEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)


            //Mid-Day
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='4' ){
                allShiftSunMD.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftMonMD.length;j++){
              this.addShiftData={"shiftTime":def_allShiftMonMD[j].shiftTime,"totalEmp":0,"day":"Mon"}
              def_mon_MD.push(this.addShiftData)
            }
            def_finalMonMDData=def_mon_MD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

            //Day-Eve
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='5' ){
                def_allShiftMonDE.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftMonDE.length;j++){
              this.addShiftData={"shiftTime":def_allShiftMonDE[j].shiftTime,"totalEmp":0,"day":"Mon"}
              def_mon_DE.push(this.addShiftData)
            }
            def_finalMonDEData=def_mon_DE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

            //Mid-Eve
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='6' ){
                def_allShiftMonEM.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftMonEM.length;j++){
              this.addShiftData={"shiftTime":def_allShiftMonEM[j].shiftTime,"totalEmp":0,"day":"Mon"}
              def_mon_EM.push(this.addShiftData)
            }
            def_finalMonEMData=def_mon_EM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)


          //Default Tue
    let def_tue=[]; let def_tueDay=[];let def_tueEve=[];let def_tueMid=[]; let def_tue_MD=[];let def_tue_DE=[];let def_tue_EM=[]
    for(var i=0;i<def_tueTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==def_tueTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==def_tueTotalEmp[i].shiftTime)
            {
              if(def_tueTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==def_tueTotalEmp[i].shiftTime && (def_tueTotalEmp[i].totalEmp!=0 || def_tueTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"}
                def_tueMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"})
              }
              else if(def_tueTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==def_tueTotalEmp[i].shiftTime){
                def_tueMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"})
              }
              else if(def_tueTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==def_tueTotalEmp[i].shiftTime && (def_tueTotalEmp[i].totalEmp!=0 || def_tueTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"}
                  def_tueDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(def_tueTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==def_tueTotalEmp[i].shiftTime){
                  def_tueDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(def_tueTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==def_tueTotalEmp[i].shiftTime && (def_tueTotalEmp[i].totalEmp!=0 || def_tueTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"}
                  def_tueEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"})
                  }
                  else if(def_tueTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==def_tueTotalEmp[i].shiftTime){
                    def_tueEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"})
                  }
                  else if(def_tueTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==def_tueTotalEmp[i].shiftTime && (def_tueTotalEmp[i].totalEmp!=0 || def_tueTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"}
                    def_tue_MD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"})
                    }
                    else if(def_tueTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==def_tueTotalEmp[i].shiftTime){
                      def_tue_MD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"})
                    }
                    else if(def_tueTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==def_tueTotalEmp[i].shiftTime && (def_tueTotalEmp[i].totalEmp!=0 || def_tueTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"}
                      def_tue_DE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"})
                        // allDayData1.push(this.addShiftData)
                      }
                      else if(def_tueTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==def_tueTotalEmp[i].shiftTime){
                        def_tue_DE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"})
                        // allDayData1.push(this.addShiftData)
                      }
                      else if(def_tueTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==def_tueTotalEmp[i].shiftTime && (def_tueTotalEmp[i].totalEmp!=0 || def_tueTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"}
                        def_tue_EM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"})
                        }
                        else if(def_tueTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==def_tueTotalEmp[i].shiftTime){
                          def_tue_EM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_tueTotalEmp[i].totalEmp,"day":"Tue"})
                        }
             }

        }

      }

      let def_allShiftTueMid=[];let def_allShiftTueDay=[];let def_allShiftTueEve=[]
      let def_finalTueMidData;let def_finalTueDayData;let def_finalTueEveData
      let def_allShiftTueMD=[];let def_allShiftTueDE=[];let def_allShiftTueEM=[]
      let def_finalTueMDData;let def_finalTueDEData;let def_finalTueEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          def_allShiftTueMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftTueMid.length;j++){
        this.addShiftData={"shiftTime":def_allShiftTueMid[j].shiftTime,"totalEmp":0,"day":"Tue"}
        def_tueMid.push(this.addShiftData)
      }
      def_finalTueMidData=def_tueMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          def_allShiftTueDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftTueDay.length;j++){
        this.addShiftData={"shiftTime":def_allShiftTueDay[j].shiftTime,"totalEmp":0,"day":"Tue"}
        def_tueDay.push(this.addShiftData)
      }
      def_finalTueDayData=  def_tueDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          def_allShiftTueEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftTueEve.length;j++){
        this.addShiftData={"shiftTime":def_allShiftTueEve[j].shiftTime,"totalEmp":0,"day":"Tue"}
        def_tueEve.push(this.addShiftData)
      }
      def_finalTueEveData=def_tueEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)


            //Mid-Day
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='4' ){
                allShiftSunMD.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftTueMD.length;j++){
              this.addShiftData={"shiftTime":def_allShiftTueMD[j].shiftTime,"totalEmp":0,"day":"Tue"}
              def_tue_MD.push(this.addShiftData)
            }
            def_finalTueMDData=def_tue_MD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

            //Day-Eve
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='5' ){
                def_allShiftTueDE.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftTueDE.length;j++){
              this.addShiftData={"shiftTime":def_allShiftTueDE[j].shiftTime,"totalEmp":0,"day":"Tue"}
              def_tue_DE.push(this.addShiftData)
            }
            def_finalTueDEData=def_tue_DE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

            //Mid-Eve
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='6' ){
                def_allShiftTueEM.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftTueEM.length;j++){
              this.addShiftData={"shiftTime":def_allShiftTueEM[j].shiftTime,"totalEmp":0,"day":"Tue"}
              def_tue_EM.push(this.addShiftData)
            }
            def_finalTueEMData=def_tue_EM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)


    //Default Wed
    let def_wed=[]; let def_wedDay=[];let def_wedEve=[];let def_wedMid=[]; let def_wed_MD=[];let def_wed_DE=[];let def_wed_EM=[]
    for(var i=0;i<def_wedTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==def_wedTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==def_wedTotalEmp[i].shiftTime)
            {
              if(def_wedTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==def_wedTotalEmp[i].shiftTime && (def_wedTotalEmp[i].totalEmp!=0 || def_wedTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"}
                def_wedMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"})
              }
              else if(def_wedTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==def_wedTotalEmp[i].shiftTime){
                def_wedMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"})
              }
              else if(def_wedTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==def_wedTotalEmp[i].shiftTime && (def_wedTotalEmp[i].totalEmp!=0 || def_wedTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"}
                  def_wedDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(def_wedTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==def_wedTotalEmp[i].shiftTime){
                  def_wedDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(def_wedTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==def_wedTotalEmp[i].shiftTime && (def_wedTotalEmp[i].totalEmp!=0 || def_wedTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"}
                  def_wedEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"})
                  }
                  else if(def_wedTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==def_wedTotalEmp[i].shiftTime){
                    def_wedEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"})
                  }
                  else if(def_wedTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==def_wedTotalEmp[i].shiftTime && (def_wedTotalEmp[i].totalEmp!=0 || def_wedTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"}
                    def_wed_MD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"})
                    }
                    else if(def_wedTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==def_wedTotalEmp[i].shiftTime){
                      def_wed_MD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"})
                    }
                    else if(def_wedTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==def_wedTotalEmp[i].shiftTime && (def_wedTotalEmp[i].totalEmp!=0 || def_wedTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"}
                      def_wed_DE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"})
                        // allDayData1.push(this.addShiftData)
                      }
                      else if(def_wedTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==def_wedTotalEmp[i].shiftTime){
                        def_wed_DE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"})
                        // allDayData1.push(this.addShiftData)
                      }
                      else if(def_wedTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==def_wedTotalEmp[i].shiftTime && (def_wedTotalEmp[i].totalEmp!=0 || def_wedTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"}
                        def_wed_EM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"})
                        }
                        else if(def_wedTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==def_wedTotalEmp[i].shiftTime){
                          def_wed_EM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_wedTotalEmp[i].totalEmp,"day":"Wed"})
                        }
             }

        }

      }

      let def_allShiftWedMid=[];let def_allShiftWedDay=[];let def_allShiftWedEve=[]
      let def_finalWedMidData;let def_finalWedDayData;let def_finalWedEveData
      let def_allShiftWedMD=[];let def_allShiftWedDE=[];let def_allShiftWedEM=[]
      let def_finalWedMDData;let def_finalWedDEData;let def_finalWedEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          def_allShiftWedMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftWedMid.length;j++){
        this.addShiftData={"shiftTime":def_allShiftWedMid[j].shiftTime,"totalEmp":0,"day":"Wed"}
        def_wedMid.push(this.addShiftData)
      }
      def_finalWedMidData=def_wedMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          def_allShiftWedDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftWedDay.length;j++){
        this.addShiftData={"shiftTime":def_allShiftWedDay[j].shiftTime,"totalEmp":0,"day":"Wed"}
        def_wedDay.push(this.addShiftData)
      }
      def_finalWedDayData=  def_wedDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          def_allShiftWedEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftWedEve.length;j++){
        this.addShiftData={"shiftTime":def_allShiftWedEve[j].shiftTime,"totalEmp":0,"day":"Wed"}
        def_wedEve.push(this.addShiftData)
      }
      def_finalWedEveData=def_wedEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)


            //Mid-Day
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='4' ){
                allShiftSunMD.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftWedMD.length;j++){
              this.addShiftData={"shiftTime":def_allShiftWedMD[j].shiftTime,"totalEmp":0,"day":"Wed"}
              def_wed_MD.push(this.addShiftData)
            }
            def_finalWedMDData=def_wed_MD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

            //Day-Eve
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='5' ){
                def_allShiftWedDE.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftWedDE.length;j++){
              this.addShiftData={"shiftTime":def_allShiftWedDE[j].shiftTime,"totalEmp":0,"day":"Wed"}
              def_wed_DE.push(this.addShiftData)
            }
            def_finalWedDEData=def_wed_DE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

            //Mid-Eve
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='6' ){
                def_allShiftWedEM.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftWedEM.length;j++){
              this.addShiftData={"shiftTime":def_allShiftWedEM[j].shiftTime,"totalEmp":0,"day":"Wed"}
              def_wed_EM.push(this.addShiftData)
            }
            def_finalWedEMData=def_wed_EM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)


    //Default Thu
    let def_thu=[]; let def_thuDay=[];let def_thuEve=[];let def_thuMid=[]; let def_thu_MD=[];let def_thu_DE=[];let def_thu_EM=[]
    for(var i=0;i<def_thuTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==def_thuTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==def_thuTotalEmp[i].shiftTime)
            {
              if(def_thuTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==def_thuTotalEmp[i].shiftTime && (def_thuTotalEmp[i].totalEmp!=0 || def_thuTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"}
                def_thuMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"})
              }
              else if(def_thuTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==def_thuTotalEmp[i].shiftTime){
                def_thuMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"})
              }
              else if(def_thuTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==def_thuTotalEmp[i].shiftTime && (def_thuTotalEmp[i].totalEmp!=0 || def_thuTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"}
                  def_thuDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(def_thuTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==def_thuTotalEmp[i].shiftTime){
                  def_thuDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(def_thuTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==def_thuTotalEmp[i].shiftTime && (def_thuTotalEmp[i].totalEmp!=0 || def_thuTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"}
                  def_thuEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"})
                  }
                  else if(def_thuTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==def_thuTotalEmp[i].shiftTime){
                    def_thuEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"})
                  }
                  else if(def_thuTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==def_thuTotalEmp[i].shiftTime && (def_thuTotalEmp[i].totalEmp!=0 || def_thuTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"}
                    def_thu_MD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"})
                    }
                    else if(def_thuTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==def_thuTotalEmp[i].shiftTime){
                      def_thu_MD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"})
                    }
                    else if(def_thuTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==def_thuTotalEmp[i].shiftTime && (def_thuTotalEmp[i].totalEmp!=0 || def_thuTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"}
                      def_thu_DE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"})
                        // allDayData1.push(this.addShiftData)
                      }
                      else if(def_thuTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==def_thuTotalEmp[i].shiftTime){
                        def_thu_DE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"})
                        // allDayData1.push(this.addShiftData)
                      }
                      else if(def_thuTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==def_thuTotalEmp[i].shiftTime && (def_thuTotalEmp[i].totalEmp!=0 || def_thuTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"}
                        def_thu_EM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"})
                        }
                        else if(def_thuTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==def_thuTotalEmp[i].shiftTime){
                          def_thu_EM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_thuTotalEmp[i].totalEmp,"day":"Thu"})
                        }
             }

        }

      }

      let def_allShiftThuMid=[];let def_allShiftThuDay=[];let def_allShiftThuEve=[]
      let def_finalThuMidData;let def_finalThuDayData;let def_finalThuEveData
      let def_allShiftThuMD=[];let def_allShiftThuDE=[];let def_allShiftThuEM=[]
      let def_finalThuMDData;let def_finalThuDEData;let def_finalThuEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          def_allShiftThuMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftThuMid.length;j++){
        this.addShiftData={"shiftTime":def_allShiftThuMid[j].shiftTime,"totalEmp":0,"day":"Thu"}
        def_thuMid.push(this.addShiftData)
      }
      def_finalThuMidData=def_thuMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          def_allShiftThuDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftThuDay.length;j++){
        this.addShiftData={"shiftTime":def_allShiftThuDay[j].shiftTime,"totalEmp":0,"day":"Thu"}
        def_thuDay.push(this.addShiftData)
      }
      def_finalThuDayData=  def_thuDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          def_allShiftThuEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftThuEve.length;j++){
        this.addShiftData={"shiftTime":def_allShiftThuEve[j].shiftTime,"totalEmp":0,"day":"Thu"}
        def_thuEve.push(this.addShiftData)
      }
      def_finalThuEveData=def_thuEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)


            //Mid-Day
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='4' ){
                allShiftSunMD.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftThuMD.length;j++){
              this.addShiftData={"shiftTime":def_allShiftThuMD[j].shiftTime,"totalEmp":0,"day":"Thu"}
              def_thu_MD.push(this.addShiftData)
            }
            def_finalThuMDData=def_thu_MD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

            //Day-Eve
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='5' ){
                def_allShiftThuDE.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftThuDE.length;j++){
              this.addShiftData={"shiftTime":def_allShiftThuDE[j].shiftTime,"totalEmp":0,"day":"Thu"}
              def_thu_DE.push(this.addShiftData)
            }
            def_finalThuDEData=def_thu_DE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

            //Mid-Eve
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='6' ){
                def_allShiftThuEM.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftThuEM.length;j++){
              this.addShiftData={"shiftTime":def_allShiftThuEM[j].shiftTime,"totalEmp":0,"day":"Thu"}
              def_thu_EM.push(this.addShiftData)
            }
            def_finalThuEMData=def_thu_EM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)


    //Default Fri
    let def_fri=[]; let def_friDay=[];let def_friEve=[];let def_friMid=[]; let def_fri_MD=[];let def_fri_DE=[];let def_fri_EM=[]
    for(var i=0;i<def_friTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==def_friTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==def_friTotalEmp[i].shiftTime)
            {
              if(def_friTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==def_friTotalEmp[i].shiftTime && (def_friTotalEmp[i].totalEmp!=0 || def_friTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"}
                def_friMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"})
              }
              else if(def_friTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==def_friTotalEmp[i].shiftTime){
                def_friMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"})
              }
              else if(def_friTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==def_friTotalEmp[i].shiftTime && (def_friTotalEmp[i].totalEmp!=0 || def_friTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"}
                  def_friDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(def_friTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==def_friTotalEmp[i].shiftTime){
                  def_friDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(def_friTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==def_friTotalEmp[i].shiftTime && (def_friTotalEmp[i].totalEmp!=0 || def_friTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"}
                  def_friEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"})
                  }
                  else if(def_friTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==def_friTotalEmp[i].shiftTime){
                    def_friEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"})
                  }
                  else if(def_friTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==def_friTotalEmp[i].shiftTime && (def_friTotalEmp[i].totalEmp!=0 || def_friTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"}
                    def_fri_MD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"})
                    }
                    else if(def_friTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==def_friTotalEmp[i].shiftTime){
                      def_fri_MD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"})
                    }
                    else if(def_friTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==def_friTotalEmp[i].shiftTime && (def_friTotalEmp[i].totalEmp!=0 || def_friTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"}
                      def_fri_DE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"})
                        // allDayData1.push(this.addShiftData)
                      }
                      else if(def_friTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==def_friTotalEmp[i].shiftTime){
                        def_fri_DE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"})
                        // allDayData1.push(this.addShiftData)
                      }
                      else if(def_friTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==def_friTotalEmp[i].shiftTime && (def_friTotalEmp[i].totalEmp!=0 || def_friTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"}
                        def_fri_EM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"})
                        }
                        else if(def_friTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==def_friTotalEmp[i].shiftTime){
                          def_fri_EM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_friTotalEmp[i].totalEmp,"day":"Fri"})
                        }
             }

        }

      }

      let def_allShiftFriMid=[];let def_allShiftFriDay=[];let def_allShiftFriEve=[]
      let def_finalFriMidData;let def_finalFriDayData;let def_finalFriEveData
      let def_allShiftFriMD=[];let def_allShiftFriDE=[];let def_allShiftFriEM=[]
      let def_finalFriMDData;let def_finalFriDEData;let def_finalFriEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          def_allShiftFriMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftFriMid.length;j++){
        this.addShiftData={"shiftTime":def_allShiftFriMid[j].shiftTime,"totalEmp":0,"day":"Fri"}
        def_friMid.push(this.addShiftData)
      }
      def_finalFriMidData=def_friMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          def_allShiftFriDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftFriDay.length;j++){
        this.addShiftData={"shiftTime":def_allShiftFriDay[j].shiftTime,"totalEmp":0,"day":"Fri"}
        def_friDay.push(this.addShiftData)
      }
      def_finalFriDayData=  def_friDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          def_allShiftFriEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftFriEve.length;j++){
        this.addShiftData={"shiftTime":def_allShiftFriEve[j].shiftTime,"totalEmp":0,"day":"Fri"}
        def_friEve.push(this.addShiftData)
      }
      def_finalFriEveData=def_friEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)


            //Mid-Day
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='4' ){
                allShiftSunMD.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftFriMD.length;j++){
              this.addShiftData={"shiftTime":def_allShiftFriMD[j].shiftTime,"totalEmp":0,"day":"Fri"}
              def_fri_MD.push(this.addShiftData)
            }
            def_finalFriMDData=def_fri_MD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

            //Day-Eve
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='5' ){
                def_allShiftFriDE.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftFriDE.length;j++){
              this.addShiftData={"shiftTime":def_allShiftFriDE[j].shiftTime,"totalEmp":0,"day":"Fri"}
              def_fri_DE.push(this.addShiftData)
            }
            def_finalFriDEData=def_fri_DE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

            //Mid-Eve
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='6' ){
                def_allShiftFriEM.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftFriEM.length;j++){
              this.addShiftData={"shiftTime":def_allShiftFriEM[j].shiftTime,"totalEmp":0,"day":"Fri"}
              def_fri_EM.push(this.addShiftData)
            }
            def_finalFriEMData=def_fri_EM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)


    //Default Sat
    let def_sat=[]; let def_satDay=[];let def_satEve=[];let def_satMid=[]; let def_sat_MD=[];let def_sat_DE=[];let def_sat_EM=[]
    for(var i=0;i<def_satTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==def_satTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==def_satTotalEmp[i].shiftTime)
            {
              if(def_satTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==def_satTotalEmp[i].shiftTime && (def_satTotalEmp[i].totalEmp!=0 || def_satTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"}
                def_satMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"})
              }
              else if(def_satTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==def_satTotalEmp[i].shiftTime){
                def_satMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"})
              }
              else if(def_satTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==def_satTotalEmp[i].shiftTime && (def_satTotalEmp[i].totalEmp!=0 || def_satTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"}
                  def_satDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(def_satTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==def_satTotalEmp[i].shiftTime){
                  def_satDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(def_satTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==def_satTotalEmp[i].shiftTime && (def_satTotalEmp[i].totalEmp!=0 || def_satTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"}
                  def_satEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"})
                  }
                  else if(def_satTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==def_satTotalEmp[i].shiftTime){
                    def_satEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"})
                  }
                  else if(def_satTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==def_satTotalEmp[i].shiftTime && (def_satTotalEmp[i].totalEmp!=0 || def_satTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"}
                    def_sat_MD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"})
                    }
                    else if(def_satTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==def_satTotalEmp[i].shiftTime){
                      def_sat_MD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"})
                    }
                    else if(def_satTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==def_satTotalEmp[i].shiftTime && (def_satTotalEmp[i].totalEmp!=0 || def_satTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"}
                      def_sat_DE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"})
                        // allDayData1.push(this.addShiftData)
                      }
                      else if(def_satTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==def_satTotalEmp[i].shiftTime){
                        def_sat_DE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"})
                        // allDayData1.push(this.addShiftData)
                      }
                      else if(def_satTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==def_satTotalEmp[i].shiftTime && (def_satTotalEmp[i].totalEmp!=0 || def_satTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"}
                        def_sat_EM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"})
                        }
                        else if(def_satTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==def_satTotalEmp[i].shiftTime){
                          def_sat_EM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_satTotalEmp[i].totalEmp,"day":"Sat"})
                        }
             }

        }

      }

      let def_allShiftSatMid=[];let def_allShiftSatDay=[];let def_allShiftSatEve=[]
      let def_finalSatMidData;let def_finalSatDayData;let def_finalSatEveData
      let def_allShiftSatMD=[];let def_allShiftSatDE=[];let def_allShiftSatEM=[]
      let def_finalSatMDData;let def_finalSatDEData;let def_finalSatEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          def_allShiftSatMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftSatMid.length;j++){
        this.addShiftData={"shiftTime":def_allShiftSatMid[j].shiftTime,"totalEmp":0,"day":"Sat"}
        def_satMid.push(this.addShiftData)
      }
      def_finalSatMidData=def_satMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          def_allShiftSatDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftSatDay.length;j++){
        this.addShiftData={"shiftTime":def_allShiftSatDay[j].shiftTime,"totalEmp":0,"day":"Sat"}
        def_satDay.push(this.addShiftData)
      }
      def_finalSatDayData=  def_satDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          def_allShiftSatEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftSatEve.length;j++){
        this.addShiftData={"shiftTime":def_allShiftSatEve[j].shiftTime,"totalEmp":0,"day":"Sat"}
        def_satEve.push(this.addShiftData)
      }
      def_finalSatEveData=def_satEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)


            //Mid-Day
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='4' ){
                allShiftSunMD.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftSatMD.length;j++){
              this.addShiftData={"shiftTime":def_allShiftSatMD[j].shiftTime,"totalEmp":0,"day":"Sat"}
              def_sat_MD.push(this.addShiftData)
            }
            def_finalSatMDData=def_sat_MD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

            //Day-Eve
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='5' ){
                def_allShiftSatDE.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftSatDE.length;j++){
              this.addShiftData={"shiftTime":def_allShiftSatDE[j].shiftTime,"totalEmp":0,"day":"Sat"}
              def_sat_DE.push(this.addShiftData)
            }
            def_finalSatDEData=def_sat_DE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

            //Mid-Eve
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='6' ){
                def_allShiftSatEM.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftSatEM.length;j++){
              this.addShiftData={"shiftTime":def_allShiftSatEM[j].shiftTime,"totalEmp":0,"day":"Sat"}
              def_sat_EM.push(this.addShiftData)
            }
            def_finalSatEMData=def_sat_EM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

    //Default Sun
    let def_sun=[]; let def_sunDay=[];let def_sunEve=[];let def_sunMid=[]; let def_sun_MD=[];let def_sun_DE=[];let def_sun_EM=[]
    for(var i=0;i<def_sunTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==def_sunTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==def_sunTotalEmp[i].shiftTime)
            {
              if(def_sunTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==def_sunTotalEmp[i].shiftTime && (def_sunTotalEmp[i].totalEmp!=0 || def_sunTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"}
                def_sunMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"})
              }
              else if(def_sunTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==def_sunTotalEmp[i].shiftTime){
                def_sunMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"})
              }
              else if(def_sunTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==def_sunTotalEmp[i].shiftTime && (def_sunTotalEmp[i].totalEmp!=0 || def_sunTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"}
                  def_sunDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(def_sunTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==def_sunTotalEmp[i].shiftTime){
                  def_sunDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(def_sunTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==def_sunTotalEmp[i].shiftTime && (def_sunTotalEmp[i].totalEmp!=0 || def_sunTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"}
                  def_sunEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"})
                  }
                  else if(def_sunTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==def_sunTotalEmp[i].shiftTime){
                    def_sunEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"})
                  }
                  else if(def_sunTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==def_sunTotalEmp[i].shiftTime && (def_sunTotalEmp[i].totalEmp!=0 || def_sunTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"}
                    def_sun_MD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"})
                    }
                    else if(def_sunTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==def_sunTotalEmp[i].shiftTime){
                      def_sun_MD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"})
                    }
                    else if(def_sunTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==def_sunTotalEmp[i].shiftTime && (def_sunTotalEmp[i].totalEmp!=0 || def_sunTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"}
                      def_sun_DE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"})
                        // allDayData1.push(this.addShiftData)
                      }
                      else if(def_sunTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==def_sunTotalEmp[i].shiftTime){
                        def_sun_DE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"})
                        // allDayData1.push(this.addShiftData)
                      }
                      else if(def_sunTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==def_sunTotalEmp[i].shiftTime && (def_sunTotalEmp[i].totalEmp!=0 || def_sunTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"}
                        def_sun_EM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"})
                        }
                        else if(def_sunTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==def_sunTotalEmp[i].shiftTime){
                          def_sun_EM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":def_sunTotalEmp[i].totalEmp,"day":"Sun"})
                        }
             }

        }

      }

      let def_allShiftSunMid=[];let def_allShiftSunDay=[];let def_allShiftSunEve=[]
      let def_finalSunMidData;let def_finalSunDayData;let def_finalSunEveData
      let def_allShiftSunMD=[];let def_allShiftSunDE=[];let def_allShiftSunEM=[]
      let def_finalSunMDData;let def_finalSunDEData;let def_finalSunEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          def_allShiftSunMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftSunMid.length;j++){
        this.addShiftData={"shiftTime":def_allShiftSunMid[j].shiftTime,"totalEmp":0,"day":"Sun"}
        def_sunMid.push(this.addShiftData)
      }
      def_finalSunMidData=def_sunMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          def_allShiftSunDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftSunDay.length;j++){
        this.addShiftData={"shiftTime":def_allShiftSunDay[j].shiftTime,"totalEmp":0,"day":"Sun"}
        def_sunDay.push(this.addShiftData)
      }
      def_finalSunDayData=  def_sunDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          def_allShiftSunEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<def_allShiftSunEve.length;j++){
        this.addShiftData={"shiftTime":def_allShiftSunEve[j].shiftTime,"totalEmp":0,"day":"Sun"}
        def_sunEve.push(this.addShiftData)
      }
      def_finalSunEveData=def_sunEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)


            //Mid-Day
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='4' ){
                allShiftSunMD.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftSunMD.length;j++){
              this.addShiftData={"shiftTime":def_allShiftSunMD[j].shiftTime,"totalEmp":0,"day":"Sun"}
              def_sun_MD.push(this.addShiftData)
            }
            def_finalSunMDData=def_sun_MD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

            //Day-Eve
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='5' ){
                def_allShiftSunDE.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftSunDE.length;j++){
              this.addShiftData={"shiftTime":def_allShiftSunDE[j].shiftTime,"totalEmp":0,"day":"Sun"}
              def_sun_DE.push(this.addShiftData)
            }
            def_finalSunDEData=def_sun_DE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

            //Mid-Eve
            for(var i=0;i<this.allShiftName.length;i++){
              if(this.allShiftName[i].shiftCategory=='6' ){
                def_allShiftSunEM.push(this.allShiftName[i])
              }
            }
            for(var j=0;j<def_allShiftSunEM.length;j++){
              this.addShiftData={"shiftTime":def_allShiftSunEM[j].shiftTime,"totalEmp":0,"day":"Sun"}
              def_sun_EM.push(this.addShiftData)
            }
            def_finalSunEMData=def_sun_EM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)


this.generatedEmpData.SUN_MID=this.sun_mid
this.generatedEmpData.SUN_DAY=this.sun_day
this.generatedEmpData.SUN_EVE=this.sun_eve
this.generatedEmpData.SUN_MID_DAY=this.sun_mid_day
this.generatedEmpData.SUN_DAY_EVE=this.sun_day_eve
this.generatedEmpData.SUN_EVE_MID=this.sun_eve_mid
this.generatedEmpData.MON_MID=this.mon_mid
this.generatedEmpData.MON_DAY=this.mon_day
this.generatedEmpData.MON_EVE=this.mon_eve
this.generatedEmpData.MON_MID_DAY=this.mon_mid_day
this.generatedEmpData.MON_DAY_EVE=this.mon_day_eve
this.generatedEmpData.MON_EVE_MID=this.mon_eve_mid
this.generatedEmpData.TUE_MID=this.tue_mid
this.generatedEmpData.TUE_DAY=this.tue_day
// console.log(this.tue_mid)
this.generatedEmpData.TUE_EVE=this.tue_eve
this.generatedEmpData.TUE_MID_DAY=this.tue_mid_day
this.generatedEmpData.TUE_DAY_EVE=this.tue_day_eve
this.generatedEmpData.TUE_EVE_MID=this.tue_eve_mid
this.generatedEmpData.WED_MID=this.wed_mid
this.generatedEmpData.WED_DAY=this.wed_day
this.generatedEmpData.WED_EVE=this.wed_eve
this.generatedEmpData.WED_MID_DAY=this.wed_mid_day
this.generatedEmpData.WED_DAY_EVE=this.wed_day_eve
this.generatedEmpData.WED_EVE_MID=this.wed_eve_mid
this.generatedEmpData.THU_MID=this.thu_mid
this.generatedEmpData.THU_DAY=this.thu_day
this.generatedEmpData.THU_EVE=this.thu_eve
this.generatedEmpData.THU_MID_DAY=this.thu_mid_day
this.generatedEmpData.THU_DAY_EVE=this.thu_day_eve
this.generatedEmpData.THU_EVE_MID=this.thu_eve_mid
this.generatedEmpData.FRI_MID=this.fri_mid
this.generatedEmpData.FRI_DAY=this.fri_day
this.generatedEmpData.FRI_EVE=this.fri_eve
this.generatedEmpData.FRI_MID_DAY=this.fri_mid_day
this.generatedEmpData.FRI_DAY_EVE=this.fri_day_eve
this.generatedEmpData.FRI_EVE_MID=this.fri_eve_mid
this.generatedEmpData.SAT_MID=this.sat_mid
this.generatedEmpData.SAT_DAY=this.sat_day
this.generatedEmpData.SAT_EVE=this.sat_eve
this.generatedEmpData.SAT_MID_DAY=this.sat_mid_day
this.generatedEmpData.SAT_DAY_EVE=this.sat_day_eve
this.generatedEmpData.SAT_EVE_MID=this.sat_eve_mid
// console.log(this.mon_day)
// console.log(this.sundAy)
this.SunDayGenerated=[]; this.SunDayRequired=[];
this.SunDayRequired.push(this.requiredEmpData.SUN_MID)
this.SunDayRequired.push(this.requiredEmpData.SUN_DAY)
this.SunDayRequired.push(this.requiredEmpData.SUN_EVE)
this.SunDayRequired.push(this.requiredEmpData.SUN_MID_DAY)
this.SunDayRequired.push(this.requiredEmpData.SUN_DAY_EVE)
this.SunDayRequired.push(this.requiredEmpData.SUN_EVE_MID)
this.SunDayGenerated.push(this.generatedEmpData.SUN_MID)
this.SunDayGenerated.push(this.generatedEmpData.SUN_DAY)
this.SunDayGenerated.push(this.generatedEmpData.SUN_EVE)
this.SunDayGenerated.push(this.generatedEmpData.SUN_MID_DAY)
this.SunDayGenerated.push(this.generatedEmpData.SUN_DAY_EVE)
this.SunDayGenerated.push(this.generatedEmpData.SUN_EVE_MID)
this.diffSunMid=this.SunDayGenerated[0] + - + this.SunDayRequired[0]
this.diffSunDay=this.SunDayGenerated[1] + - + this.SunDayRequired[1]
this.diffSunEve=this.SunDayGenerated[2] + - + this.SunDayRequired[2]
this.diffSunMidDay=this.SunDayGenerated[3] + - + this.SunDayRequired[3]
this.diffSunDayEve=this.SunDayGenerated[4] + - + this.SunDayRequired[4]
this.diffSunEveMid=this.SunDayGenerated[5] + - + this.SunDayRequired[5]
this.totalSunRequired= this.SunDayRequired[0] + + + this.SunDayRequired[1] + + + this.SunDayRequired[2]+ + +this.SunDayRequired[3] + + + this.SunDayRequired[4] + + + this.SunDayRequired[5]
this.totalSunGenerated= this.SunDayGenerated[0] + + + this.SunDayGenerated[1] + + + this.SunDayGenerated[2]+ + +this.SunDayGenerated[3] + + + this.SunDayGenerated[4] + + + this.SunDayGenerated[5]
this.totalSundiff=this.totalSunGenerated+ - + this.totalSunRequired

this.MonDayGenerated=[]; this.MonDayRequired=[];
this.MonDayRequired.push(this.requiredEmpData.MON_MID)
this.MonDayRequired.push(this.requiredEmpData.MON_DAY)
this.MonDayRequired.push(this.requiredEmpData.MON_EVE)
this.MonDayGenerated.push(this.generatedEmpData.MON_MID)
this.MonDayGenerated.push(this.generatedEmpData.MON_DAY)
this.MonDayGenerated.push(this.generatedEmpData.MON_EVE)
this.MonDayRequired.push(this.requiredEmpData.MON_MID_DAY)
this.MonDayRequired.push(this.requiredEmpData.MON_DAY_EVE)
this.MonDayRequired.push(this.requiredEmpData.MON_EVE_MID)
this.MonDayGenerated.push(this.generatedEmpData.MON_MID_DAY)
this.MonDayGenerated.push(this.generatedEmpData.MON_DAY_EVE)
this.MonDayGenerated.push(this.generatedEmpData.MON_EVE_MID)
this.diffMonMid=this.MonDayGenerated[0] + - + this.MonDayRequired[0]
this.diffMonDay=this.MonDayGenerated[1] + - + this.MonDayRequired[1]
this.diffMonEve=this.MonDayGenerated[2] + - + this.MonDayRequired[2]
this.diffMonMidDay=this.MonDayGenerated[3] + - + this.MonDayRequired[3]
this.diffMonDayEve=this.MonDayGenerated[4] + - + this.MonDayRequired[4]
this.diffMonEveMid=this.MonDayGenerated[5] + - + this.MonDayRequired[5]
this.totalMonRequired= this.MonDayRequired[0] + + + this.MonDayRequired[1] + + + this.MonDayRequired[2]+ + +this.MonDayRequired[3] + + + this.MonDayRequired[4] + + + this.MonDayRequired[5]
this.totalMonGenerated= this.MonDayGenerated[0] + + + this.MonDayGenerated[1] + + + this.MonDayGenerated[2]+ + +this.MonDayGenerated[3] + + + this.MonDayGenerated[4] + + + this.MonDayGenerated[5]
this.totalMondiff=this.totalMonGenerated+ - + this.totalMonRequired
this.TueDayGenerated=[]; this.TueDayRequired=[];
this.TueDayRequired.push(this.requiredEmpData.TUE_MID)
this.TueDayRequired.push(this.requiredEmpData.TUE_DAY)
this.TueDayRequired.push(this.requiredEmpData.TUE_EVE)
this.TueDayGenerated.push(this.generatedEmpData.TUE_MID)
this.TueDayGenerated.push(this.generatedEmpData.TUE_DAY)
this.TueDayGenerated.push(this.generatedEmpData.TUE_EVE)
this.TueDayRequired.push(this.requiredEmpData.TUE_MID_DAY)
this.TueDayRequired.push(this.requiredEmpData.TUE_DAY_EVE)
this.TueDayRequired.push(this.requiredEmpData.TUE_EVE_MID)
this.TueDayGenerated.push(this.generatedEmpData.TUE_MID_DAY)
this.TueDayGenerated.push(this.generatedEmpData.TUE_DAY_EVE)
this.TueDayGenerated.push(this.generatedEmpData.TUE_EVE_MID)
this.diffTueMid=this.TueDayGenerated[0] + - + this.TueDayRequired[0]
this.diffTueDay=this.TueDayGenerated[1] + - + this.TueDayRequired[1]
this.diffTueEve=this.TueDayGenerated[2] + - + this.TueDayRequired[2]
this.diffTueMidDay=this.TueDayGenerated[3] + - + this.TueDayRequired[3]
this.diffTueDayEve=this.TueDayGenerated[4] + - + this.TueDayRequired[4]
this.diffTueEveMid=this.TueDayGenerated[5] + - + this.TueDayRequired[5]
this.totalTueRequired= this.TueDayRequired[0] + + + this.TueDayRequired[1] + + + this.TueDayRequired[2]+ + +this.TueDayRequired[3] + + + this.TueDayRequired[4] + + + this.TueDayRequired[5]
this.totalTueGenerated= this.TueDayGenerated[0] + + + this.TueDayGenerated[1] + + + this.TueDayGenerated[2]+ + +this.TueDayGenerated[3] + + + this.TueDayGenerated[4] + + + this.TueDayGenerated[5]
this.totalTuediff=this.totalTueGenerated+ - + this.totalTueRequired
// console.log(this.generatedEmpData.TUE_MID)
this.WedDayGenerated=[]; this.WedDayRequired=[];
this.WedDayRequired.push(this.requiredEmpData.WED_MID)
this.WedDayRequired.push(this.requiredEmpData.WED_DAY)
this.WedDayRequired.push(this.requiredEmpData.WED_EVE)
this.WedDayGenerated.push(this.generatedEmpData.WED_MID)
this.WedDayGenerated.push(this.generatedEmpData.WED_DAY)
this.WedDayGenerated.push(this.generatedEmpData.WED_EVE)
this.WedDayRequired.push(this.requiredEmpData.WED_MID_DAY)
this.WedDayRequired.push(this.requiredEmpData.WED_DAY_EVE)
this.WedDayRequired.push(this.requiredEmpData.WED_EVE_MID)
this.WedDayGenerated.push(this.generatedEmpData.WED_MID_DAY)
this.WedDayGenerated.push(this.generatedEmpData.WED_DAY_EVE)
this.WedDayGenerated.push(this.generatedEmpData.WED_EVE_MID)
this.diffWedMid=this.WedDayGenerated[0] + - + this.WedDayRequired[0]
this.diffWedDay=this.WedDayGenerated[1] + - + this.WedDayRequired[1]
this.diffWedEve=this.WedDayGenerated[2] + - + this.WedDayRequired[2]
this.diffWedMidDay=this.WedDayGenerated[3] + - + this.WedDayRequired[3]
this.diffWedDayEve=this.WedDayGenerated[4] + - + this.WedDayRequired[4]
this.diffWedEveMid=this.WedDayGenerated[5] + - + this.WedDayRequired[5]
this.totalWedRequired= this.WedDayRequired[0] + + + this.WedDayRequired[1] + + + this.WedDayRequired[2]+ + +this.WedDayRequired[3] + + + this.WedDayRequired[4] + + + this.WedDayRequired[5]
this.totalWedGenerated= this.WedDayGenerated[0] + + + this.WedDayGenerated[1] + + + this.WedDayGenerated[2]+ + +this.WedDayGenerated[3] + + + this.WedDayGenerated[4] + + + this.WedDayGenerated[5]
this.totalWeddiff=this.totalWedGenerated+ - + this.totalWedRequired
// console.log(this.WedDayGenerated)
this.ThuDayGenerated=[]; this.ThuDayRequired=[];
this.ThuDayRequired.push(this.requiredEmpData.THU_MID)
this.ThuDayRequired.push(this.requiredEmpData.THU_DAY)
this.ThuDayRequired.push(this.requiredEmpData.THU_EVE)
this.ThuDayGenerated.push(this.generatedEmpData.THU_MID)
this.ThuDayGenerated.push(this.generatedEmpData.THU_DAY)
this.ThuDayGenerated.push(this.generatedEmpData.THU_EVE)
this.ThuDayRequired.push(this.requiredEmpData.THU_MID_DAY)
this.ThuDayRequired.push(this.requiredEmpData.THU_DAY_EVE)
this.ThuDayRequired.push(this.requiredEmpData.THU_EVE_MID)
this.ThuDayGenerated.push(this.generatedEmpData.THU_MID_DAY)
this.ThuDayGenerated.push(this.generatedEmpData.THU_DAY_EVE)
this.ThuDayGenerated.push(this.generatedEmpData.THU_EVE_MID)
this.diffThuMid=this.ThuDayGenerated[0] + - + this.ThuDayRequired[0]
this.diffThuDay=this.ThuDayGenerated[1] + - + this.ThuDayRequired[1]
this.diffThuEve=this.ThuDayGenerated[2] + - + this.ThuDayRequired[2]
this.diffThuMidDay=this.ThuDayGenerated[3] + - + this.ThuDayRequired[3]
this.diffThuDayEve=this.ThuDayGenerated[4] + - + this.ThuDayRequired[4]
this.diffThuEveMid=this.ThuDayGenerated[5] + - + this.ThuDayRequired[5]
this.totalThuRequired= this.ThuDayRequired[0] + + + this.ThuDayRequired[1] + + + this.ThuDayRequired[2]+ + +this.ThuDayRequired[3] + + + this.ThuDayRequired[4] + + + this.ThuDayRequired[5]
this.totalThuGenerated= this.ThuDayGenerated[0] + + + this.ThuDayGenerated[1] + + + this.ThuDayGenerated[2]+ + +this.ThuDayGenerated[3] + + + this.ThuDayGenerated[4] + + + this.ThuDayGenerated[5]
this.totalThudiff=this.totalThuGenerated+ - + this.totalThuRequired
this.FriDayGenerated=[]; this.FriDayRequired=[];
this.FriDayRequired.push(this.requiredEmpData.FRI_MID)
this.FriDayRequired.push(this.requiredEmpData.FRI_DAY)
this.FriDayRequired.push(this.requiredEmpData.FRI_EVE)
this.FriDayGenerated.push(this.generatedEmpData.FRI_MID)
this.FriDayGenerated.push(this.generatedEmpData.FRI_DAY)
this.FriDayGenerated.push(this.generatedEmpData.FRI_EVE)
this.FriDayRequired.push(this.requiredEmpData.FRI_MID_DAY)
this.FriDayRequired.push(this.requiredEmpData.FRI_DAY_EVE)
this.FriDayRequired.push(this.requiredEmpData.FRI_EVE_MID)
this.FriDayGenerated.push(this.generatedEmpData.FRI_MID_DAY)
this.FriDayGenerated.push(this.generatedEmpData.FRI_DAY_EVE)
this.FriDayGenerated.push(this.generatedEmpData.FRI_EVE_MID)
this.diffFriMid=this.FriDayGenerated[0] + - + this.FriDayRequired[0]
this.diffFriDay=this.FriDayGenerated[1] + - + this.FriDayRequired[1]
this.diffFriEve=this.FriDayGenerated[2] + - + this.FriDayRequired[2]
this.diffFriMidDay=this.FriDayGenerated[3] + - + this.FriDayRequired[3]
this.diffFriDayEve=this.FriDayGenerated[4] + - + this.FriDayRequired[4]
this.diffFriEveMid=this.FriDayGenerated[5] + - + this.FriDayRequired[5]
this.totalFriRequired= this.FriDayRequired[0] + + + this.FriDayRequired[1] + + + this.FriDayRequired[2]+ + +this.FriDayRequired[3] + + + this.FriDayRequired[4] + + + this.FriDayRequired[5]
this.totalFriGenerated= this.FriDayGenerated[0] + + + this.FriDayGenerated[1] + + + this.FriDayGenerated[2]+ + +this.FriDayGenerated[3] + + + this.FriDayGenerated[4] + + + this.FriDayGenerated[5]
this.totalFridiff=this.totalFriGenerated+ - + this.totalFriRequired
// console.log(this.FriDayGenerated)
this.SatDayGenerated=[]; this.SatDayRequired=[];
this.SatDayRequired.push(this.requiredEmpData.SAT_MID)
this.SatDayRequired.push(this.requiredEmpData.SAT_DAY)
this.SatDayRequired.push(this.requiredEmpData.SAT_EVE)
this.SatDayGenerated.push(this.generatedEmpData.SAT_MID)
this.SatDayGenerated.push(this.generatedEmpData.SAT_DAY)
this.SatDayGenerated.push(this.generatedEmpData.SAT_EVE)
this.SatDayRequired.push(this.requiredEmpData.SAT_MID_DAY)
this.SatDayRequired.push(this.requiredEmpData.SAT_DAY_EVE)
this.SatDayRequired.push(this.requiredEmpData.SAT_EVE_MID)
this.SatDayGenerated.push(this.generatedEmpData.SAT_MID_DAY)
this.SatDayGenerated.push(this.generatedEmpData.SAT_DAY_EVE)
this.SatDayGenerated.push(this.generatedEmpData.SAT_EVE_MID)
this.diffSatMid=this.SatDayGenerated[0] + - + this.SatDayRequired[0]
this.diffSatDay=this.SatDayGenerated[1] + - + this.SatDayRequired[1]
this.diffSatEve=this.SatDayGenerated[2] + - + this.SatDayRequired[2]
this.diffSatMidDay=this.SatDayGenerated[3] + - + this.SatDayRequired[3]
this.diffSatDayEve=this.SatDayGenerated[4] + - + this.SatDayRequired[4]
this.diffSatEveMid=this.SatDayGenerated[5] + - + this.SatDayRequired[5]
this.totalSatRequired= this.SatDayRequired[0] + + + this.SatDayRequired[1] + + + this.SatDayRequired[2]+ + +this.SatDayRequired[3] + + + this.SatDayRequired[4] + + + this.SatDayRequired[5]
this.totalSatGenerated= this.SatDayGenerated[0] + + + this.SatDayGenerated[1] + + + this.SatDayGenerated[2]+ + +this.SatDayGenerated[3] + + + this.SatDayGenerated[4] + + + this.SatDayGenerated[5]
this.totalSatdiff=this.totalSatGenerated+ - + this.totalSatRequired


//Default Summary  Data
this.defGeneratedData.SUN_MID=this.def_sun_mid
this.defGeneratedData.SUN_DAY=this.def_sun_day
this.defGeneratedData.SUN_EVE=this.def_sun_eve
this.defGeneratedData.SUN_MID_DAY=this.def_sun_mid_day
this.defGeneratedData.SUN_DAY_EVE=this.def_sun_day_eve
this.defGeneratedData.SUN_EVE_MID=this.def_sun_eve_mid
this.defGeneratedData.MON_MID=this.def_mon_mid
this.defGeneratedData.MON_DAY=this.def_mon_day
this.defGeneratedData.MON_EVE=this.def_mon_eve
this.defGeneratedData.MON_MID_DAY=this.def_mon_mid_day
this.defGeneratedData.MON_DAY_EVE=this.def_mon_day_eve
this.defGeneratedData.MON_EVE_MID=this.def_mon_eve_mid
this.defGeneratedData.TUE_MID=this.def_tue_mid
this.defGeneratedData.TUE_DAY=this.def_tue_day
// console.log(this.def_tue_mid)
this.defGeneratedData.TUE_EVE=this.def_tue_eve
this.defGeneratedData.TUE_MID_DAY=this.def_tue_mid_day
this.defGeneratedData.TUE_DAY_EVE=this.def_tue_day_eve
this.defGeneratedData.TUE_EVE_MID=this.def_tue_eve_mid
this.defGeneratedData.WED_MID=this.def_wed_mid
this.defGeneratedData.WED_DAY=this.def_wed_day
this.defGeneratedData.WED_EVE=this.def_wed_eve
this.defGeneratedData.WED_MID_DAY=this.def_wed_mid_day
this.defGeneratedData.WED_DAY_EVE=this.def_wed_day_eve
this.defGeneratedData.WED_EVE_MID=this.def_wed_eve_mid
this.defGeneratedData.THU_MID=this.def_thu_mid
this.defGeneratedData.THU_DAY=this.def_thu_day
this.defGeneratedData.THU_EVE=this.def_thu_eve
this.defGeneratedData.THU_MID_DAY=this.def_thu_mid_day
this.defGeneratedData.THU_DAY_EVE=this.def_thu_day_eve
this.defGeneratedData.THU_EVE_MID=this.def_thu_eve_mid
this.defGeneratedData.FRI_MID=this.def_fri_mid
this.defGeneratedData.FRI_DAY=this.def_fri_day
this.defGeneratedData.FRI_EVE=this.def_fri_eve
this.defGeneratedData.FRI_MID_DAY=this.def_fri_mid_day
this.defGeneratedData.FRI_DAY_EVE=this.def_fri_day_eve
this.defGeneratedData.FRI_EVE_MID=this.def_fri_eve_mid
this.defGeneratedData.SAT_MID=this.def_sat_mid
this.defGeneratedData.SAT_DAY=this.def_sat_day
this.defGeneratedData.SAT_EVE=this.def_sat_eve
this.defGeneratedData.SAT_MID_DAY=this.def_sat_mid_day
this.defGeneratedData.SAT_DAY_EVE=this.def_sat_day_eve
this.defGeneratedData.SAT_EVE_MID=this.def_sat_eve_mid
this.defaultSunDayRequired=[];this.defaultSunDayGenerated=[];
this.defaultSunDayRequired.push(this.defRequiredData.SUN_MID)
this.defaultSunDayRequired.push(this.defRequiredData.SUN_DAY)
this.defaultSunDayRequired.push(this.defRequiredData.SUN_EVE)
this.defaultSunDayRequired.push(this.defRequiredData.SUN_MID_DAY)
this.defaultSunDayRequired.push(this.defRequiredData.SUN_DAY_EVE)
this.defaultSunDayRequired.push(this.defRequiredData.SUN_EVE_MID)
this.defaultSunDayGenerated.push(this.defGeneratedData.SUN_MID)
this.defaultSunDayGenerated.push(this.defGeneratedData.SUN_DAY)
this.defaultSunDayGenerated.push(this.defGeneratedData.SUN_EVE)
this.defaultSunDayGenerated.push(this.defGeneratedData.SUN_MID_DAY)
this.defaultSunDayGenerated.push(this.defGeneratedData.SUN_DAY_EVE)
this.defaultSunDayGenerated.push(this.defGeneratedData.SUN_EVE_MID)
this.defaultDiffSunMid=this.defaultSunDayGenerated[0] + - + this.defaultSunDayRequired[0]
this.defaultDiffSunDay=this.defaultSunDayGenerated[1] + - + this.defaultSunDayRequired[1]
this.defaultDiffSunEve=this.defaultSunDayGenerated[2] + - + this.defaultSunDayRequired[2]
this.defaultDiffSunMidDay=this.defaultSunDayGenerated[3] + - + this.defaultSunDayRequired[3]
this.defaultDiffSunDayEve=this.defaultSunDayGenerated[4] + - + this.defaultSunDayRequired[4]
this.defaultDiffSunEveMid=this.defaultSunDayGenerated[5] + - + this.defaultSunDayRequired[5]
this.defaultTotalSunRequired= this.defaultSunDayRequired[0] + + + this.defaultSunDayRequired[1] + + + this.defaultSunDayRequired[2]+ + + this.defaultSunDayRequired[3] + + + this.defaultSunDayRequired[4] + + + this.defaultSunDayRequired[5]
this.defaultTotalSunGenerated= this.defaultSunDayGenerated[0] + + + this.defaultSunDayGenerated[1] + + + this.defaultSunDayGenerated[2]+ + +this.defaultSunDayGenerated[3] + + + this.defaultSunDayGenerated[4] + + + this.defaultSunDayGenerated[5]
this.defaultTotalSundiff=this.defaultTotalSunGenerated+ - + this.defaultTotalSunRequired

this.defaultMonDayRequired=[];this.defaultMonDayGenerated=[];
this.defaultMonDayRequired.push(this.defRequiredData.MON_MID)
this.defaultMonDayRequired.push(this.defRequiredData.MON_DAY)
this.defaultMonDayRequired.push(this.defRequiredData.MON_EVE)
this.defaultMonDayRequired.push(this.defRequiredData.MON_MID_DAY)
this.defaultMonDayRequired.push(this.defRequiredData.MON_DAY_EVE)
this.defaultMonDayRequired.push(this.defRequiredData.MON_EVE_MID)
this.defaultMonDayGenerated.push(this.defGeneratedData.MON_MID)
this.defaultMonDayGenerated.push(this.defGeneratedData.MON_DAY)
this.defaultMonDayGenerated.push(this.defGeneratedData.MON_EVE)
this.defaultMonDayGenerated.push(this.defGeneratedData.MON_MID_DAY)
this.defaultMonDayGenerated.push(this.defGeneratedData.MON_DAY_EVE)
this.defaultMonDayGenerated.push(this.defGeneratedData.MON_EVE_MID)
this.defaultDiffMonMid=this.defaultMonDayGenerated[0] + - + this.defaultMonDayRequired[0]
this.defaultDiffMonDay=this.defaultMonDayGenerated[1] + - + this.defaultMonDayRequired[1]
this.defaultDiffMonEve=this.defaultMonDayGenerated[2] + - + this.defaultMonDayRequired[2]
this.defaultDiffMonMidDay=this.defaultMonDayGenerated[3] + - + this.defaultMonDayRequired[3]
this.defaultDiffMonDayEve=this.defaultMonDayGenerated[4] + - + this.defaultMonDayRequired[4]
this.defaultDiffMonEveMid=this.defaultMonDayGenerated[5] + - + this.defaultMonDayRequired[5]
this.defaultTotalMonRequired= this.defaultMonDayRequired[0] + + + this.defaultMonDayRequired[1] + + + this.defaultMonDayRequired[2]+ + + this.defaultMonDayRequired[3] + + + this.defaultMonDayRequired[4] + + + this.defaultMonDayRequired[5]
this.defaultTotalMonGenerated= this.defaultMonDayGenerated[0] + + + this.defaultMonDayGenerated[1] + + + this.defaultMonDayGenerated[2]+ + +this.defaultMonDayGenerated[3] + + + this.defaultMonDayGenerated[4] + + + this.defaultMonDayGenerated[5]
this.defaultTotalMondiff=this.defaultTotalMonGenerated+ - + this.defaultTotalMonRequired

this.defaultTueDayRequired=[];this.defaultTueDayGenerated=[];
this.defaultTueDayRequired.push(this.defRequiredData.TUE_MID)
this.defaultTueDayRequired.push(this.defRequiredData.TUE_DAY)
this.defaultTueDayRequired.push(this.defRequiredData.TUE_EVE)
this.defaultTueDayRequired.push(this.defRequiredData.TUE_MID_DAY)
this.defaultTueDayRequired.push(this.defRequiredData.TUE_DAY_EVE)
this.defaultTueDayRequired.push(this.defRequiredData.TUE_EVE_MID)
this.defaultTueDayGenerated.push(this.defGeneratedData.TUE_MID)
this.defaultTueDayGenerated.push(this.defGeneratedData.TUE_DAY)
this.defaultTueDayGenerated.push(this.defGeneratedData.TUE_EVE)
this.defaultTueDayGenerated.push(this.defGeneratedData.TUE_MID_DAY)
this.defaultTueDayGenerated.push(this.defGeneratedData.TUE_DAY_EVE)
this.defaultTueDayGenerated.push(this.defGeneratedData.TUE_EVE_MID)
this.defaultDiffTueMid=this.defaultTueDayGenerated[0] + - + this.defaultTueDayRequired[0]
this.defaultDiffTueDay=this.defaultTueDayGenerated[1] + - + this.defaultTueDayRequired[1]
this.defaultDiffTueEve=this.defaultTueDayGenerated[2] + - + this.defaultTueDayRequired[2]
this.defaultDiffTueMidDay=this.defaultTueDayGenerated[3] + - + this.defaultTueDayRequired[3]
this.defaultDiffTueDayEve=this.defaultTueDayGenerated[4] + - + this.defaultTueDayRequired[4]
this.defaultDiffTueEveMid=this.defaultTueDayGenerated[5] + - + this.defaultTueDayRequired[5]
this.defaultTotalTueRequired= this.defaultTueDayRequired[0] + + + this.defaultTueDayRequired[1] + + + this.defaultTueDayRequired[2]+ + + this.defaultTueDayRequired[3] + + + this.defaultTueDayRequired[4] + + + this.defaultTueDayRequired[5]
this.defaultTotalTueGenerated= this.defaultTueDayGenerated[0] + + + this.defaultTueDayGenerated[1] + + + this.defaultTueDayGenerated[2]+ + +this.defaultTueDayGenerated[3] + + + this.defaultTueDayGenerated[4] + + + this.defaultTueDayGenerated[5]
this.defaultTotalTuediff=this.defaultTotalTueGenerated+ - + this.defaultTotalTueRequired

this.defaultWedDayRequired=[];this.defaultWedDayGenerated=[];
this.defaultWedDayRequired.push(this.defRequiredData.WED_MID)
this.defaultWedDayRequired.push(this.defRequiredData.WED_DAY)
this.defaultWedDayRequired.push(this.defRequiredData.WED_EVE)
this.defaultWedDayRequired.push(this.defRequiredData.WED_MID_DAY)
this.defaultWedDayRequired.push(this.defRequiredData.WED_DAY_EVE)
this.defaultWedDayRequired.push(this.defRequiredData.WED_EVE_MID)
this.defaultWedDayGenerated.push(this.defGeneratedData.WED_MID)
this.defaultWedDayGenerated.push(this.defGeneratedData.WED_DAY)
this.defaultWedDayGenerated.push(this.defGeneratedData.WED_EVE)
this.defaultWedDayGenerated.push(this.defGeneratedData.WED_MID_DAY)
this.defaultWedDayGenerated.push(this.defGeneratedData.WED_DAY_EVE)
this.defaultWedDayGenerated.push(this.defGeneratedData.WED_EVE_MID)
this.defaultDiffWedMid=this.defaultWedDayGenerated[0] + - + this.defaultWedDayRequired[0]
this.defaultDiffWedDay=this.defaultWedDayGenerated[1] + - + this.defaultWedDayRequired[1]
this.defaultDiffWedEve=this.defaultWedDayGenerated[2] + - + this.defaultWedDayRequired[2]
this.defaultDiffWedMidDay=this.defaultWedDayGenerated[3] + - + this.defaultWedDayRequired[3]
this.defaultDiffWedDayEve=this.defaultWedDayGenerated[4] + - + this.defaultWedDayRequired[4]
this.defaultDiffWedEveMid=this.defaultWedDayGenerated[5] + - + this.defaultWedDayRequired[5]
this.defaultTotalWedRequired= this.defaultWedDayRequired[0] + + + this.defaultWedDayRequired[1] + + + this.defaultWedDayRequired[2]+ + + this.defaultWedDayRequired[3] + + + this.defaultWedDayRequired[4] + + + this.defaultWedDayRequired[5]
this.defaultTotalWedGenerated= this.defaultWedDayGenerated[0] + + + this.defaultWedDayGenerated[1] + + + this.defaultWedDayGenerated[2]+ + +this.defaultWedDayGenerated[3] + + + this.defaultWedDayGenerated[4] + + + this.defaultWedDayGenerated[5]
this.defaultTotalWeddiff=this.defaultTotalWedGenerated+ - + this.defaultTotalWedRequired

this.defaultThuDayRequired=[];this.defaultThuDayGenerated=[];
this.defaultThuDayRequired.push(this.defRequiredData.THU_MID)
this.defaultThuDayRequired.push(this.defRequiredData.THU_DAY)
this.defaultThuDayRequired.push(this.defRequiredData.THU_EVE)
this.defaultThuDayRequired.push(this.defRequiredData.THU_MID_DAY)
this.defaultThuDayRequired.push(this.defRequiredData.THU_DAY_EVE)
this.defaultThuDayRequired.push(this.defRequiredData.THU_EVE_MID)
this.defaultThuDayGenerated.push(this.defGeneratedData.THU_MID)
this.defaultThuDayGenerated.push(this.defGeneratedData.THU_DAY)
this.defaultThuDayGenerated.push(this.defGeneratedData.THU_EVE)
this.defaultThuDayGenerated.push(this.defGeneratedData.THU_MID_DAY)
this.defaultThuDayGenerated.push(this.defGeneratedData.THU_DAY_EVE)
this.defaultThuDayGenerated.push(this.defGeneratedData.THU_EVE_MID)
this.defaultDiffThuMid=this.defaultThuDayGenerated[0] + - + this.defaultThuDayRequired[0]
this.defaultDiffThuDay=this.defaultThuDayGenerated[1] + - + this.defaultThuDayRequired[1]
this.defaultDiffThuEve=this.defaultThuDayGenerated[2] + - + this.defaultThuDayRequired[2]
this.defaultDiffThuMidDay=this.defaultThuDayGenerated[3] + - + this.defaultThuDayRequired[3]
this.defaultDiffThuDayEve=this.defaultThuDayGenerated[4] + - + this.defaultThuDayRequired[4]
this.defaultDiffThuEveMid=this.defaultThuDayGenerated[5] + - + this.defaultThuDayRequired[5]
this.defaultTotalThuRequired= this.defaultThuDayRequired[0] + + + this.defaultThuDayRequired[1] + + + this.defaultThuDayRequired[2]+ + + this.defaultThuDayRequired[3] + + + this.defaultThuDayRequired[4] + + + this.defaultThuDayRequired[5]
this.defaultTotalThuGenerated= this.defaultThuDayGenerated[0] + + + this.defaultThuDayGenerated[1] + + + this.defaultThuDayGenerated[2]+ + +this.defaultThuDayGenerated[3] + + + this.defaultThuDayGenerated[4] + + + this.defaultThuDayGenerated[5]
this.defaultTotalThudiff=this.defaultTotalThuGenerated+ - + this.defaultTotalThuRequired

this.defaultFriDayRequired=[];this.defaultFriDayGenerated=[];
this.defaultFriDayRequired.push(this.defRequiredData.FRI_MID)
this.defaultFriDayRequired.push(this.defRequiredData.FRI_DAY)
this.defaultFriDayRequired.push(this.defRequiredData.FRI_EVE)
this.defaultFriDayRequired.push(this.defRequiredData.FRI_MID_DAY)
this.defaultFriDayRequired.push(this.defRequiredData.FRI_DAY_EVE)
this.defaultFriDayRequired.push(this.defRequiredData.FRI_EVE_MID)
this.defaultFriDayGenerated.push(this.defGeneratedData.FRI_MID)
this.defaultFriDayGenerated.push(this.defGeneratedData.FRI_DAY)
this.defaultFriDayGenerated.push(this.defGeneratedData.FRI_EVE)
this.defaultFriDayGenerated.push(this.defGeneratedData.FRI_MID_DAY)
this.defaultFriDayGenerated.push(this.defGeneratedData.FRI_DAY_EVE)
this.defaultFriDayGenerated.push(this.defGeneratedData.FRI_EVE_MID)
this.defaultDiffFriMid=this.defaultFriDayGenerated[0] + - + this.defaultFriDayRequired[0]
this.defaultDiffFriDay=this.defaultFriDayGenerated[1] + - + this.defaultFriDayRequired[1]
this.defaultDiffFriEve=this.defaultFriDayGenerated[2] + - + this.defaultFriDayRequired[2]
this.defaultDiffFriMidDay=this.defaultFriDayGenerated[3] + - + this.defaultFriDayRequired[3]
this.defaultDiffFriDayEve=this.defaultFriDayGenerated[4] + - + this.defaultFriDayRequired[4]
this.defaultDiffFriEveMid=this.defaultFriDayGenerated[5] + - + this.defaultFriDayRequired[5]
this.defaultTotalFriRequired= this.defaultFriDayRequired[0] + + + this.defaultFriDayRequired[1] + + + this.defaultFriDayRequired[2]+ + + this.defaultFriDayRequired[3] + + + this.defaultFriDayRequired[4] + + + this.defaultFriDayRequired[5]
this.defaultTotalFriGenerated= this.defaultFriDayGenerated[0] + + + this.defaultFriDayGenerated[1] + + + this.defaultFriDayGenerated[2]+ + +this.defaultFriDayGenerated[3] + + + this.defaultFriDayGenerated[4] + + + this.defaultFriDayGenerated[5]
this.defaultTotalFridiff=this.defaultTotalFriGenerated+ - + this.defaultTotalFriRequired

this.defaultSatDayRequired=[];this.defaultSatDayGenerated=[];
this.defaultSatDayRequired.push(this.defRequiredData.SAT_MID)
this.defaultSatDayRequired.push(this.defRequiredData.SAT_DAY)
this.defaultSatDayRequired.push(this.defRequiredData.SAT_EVE)
this.defaultSatDayRequired.push(this.defRequiredData.SAT_MID_DAY)
this.defaultSatDayRequired.push(this.defRequiredData.SAT_DAY_EVE)
this.defaultSatDayRequired.push(this.defRequiredData.SAT_EVE_MID)
this.defaultSatDayGenerated.push(this.defGeneratedData.SAT_MID)
this.defaultSatDayGenerated.push(this.defGeneratedData.SAT_DAY)
this.defaultSatDayGenerated.push(this.defGeneratedData.SAT_EVE)
this.defaultSatDayGenerated.push(this.defGeneratedData.SAT_MID_DAY)
this.defaultSatDayGenerated.push(this.defGeneratedData.SAT_DAY_EVE)
this.defaultSatDayGenerated.push(this.defGeneratedData.SAT_EVE_MID)
this.defaultDiffSatMid=this.defaultSatDayGenerated[0] + - + this.defaultSatDayRequired[0]
this.defaultDiffSatDay=this.defaultSatDayGenerated[1] + - + this.defaultSatDayRequired[1]
this.defaultDiffSatEve=this.defaultSatDayGenerated[2] + - + this.defaultSatDayRequired[2]
this.defaultDiffSatMidDay=this.defaultSatDayGenerated[3] + - + this.defaultSatDayRequired[3]
this.defaultDiffSatDayEve=this.defaultSatDayGenerated[4] + - + this.defaultSatDayRequired[4]
this.defaultDiffSatEveMid=this.defaultSatDayGenerated[5] + - + this.defaultSatDayRequired[5]
this.defaultTotalSatRequired= this.defaultSatDayRequired[0] + + + this.defaultSatDayRequired[1] + + + this.defaultSatDayRequired[2]+ + + this.defaultSatDayRequired[3] + + + this.defaultSatDayRequired[4] + + + this.defaultSatDayRequired[5]
this.defaultTotalSatGenerated= this.defaultSatDayGenerated[0] + + + this.defaultSatDayGenerated[1] + + + this.defaultSatDayGenerated[2]+ + +this.defaultSatDayGenerated[3] + + + this.defaultSatDayGenerated[4] + + + this.defaultSatDayGenerated[5]
this.defaultTotalSatdiff=this.defaultTotalSatGenerated+ - + this.defaultTotalSatRequired

this.reqData=[]
for(var i=0;i<this.allShiftData.length;i++){
  this.req_shift_1_data={"shiftTime":this.allShiftData[i].startTime,"sun":this.allShiftData[i].Sun,"mon":this.allShiftData[i].Mon,"tue":this.allShiftData[i].Tue,"wed":this.allShiftData[i].Wed,"thu":this.allShiftData[i].Thu,"fri":this.allShiftData[i].Fri,"sat":this.allShiftData[i].Sat}
  this.reqData.push(this.req_shift_1_data)
}
// console.log(this.reqData.length)
this.reqvsgenDataShiftTime=[];this.reqvsgenDataSun=[];this.reqvsgenDataMon=[];this.reqvsgenDataTue=[];this.reqvsgenDataWed=[];this.reqvsgenDataThu=[];this.reqvsgenDataFri=[];this.reqvsgenDataSat=[];

this.reqvsgenDataShiftTime.push("")
this.reqvsgenDataSun.push("Sun")
this.reqvsgenDataMon.push("Mon")
this.reqvsgenDataTue.push("Tue")
this.reqvsgenDataWed.push("Wed")
this.reqvsgenDataThu.push("Thu")
this.reqvsgenDataFri.push("Fri")
this.reqvsgenDataSat.push("Sat")

for(var i=0;i<this.reqData.length;i++){
  this.reqvsgenDataShiftTime.push(String(this.reqData[i].shiftTime))
  for(var j=0;j<finalSunMidData.length;j++){
    if(this.reqData[i].shiftTime===finalSunMidData[j].shiftTime){
      this.reqvsgenDataSun.push(Number(this.reqData[i].sun)+ '/' + Number(finalSunMidData[j].totalEmp))
    }
  }
  for(var j=0;j<finalSunDayData.length;j++){
    if(this.reqData[i].shiftTime===finalSunDayData[j].shiftTime){
      this.reqvsgenDataSun.push(Number(this.reqData[i].sun)+ '/' + Number(finalSunDayData[j].totalEmp))
    }
  }
  for(var j=0;j<finalSunEveData.length;j++){
    if(this.reqData[i].shiftTime===finalSunEveData[j].shiftTime){
      this.reqvsgenDataSun.push(Number(this.reqData[i].sun)+ '/' + Number(finalSunEveData[j].totalEmp))
    }
  }
  for(var j=0;j<finalSunMDData.length;j++){
    if(this.reqData[i].shiftTime===finalSunMDData[j].shiftTime){
      this.reqvsgenDataSun.push(Number(this.reqData[i].sun)+ '/' + Number(finalSunMDData[j].totalEmp))
    }
  }
  for(var j=0;j<finalSunDEData.length;j++){
    if(this.reqData[i].shiftTime===finalSunDEData[j].shiftTime){
      this.reqvsgenDataSun.push(Number(this.reqData[i].sun)+ '/' + Number(finalSunDEData[j].totalEmp))
    }
  }
  for(var j=0;j<finalSunEMData.length;j++){
    if(this.reqData[i].shiftTime===finalSunEMData[j].shiftTime){
      this.reqvsgenDataSun.push(Number(this.reqData[i].sun)+ '/' + Number(finalSunEMData[j].totalEmp))
    }
  }



  for(var j=0;j<finalMonMidData.length;j++){
    if(this.reqData[i].shiftTime===finalMonMidData[j].shiftTime){
      this.reqvsgenDataMon.push(Number(this.reqData[i].mon)+ '/' + Number(finalMonMidData[j].totalEmp))
    }
  }
  for(var j=0;j<finalMonDayData.length;j++){
    if(this.reqData[i].shiftTime===finalMonDayData[j].shiftTime){
      this.reqvsgenDataMon.push(Number(this.reqData[i].mon)+ '/' + Number(finalMonDayData[j].totalEmp))
    }
  }
  for(var j=0;j<finalMonEveData.length;j++){
    if(this.reqData[i].shiftTime===finalMonEveData[j].shiftTime){
      this.reqvsgenDataMon.push(Number(this.reqData[i].mon)+ '/' + Number(finalMonEveData[j].totalEmp))
    }
  }
  for(var j=0;j<finalMonMDData.length;j++){
    if(this.reqData[i].shiftTime===finalMonMDData[j].shiftTime){
      this.reqvsgenDataMon.push(Number(this.reqData[i].mon)+ '/' + Number(finalMonMDData[j].totalEmp))
    }
  }
  for(var j=0;j<finalMonDEData.length;j++){
    if(this.reqData[i].shiftTime===finalMonDEData[j].shiftTime){
      this.reqvsgenDataMon.push(Number(this.reqData[i].mon)+ '/' + Number(finalMonDEData[j].totalEmp))
    }
  }
  for(var j=0;j<finalMonEMData.length;j++){
    if(this.reqData[i].shiftTime===finalMonEMData[j].shiftTime){
      this.reqvsgenDataMon.push(Number(this.reqData[i].mon)+ '/' + Number(finalMonEMData[j].totalEmp))
    }
  }



  for(var j=0;j<finalTueMidData.length;j++){
    if(this.reqData[i].shiftTime===finalTueMidData[j].shiftTime){
      this.reqvsgenDataTue.push(Number(this.reqData[i].tue)+ '/' + Number(finalTueMidData[j].totalEmp))
    }
  }
  for(var j=0;j<finalTueDayData.length;j++){
    if(this.reqData[i].shiftTime===finalTueDayData[j].shiftTime){
      this.reqvsgenDataTue.push(Number(this.reqData[i].tue)+ '/' + Number(finalTueDayData[j].totalEmp))
    }
  }
  for(var j=0;j<finalTueEveData.length;j++){
    if(this.reqData[i].shiftTime===finalTueEveData[j].shiftTime){
      this.reqvsgenDataTue.push(Number(this.reqData[i].tue)+ '/' + Number(finalTueEveData[j].totalEmp))
    }
  }
  for(var j=0;j<finalTueMDData.length;j++){
    if(this.reqData[i].shiftTime===finalTueMDData[j].shiftTime){
      this.reqvsgenDataTue.push(Number(this.reqData[i].tue)+ '/' + Number(finalTueMDData[j].totalEmp))
    }
  }
  for(var j=0;j<finalTueDEData.length;j++){
    if(this.reqData[i].shiftTime===finalTueDEData[j].shiftTime){
      this.reqvsgenDataTue.push(Number(this.reqData[i].tue)+ '/' + Number(finalTueDEData[j].totalEmp))
    }
  }
  for(var j=0;j<finalTueEMData.length;j++){
    if(this.reqData[i].shiftTime===finalTueEMData[j].shiftTime){
      this.reqvsgenDataTue.push(Number(this.reqData[i].tue)+ '/' + Number(finalTueEMData[j].totalEmp))
    }
  }

  for(var j=0;j<finalWedMidData.length;j++){
    if(this.reqData[i].shiftTime===finalWedMidData[j].shiftTime){
      this.reqvsgenDataWed.push(Number(this.reqData[i].wed)+ '/' + Number(finalWedMidData[j].totalEmp))
    }
  }
  for(var j=0;j<finalWedDayData.length;j++){
    if(this.reqData[i].shiftTime===finalWedDayData[j].shiftTime){
      this.reqvsgenDataWed.push(Number(this.reqData[i].wed)+ '/' + Number(finalWedDayData[j].totalEmp))
    }
  }
  for(var j=0;j<finalWedEveData.length;j++){
    if(this.reqData[i].shiftTime===finalWedEveData[j].shiftTime){
      this.reqvsgenDataWed.push(Number(this.reqData[i].wed)+ '/' + Number(finalWedEveData[j].totalEmp))
    }
  }
  for(var j=0;j<finalWedMDData.length;j++){
    if(this.reqData[i].shiftTime===finalWedMDData[j].shiftTime){
      this.reqvsgenDataWed.push(Number(this.reqData[i].wed)+ '/' + Number(finalWedMDData[j].totalEmp))
    }
  }
  for(var j=0;j<finalWedDEData.length;j++){
    if(this.reqData[i].shiftTime===finalWedDEData[j].shiftTime){
      this.reqvsgenDataWed.push(Number(this.reqData[i].wed)+ '/' + Number(finalWedDEData[j].totalEmp))
    }
  }
  for(var j=0;j<finalWedEMData.length;j++){
    if(this.reqData[i].shiftTime===finalWedEMData[j].shiftTime){
      this.reqvsgenDataWed.push(Number(this.reqData[i].wed)+ '/' + Number(finalWedEMData[j].totalEmp))
    }
  }

  for(var j=0;j<finalThuMidData.length;j++){
    if(this.reqData[i].shiftTime===finalThuMidData[j].shiftTime){
      this.reqvsgenDataThu.push(Number(this.reqData[i].thu)+ '/' + Number(finalThuMidData[j].totalEmp))
    }
  }
  for(var j=0;j<finalThuDayData.length;j++){
    if(this.reqData[i].shiftTime===finalThuDayData[j].shiftTime){
      this.reqvsgenDataThu.push(Number(this.reqData[i].thu)+ '/' + Number(finalThuDayData[j].totalEmp))
    }
  }
  for(var j=0;j<finalThuEveData.length;j++){
    if(this.reqData[i].shiftTime===finalThuEveData[j].shiftTime){
      this.reqvsgenDataThu.push(Number(this.reqData[i].thu)+ '/' + Number(finalThuEveData[j].totalEmp))
    }
  }
  for(var j=0;j<finalThuMDData.length;j++){
    if(this.reqData[i].shiftTime===finalThuMDData[j].shiftTime){
      this.reqvsgenDataThu.push(Number(this.reqData[i].thu)+ '/' + Number(finalThuMDData[j].totalEmp))
    }
  }
  for(var j=0;j<finalThuDEData.length;j++){
    if(this.reqData[i].shiftTime===finalThuDEData[j].shiftTime){
      this.reqvsgenDataThu.push(Number(this.reqData[i].thu)+ '/' + Number(finalThuDEData[j].totalEmp))
    }
  }
  for(var j=0;j<finalThuEMData.length;j++){
    if(this.reqData[i].shiftTime===finalThuEMData[j].shiftTime){
      this.reqvsgenDataThu.push(Number(this.reqData[i].thu)+ '/' + Number(finalThuEMData[j].totalEmp))
    }
  }

  for(var j=0;j<finalFriMidData.length;j++){
    if(this.reqData[i].shiftTime===finalFriMidData[j].shiftTime){
      this.reqvsgenDataFri.push(Number(this.reqData[i].fri)+ '/' + Number(finalFriMidData[j].totalEmp))
    }
  }
  for(var j=0;j<finalFriDayData.length;j++){
    if(this.reqData[i].shiftTime===finalFriDayData[j].shiftTime){
      this.reqvsgenDataFri.push(Number(this.reqData[i].fri)+ '/' + Number(finalFriDayData[j].totalEmp))
    }
  }
  for(var j=0;j<finalFriEveData.length;j++){
    if(this.reqData[i].shiftTime===finalFriEveData[j].shiftTime){
      this.reqvsgenDataFri.push(Number(this.reqData[i].fri)+ '/' + Number(finalFriEveData[j].totalEmp))
    }
  }
  for(var j=0;j<finalFriMDData.length;j++){
    if(this.reqData[i].shiftTime===finalFriMDData[j].shiftTime){
      this.reqvsgenDataFri.push(Number(this.reqData[i].fri)+ '/' + Number(finalFriMDData[j].totalEmp))
    }
  }
  for(var j=0;j<finalFriDEData.length;j++){
    if(this.reqData[i].shiftTime===finalFriDEData[j].shiftTime){
      this.reqvsgenDataFri.push(Number(this.reqData[i].fri)+ '/' + Number(finalFriDEData[j].totalEmp))
    }
  }
  for(var j=0;j<finalFriEMData.length;j++){
    if(this.reqData[i].shiftTime===finalFriEMData[j].shiftTime){
      this.reqvsgenDataFri.push(Number(this.reqData[i].fri)+ '/' + Number(finalFriEMData[j].totalEmp))
    }
  }

  for(var j=0;j<finalSatMidData.length;j++){
    if(this.reqData[i].shiftTime===finalSatMidData[j].shiftTime){
      this.reqvsgenDataSat.push(Number(this.reqData[i].sat)+ '/' + Number(finalSatMidData[j].totalEmp))
    }
  }
  for(var j=0;j<finalSatDayData.length;j++){
    if(this.reqData[i].shiftTime===finalSatDayData[j].shiftTime){
      this.reqvsgenDataSat.push(Number(this.reqData[i].sat)+ '/' + Number(finalSatDayData[j].totalEmp))
    }
  }
  for(var j=0;j<finalSatEveData.length;j++){
    if(this.reqData[i].shiftTime===finalSatEveData[j].shiftTime){
      this.reqvsgenDataSat.push(Number(this.reqData[i].sat)+ '/' + Number(finalSatEveData[j].totalEmp))
    }
  }
  for(var j=0;j<finalSatMDData.length;j++){
    if(this.reqData[i].shiftTime===finalSatMDData[j].shiftTime){
      this.reqvsgenDataSat.push(Number(this.reqData[i].sat)+ '/' + Number(finalSatMDData[j].totalEmp))
    }
  }
  for(var j=0;j<finalSatDEData.length;j++){
    if(this.reqData[i].shiftTime===finalSatDEData[j].shiftTime){
      this.reqvsgenDataSat.push(Number(this.reqData[i].sat)+ '/' + Number(finalSatDEData[j].totalEmp))
    }
  }
  for(var j=0;j<finalSatEMData.length;j++){
    if(this.reqData[i].shiftTime===finalSatEMData[j].shiftTime){
      this.reqvsgenDataSat.push(Number(this.reqData[i].sat)+ '/' + Number(finalSatEMData[j].totalEmp))
    }
  }

}

this.reqvsgenDefDataShiftTime=[];this.reqvsgenDefDataSun=[];this.reqvsgenDefDataMon=[];this.reqvsgenDefDataTue=[];this.reqvsgenDefDataWed=[];this.reqvsgenDefDataThu=[];this.reqvsgenDefDataFri=[];this.reqvsgenDefDataSat=[];
this.reqvsgenDefDataShiftTime.push("")
this.reqvsgenDefDataSun.push("Sun")
this.reqvsgenDefDataMon.push("Mon")
this.reqvsgenDefDataTue.push("Tue")
this.reqvsgenDefDataWed.push("Wed")
this.reqvsgenDefDataThu.push("Thu")
this.reqvsgenDefDataFri.push("Fri")
this.reqvsgenDefDataSat.push("Sat")


for(var i=0;i<this.reqData.length;i++){
  this.reqvsgenDefDataShiftTime.push(String(this.reqData[i].shiftTime))
  // console.log(String(this.reqData[i].shiftTime))
  for(var j=0;j<def_finalSunMidData.length;j++){
    if(this.reqData[i].shiftTime===def_finalSunMidData[j].shiftTime){

      this.reqvsgenDefDataSun.push(Number(this.reqData[i].sun)+ '/' + Number(def_finalSunMidData[j].totalEmp))
    }
  }
  for(var j=0;j<def_finalSunDayData.length;j++){
    if(this.reqData[i].shiftTime===def_finalSunDayData[j].shiftTime){
      this.reqvsgenDefDataSun.push(Number(this.reqData[i].sun)+ '/' + Number(def_finalSunDayData[j].totalEmp))
    }
  }
  for(var j=0;j<def_finalSunEveData.length;j++){
    if(this.reqData[i].shiftTime===def_finalSunEveData[j].shiftTime){
      this.reqvsgenDefDataSun.push(Number(this.reqData[i].sun)+ '/' + Number(def_finalSunEveData[j].totalEmp))
    }
  }
  for(var j=0;j<def_finalSunMDData.length;j++){
    if(this.reqData[i].shiftTime===def_finalSunMDData[j].shiftTime){
      this.reqvsgenDefDataSun.push(Number(this.reqData[i].sun)+ '/' + Number(def_finalSunMDData[j].totalEmp))
    }
  }
  for(var j=0;j<def_finalSunDEData.length;j++){
    if(this.reqData[i].shiftTime===def_finalSunDEData[j].shiftTime){
      this.reqvsgenDefDataSun.push(Number(this.reqData[i].sun)+ '/' + Number(def_finalSunDEData[j].totalEmp))
    }
  }
  for(var j=0;j<def_finalSunEMData.length;j++){
    if(this.reqData[i].shiftTime===def_finalSunEMData[j].shiftTime){
      this.reqvsgenDefDataSun.push(Number(this.reqData[i].sun)+ '/' + Number(def_finalSunEMData[j].totalEmp))
    }
  }
//Mon
  for(var j=0;j<def_finalMonMidData.length;j++){
    if(this.reqData[i].shiftTime===def_finalMonMidData[j].shiftTime){
      this.reqvsgenDefDataMon.push(Number(this.reqData[i].mon)+ '/' + Number(def_finalMonMidData[j].totalEmp))
    }
  }
  for(var j=0;j<def_finalMonDayData.length;j++){
    if(this.reqData[i].shiftTime===def_finalMonDayData[j].shiftTime){
      this.reqvsgenDefDataMon.push(Number(this.reqData[i].mon)+ '/' + Number(def_finalMonDayData[j].totalEmp))
    }
  }
  for(var j=0;j<def_finalMonEveData.length;j++){
    if(this.reqData[i].shiftTime===def_finalMonEveData[j].shiftTime){
      this.reqvsgenDefDataMon.push(Number(this.reqData[i].mon)+ '/' + Number(def_finalMonEveData[j].totalEmp))
    }
  }
  for(var j=0;j<def_finalMonMDData.length;j++){
    if(this.reqData[i].shiftTime===def_finalMonMDData[j].shiftTime){
      this.reqvsgenDefDataMon.push(Number(this.reqData[i].mon)+ '/' + Number(def_finalMonMDData[j].totalEmp))
    }
  }
  for(var j=0;j<def_finalMonDEData.length;j++){
    if(this.reqData[i].shiftTime===def_finalMonDEData[j].shiftTime){
      this.reqvsgenDefDataMon.push(Number(this.reqData[i].mon)+ '/' + Number(def_finalMonDEData[j].totalEmp))
    }
  }
  for(var j=0;j<def_finalMonEMData.length;j++){
    if(this.reqData[i].shiftTime===def_finalMonEMData[j].shiftTime){
      this.reqvsgenDefDataMon.push(Number(this.reqData[i].mon)+ '/' + Number(def_finalMonEMData[j].totalEmp))
    }
  }

//Tue
for(var j=0;j<def_finalTueMidData.length;j++){
  if(this.reqData[i].shiftTime===def_finalTueMidData[j].shiftTime){
    this.reqvsgenDefDataTue.push(Number(this.reqData[i].tue)+ '/' + Number(def_finalTueMidData[j].totalEmp))
  }
}
for(var j=0;j<def_finalTueDayData.length;j++){
  if(this.reqData[i].shiftTime===def_finalTueDayData[j].shiftTime){
    this.reqvsgenDefDataTue.push(Number(this.reqData[i].tue)+ '/' + Number(def_finalTueDayData[j].totalEmp))
  }
}
for(var j=0;j<def_finalTueEveData.length;j++){
  if(this.reqData[i].shiftTime===def_finalTueEveData[j].shiftTime){
    this.reqvsgenDefDataTue.push(Number(this.reqData[i].tue)+ '/' + Number(def_finalTueEveData[j].totalEmp))
  }
}
for(var j=0;j<def_finalTueMDData.length;j++){
  if(this.reqData[i].shiftTime===def_finalTueMDData[j].shiftTime){
    this.reqvsgenDefDataTue.push(Number(this.reqData[i].tue)+ '/' + Number(def_finalTueMDData[j].totalEmp))
  }
}
for(var j=0;j<def_finalTueDEData.length;j++){
  if(this.reqData[i].shiftTime===def_finalTueDEData[j].shiftTime){
    this.reqvsgenDefDataTue.push(Number(this.reqData[i].tue)+ '/' + Number(def_finalTueDEData[j].totalEmp))
  }
}
for(var j=0;j<def_finalTueEMData.length;j++){
  if(this.reqData[i].shiftTime===def_finalTueEMData[j].shiftTime){
    this.reqvsgenDefDataTue.push(Number(this.reqData[i].tue)+ '/' + Number(def_finalTueEMData[j].totalEmp))
  }
}


//Wed
for(var j=0;j<def_finalWedMidData.length;j++){
  if(this.reqData[i].shiftTime===def_finalWedMidData[j].shiftTime){
    this.reqvsgenDefDataWed.push(Number(this.reqData[i].wed)+ '/' + Number(def_finalWedMidData[j].totalEmp))
  }
}
for(var j=0;j<def_finalWedDayData.length;j++){
  if(this.reqData[i].shiftTime===def_finalWedDayData[j].shiftTime){
    this.reqvsgenDefDataWed.push(Number(this.reqData[i].wed)+ '/' + Number(def_finalWedDayData[j].totalEmp))
  }
}
for(var j=0;j<def_finalWedEveData.length;j++){
  if(this.reqData[i].shiftTime===def_finalWedEveData[j].shiftTime){
    this.reqvsgenDefDataWed.push(Number(this.reqData[i].wed)+ '/' + Number(def_finalWedEveData[j].totalEmp))
  }
}
for(var j=0;j<def_finalWedMDData.length;j++){
  if(this.reqData[i].shiftTime===def_finalWedMDData[j].shiftTime){
    this.reqvsgenDefDataWed.push(Number(this.reqData[i].wed)+ '/' + Number(def_finalWedMDData[j].totalEmp))
  }
}
for(var j=0;j<def_finalWedDEData.length;j++){
  if(this.reqData[i].shiftTime===def_finalWedDEData[j].shiftTime){
    this.reqvsgenDefDataWed.push(Number(this.reqData[i].wed)+ '/' + Number(def_finalWedDEData[j].totalEmp))
  }
}
for(var j=0;j<def_finalWedEMData.length;j++){
  if(this.reqData[i].shiftTime===def_finalWedEMData[j].shiftTime){
    this.reqvsgenDefDataWed.push(Number(this.reqData[i].wed)+ '/' + Number(def_finalWedEMData[j].totalEmp))
  }
}


//Thu
for(var j=0;j<def_finalThuMidData.length;j++){
  if(this.reqData[i].shiftTime===def_finalThuMidData[j].shiftTime){
    this.reqvsgenDefDataThu.push(Number(this.reqData[i].thu)+ '/' + Number(def_finalThuMidData[j].totalEmp))
  }
}
for(var j=0;j<def_finalThuDayData.length;j++){
  if(this.reqData[i].shiftTime===def_finalThuDayData[j].shiftTime){
    this.reqvsgenDefDataThu.push(Number(this.reqData[i].thu)+ '/' + Number(def_finalThuDayData[j].totalEmp))
  }
}
for(var j=0;j<def_finalThuEveData.length;j++){
  if(this.reqData[i].shiftTime===def_finalThuEveData[j].shiftTime){
    this.reqvsgenDefDataThu.push(Number(this.reqData[i].thu)+ '/' + Number(def_finalThuEveData[j].totalEmp))
  }
}
for(var j=0;j<def_finalThuMDData.length;j++){
  if(this.reqData[i].shiftTime===def_finalThuMDData[j].shiftTime){
    this.reqvsgenDefDataThu.push(Number(this.reqData[i].thu)+ '/' + Number(def_finalThuMDData[j].totalEmp))
  }
}
for(var j=0;j<def_finalThuDEData.length;j++){
  if(this.reqData[i].shiftTime===def_finalThuDEData[j].shiftTime){
    this.reqvsgenDefDataThu.push(Number(this.reqData[i].thu)+ '/' + Number(def_finalThuDEData[j].totalEmp))
  }
}
for(var j=0;j<def_finalThuEMData.length;j++){
  if(this.reqData[i].shiftTime===def_finalThuEMData[j].shiftTime){
    this.reqvsgenDefDataThu.push(Number(this.reqData[i].thu)+ '/' + Number(def_finalThuEMData[j].totalEmp))
  }
}


//Fri
for(var j=0;j<def_finalFriMidData.length;j++){
  if(this.reqData[i].shiftTime===def_finalFriMidData[j].shiftTime){
    this.reqvsgenDefDataFri.push(Number(this.reqData[i].fri)+ '/' + Number(def_finalFriMidData[j].totalEmp))
  }
}
for(var j=0;j<def_finalFriDayData.length;j++){
  if(this.reqData[i].shiftTime===def_finalFriDayData[j].shiftTime){
    this.reqvsgenDefDataFri.push(Number(this.reqData[i].fri)+ '/' + Number(def_finalFriDayData[j].totalEmp))
  }
}
for(var j=0;j<def_finalFriEveData.length;j++){
  if(this.reqData[i].shiftTime===def_finalFriEveData[j].shiftTime){
    this.reqvsgenDefDataFri.push(Number(this.reqData[i].fri)+ '/' + Number(def_finalFriEveData[j].totalEmp))
  }
}
for(var j=0;j<def_finalFriMDData.length;j++){
  if(this.reqData[i].shiftTime===def_finalFriMDData[j].shiftTime){
    this.reqvsgenDefDataFri.push(Number(this.reqData[i].fri)+ '/' + Number(def_finalFriMDData[j].totalEmp))
  }
}
for(var j=0;j<def_finalFriDEData.length;j++){
  if(this.reqData[i].shiftTime===def_finalFriDEData[j].shiftTime){
    this.reqvsgenDefDataFri.push(Number(this.reqData[i].fri)+ '/' + Number(def_finalFriDEData[j].totalEmp))
  }
}
for(var j=0;j<def_finalFriEMData.length;j++){
  if(this.reqData[i].shiftTime===def_finalFriEMData[j].shiftTime){
    this.reqvsgenDefDataFri.push(Number(this.reqData[i].fri)+ '/' + Number(def_finalFriEMData[j].totalEmp))
  }
}

//Sat
for(var j=0;j<def_finalSatMidData.length;j++){
  if(this.reqData[i].shiftTime===def_finalSatMidData[j].shiftTime){
    this.reqvsgenDefDataSat.push(Number(this.reqData[i].sat)+ '/' + Number(def_finalSatMidData[j].totalEmp))
  }
}
for(var j=0;j<def_finalSatDayData.length;j++){
  if(this.reqData[i].shiftTime===def_finalSatDayData[j].shiftTime){
    this.reqvsgenDefDataSat.push(Number(this.reqData[i].sat)+ '/' + Number(def_finalSatDayData[j].totalEmp))
  }
}
for(var j=0;j<def_finalSatEveData.length;j++){
  if(this.reqData[i].shiftTime===def_finalSatEveData[j].shiftTime){
    this.reqvsgenDefDataSat.push(Number(this.reqData[i].sat)+ '/' + Number(def_finalSatEveData[j].totalEmp))
  }
}
for(var j=0;j<def_finalSatMDData.length;j++){
  if(this.reqData[i].shiftTime===def_finalSatMDData[j].shiftTime){
    this.reqvsgenDefDataSat.push(Number(this.reqData[i].sat)+ '/' + Number(def_finalSatMDData[j].totalEmp))
  }
}
for(var j=0;j<def_finalSatDEData.length;j++){
  if(this.reqData[i].shiftTime===def_finalSatDEData[j].shiftTime){
    this.reqvsgenDefDataSat.push(Number(this.reqData[i].sat)+ '/' + Number(def_finalSatDEData[j].totalEmp))
  }
}
for(var j=0;j<def_finalSatEMData.length;j++){
  if(this.reqData[i].shiftTime===def_finalSatEMData[j].shiftTime){
    this.reqvsgenDefDataSat.push(Number(this.reqData[i].sat)+ '/' + Number(def_finalSatEMData[j].totalEmp))
  }
}

}


      // this.gen_shift_1_data={"":this.shift[0],"sun":this.sun_1,"mon":this.mon_1,"tue":this.tue_1,"wed":this.wed_2,"thu":this.thu_1,"fri":this.fri_1,"sat":this.sat_1}
      // this.gen_shift_2_data={"":this.shift[1],"sun":this.sun_2,"mon":this.mon_2,"tue":this.tue_2,"wed":this.wed_2,"thu":this.thu_2,"fri":this.fri_2,"sat":this.sat_2,}
      // this.gen_shift_3_data={"":this.shift[2],"sun":this.sun_3,"mon":this.mon_3,"tue":this.tue_3,"wed":this.wed_3,"thu":this.thu_3,"fri":this.fri_3,"sat":this.sat_3,}
      // this.gen_shift_4_data={"":this.shift[3],"sun":this.sun_4,"mon":this.mon_4,"tue":this.tue_4,"wed":this.wed_4,"thu":this.thu_4,"fri":this.fri_4,"sat":this.sat_4,}
      // this.gen_shift_5_data={"":this.shift[4],"sun":this.sun_5,"mon":this.mon_5,"tue":this.tue_5,"wed":this.wed_5,"thu":this.thu_5,"fri":this.fri_5,"sat":this.sat_5,}
// console.log(this.gen_shift_3_data)
      this.ReqVsGeneMidData=["MID",this.requiredEmpData.SUN_MID+'/'+this.generatedEmpData.SUN_MID,this.requiredEmpData.MON_MID+'/'+this.generatedEmpData.MON_MID,this.requiredEmpData.TUE_MID+'/'+this.generatedEmpData.TUE_MID,this.requiredEmpData.WED_MID+'/'+this.generatedEmpData.WED_MID,this.requiredEmpData.THU_MID+'/'+this.generatedEmpData.THU_MID,this.requiredEmpData.FRI_MID+'/'+this.generatedEmpData.FRI_MID,this.requiredEmpData.SAT_MID+'/'+this.generatedEmpData.SAT_MID]
      this.ReqVsGeneDayData=["DAY",this.requiredEmpData.SUN_DAY+'/'+this.generatedEmpData.SUN_DAY,this.requiredEmpData.MON_DAY+'/'+this.generatedEmpData.MON_DAY,this.requiredEmpData.TUE_DAY+'/'+this.generatedEmpData.TUE_DAY,this.requiredEmpData.WED_DAY+'/'+this.generatedEmpData.WED_DAY,this.requiredEmpData.THU_DAY+'/'+this.generatedEmpData.THU_DAY,this.requiredEmpData.FRI_DAY+'/'+this.generatedEmpData.FRI_DAY,this.requiredEmpData.SAT_DAY+'/'+this.generatedEmpData.SAT_DAY]
      this.ReqVsGeneEveData=["EVE",this.requiredEmpData.SUN_EVE+'/'+this.generatedEmpData.SUN_EVE,this.requiredEmpData.MON_EVE+'/'+this.generatedEmpData.MON_EVE,this.requiredEmpData.TUE_EVE+'/'+this.generatedEmpData.TUE_EVE,this.requiredEmpData.WED_EVE+'/'+this.generatedEmpData.WED_EVE,this.requiredEmpData.THU_EVE+'/'+this.generatedEmpData.THU_EVE,this.requiredEmpData.FRI_EVE+'/'+this.generatedEmpData.FRI_EVE,this.requiredEmpData.SAT_EVE+'/'+this.generatedEmpData.SAT_EVE]
      this.ReqVsGeneMidDayData=["MID-DAY",this.requiredEmpData.SUN_MID_DAY+'/'+this.generatedEmpData.SUN_MID_DAY,this.requiredEmpData.MON_MID_DAY+'/'+this.generatedEmpData.MON_MID_DAY,this.requiredEmpData.TUE_MID_DAY+'/'+this.generatedEmpData.TUE_MID_DAY,this.requiredEmpData.WED_MID_DAY+'/'+this.generatedEmpData.WED_MID_DAY,this.requiredEmpData.THU_MID_DAY+'/'+this.generatedEmpData.THU_MID_DAY,this.requiredEmpData.FRI_MID_DAY+'/'+this.generatedEmpData.FRI_MID_DAY,this.requiredEmpData.SAT_MID_DAY+'/'+this.generatedEmpData.SAT_MID_DAY]
      this.ReqVsGeneDayEveData=["DAY-EVE",this.requiredEmpData.SUN_DAY_EVE+'/'+this.generatedEmpData.SUN_DAY_EVE,this.requiredEmpData.MON_DAY_EVE+'/'+this.generatedEmpData.MON_DAY_EVE,this.requiredEmpData.TUE_DAY_EVE+'/'+this.generatedEmpData.TUE_DAY_EVE,this.requiredEmpData.WED_DAY_EVE+'/'+this.generatedEmpData.WED_DAY_EVE,this.requiredEmpData.THU_DAY_EVE+'/'+this.generatedEmpData.THU_DAY_EVE,this.requiredEmpData.FRI_DAY_EVE+'/'+this.generatedEmpData.FRI_DAY_EVE,this.requiredEmpData.SAT_DAY_EVE+'/'+this.generatedEmpData.SAT_DAY_EVE]
      this.ReqVsGeneEveMidData=["EVE-MID",this.requiredEmpData.SUN_EVE_MID+'/'+this.generatedEmpData.SUN_EVE_MID,this.requiredEmpData.MON_EVE_MID+'/'+this.generatedEmpData.MON_EVE_MID,this.requiredEmpData.TUE_EVE_MID+'/'+this.generatedEmpData.TUE_EVE_MID,this.requiredEmpData.WED_EVE_MID+'/'+this.generatedEmpData.WED_EVE_MID,this.requiredEmpData.THU_EVE_MID+'/'+this.generatedEmpData.THU_EVE_MID,this.requiredEmpData.FRI_EVE_MID+'/'+this.generatedEmpData.FRI_EVE_MID,this.requiredEmpData.SAT_EVE_MID+'/'+this.generatedEmpData.SAT_EVE_MID]
      this.ReqVsGeneTotalData=["",this.totalSunRequired+'/'+ this.totalSunGenerated,this.totalMonRequired+'/'+ this.totalMonGenerated,this.totalTueRequired+'/'+ this.totalTueGenerated,this.totalWedRequired+'/'+ this.totalWedGenerated,this.totalThuRequired+'/'+ this.totalThuGenerated,this.totalFriRequired+'/'+ this.totalFriGenerated,this.totalSatRequired+'/'+ this.totalSatGenerated]


this.defReqVsGeneMidData=["MID",this.defRequiredData.SUN_MID+'/'+this.defGeneratedData.SUN_MID,this.defRequiredData.MON_MID+'/'+this.defGeneratedData.MON_MID,this.defRequiredData.TUE_MID+'/'+this.defGeneratedData.TUE_MID,this.defRequiredData.WED_MID+'/'+this.defGeneratedData.WED_MID,this.defRequiredData.THU_MID+'/'+this.defGeneratedData.THU_MID,this.defRequiredData.FRI_MID+'/'+this.defGeneratedData.FRI_MID,this.defRequiredData.SAT_MID+'/'+this.defGeneratedData.SAT_MID]
this.defReqVsGeneDayData=["DAY",this.defRequiredData.SUN_DAY+'/'+this.defGeneratedData.SUN_DAY,this.defRequiredData.MON_DAY+'/'+this.defGeneratedData.MON_DAY,this.defRequiredData.TUE_DAY+'/'+this.defGeneratedData.TUE_DAY,this.defRequiredData.WED_DAY+'/'+this.defGeneratedData.WED_DAY,this.defRequiredData.THU_DAY+'/'+this.defGeneratedData.THU_DAY,this.defRequiredData.FRI_DAY+'/'+this.defGeneratedData.FRI_DAY,this.defRequiredData.SAT_DAY+'/'+this.defGeneratedData.SAT_DAY]
this.defReqVsGeneEveData=["EVE",this.defRequiredData.SUN_EVE+'/'+this.defGeneratedData.SUN_EVE,this.defRequiredData.MON_EVE+'/'+this.defGeneratedData.MON_EVE,this.defRequiredData.TUE_EVE+'/'+this.defGeneratedData.TUE_EVE,this.defRequiredData.WED_EVE+'/'+this.defGeneratedData.WED_EVE,this.defRequiredData.THU_EVE+'/'+this.defGeneratedData.THU_EVE,this.defRequiredData.FRI_EVE+'/'+this.defGeneratedData.FRI_EVE,this.defRequiredData.SAT_EVE+'/'+this.defGeneratedData.SAT_EVE]
this.defReqVsGeneMidDayData=["MID-DAY",this.defRequiredData.SUN_MID_DAY+'/'+this.defGeneratedData.SUN_MID_DAY,this.defRequiredData.MON_MID_DAY+'/'+this.defGeneratedData.MON_MID_DAY,this.defRequiredData.TUE_MID_DAY+'/'+this.defGeneratedData.TUE_MID_DAY,this.defRequiredData.WED_MID_DAY+'/'+this.defGeneratedData.WED_MID_DAY,this.defRequiredData.THU_MID_DAY+'/'+this.defGeneratedData.THU_MID_DAY,this.defRequiredData.FRI_MID_DAY+'/'+this.defGeneratedData.FRI_MID_DAY,this.defRequiredData.SAT_MID_DAY+'/'+this.defGeneratedData.SAT_MID_DAY]
this.defReqVsGeneDayEveData=["DAY-EVE",this.defRequiredData.SUN_DAY_EVE+'/'+this.defGeneratedData.SUN_DAY_EVE,this.defRequiredData.MON_DAY_EVE+'/'+this.defGeneratedData.MON_DAY_EVE,this.defRequiredData.TUE_DAY_EVE+'/'+this.defGeneratedData.TUE_DAY_EVE,this.defRequiredData.WED_DAY_EVE+'/'+this.defGeneratedData.WED_DAY_EVE,this.defRequiredData.THU_DAY_EVE+'/'+this.defGeneratedData.THU_DAY_EVE,this.defRequiredData.FRI_DAY_EVE+'/'+this.defGeneratedData.FRI_DAY_EVE,this.defRequiredData.SAT_DAY_EVE+'/'+this.defGeneratedData.SAT_DAY_EVE]
this.defReqVsGeneEveMidData=["EVE-MID",this.defRequiredData.SUN_EVE_MID+'/'+this.defGeneratedData.SUN_EVE_MID,this.defRequiredData.MON_EVE_MID+'/'+this.defGeneratedData.MON_EVE_MID,this.defRequiredData.TUE_EVE_MID+'/'+this.defGeneratedData.TUE_EVE_MID,this.defRequiredData.WED_EVE_MID+'/'+this.defGeneratedData.WED_EVE_MID,this.defRequiredData.THU_EVE_MID+'/'+this.defGeneratedData.THU_EVE_MID,this.defRequiredData.FRI_EVE_MID+'/'+this.defGeneratedData.FRI_EVE_MID,this.defRequiredData.SAT_EVE_MID+'/'+this.defGeneratedData.SAT_EVE_MID]
this.defReqVsGeneTotalData=["",this.defaultTotalSunRequired+'/'+ this.defaultTotalSunGenerated,this.defaultTotalMonRequired+'/'+ this.defaultTotalMonGenerated,this.defaultTotalTueRequired+'/'+ this.defaultTotalTueGenerated,this.defaultTotalWedRequired+'/'+ this.defaultTotalWedGenerated,this.defaultTotalThuRequired+'/'+ this.defaultTotalThuGenerated,this.defaultTotalFriRequired+'/'+ this.defaultTotalFriGenerated,this.defaultTotalSatRequired+'/'+ this.defaultTotalSatGenerated]
      // this.defReqVsGeneTotalData=["",(this.defRequiredData.SUN_MID+this.defRequiredData.SUN_DAY+this.defRequiredData.SUN_EVE)+'/'+ (this.defGeneratedData.SUN_MID+ + +this.defGeneratedData.SUN_DAY+ + +this.defGeneratedData.SUN_EVE),(this.defRequiredData.MON_MID+this.defRequiredData.MON_DAY+this.defRequiredData.MON_EVE)+'/'+ (this.defGeneratedData.MON_MID+ + +this.defGeneratedData.MON_DAY+ + +this.defGeneratedData.MON_EVE),(this.defRequiredData.TUE_MID+this.defRequiredData.TUE_DAY+this.defRequiredData.TUE_EVE)+'/'+ (this.defGeneratedData.TUE_MID+ + +this.defGeneratedData.TUE_DAY+ + +this.defGeneratedData.TUE_EVE),(this.defRequiredData.WED_MID+this.defRequiredData.WED_DAY+this.defRequiredData.WED_EVE)+'/'+ (this.defGeneratedData.WED_MID+ + +this.defGeneratedData.WED_DAY+ + +this.defGeneratedData.WED_EVE),(this.defRequiredData.THU_MID+this.defRequiredData.THU_DAY+this.defRequiredData.THU_EVE)+'/'+ (this.defGeneratedData.THU_MID+ + +this.defGeneratedData.THU_DAY+ + +this.defGeneratedData.THU_EVE),(this.defRequiredData.FRI_MID+this.defRequiredData.FRI_DAY+this.defRequiredData.FRI_EVE)+'/'+ (this.defGeneratedData.FRI_MID+ + +this.defGeneratedData.FRI_DAY+ + +this.defGeneratedData.FRI_EVE),(this.defRequiredData.SAT_MID+this.defRequiredData.SAT_DAY+this.defRequiredData.SAT_EVE)+'/'+ (this.defGeneratedData.SAT_MID+ + +this.defGeneratedData.SAT_DAY+ + +this.defGeneratedData.SAT_EVE),]
// console.log(this.defGeneratedData.MON_MID)
// this.customized=["",this.ReqVsGeneMidData[0],this.ReqVsGeneDayData[0],this.ReqVsGeneEveData[0]]
// this.customizedSun=["Sun",this.ReqVsGeneMidData[1],this.ReqVsGeneDayData[1],this.ReqVsGeneEveData[1]]
// this.customizedMon=["Mon",this.ReqVsGeneMidData[2],this.ReqVsGeneDayData[2],this.ReqVsGeneEveData[2]]
// this.customizedTue=["Tue",this.ReqVsGeneMidData[3],this.ReqVsGeneDayData[3],this.ReqVsGeneEveData[3]]
// this.customizedWed=["Wed",this.ReqVsGeneMidData[4],this.ReqVsGeneDayData[4],this.ReqVsGeneEveData[4]]
// this.customizedThu=["Thu",this.ReqVsGeneMidData[5],this.ReqVsGeneDayData[5],this.ReqVsGeneEveData[5]]
// this.customizedFri=["Fri",this.ReqVsGeneMidData[6],this.ReqVsGeneDayData[6],this.ReqVsGeneEveData[6]]
// this.customizedSat=["Sat",this.ReqVsGeneMidData[7],this.ReqVsGeneDayData[7],this.ReqVsGeneEveData[7]]

// console.log(this.customizedSun)
// this.def=["",this.defReqVsGeneMidData[0],this.defReqVsGeneDayData[0],this.defReqVsGeneEveData[0]]
// this.defSun=["Sun",this.defReqVsGeneMidData[1],this.defReqVsGeneDayData[1],this.defReqVsGeneEveData[1]]
// this.defMon=["Mon",this.defReqVsGeneMidData[2],this.defReqVsGeneDayData[2],this.defReqVsGeneEveData[2]]
// this.defTue=["Tue",this.defReqVsGeneMidData[3],this.defReqVsGeneDayData[3],this.defReqVsGeneEveData[3]]
// this.defWed=["Wed",this.defReqVsGeneMidData[4],this.defReqVsGeneDayData[4],this.defReqVsGeneEveData[4]]
// this.defThu=["Thu",this.defReqVsGeneMidData[5],this.defReqVsGeneDayData[5],this.defReqVsGeneEveData[5]]
// this.defFri=["Fri",this.defReqVsGeneMidData[6],this.defReqVsGeneDayData[6],this.defReqVsGeneEveData[6]]
// this.defSat=["Sat",this.defReqVsGeneMidData[7],this.defReqVsGeneDayData[7],this.defReqVsGeneEveData[7]]
this.customized=[]
this.customizedSun=[]
this.customizedMon=[]
this.customizedTue=[]
this.customizedWed=[]
this.customizedThu=[]
this.customizedFri=[]
this.customizedSat=[]

this.customized=[""]
this.customizedSun=["Sun"]
this.customizedMon=["Mon"]
this.customizedTue=["Tue"]
this.customizedWed=["Wed"]
this.customizedThu=["Thu"]
this.customizedFri=["Fri"]
this.customizedSat=["Sat"]

// console.log(this.customizedSun)
this.def=[""]
this.defSun=["Sun"]
this.defMon=["Mon"]
this.defTue=["Tue"]
this.defWed=["Wed"]
this.defThu=["Thu"]
this.defFri=["Fri"]
this.defSat=["Sat"]
this.customized.push(this.ReqVsGeneMidData[0])
this.customizedSun.push(this.ReqVsGeneMidData[1])
this.customizedMon.push(this.ReqVsGeneMidData[2])
this.customizedTue.push(this.ReqVsGeneMidData[3])
this.customizedWed.push(this.ReqVsGeneMidData[4])
this.customizedThu.push(this.ReqVsGeneMidData[5])
this.customizedFri.push(this.ReqVsGeneMidData[6])
this.customizedSat.push(this.ReqVsGeneMidData[7])

  this.def.push(this.defReqVsGeneMidData[0])
this.defSun.push(this.defReqVsGeneMidData[1])
this.defMon.push(this.defReqVsGeneMidData[2])
this.defTue.push(this.defReqVsGeneMidData[3])
this.defWed.push(this.defReqVsGeneMidData[4])
this.defThu.push(this.defReqVsGeneMidData[5])
this.defFri.push(this.defReqVsGeneMidData[6])
this.defSat.push(this.defReqVsGeneMidData[7])
if(  this.hideSplitShiftMidDay===true){
  this.customized.push(this.ReqVsGeneMidDayData[0])
this.customizedSun.push(this.ReqVsGeneMidDayData[1])
this.customizedMon.push(this.ReqVsGeneMidDayData[2])
this.customizedTue.push(this.ReqVsGeneMidDayData[3])
this.customizedWed.push(this.ReqVsGeneMidDayData[4])
this.customizedThu.push(this.ReqVsGeneMidDayData[5])
this.customizedFri.push(this.ReqVsGeneMidDayData[6])
this.customizedSat.push(this.ReqVsGeneMidDayData[7])

  this.def.push(this.defReqVsGeneMidDayData[0])
this.defSun.push(this.defReqVsGeneMidDayData[1])
this.defMon.push(this.defReqVsGeneMidDayData[2])
this.defTue.push(this.defReqVsGeneMidDayData[3])
this.defWed.push(this.defReqVsGeneMidDayData[4])
this.defThu.push(this.defReqVsGeneMidDayData[5])
this.defFri.push(this.defReqVsGeneMidDayData[6])
this.defSat.push(this.defReqVsGeneMidDayData[7])

}
this.customized.push(this.ReqVsGeneDayData[0])
this.customizedSun.push(this.ReqVsGeneDayData[1])
this.customizedMon.push(this.ReqVsGeneDayData[2])
this.customizedTue.push(this.ReqVsGeneDayData[3])
this.customizedWed.push(this.ReqVsGeneDayData[4])
this.customizedThu.push(this.ReqVsGeneDayData[5])
this.customizedFri.push(this.ReqVsGeneDayData[6])
this.customizedSat.push(this.ReqVsGeneDayData[7])

  this.def.push(this.defReqVsGeneDayData[0])
this.defSun.push(this.defReqVsGeneDayData[1])
this.defMon.push(this.defReqVsGeneDayData[2])
this.defTue.push(this.defReqVsGeneDayData[3])
this.defWed.push(this.defReqVsGeneDayData[4])
this.defThu.push(this.defReqVsGeneDayData[5])
this.defFri.push(this.defReqVsGeneDayData[6])
this.defSat.push(this.defReqVsGeneDayData[7])

if( this.hideSplitShiftDayEve===true){
  this.customized.push(this.ReqVsGeneDayEveData[0])
this.customizedSun.push(this.ReqVsGeneDayEveData[1])
this.customizedMon.push(this.ReqVsGeneDayEveData[2])
this.customizedTue.push(this.ReqVsGeneDayEveData[3])
this.customizedWed.push(this.ReqVsGeneDayEveData[4])
this.customizedThu.push(this.ReqVsGeneDayEveData[5])
this.customizedFri.push(this.ReqVsGeneDayEveData[6])
this.customizedSat.push(this.ReqVsGeneDayEveData[7])

  this.def.push(this.defReqVsGeneDayEveData[0])
this.defSun.push(this.defReqVsGeneDayEveData[1])
this.defMon.push(this.defReqVsGeneDayEveData[2])
this.defTue.push(this.defReqVsGeneDayEveData[3])
this.defWed.push(this.defReqVsGeneDayEveData[4])
this.defThu.push(this.defReqVsGeneDayEveData[5])
this.defFri.push(this.defReqVsGeneDayEveData[6])
this.defSat.push(this.defReqVsGeneDayEveData[7])

}
this.customized.push(this.ReqVsGeneEveData[0])
this.customizedSun.push(this.ReqVsGeneEveData[1])
this.customizedMon.push(this.ReqVsGeneEveData[2])
this.customizedTue.push(this.ReqVsGeneEveData[3])
this.customizedWed.push(this.ReqVsGeneEveData[4])
this.customizedThu.push(this.ReqVsGeneEveData[5])
this.customizedFri.push(this.ReqVsGeneEveData[6])
this.customizedSat.push(this.ReqVsGeneEveData[7])

  this.def.push(this.defReqVsGeneEveData[0])
this.defSun.push(this.defReqVsGeneEveData[1])
this.defMon.push(this.defReqVsGeneEveData[2])
this.defTue.push(this.defReqVsGeneEveData[3])
this.defWed.push(this.defReqVsGeneEveData[4])
this.defThu.push(this.defReqVsGeneEveData[5])
this.defFri.push(this.defReqVsGeneEveData[6])
this.defSat.push(this.defReqVsGeneEveData[7])
if( this.hideSplitShiftEveMid===true){
  this.customized.push(this.ReqVsGeneEveMidData[0])
this.customizedSun.push(this.ReqVsGeneEveMidData[1])
this.customizedMon.push(this.ReqVsGeneEveMidData[2])
this.customizedTue.push(this.ReqVsGeneEveMidData[3])
this.customizedWed.push(this.ReqVsGeneEveMidData[4])
this.customizedThu.push(this.ReqVsGeneEveMidData[5])
this.customizedFri.push(this.ReqVsGeneEveMidData[6])
this.customizedSat.push(this.ReqVsGeneEveMidData[7])

  this.def.push(this.defReqVsGeneEveMidData[0])
this.defSun.push(this.defReqVsGeneEveMidData[1])
this.defMon.push(this.defReqVsGeneEveMidData[2])
this.defTue.push(this.defReqVsGeneEveMidData[3])
this.defWed.push(this.defReqVsGeneEveMidData[4])
this.defThu.push(this.defReqVsGeneEveMidData[5])
this.defFri.push(this.defReqVsGeneEveMidData[6])
this.defSat.push(this.defReqVsGeneEveMidData[7])
}
this.customized.push(this.ReqVsGeneTotalData[0])
this.customizedSun.push(this.ReqVsGeneTotalData[1])
this.customizedMon.push(this.ReqVsGeneTotalData[2])
this.customizedTue.push(this.ReqVsGeneTotalData[3])
this.customizedWed.push(this.ReqVsGeneTotalData[4])
this.customizedThu.push(this.ReqVsGeneTotalData[5])
this.customizedFri.push(this.ReqVsGeneTotalData[6])
this.customizedSat.push(this.ReqVsGeneTotalData[7])

  this.def.push(this.defReqVsGeneTotalData[0])
this.defSun.push(this.defReqVsGeneTotalData[1])
this.defMon.push(this.defReqVsGeneTotalData[2])
this.defTue.push(this.defReqVsGeneTotalData[3])
this.defWed.push(this.defReqVsGeneTotalData[4])
this.defThu.push(this.defReqVsGeneTotalData[5])
this.defFri.push(this.defReqVsGeneTotalData[6])
this.defSat.push(this.defReqVsGeneTotalData[7])

      // End Comparison of Required and Generated Emp data

//System Generated Schedule Lines

  this.totalDefaultScheduleLine=i

// this.totalShiftLine={"Total Shift Lines":String(this.defscheduleShift.length)}
this.totalShiftLine=String(this.defscheduleShift.length)
this.totalCustomizeShiftLine=this.scheduleShift.length
this.required_title={"Required Workforce":"Required Workforce"}
this.generated_title={'System Generated Workforce':'System Generated Workforc'}
this.required_vs_generated_title={"Required vs System Generated Workforce":"Required vs System Generated Workforce"}
// console.log(this.totalCustomizeShiftLine  )
this.defaultScheduleShift.push(this.totalShiftLine)


// for(var i=0;i<this.defscheduleShift.length;i++){

//   this.defaultScheduleShift.push(this.defscheduleShift[i])

// }
this.countSunSat=0;this.countSunMon=0;this.countMonTue=0;this.countTueWed=0;this.countWedThu=0;this.countThuFri=0;this.countFriSat=0;
for(var i=0; i<=this.scheduleShift.length;i++)
{
  if(this.scheduleShift[i]?.SL  == 'SS' || this.scheduleShift[i]?.SL  == 'SS-A'){
    this.countSunSat++
  }
  else if(this.scheduleShift[i]?.SL  == 'SM' || this.scheduleShift[i]?.SL  == 'SM-A'){
    this.countSunMon++
  }
  else if(this.scheduleShift[i]?.SL  == 'MT' || this.scheduleShift[i]?.SL  == 'MT-A'){
    this.countMonTue++
  }
  else if(this.scheduleShift[i]?.SL  == 'TW' || this.scheduleShift[i]?.SL  == 'TW-A'){
    this.countTueWed++
  }
  else if(this.scheduleShift[i]?.SL  == 'WT' || this.scheduleShift[i]?.SL  == 'WT-A'){
    this.countWedThu++
  }
  else if(this.scheduleShift[i]?.SL  == 'TF' || this.scheduleShift[i]?.SL  == 'TF-A'){
    this.countThuFri++
  }
  else if(this.scheduleShift[i]?.SL  == 'FS' || this.scheduleShift[i]?.SL  == 'FS-A'){
    this.countFriSat++
  }
  this.totalCount = this.countSunSat + this.countSunMon + this.countMonTue + this.countTueWed + this.countWedThu + this.countThuFri +this.countFriSat
  // console.log(this.totalCount)
}
for(var j=0; j<=this.scheduleShift.length;j++)
{
  if(this.scheduleShift[j]?.Sun == 'X' && this.scheduleShift[j]?.Sat == 'X'){
    this.result1.push(this.scheduleShift[j]);
  }
  else if(this.scheduleShift[j]?.Sun == 'X' && this.scheduleShift[j]?.Mon == 'X'){
    this.result2.push(this.scheduleShift[j]);
  }
}
        return this.totalCount,this.countSunSat,this.countSunMon,this.countMonTue,this.countTueWed,this.countWedThu,this.countThuFri,this.countFriSat,this.SunSat,this.SunMon,this.MonTue,this.TueWed,this.WedThu,this.ThuFri,this.FriSat


  }
  goBack(){
    this.navCtrl.navigateBack([straightlines_io_apis.apis.enter_Work_load_api])
  }
  change(){
    // IonSlides.

    this.slides.getActiveIndex().then(index => {
      // console.log(index);
      this.schedule_id=index
      this.ngOnInit()
   })
    // console.log(IonSlides.length)
  }
  async openMenu(){
    const actionSheet = await this.actionsheetCtrl.create({
      header: 'Save',
      cssClass: 'my-custom-class',
      buttons: [{
        text: 'Save',
        handler: () => {
          this.saveInDataBase()
        }
      }, {
        text: 'Export',
        handler: () => {
          this.export()
        }
      }, {
        text: 'Cancel',
        icon: 'close',
        role: 'cancel',
        handler: () => {
          console.log('Cancel clicked');
        }
      }]
    });
    await actionSheet.present();

    const { role } = await actionSheet.onDidDismiss();
  }

  async saveInDataBase(){
var saveDuplicateSchedule=[]
// console.log(this.scheduleShift)
//   var storeSchedule={"schedule_name":"","allShiftRequiredData":this.allShiftData,"customizedScheduleShiftLine":data,"defaultScheduleShiftLine":data1,"generatedEmpData":this.generatedEmpData,
//   "requiredEmpData":this.requiredEmpData,"defGeneratedEmpData":this.defGeneratedData,"defRequiredEmpData":this.defRequiredData,
//   "workLoadData":this.workLoadData,"hideBLrulesLabels":{"hideBLrulesLabels":false}}
const modal = await this.modalCtrl.create({
  component: SaveScheduleComponent,
  // componentProps: { days: day_summary,schedule_id:this.schedule_id },
  cssClass: 'saveSchedule',
  componentProps: { saveSchedule:this.scheduleShift,schedule:[]},
  swipeToClose:true
});
return await modal.present();


  }

async export() {
  this.da=JSON.stringify(this.totalCustomizeShiftLine)
      // const workBook = XLSX.utils.book_new(); // create a new blank book
      // const workSheet = XLSX.utils.json_to_sheet(this.reqData);

      // XLSX.utils.book_append_sheet(workBook, workSheet, 'data'); // add the worksheet to the book
      // XLSX.writeFile(workBook, 'temp.xlsx');









      // Create workbook and worksheet
      const workbook = new Workbook();


  //Customized Schedule

  const header = ['Id', 'Sun', 'Mon', 'Tue', 'Wed', 'Thu','Fri','Sat','Pattern'];

  const customized_worksheet = workbook.addWorksheet('Customized Schedule');
  // const customized_header = ['Id', 'Sun', 'Mon', 'Tue', 'Wed', 'Thu','Fri','Sat','Pattern'];

  const customized_headerRow = customized_worksheet.addRow(header);

  // Cell Style : Fill and Border
  customized_headerRow.eachCell((F6, number) => {
  });
  customized_worksheet.getCell('A1').alignment={ vertical: 'middle'  }
  customized_worksheet.getCell('I1').alignment={ vertical: 'middle' }
  customized_worksheet.getCell('B1').alignment={ vertical: 'middle', horizontal: 'center' }
  customized_worksheet.getCell('C1').alignment={ vertical: 'middle', horizontal: 'center' }
  customized_worksheet.getCell('D1').alignment={ vertical: 'middle', horizontal: 'center' }
  customized_worksheet.getCell('E1').alignment={ vertical: 'middle', horizontal: 'center' }
  customized_worksheet.getCell('F1').alignment={ vertical: 'middle', horizontal: 'center' }
  customized_worksheet.getCell('G1').alignment={ vertical: 'middle', horizontal: 'center' }
  customized_worksheet.getCell('H1').alignment={ vertical: 'middle', horizontal: 'center' }
  // Add Data and Conditional Formatting

  customized_worksheet.getCell('A1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('B1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('C1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('D1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('E1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('F1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('G1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('H1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('I1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};


  this.customizeScheduleShiftLines.forEach(d => {
    const row = customized_worksheet.addRow(d);
    // const id = row.getCell(1);
    const sun = row.getCell(2);
    const mon = row.getCell(3);
    const tue = row.getCell(4);
    const wed = row.getCell(5);
    const thu = row.getCell(6);
    const fri = row.getCell(7);
    const sat= row.getCell(8);
    const pattern= row.getCell(9);
    row.addPageBreak();
    // id.alignment={ vertical: 'middle', horizontal: 'center' }
    sun.alignment={ vertical: 'middle', horizontal: 'center' }
  mon.alignment={ vertical: 'middle', horizontal: 'center' }
  tue.alignment={ vertical: 'middle', horizontal: 'center' }
  wed.alignment={ vertical: 'middle', horizontal: 'center' }
  thu.alignment={ vertical: 'middle', horizontal: 'center' }
  fri.alignment={ vertical: 'middle', horizontal: 'center' }
  sat.alignment={ vertical: 'middle', horizontal: 'center' }
  pattern.alignment={ vertical: 'middle' }
  }

  );


  const customized_total_shit_line_label = customized_worksheet.getCell('K1');
  customized_total_shit_line_label.value = "Total Shift Lines";
  customized_total_shit_line_label.fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_total_shit_line_label.alignment={ vertical: 'middle', horizontal: 'center' };
  const  customized_total_shit_line = customized_worksheet.getCell('K2');
  customized_total_shit_line.alignment={ vertical: 'middle', horizontal: 'center' };
  customized_total_shit_line.value = this.totalCustomizeShiftLine;
  const  customized_required_vs_generated_title=customized_worksheet.getCell('K4')
  customized_required_vs_generated_title.alignment={ vertical: 'middle', horizontal: 'center' };
  customized_required_vs_generated_title.value="Required vs System Generated Workforce (Shift Category)"
  customized_required_vs_generated_title.fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  const  customized_required_title=customized_worksheet.getCell('K14')
  customized_required_title.alignment={ vertical: 'middle', horizontal: 'center' };
  customized_required_title.value="Required Workforce vs System Generated Workforce (Shift Time)"
  customized_required_title.fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  // const  customized_generated_title=customized_worksheet.getCell('T11')
  // customized_generated_title.alignment={ vertical: 'middle', horizontal: 'center' };
  // customized_generated_title.value="System Generated Workforce"
  // customized_generated_title.fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.mergeCells('K1:L1');
  customized_worksheet.mergeCells('K2:L2');
  customized_worksheet.mergeCells('K4:R4');
  customized_worksheet.mergeCells('K14:R14');
  // customized_worksheet.mergeCells('T11:AA11');
  customized_worksheet.getCell('K5').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('L5').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('M5').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('N5').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('O5').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('P5').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('Q5').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('R5').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  // const defsun=customized_worksheet.getCell('K5');
  for(var i=0;i<this.customized.length;i++){
  const defCompTitle=customized_worksheet.getCell('K'+(i+ + + 5));
  defCompTitle.value=this.customized[i]

  }
  for(var i=0;i<this.customizedSun.length;i++){
  const defCompSun=customized_worksheet.getCell('L'+(i+ + + 5));
  if(i==0){
    defCompSun.value=this.customizedSun[i]
  }else{
   var strDefCompSun = String(this.customizedSun[i])
  var splittedDefCompSun = strDefCompSun.split("/");

  defCompSun.value={richText: [
  {font: {color: {'argb': '0080'}}, text: String(splittedDefCompSun[0])},
  {font: {color: {'argb': '0080'}}, text:'/'},
  {font: {color: {'argb': '066CC'}}, text: String(splittedDefCompSun[1])}
  ]}}
  defCompSun.alignment={ vertical: 'middle', horizontal: 'center' };


  }

  for(var i=0;i<this.customizedMon.length;i++){
  const defCompMon=customized_worksheet.getCell('M'+(i+ + + 5));
  if(i==0){
    defCompMon.value=this.customizedMon[i]
  }else{
   var strDefCompMon = String(this.customizedMon[i])
  var splittedDefCompMon = strDefCompMon.split("/");

  defCompMon.value={richText: [
  {font: {color: {'argb': '0080'}}, text: String(splittedDefCompMon[0])},
  {font: {color: {'argb': '0080'}}, text:'/'},
  {font: {color: {'argb': '066CC'}}, text: String(splittedDefCompMon[1])}
  ]}}
  defCompMon.alignment={ vertical: 'middle', horizontal: 'center' };


  }
  for(var i=0;i<this.customizedTue.length;i++){
  const defCompTue=customized_worksheet.getCell('N'+(i+ + + 5));
  if(i==0){
    defCompTue.value=this.customizedTue[i]
  }else{
   var strDefCompTue = String(this.customizedTue[i])
  var splittedDefCompTue = strDefCompTue.split("/");

  defCompTue.value={richText: [
  {font: {color: {'argb': '0080'}}, text: String(splittedDefCompTue[0])},
  {font: {color: {'argb': '0080'}}, text:'/'},
  {font: {color: {'argb': '066CC'}}, text: String(splittedDefCompTue[1])}
  ]}}
  defCompTue.alignment={ vertical: 'middle', horizontal: 'center' };


  }
  for(var i=0;i<this.customizedWed.length;i++){
  const defCompWed=customized_worksheet.getCell('O'+(i+ + + 5));
  if(i==0){
    defCompWed.value=this.customizedWed[i]
  }else{
   var strDefCompWed = String(this.customizedWed[i])
  var splittedDefCompWed = strDefCompWed.split("/");

  defCompWed.value={richText: [
  {font: {color: {'argb': '0080'}}, text: String(splittedDefCompWed[0])},
  {font: {color: {'argb': '0080'}}, text:'/'},
  {font: {color: {'argb': '066CC'}}, text: String(splittedDefCompWed[1])}
  ]}}
  defCompWed.alignment={ vertical: 'middle', horizontal: 'center' };


  }

  for(var i=0;i<this.customizedThu.length;i++){
  const defCompThu=customized_worksheet.getCell('P'+(i+ + + 5));
  if(i==0){
    defCompThu.value=this.customizedThu[i]
  }else{
   var strDefCompThu = String(this.customizedThu[i])
  var splittedDefCompThu = strDefCompThu.split("/");

  defCompThu.value={richText: [
  {font: {color: {'argb': '0080'}}, text: String(splittedDefCompThu[0])},
  {font: {color: {'argb': '0080'}}, text:'/'},
  {font: {color: {'argb': '066CC'}}, text: String(splittedDefCompThu[1])}
  ]}}
  defCompThu.alignment={ vertical: 'middle', horizontal: 'center' };


  }

  for(var i=0;i<this.customizedFri.length;i++){
  const defCompFri=customized_worksheet.getCell('Q'+(i+ + + 5));
  if(i==0){
    defCompFri.value=this.customizedFri[i]
  }else{
   var strDefCompFri = String(this.customizedFri[i])
  var splittedDefCompFri = strDefCompFri.split("/");

  defCompFri.value={richText: [
  {font: {color: {'argb': '0080'}}, text: String(splittedDefCompFri[0])},
  {font: {color: {'argb': '0080'}}, text:'/'},
  {font: {color: {'argb': '066CC'}}, text: String(splittedDefCompFri[1])}
  ]}}
  defCompFri.alignment={ vertical: 'middle', horizontal: 'center' };


  }

  for(var i=0;i<this.customizedSat.length;i++){
  const defCompSat=customized_worksheet.getCell('R'+(i+ + + 5));
  if(i==0){
    defCompSat.value=this.customizedSat[i]
  }else{
   var strDefCompSat = String(this.customizedSat[i])
  var splittedDefCompSat = strDefCompSat.split("/");

  defCompSat.value={richText: [
  {font: {color: {'argb': '0080'}}, text: String(splittedDefCompSat[0])},
  {font: {color: {'argb': '0080'}}, text:'/'},
  {font: {color: {'argb': '066CC'}}, text: String(splittedDefCompSat[1])}
  ]}}
  defCompSat.alignment={ vertical: 'middle', horizontal: 'center' };


  }
  customized_worksheet.getCell('K15').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('L15').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('M15').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('N15').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('O15').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('P15').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('Q15').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  customized_worksheet.getCell('R15').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};

  for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
  const defReqShiftTime=customized_worksheet.getCell('K'+(i+ + + 15));
  defReqShiftTime.value=String(this.reqvsgenDataShiftTime[i])
  defReqShiftTime.alignment={ vertical: 'middle'};
  // const defGenShiftTime=customized_worksheet.getCell('T'+(i+ + + 12));
  // defGenShiftTime.value=String(this.genDataShiftTime[i])
  // defGenShiftTime.alignment={ vertical: 'middle'};
  }
  const defReqSun=customized_worksheet.getCell('L'+(0+ + + 15));
  defReqSun.value=String(this.reqvsgenDataSun[0])
  defReqSun.alignment={ vertical: 'middle', horizontal: 'center' };
  // const defGenSun=customized_worksheet.getCell('U'+(0+ + + 12));
  // defGenSun.value=String(this.genDataSun[0])
  // defGenSun.alignment={ vertical: 'middle', horizontal: 'center' };
  for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
  const defReqSun=customized_worksheet.getCell('L'+(i+ + + 15));

  var strSun = String(this.reqvsgenDataSun[i])
  var splittedSun = strSun.split("/");

  defReqSun.value={richText: [
    {font: {color: {'argb': '0080  '}}, text: String(splittedSun[0])},
    {font: {color: {'argb': '0080 '}}, text:'/'},
    {font: {color: {'argb': '066CC  '}}, text: String(splittedSun[1])}
  ]}

  defReqSun.alignment={ vertical: 'middle', horizontal: 'center' };
  // const defGenSun=customized_worksheet.getCell('U'+(i+ + + 12));
  // defGenSun.value=String(this.genDataSun[i])
  // defGenSun.alignment={ vertical: 'middle', horizontal: 'center' };
  }
  const defReqMon=customized_worksheet.getCell('M'+(0+ + + 15));
  defReqMon.value=String(this.reqvsgenDataMon[0])
  defReqMon.alignment={ vertical: 'middle', horizontal: 'center' };
  // const defGenMon=customized_worksheet.getCell('V'+(0+ + + 12));
  // defGenMon.value=String(this.genDataMon[0])
  // defGenMon.alignment={ vertical: 'middle', horizontal: 'center' };
  for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
  const defReqMon=customized_worksheet.getCell('M'+(i+ + + 15));

  var strMon = String(this.reqvsgenDataMon[i])
  var splittedMon = strMon.split("/");

  defReqMon.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedMon[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedMon[1])}
  ]}

  defReqMon.alignment={ vertical: 'middle', horizontal: 'center' };
  // const defGenMon=customized_worksheet.getCell('V'+(i+ + + 12));
  // defGenMon.value=String(this.genDataMon[i])
  // defGenMon.alignment={ vertical: 'middle', horizontal: 'center' };
  }
  const defReqTue=customized_worksheet.getCell('N'+(0+ + + 15));
  defReqTue.value=String(this.reqvsgenDataTue[0])
  defReqTue.alignment={ vertical: 'middle', horizontal: 'center' };
  // const defGenTue=customized_worksheet.getCell('W'+(0+ + + 12));
  // defGenTue.value=String(this.genDataTue[0])
  // defGenTue.alignment={ vertical: 'middle', horizontal: 'center' };
  for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
  const defReqTue=customized_worksheet.getCell('N'+(i+ + + 15));

  var strTue = String(this.reqvsgenDataTue[i])
  var splittedTue = strTue.split("/");

  defReqTue.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedTue[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedTue[1])}
  ]}

  defReqTue.alignment={ vertical: 'middle', horizontal: 'center' };
  // const defGenTue=customized_worksheet.getCell('W'+(i+ + + 12));
  // defGenTue.value=String(this.genDataTue[i])
  // defGenTue.alignment={ vertical: 'middle', horizontal: 'center' };
  }
  const defReqWed=customized_worksheet.getCell('O'+(0+ + + 15));
  defReqWed.value=String(this.reqvsgenDataWed[0])
  defReqWed.alignment={ vertical: 'middle', horizontal: 'center' };
  // const defGenWed=customized_worksheet.getCell('X'+(0+ + + 12));
  // defGenWed.value=String(this.genDataWed[0])
  // defGenWed.alignment={ vertical: 'middle', horizontal: 'center' };
  for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
  const defReqWed=customized_worksheet.getCell('O'+(i+ + + 15));


  var strWed = String(this.reqvsgenDataWed[i])
  var splittedWed = strWed.split("/");

  defReqWed.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedWed[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedWed[1])}
  ]}

  defReqWed.alignment={ vertical: 'middle', horizontal: 'center' };
  // const defGenWed=customized_worksheet.getCell('X'+(i+ + + 12));
  // defGenWed.value=String(this.genDataWed[i])
  // defGenWed.alignment={ vertical: 'middle', horizontal: 'center' };
  }
  const defReqThu=customized_worksheet.getCell('P'+(0+ + + 15));
  defReqThu.value=String(this.reqvsgenDataThu[0])
  defReqThu.alignment={ vertical: 'middle', horizontal: 'center' };
  // const defGenThu=customized_worksheet.getCell('Y'+(0+ + + 12));
  // defGenThu.value=String(this.genDataThu[0])
  // defGenThu.alignment={ vertical: 'middle', horizontal: 'center' };
  for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
  const defReqThu=customized_worksheet.getCell('P'+(i+ + + 15));

  var strThu = String(this.reqvsgenDataThu[i])
  var splittedThu = strThu.split("/");

  defReqThu.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedThu[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedThu[1])}
  ]}

  defReqThu.alignment={ vertical: 'middle', horizontal: 'center' };
  // const defGenThu=customized_worksheet.getCell('Y'+(i+ + + 12));
  // defGenThu.value=String(this.genDataThu[i])
  // defGenThu.alignment={ vertical: 'middle', horizontal: 'center' };
  }
  const defReqFri=customized_worksheet.getCell('Q'+(0+ + + 15));
  defReqFri.value=String(this.reqvsgenDataFri[0])
  defReqFri.alignment={ vertical: 'middle', horizontal: 'center' };
  // const defGenFri=customized_worksheet.getCell('Z'+(0+ + + 12));
  // defGenFri.value=String(this.genDataFri[0])
  // defGenFri.alignment={ vertical: 'middle', horizontal: 'center' };
  for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
  const defReqFri=customized_worksheet.getCell('Q'+(i+ + + 15));

  var strFri = String(this.reqvsgenDataFri[i])
  var splittedFri = strFri.split("/");

  defReqFri.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedFri[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedFri[1])}
  ]}

  defReqFri.alignment={ vertical: 'middle', horizontal: 'center' };
  // const defGenFri=customized_worksheet.getCell('Z'+(i+ + + 12));
  // defGenFri.value=String(this.genDataFri[i])
  // defGenFri.alignment={ vertical: 'middle', horizontal: 'center' };
  }

  const defReqSat=customized_worksheet.getCell('R'+(0+ + + 15));
  defReqSat.value=String(this.reqvsgenDataSat[0])
  defReqSat.alignment={ vertical: 'middle', horizontal: 'center' };
  // const defGenSat=customized_worksheet.getCell('AA'+(0+ + + 12));
  // defGenSat.value=String(this.genDataSat[0])
  // defGenSat.alignment={ vertical: 'middle', horizontal: 'center' };
  for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
  const defReqSat=customized_worksheet.getCell('R'+(i+ + + 15));

  var strSat = String(this.reqvsgenDataSat[i])
  var splittedSat = strSat.split("/");

  defReqSat.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedSat[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedSat[1])}
  ]}

  defReqSat.alignment={ vertical: 'middle', horizontal: 'center' };
  // const defGenSat=customized_worksheet.getCell('AA'+(i+ + + 12));
  // defGenSat.value=String(this.genDataSat[i])
  // defGenSat.alignment={ vertical: 'middle', horizontal: 'center' };
  }


      const worksheet = workbook.addWorksheet('System Generated Schedule');


      const headerRow = worksheet.addRow(header);

  // Cell Style : Fill and Border
      headerRow.eachCell((F6, number) => {
  });

  worksheet.getCell('A1').alignment={ vertical: 'middle', horizontal: 'center'  }
  worksheet.getCell('I1').alignment={ vertical: 'middle' }
  worksheet.getCell('B1').alignment={ vertical: 'middle', horizontal: 'center' }
  worksheet.getCell('C1').alignment={ vertical: 'middle', horizontal: 'center' }
  worksheet.getCell('D1').alignment={ vertical: 'middle', horizontal: 'center' }
  worksheet.getCell('E1').alignment={ vertical: 'middle', horizontal: 'center' }
  worksheet.getCell('F1').alignment={ vertical: 'middle', horizontal: 'center' }
  worksheet.getCell('G1').alignment={ vertical: 'middle', horizontal: 'center' }
  worksheet.getCell('H1').alignment={ vertical: 'middle', horizontal: 'center' }

  worksheet.getCell('A1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  worksheet.getCell('B1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  worksheet.getCell('C1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  worksheet.getCell('D1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  worksheet.getCell('E1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  worksheet.getCell('F1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  worksheet.getCell('G1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  worksheet.getCell('H1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  worksheet.getCell('I1').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};

  // Add Data and Conditional Formatting
      this.updatedDefScheduleShiftLines.forEach(d => {
        const row = worksheet.addRow(d);
        const id = row.getCell(1);
        const sun = row.getCell(2);
        const mon = row.getCell(3);
        const tue = row.getCell(4);
        const wed = row.getCell(5);
        const thu = row.getCell(6);
        const fri = row.getCell(7);
        const sat= row.getCell(8);
        const pattern= row.getCell(9);
        row.addPageBreak();
        id.alignment={ vertical: 'middle', horizontal: 'center' }
        sun.alignment={ vertical: 'middle', horizontal: 'center' }
      mon.alignment={ vertical: 'middle', horizontal: 'center' }
      tue.alignment={ vertical: 'middle', horizontal: 'center' }
      wed.alignment={ vertical: 'middle', horizontal: 'center' }
      thu.alignment={ vertical: 'middle', horizontal: 'center' }
      fri.alignment={ vertical: 'middle', horizontal: 'center' }
      sat.alignment={ vertical: 'middle', horizontal: 'center' }
      pattern.alignment={ vertical: 'middle' }
  }

  );


    const total_shit_line_label = worksheet.getCell('K1');
    total_shit_line_label.value = "Total Shift Lines";
    total_shit_line_label.fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}}
    total_shit_line_label.alignment={ vertical: 'middle', horizontal: 'center' };
    const total_shit_line = worksheet.getCell('K2');
    total_shit_line.alignment={ vertical: 'middle', horizontal: 'center' };
    total_shit_line.value = this.totalShiftLine;
  const required_vs_generated_title=worksheet.getCell('K4')
  required_vs_generated_title.alignment={ vertical: 'middle', horizontal: 'center' };
  required_vs_generated_title.value="Required vs System Generated Workforce (Shift Category)"
  required_vs_generated_title.fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  const required_title=worksheet.getCell('K14')
  required_title.alignment={ vertical: 'middle', horizontal: 'center' };
  required_title.value="Required Workforce vs System Generated Workforce (Shift Time)"
  required_title.fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  // const generated_title=worksheet.getCell('T11')
  // generated_title.alignment={ vertical: 'middle', horizontal: 'center' };
  // generated_title.value="System Generated Workforce"
  // generated_title.fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
      worksheet.mergeCells('K1:L1');
      worksheet.mergeCells('K2:L2');
      worksheet.mergeCells('K4:R4');
      worksheet.mergeCells('K14:R14');
      // worksheet.mergeCells('T11:AA11');
      worksheet.getCell('K5').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
      worksheet.getCell('L5').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
      worksheet.getCell('M5').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
      worksheet.getCell('N5').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
      worksheet.getCell('O5').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
      worksheet.getCell('P5').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
      worksheet.getCell('Q5').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
      worksheet.getCell('R5').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  // const defsun=worksheet.getCell('K5');
  for(var i=0;i<this.def.length;i++){
    const defCompTitle=worksheet.getCell('K'+(i+ + + 5));
    defCompTitle.value=this.def[i]
  }
  for(var i=0;i<this.defSun.length;i++){
    const defCompSun=worksheet.getCell('L'+(i+ + + 5));
    if(i==0){
      defCompSun.value=this.defSun[i]
    }else{
     var strDefCompSun = String(this.defSun[i])
    var splittedDefCompSun = strDefCompSun.split("/");

    defCompSun.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedDefCompSun[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedDefCompSun[1])}
    ]}}
    defCompSun.alignment={ vertical: 'middle', horizontal: 'center' };

  }

  for(var i=0;i<this.defMon.length;i++){
    const defCompMon=worksheet.getCell('M'+(i+ + + 5));
    if(i==0){
      defCompMon.value=this.defMon[i]
    }else{
     var strDefCompMon = String(this.defMon[i])
    var splittedDefCompMon = strDefCompMon.split("/");

    defCompMon.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedDefCompMon[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedDefCompMon[1])}
    ]}}
    defCompMon.alignment={ vertical: 'middle', horizontal: 'center' };

  }
  for(var i=0;i<this.defTue.length;i++){
    const defCompTue=worksheet.getCell('N'+(i+ + + 5));
    if(i==0){
      defCompTue.value=this.defTue[i]
    }else{
     var strDefCompTue = String(this.defTue[i])
    var splittedDefCompTue = strDefCompTue.split("/");

    defCompTue.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedDefCompTue[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedDefCompTue[1])}
    ]}}
    defCompTue.alignment={ vertical: 'middle', horizontal: 'center' };

  }
  for(var i=0;i<this.defWed.length;i++){
    const defCompWed=worksheet.getCell('O'+(i+ + + 5));
    if(i==0){
      defCompWed.value=this.defWed[i]
    }else{
     var strDefCompWed = String(this.defWed[i])
    var splittedDefCompWed = strDefCompWed.split("/");

    defCompWed.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedDefCompWed[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedDefCompWed[1])}
    ]}}
    defCompWed.alignment={ vertical: 'middle', horizontal: 'center' };

  }

  for(var i=0;i<this.defThu.length;i++){
    const defCompThu=worksheet.getCell('P'+(i+ + + 5));
    if(i==0){
      defCompThu.value=this.defThu[i]
    }else{
     var strDefCompThu = String(this.defThu[i])
    var splittedDefCompThu = strDefCompThu.split("/");

    defCompThu.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedDefCompThu[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedDefCompThu[1])}
    ]}}
    defCompThu.alignment={ vertical: 'middle', horizontal: 'center' };

  }

  for(var i=0;i<this.defFri.length;i++){
    const defCompFri=worksheet.getCell('Q'+(i+ + + 5));
    if(i==0){
      defCompFri.value=this.defFri[i]
    }else{
     var strDefCompFri = String(this.defFri[i])
    var splittedDefCompFri = strDefCompFri.split("/");

    defCompFri.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedDefCompFri[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedDefCompFri[1])}
    ]}}
    defCompFri.alignment={ vertical: 'middle', horizontal: 'center' };



  }

  for(var i=0;i<this.defSat.length;i++){
    const defCompSat=worksheet.getCell('R'+(i+ + + 5));
    if(i==0){
      defCompSat.value=this.defSat[i]
    }else{
     var strDefCompSat = String(this.defSat[i])
    var splittedDefCompSat = strDefCompSat.split("/");

    defCompSat.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedDefCompSat[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedDefCompSat[1])}
    ]}}
    defCompSat.alignment={ vertical: 'middle', horizontal: 'center' };

  }
  worksheet.getCell('K15').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  worksheet.getCell('L15').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  worksheet.getCell('M15').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  worksheet.getCell('N15').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  worksheet.getCell('O15').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  worksheet.getCell('P15').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  worksheet.getCell('Q15').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  worksheet.getCell('R15').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  // worksheet.getCell('T12').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  // worksheet.getCell('U12').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  // worksheet.getCell('V12').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  // worksheet.getCell('W12').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  // worksheet.getCell('X12').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  // worksheet.getCell('Y12').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  // worksheet.getCell('Z12').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};
  // worksheet.getCell('AA12').fill = {type: 'pattern',pattern:'solid',fgColor:{argb:'d1d1e0'}};

  for(var i=0;i<this.reqvsgenDefDataShiftTime.length;i++){
    const defGenShiftTime=worksheet.getCell('K'+(i+ + + 15));
    defGenShiftTime.value=String(this.reqvsgenDefDataShiftTime[i])
    defGenShiftTime.alignment={ vertical: 'middle'};
  }

  for(var i=0;i<this.reqvsgenDefDataShiftTime.length;i++){

    const defGenSun=worksheet.getCell('L'+(i+ + + 15));
    if(i==0){
     defGenSun.value = String(this.reqvsgenDefDataSun[i])
    }else{
    var strDefSun = String(this.reqvsgenDefDataSun[i])
  var splittedDefSun = strDefSun.split("/");

  defGenSun.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedDefSun[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedDefSun[1])}
  ]}
  }
    defGenSun.alignment={ vertical: 'middle', horizontal: 'center' };
  }
  for(var i=0;i<this.reqvsgenDefDataShiftTime.length;i++){
    const defGenMon=worksheet.getCell('M'+(i+ + + 15));
    if(i==0){
      defGenMon.value = String(this.reqvsgenDefDataMon[i])
     }else{
    var strDefMon = String(this.reqvsgenDefDataMon[i])
  var splittedDefMon = strDefMon.split("/");

  defGenMon.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedDefMon[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedDefMon[1])}
  ]}
     }
    defGenMon.alignment={ vertical: 'middle', horizontal: 'center' };

  }
  for(var i=0;i<this.reqvsgenDefDataShiftTime.length;i++){
    const defGenTue=worksheet.getCell('N'+(i+ + + 15));
    if(i==0){
      defGenTue.value = String(this.reqvsgenDefDataTue[i])
     }else{
    var strDefTue = String(this.reqvsgenDefDataTue[i])
  var splittedDefTue = strDefTue.split("/");

  defGenTue.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedDefTue[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedDefTue[1])}
  ]}}
    defGenTue.alignment={ vertical: 'middle', horizontal: 'center' };

  }
  for(var i=0;i<this.reqvsgenDefDataShiftTime.length;i++){
    const defGenWed=worksheet.getCell('O'+(i+ + + 15));
    if(i==0){
      defGenWed.value = String(this.reqvsgenDefDataWed[i])
     }else{
    var strDefWed = String(this.reqvsgenDefDataWed[i])
  var splittedDefWed = strDefWed.split("/");

  defGenWed.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedDefWed[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedDefWed[1])}
  ]}
     }
    defGenWed.alignment={ vertical: 'middle', horizontal: 'center' };
  }

  for(var i=0;i<this.reqvsgenDefDataShiftTime.length;i++){
    const defGenThu=worksheet.getCell('P'+(i+ + + 15));
    if(i==0){
      defGenThu.value = String(this.reqvsgenDefDataThu[i])
     }else{
    var strDefThu = String(this.reqvsgenDefDataThu[i])
  var splittedDefThu = strDefThu.split("/");

  defGenThu.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedDefThu[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedDefThu[1])}
  ]}}
    defGenThu.alignment={ vertical: 'middle', horizontal: 'center' };
  }

  for(var i=0;i<this.reqvsgenDefDataShiftTime.length;i++){
    const defGenFri=worksheet.getCell('Q'+(i+ + + 15));
    if(i==0){
      defGenFri.value = String(this.reqvsgenDefDataFri[i])
     }else{
    var strDefFri = String(this.reqvsgenDefDataFri[i])
  var splittedDefFri = strDefFri.split("/");

  defGenFri.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedDefFri[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedDefFri[1])}
  ]}}
    defGenFri.alignment={ vertical: 'middle', horizontal: 'center' };
  }

  for(var i=0;i<this.reqvsgenDefDataShiftTime.length;i++){
    const defGenSat=worksheet.getCell('R'+(i+ + + 15));
    if(i==0){
      defGenSat.value = String(this.reqvsgenDefDataSat[i])
     }else{
    var strDefSat = String(this.reqvsgenDefDataSat[i])
  var splittedDefSat = strDefSat.split("/");

  defGenSat.value={richText: [
    {font: {color: {'argb': '0080'}}, text: String(splittedDefSat[0])},
    {font: {color: {'argb': '0080'}}, text:'/'},
    {font: {color: {'argb': '066CC'}}, text: String(splittedDefSat[1])}
  ]}}
    defGenSat.alignment={ vertical: 'middle', horizontal: 'center' };
  }


  // Generate Excel File with given name
      workbook.xlsx.writeBuffer().then((data: any) => {
    const blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    fs.saveAs(blob,  this.fileName);
  });

    }

    async addNewShiftLine(){
      const modal = await this.modalCtrl.create({
        component: AddNewShiftLinePage,
        cssClass: 'addNewShiftLine',
        swipeToClose:true,
       componentProps: { schedule_id:this.schedule_id }

      });
      // // this.scheduleShift=EditScheduleDataPage.data5
      // // console.log(this.scheduleShift)
      return await modal.present();

    }
    async midShiftsDetails(){
      const modal = await this.modalCtrl.create({
        component: ViewTotalMidShiftLinesDataPage,
        cssClass: 'viewShiftData',
        swipeToClose:true,
        componentProps: { schedule_id:this.schedule_id }

      });
      // this.scheduleShift=EditScheduleDataPage.data5
      // console.log(this.scheduleShift)
      return await modal.present();

    }

    async dayShiftsDetails(){
      const modal = await this.modalCtrl.create({
        component: ViewTotalDayShiftLinesDataPage,
        cssClass: 'viewShiftData',
        swipeToClose:true,
        componentProps: { schedule_id:this.schedule_id }
        // componentProps: { scheduleData: scheduleShift }

      });
      // this.scheduleShift=EditScheduleDataPage.data5
      // console.log(this.scheduleShift)
      return await modal.present();

    }

    async eveShiftsDetails(){
      const modal = await this.modalCtrl.create({
        component: ViewTotalEveShiftLinesDataPage,
        cssClass: 'viewShiftData',
        swipeToClose:true,
        componentProps: { schedule_id:this.schedule_id }
        // componentProps: { scheduleData: scheduleShift }

      });
      // this.scheduleShift=EditScheduleDataPage.data5
      // console.log(this.scheduleShift)
      return await modal.present();

    }
    async daySummary(day_summary){
      // console.log(day_summary)
      const modal = await this.modalCtrl.create({
        component: ViewSummaryDayCategoryWisePage,
        componentProps: { days: day_summary,schedule_id:this.schedule_id },
        cssClass: 'daySummaryData',
        swipeToClose:true
      });
      return await modal.present();

    }
    logOut(){
      localStorage.removeItem('token')
    this.navCtrl.navigateBack('login')
    }
    getIndicatorClass(id1){
      if(this.schedule_id===id1 ) {
        return 'active';
      }else {
        return 'small';
      }
      return 'hidden';
    }
    showLegends(){

      if(this.hide_BL_rules_Labels==false){
        return this.hide_BL_rules_Labels=true
      }else{
        return this.hide_BL_rules_Labels=false
      }
    }
    handleSlide(event){
      // console.log(event)
      event.target.getSlidingRatio().then(res=> {
        if(res>1.2){
          this.nextslide=false
          this.slides.lockSwipes(false);
          // this.slides.slid(1)

        }
        if(res > 0 && res<1.2){
          this.nextslide=true
          this.slides.lockSwipes(true);
        }
      });
    }
    scheduleOne=true
    scheduleTwo=false
    scheduleThree=false
    // schedule(id){
    //     if(id==0){
    //       this.schedule_id=0
    //       // this.slideOption={
    //       //   shortSwipes:false,
    //       //   longSwipes:true,
    //       //   longSwipesRatio:0.5,
    //       //   initialSlide: 0,
    //       //   spaceBetween: 150
    //       //  }
    //       localStorage.setItem('focusShiftLine',JSON.stringify({"shift_line":'',"schedule_id":this.schedule_id}))
    //       this.ngOnInit()
    //     }else if(id==1){
    //       this.schedule_id=1
    //       // this.slideOption={
    //       //   shortSwipes:false,
    //       //   longSwipes:true,
    //       //   longSwipesRatio:0.5,
    //       //   initialSlide: 1,
    //       //   spaceBetween: 150
    //       //  }
    //       localStorage.setItem('focusShiftLine',JSON.stringify({"shift_line":'',"schedule_id":this.schedule_id}))
    //       this.ngOnInit();
    //     }else if(id==2){
    //       this.schedule_id=2
    //       localStorage.setItem('focusShiftLine',JSON.stringify({"shift_line":'',"schedule_id":this.schedule_id}))
    //       this.ngOnInit()
    //     }
    // }
    schedule(id){
      if(id==0){
        this.slides.slideTo(id)
              this.schedule_id=0
      }else if(id==1){
        this.slides.slideTo(id)
        this.schedule_id=1
      }else if(id==2){
        this.slides.slideTo(id)
        this.schedule_id=2
      }
  }
  }
