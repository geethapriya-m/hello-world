import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ModalController, NavController, NavParams } from '@ionic/angular';
import { SetUpBidParametersService } from 'src/app/dashboard/bidding-dashboard/manage-bid-schedule/set-up-bid-parameters/service/set-up-bid-parameters.service';
import { HeaderTitleService } from 'src/app/dashboard/nav-bar-footer/header-title.service';
import { GeneratedScheduleService } from 'src/app/services/schedule/generated-schedule.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-save-schedule',
  templateUrl: './save-schedule.component.html',
  styleUrls: ['./save-schedule.component.scss'],
})
export class SaveScheduleComponent implements OnInit {

  scheduleNameForm: FormGroup;
  select_shiftline_schedule=['Trimester1_Shiftline Schedule','Trimester2_Shiftline Schedule','Trimester3_Shiftline Schedule']
  saveSchedule=[];
  all_Schedule: any;
  updateScheduleId: any;
  schedule__name: any;
  allShiftData=[]
  user_data: any;
  scheduleNameUnique=true;
  saveDuplicateSchedule=[];
  constructor(public navCtrl: NavController,
    public modalCtrl: ModalController,
    public navParams: NavParams,
    private headerTitleService: HeaderTitleService,
    private sbpHeaderService:SetUpBidParametersService,
    private scheduleService:GeneratedScheduleService,
    private fb:FormBuilder) {
      this.saveSchedule=navParams.get('saveSchedule')
      this.saveDuplicateSchedule=navParams.get('schedule')

   }

  ngOnInit() {
    this.allShiftData=  JSON.parse(localStorage.getItem('allShiftRequiredData'))
    this.updateScheduleId=JSON.parse(localStorage.getItem('updateScheduleId'))
    // console.log(this.updateScheduleId)

    this.allShiftData=[]
    // if(this.updateScheduleId==''){
    //   this.schedule__name=''
    // }
    // else{
    // for(var i=0;i<this.all_Schedule.length;i++){
    //   if(i===Number(this.updateScheduleId)){
    //     this.schedule__name=this.all_Schedule[i].schedule_name;
    //   }
    // }}
    this.scheduleNameForm = this.fb.group({
     schedule_name:new FormControl(this.schedule__name,Validators.compose([Validators.required])),
    })
    // console.log(this.saveSchedule)
    // console.log(this.scheduleNameForm.value)
    // console.log(this.schedule__name)
  }
  get schedule_name(){
    return this.scheduleNameForm.get('schedule_name')
  }

  scheduleShiftLine(){}
  submit(){

// console.log(this.saveSchedule)
var tempObj={},tempShiftObj={}
var tempArr=[]
var tempShiftDefintionArr=[]
this.user_data=JSON.parse(localStorage.getItem('userData'))

if(this.saveSchedule.length>0){
for(var i=0;i<this.saveSchedule.length;i++){
  console.log(this.saveSchedule[i])
  tempObj={
      "seq_id": this.saveSchedule[i].id,
      "mon": this.saveSchedule[i].Mon,
      "tue": this.saveSchedule[i].Tue,
      "wed": this.saveSchedule[i].Wed,
      "thu": this.saveSchedule[i].Thu,
      "fri": this.saveSchedule[i].Fri,
      "sat": this.saveSchedule[i].Sat,
      "sun": this.saveSchedule[i].Sun,
      "schedulename": this.scheduleNameForm.value.schedule_name,
      "shiftname": this.saveSchedule[i].SL,
      "areaid": 4,
      "pattern":this.saveSchedule[i].Pattern,
      "userid": this.user_data.id
  }
  tempArr.push(tempObj)
}
}else{
  for(var i=0;i<this.saveDuplicateSchedule.length;i++){
    tempObj={
        "seq_id": this.saveDuplicateSchedule[i].seq_id,
        "mon": this.saveDuplicateSchedule[i].mon,
        "tue": this.saveDuplicateSchedule[i].tue,
        "wed": this.saveDuplicateSchedule[i].wed,
        "thu": this.saveDuplicateSchedule[i].thu,
        "fri": this.saveDuplicateSchedule[i].fri,
        "sat": this.saveDuplicateSchedule[i].sat,
        "sun": this.saveDuplicateSchedule[i].sun,
        "schedulename": this.scheduleNameForm.value.schedule_name,
        "shiftname": this.saveDuplicateSchedule[i].shiftname,
        "areaid": this.saveDuplicateSchedule[i].areaid,
        "pattern":this.saveDuplicateSchedule[i].pattern,
        "userid": this.user_data.id
    }
    tempArr.push(tempObj)
  }
}
tempShiftDefintionArr=[]
for(var i=0;i<this.allShiftData.length;i++){
  tempShiftObj={
    "schedulename": this.scheduleNameForm.value.schedule_name,
    "userid": this.user_data.id,
    "shiftname": this.allShiftData[i].shiftName,
    "starttime": this.allShiftData[i].startTime

  }
  tempShiftDefintionArr.push(tempShiftObj)
}
this.scheduleService.checkScheduleName({"schedulename":this.scheduleNameForm.value.schedule_name}).subscribe((res)=>{

    var message=res['message']
    if(message==='Duplicate'){
      this.scheduleNameUnique=false
    }
    else if(message=== 'Unique'){
      this.scheduleNameUnique=true
      console.log(tempArr)
      this.scheduleService.saveAllShiftLine(tempArr).subscribe((res)=>{
                Swal.fire({
              title: 'Success!',
              html: 'Your schedule is saved!',
              icon: 'success',
              showCancelButton: false,
              imageHeight:'250px',
              heightAuto:false,
              confirmButtonColor: '#57818A',
            }).then((result) => {
            })
        },(error)=>{
          console.log(error)
          Swal.fire({
            title: 'Error!',
            html: 'Please try again later!',
            icon: 'error',
            showCancelButton: false,
            confirmButtonColor:'#FF0000',
            imageHeight:'250px',
            heightAuto:false,
          }).then((result) => {
          })

        },()=>{

              this.modalCtrl.dismiss()
        })
    }
},(error)=>{
  console.log(error)
},()=>{
})

// this.scheduleService.saveAllShiftLine(tempArr).subscribe((res)=>{
//   console.log(res)
// },(error)=>{
//   console.log(error)
// },()=>{
//       // this.modalCtrl.dismiss()
// })
// this.all_Schedule=JSON.parse(localStorage.getItem('allSchedule'))
// this.updateScheduleId=JSON.parse(localStorage.getItem('updateScheduleId'))
// var all_shift_data=[]
// for(var i=0;i<this.allShiftData.length;i++){

//   all_shift_data.push({
//   "id": this.allShiftData[i].id,
//   "shiftCategory": this.allShiftData[i].shiftCategory,
//   "shiftName": this.allShiftData[i].shiftName,
//   "startTime": this.allShiftData[i].startTime})
// }
//   if(this.all_Schedule==null){
//     this.all_Schedule=[]
//     var storeSchedule={"schedule_name":this.scheduleNameForm.value.schedule_name,"allShiftRequiredData":all_shift_data,"customizedScheduleShiftLine":this.saveSchedule.customizedScheduleShiftLine,"defaultScheduleShiftLine":this.saveSchedule.defaultScheduleShiftLine}
//       this.all_Schedule.push(storeSchedule)
//       localStorage.setItem('allSchedule',JSON.stringify(this.all_Schedule))
//     }
//     else{
//     var storeSchedule={"schedule_name":this.scheduleNameForm.value.schedule_name,"allShiftRequiredData":all_shift_data,"customizedScheduleShiftLine":this.saveSchedule.customizedScheduleShiftLine,"defaultScheduleShiftLine":this.saveSchedule.defaultScheduleShiftLine}
//       this.all_Schedule.push(storeSchedule)
//       localStorage.setItem('allSchedule',JSON.stringify(this.all_Schedule))

//     }

  }
  close(){
    this.modalCtrl.dismiss()
  }
}
