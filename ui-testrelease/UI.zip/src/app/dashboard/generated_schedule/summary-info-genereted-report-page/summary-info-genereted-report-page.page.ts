import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-summary-info-genereted-report-page',
  templateUrl: './summary-info-genereted-report-page.page.html',
  styleUrls: ['./summary-info-genereted-report-page.page.scss'],
})
export class SummaryInfoGeneretedReportPagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
