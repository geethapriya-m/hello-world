import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ModalController, NavParams } from '@ionic/angular';

import { WorkLoadService } from 'src/app//services/work-load.service';
import data222 from 'src/app//json/work-load-data.json';
import  GeneratedScheduleData  from "src/app//json/Generated_Schedule.json";
import { ScheduleDataService } from 'src/app/services/schedule-data.service';
import { BusinessRulesValidationService } from 'src/app/services/business-rules-validation.service';
import { HeaderTitleForModalPageService } from 'src/app/dashboard/nav-bar-footer/header-title-for-modal-page.service';
@Component({
  selector: 'app-add-new-shift-line',
  templateUrl: './add-new-shift-line.page.html',
  styleUrls: ['./add-new-shift-line.page.scss'],
})
export class AddNewShiftLinePage implements OnInit {

  worData=GeneratedScheduleData
  workShiftLine=[] as any;
  resultShiftLine=[] as any
  finalResultShiftLine=[]as any
  scheduleDataId: any;
  scheduleData: any;
  errorMsg: any;
  scheduleDataSunSat: any;
  // workLoadData: any;
da1=[] as any
  wDataThree: any;
  wDataTwelve: any;
  wDataOne: any;
  wDataTwo: any;
  wDataFour: any;
  wDataElevenNight: any;
  wDataEleven: any;
  wDataTen: any;
  wDataNine: any;
  wDataEight: any;
  wDataSeven: any;
  wDataSix: any;
  wDataFive: any;
  ishidden = false;
  x
  status: boolean = true;
  editScheduleDataForm: FormGroup;
workPattern
  public HideId: boolean = false;
  public showHideText: boolean = false;
  editData: any;
   exampleArray = []
  valid: any =false;
  tempScheduleDataStored: any[];
  data1: any[];
  gapBetweenshift: any;
  da: any[];
  static urlArray;
  workD: any;
  scheduleShiftLine: any;
  scheduleLData: any;
  workLoadData: any=data222;
  testing: any[];
  static data5;
  data2: any;
  pattern
  work_Pattern: any;
  dat1: any;
  WED: any;
  addScheduleDataForm: FormGroup;
  shiftLine: any;
  newId: any;
  convertStringToCharLeft
  convertStringToCharRight
  patternRight
  patternLeft
  allShiftName=[] as any
  allShiftData
  temp
  shift_line
  shift_length
  schedule_id
  edit_schedule_id: any;
  all_Schedule: any;
  edit_schedule: any;
  // workloadData=data222
  constructor(private route:Router,
              public workLoadDataService:WorkLoadService,
              public busniessRulesValidation:BusinessRulesValidationService,
              public dataService:ScheduleDataService,
              public modalCtrl: ModalController,
              public navParams: NavParams,
              public viewCtrl: ModalController,
              private headerTitleService: HeaderTitleForModalPageService,
             public formBuilder: FormBuilder
    ) {
      this.schedule_id=navParams.get('schedule_id')
      console.log(this.schedule_id)
      this.edit_schedule=navParams.get('edit_schedule')
      console.log(this.edit_schedule)
    }
  ngOnInit() {
    this.headerTitleService.setTitle('Add New Shift Line');
if(this.edit_schedule=='edit_schedule'){
  // console.log(isNaN(this.schedule_id))
  // console.log(isNaN(this.edit_schedule_id))
  this.allShiftData=  JSON.parse(localStorage.getItem('allShiftRequiredDataForEditSchedule'))
  this.scheduleShiftLine=JSON.parse(localStorage.getItem('editCustomizedScheduleShiftLine'))
}else{
  // console.log(isNaN(this.edit_schedule_id))

    this.scheduleShiftLine=JSON.parse(localStorage.getItem('customizedScheduleShiftLine'))
    this.scheduleShiftLine=this.scheduleShiftLine[this.schedule_id]

    this.allShiftData=  JSON.parse(localStorage.getItem('allShiftRequiredData'))
// console.log(this.allShiftData)
    // this.data2=JSON.parse(localStorage.getItem('workData'))
    this.workLoadData=this.allShiftData
}

this.allShiftName=[]
// this.allShiftName.push({"shiftName":'X',"shiftCategory":'X',"shift_StartTime":'X'})
for(var i=0;i<this.allShiftData.length;i++){
// console.log(this.allShiftData[i].shiftName)
// console.log( )
if(isNaN(this.allShiftData[i].shiftName)==false){

  if(this.allShiftData[i].shiftCategory==1){
    this.allShiftName.push({"shiftName":Number(this.allShiftData[i].shiftName),"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'MID'})
  }
  else if(this.allShiftData[i].shiftCategory==2){
    this.allShiftName.push({"shiftName":Number(this.allShiftData[i].shiftName),"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'EVE'})
  }
  else if(this.allShiftData[i].shiftCategory==3){
    this.allShiftName.push({"shiftName":Number(this.allShiftData[i].shiftName),"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'DAY'})
  }
  else if(this.allShiftData[i].shiftCategory==4){
    this.allShiftName.push({"shiftName":Number(this.allShiftData[i].shiftName),"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'M/D'})
  }
  else if(this.allShiftData[i].shiftCategory==5){
    this.allShiftName.push({"shiftName":Number(this.allShiftData[i].shiftName),"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'D/E'})
  }
  else if(this.allShiftData[i].shiftCategory==6){
    this.allShiftName.push({"shiftName":Number(this.allShiftData[i].shiftName),"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'E/M'})
  }

}else{
  if(this.allShiftData[i].shiftCategory==1){
    this.allShiftName.push({"shiftName":this.allShiftData[i].shiftName,"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'MID'})
  }
  else if(this.allShiftData[i].shiftCategory==2){
    this.allShiftName.push({"shiftName":this.allShiftData[i].shiftName,"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'EVE'})
  }
  else if(this.allShiftData[i].shiftCategory==3){
    this.allShiftName.push({"shiftName":this.allShiftData[i].shiftName,"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'DAY'})
  }
  else if(this.allShiftData[i].shiftCategory==4){
    this.allShiftName.push({"shiftName":this.allShiftData[i].shiftName,"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'M/D'})
  }
  else if(this.allShiftData[i].shiftCategory==5){
    this.allShiftName.push({"shiftName":this.allShiftData[i].shiftName,"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'D/E'})
  }
  else if(this.allShiftData[i].shiftCategory==6){
    this.allShiftName.push({"shiftName":this.allShiftData[i].shiftName,"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'E/M'})
  }

}
// console.log(this.allShiftName)
}

console.log(Number(this.scheduleShiftLine[(this.scheduleShiftLine.length+ - +1)].seq_id))
this.newId=Number(this.scheduleShiftLine[(this.scheduleShiftLine.length+ - +1)].seq_id)+ + +1
// console.log()
console.log(this.newId)
 this.addScheduleDataForm = this.formBuilder.group({
  id:[],
  Mon: ['X'],
  Tue:['X'],
  Wed: ['X'],
  Thu: ['X'],
  Fri: ['X'],
  Sat: ['X'],
  Sun: ['X'],
  Pattern:[''],
  // BMLRule: [this.valid],
  SL:['']

 })
 return  this.wDataOne,this.wDataTwo,this.wDataThree,this.wDataFour,this.wDataFive,this.wDataSix,this.wDataSeven,this.wDataEight,this.wDataNine,this.wDataTen,this.wDataEleven,this.wDataElevenNight, this.wDataTwelve

  }


 businessRuleValidation(){
// console.log(this.tempScheduleDataStored)
 this.tempScheduleDataStored = [this.Sun.value,this.Mon.value,this.Tue.value,this.Wed.value,this.Thu.value,this.Fri.value,this.Sat.value];
 this.work_Pattern=''
console.log(this.tempScheduleDataStored)
for(var j=0;j<this.tempScheduleDataStored.length;j++){
  for(var k=0;k<this.allShiftName.length;k++){
    if(this.tempScheduleDataStored[j]==this.allShiftName[k].shiftName){
      // console.log(this.allShiftName[j].shiftName,this.allShiftName[j].shiftCategory)
      this.work_Pattern=this.work_Pattern+this.allShiftName[k].shiftCategory

    }
  }
  // console.log(this.allShiftName[j].shiftName)
}

var right_text = this.work_Pattern.substring(7, this.work_Pattern.indexOf("X"),this.work_Pattern.indexOf("X"));
 var left_text = this.work_Pattern.substring(0, this.work_Pattern.indexOf("X"),this.work_Pattern.indexOf("X"));
 this.convertStringToCharLeft=Array.from(left_text)
//  console.log(right_text)
//  console.log(left_text)
 this.convertStringToCharRight=Array.from(right_text)
//  console.log(this.work_Pattern)
//  console.log(this.convertStringToCharRight,this.convertStringToCharLeft)
this.patternRight=''
this.patternLeft=''
for(var i=0;i<this.convertStringToCharRight.length;i++){
  if(this.convertStringToCharRight[i]!=='X'){
    this.patternRight=this.patternRight+this.convertStringToCharRight[i]
  }
}
for(var i=0;i<this.convertStringToCharLeft.length;i++){
  if(this.convertStringToCharLeft[i]!=='X'){
    this.patternLeft=this.patternLeft+this.convertStringToCharLeft[i]
  }
}
this.work_Pattern=this.patternRight+this.patternLeft
this.workPattern=''
this.convertStringToCharLeft=Array.from(this.work_Pattern)

for(var i=0;i<this.convertStringToCharLeft.length;i++){
  if(this.convertStringToCharLeft[i]=='1'||this.convertStringToCharLeft[i]==1){
    this.workPattern=this.workPattern+'M'
  }
  else if(this.convertStringToCharLeft[i]=='2'||this.convertStringToCharLeft[i]==2){
    this.workPattern=this.workPattern+'E'
  }
  else if(this.convertStringToCharLeft[i]=='3'||this.convertStringToCharLeft[i]==3){
    this.workPattern=this.workPattern+'D'
  }
  else if(this.convertStringToCharLeft[i]=='4'||this.convertStringToCharLeft[i]==4){
   this.workPattern=this.workPattern+'S'
 }
 else if(this.convertStringToCharLeft[i]=='5'||this.convertStringToCharLeft[i]==5){
   this.workPattern=this.workPattern+'S'
 }else if(this.convertStringToCharLeft[i]=='6'||this.convertStringToCharLeft[i]==6){
   this.workPattern=this.workPattern+'S'
 }

}
this.work_Pattern=this.workPattern
  if(this.Sun.value==='X'&&this.Sat.value==='X'){
    this.shiftLine='SS-A'
    // this.valid=true
  }else if(this.Sun.value==='X'&&this.Mon.value==='X'){
    this.shiftLine='SM-A'
    // this.valid=true
  }else if(this.Mon.value==='X'&&this.Tue.value==='X'){
    this.shiftLine='MT-A'
    // this.valid=true
  }else if(this.Tue.value==='X'&&this.Wed.value==='X'){
    this.shiftLine='TW-A'
    // this.valid=true
  }else if(this.Wed.value==='X'&&this.Thu.value==='X'){
    this.shiftLine='WT-A'
    // this.valid=true
  }else if(this.Thu.value==='X'&&this.Fri.value==='X'){
    this.shiftLine='TF-A'
    // this.valid=true
  }else if(this.Fri.value==='X'&&this.Sat.value==='X'){
    this.shiftLine='FS-A'
    // this.valid=true
  }else{
    this.valid=false
  }
//  }
// this.addScheduleDataForm.Pattern.value=this.work_Pattern
this.addScheduleDataForm = this.formBuilder.group({
  id:[this.newId],
  Mon: [this.Mon.value],
  Tue:[this.Tue.value],
  Wed: [this.Wed.value],
  Thu: [this.Thu.value],
  Fri: [this.Fri.value],
  Sat: [this.Sat.value],
  Sun: [this.Sun.value],
  Pattern:[this.work_Pattern],
  // BMLRule: [this.valid],
  SL:[this.shiftLine]

 })


const test=[]

  for(var j = 0;j<this.tempScheduleDataStored.length;j++){
    for(var i=0;i<this.allShiftName.length;i++){
    if(this.allShiftName[i].shiftName==this.tempScheduleDataStored[j]){
      // console.log(this.allShiftName[i].shift_StartTime)
      this.temp =this.allShiftName[i].shift_StartTime
    }else if(this.tempScheduleDataStored[j]=='X'){
      // console.log('X')
      this.temp='X'
    }
  }
  test.push(this.temp)
}


this.shift_line={
  "shift_line": test,
    "shift_length":8
}

this.busniessRulesValidation.businessRulesCheck(this.shift_line).subscribe(
  async (response)=>{
    this.valid=response['business_rules']
    // console.log(this.valid)
},
(error: any)=>{this.errorMsg=error;console.log(this.errorMsg)},
async () => {
}
);
console.log(this.valid)
}
get Mon(){
  return this.addScheduleDataForm.get('Mon')
}

get Tue(){
  return this.addScheduleDataForm.get('Tue')
}
get Wed(){
  return this.addScheduleDataForm.get('Wed')
}
get Thu(){
  return this.addScheduleDataForm.get('Thu')
}
get Fri(){
  return this.addScheduleDataForm.get('Fri')
}
get Sat(){
  return this.addScheduleDataForm.get('Sat')
}
get Sun(){
  return this.addScheduleDataForm.get('Sun')
}
// get BMRule(){
//   return this.addScheduleDataForm.get('BMRule')
// }
get Pattern(){
  return this.addScheduleDataForm.get('Pattern')
}


  addNewShiftLine(){
    // console.log(this.Sun.value);
    var addNewShiftLineData=this.addScheduleDataForm.value
    // this.editData.BMLRule=this.valid
    // console.log(this.editData)



if(this.edit_schedule==='edit_schedule'){
  var tempObj={
    "id":null,
    "seq_id":addNewShiftLineData.id,
    "Mon":addNewShiftLineData.Mon,
    "Tue": addNewShiftLineData.Tue,
    "Wed": addNewShiftLineData.Wed,
    "Thu": addNewShiftLineData.Thu,
    "Fri": addNewShiftLineData.Fri,
    "Sat": addNewShiftLineData.Sat,
    "Sun": addNewShiftLineData.Sun,
    "schedulename": this.scheduleShiftLine[0].schedulename,
    "SL": addNewShiftLineData.SL,
    "areaid": this.scheduleShiftLine[0].areaid,
    "Pattern":addNewShiftLineData.Pattern,
    "userid": this.scheduleShiftLine[0].userid
}
  this.scheduleShiftLine.push(tempObj)
  console.log(this.scheduleShiftLine)
  // var current_customized_schedule=JSON.parse(localStorage.getItem('editCustomizedScheduleShiftLine'))

      localStorage.setItem('editCustomizedScheduleShiftLine',JSON.stringify(this.scheduleShiftLine))
      localStorage.setItem('hideBLrulesLabels',JSON.stringify({"hideBLrulesLabels":true}))

              location.reload()
            }else{
              this.scheduleShiftLine.push(addNewShiftLineData)
              var current_customized_schedule=JSON.parse(localStorage.getItem('customizedScheduleShiftLine'))
              var temp_schedule=[],after_add_new_shift_line=[]

              for(var i=0;i<current_customized_schedule.length;i++){
                if(i==Number(this.schedule_id)){
                  temp_schedule=this.scheduleShiftLine
                }else{
                  temp_schedule=current_customized_schedule[i]
                }
                after_add_new_shift_line.push(temp_schedule)
              }

                  localStorage.removeItem('customizedScheduleShiftLine')
                  localStorage.setItem('focusShiftLine',JSON.stringify({"shift_line":addNewShiftLineData,"schedule_id":this.schedule_id}))
                  localStorage.setItem('customizedScheduleShiftLine',JSON.stringify(after_add_new_shift_line))
                  localStorage.setItem('hideBLrulesLabels',JSON.stringify({"hideBLrulesLabels":true}))
              location.reload()
                        // this.modalCtrl.dismiss();

              }

  }
  dismiss() {
    this.modalCtrl.dismiss();
  }
  showHide(){

    this.showHideText = !this.showHideText;


  }


  reset(){
    this.addScheduleDataForm = this.formBuilder.group({
      id:[],
      Mon: ['X'],
      Tue:['X'],
      Wed: ['X'],
      Thu: ['X'],
      Fri: ['X'],
      Sat: ['X'],
      Sun: ['X'],
      Pattern:[''],
      // BMLRule: [this.valid],
      SL:['']

    })
  }
  // static sayHello(user: string): any {
  //   // console.log( EditScheduleDataPage.urlArray);
  //   EditScheduleDataPage.urlArray=this.urlArray="false"
  //   console.log(EditScheduleDataPage.urlArray)
  //   return "Hello " + user+ "!";
  //   //throw new Error('Method not implemented.');
  // }

     sayHello(user: string): any {
    // console.log( EditScheduleDataPage.urlArray);

    // console.log(EditScheduleDataPage.urlArray)
    return "Hello "
    //throw new Error('Method not implemented.');
  }
}
