import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController, AlertController, LoadingController, PopoverController, NavController, NavParams, ActionSheetController } from '@ionic/angular';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import { Label } from 'ng2-charts';
import { HeaderTitleForModalPageService } from 'src/app/dashboard/nav-bar-footer/header-title-for-modal-page.service';
import { RequiredWorkforceService } from 'src/app/services/required-workforce.service';
import { ScheduleDataService } from 'src/app/services/schedule-data.service';
import { FullscreenChartPage } from './fullscreen-chart/fullscreen-chart.page';



@Component({
  selector: 'app-view-summary-day-category-wise',
  templateUrl: './view-summary-day-category-wise.page.html',
  styleUrls: ['./view-summary-day-category-wise.page.scss'],
})
export class ViewSummaryDayCategoryWisePage implements OnInit {


hideChart=false
hide_chart_and_plot=false
  result1:any=[];
  result2:any=[];
  gData:any=[]
  totalShiftLine:any=[]
  ishidden = true;
  countSunSat=0;countSunMon=0;countMonTue=0;countTueWed=0;countWedThu=0;countThuFri=0;countFriSat=0;
  SunSat=0;SunMon=0;MonTue=0;TueWed=0;WedThu=0;ThuFri=0;FriSat=0;
  coun: any;
  showRDOinfo=false
  excelHeaders:string[] = ["Id","Mon","Tue","Wed","Thu","Fri","Sat"];
  templateToExcel:string[][] = [this.excelHeaders,[]];
  totalCount: any;
  totalDefaultScheduleLine=0
  scheduleShift: any []=[]
  afterdeleteShiftLines:any []=[]
  deleteShiftLines:any []=[]
  defaultscheduleShift: any []=[]
  defaultScheduleShift: any []=[]
  gDatasun: any;
  gDatamon: any;
  gDatatue: any;
  gDatawed: any;
  gDatathu: any;
  gDatafri: any;
  gDatasat: any;
  gDataPattern: any;
  generatedComparisonData: any []=[]
  generatedShiftLines:any []=[]
  generatedScheduleData:any []=[]
  requiredEmpData:any
  generatedEmpData
  sun:any;SunDayRequired = [];SunDayGenerated = [];totalSundiff: any;totalSunGenerated: any;totalSunRequired: any;diffSunMid: any;diffSunDay: any;diffSunEve: any;diffSunMidDay: any;diffSunDayEve: any;diffSunEveMid: any;validSunMid: boolean;validSunDay: boolean;validSunEve: boolean;
  mon: any;MonDayRequired= [];MonDayGenerated= [];diffMonMid: any;diffMonDay: any;diffMonEve: any;totalMonRequired: any;totalMonGenerated: any;totalMondiff: any;diffMonMidDay: any;diffMonDayEve: any;diffMonEveMid: any;
  tue:any;TueDayRequired= [];TueDayGenerated= [];diffTueMid: any;diffTueDay: any;diffTueEve: any;totalTueRequired: any;totalTueGenerated: any;totalTuediff: any;diffTueMidDay: any;diffTueDayEve: any;diffTueEveMid: any;
  wed:any;WedDayRequired= [];WedDayGenerated= [];diffWedMid: any;diffWedDay: any;diffWedEve: any;totalWedRequired: any;totalWedGenerated: any;totalWeddiff: any;diffWedMidDay: any;diffWedDayEve: any;diffWedEveMid: any;
  thu:any;ThuDayRequired= [];ThuDayGenerated= [];diffThuMid: any;diffThuDay: any;diffThuEve: any;totalThuRequired: any;totalThuGenerated: any;totalThudiff: any;diffThuMidDay: any;diffThuDayEve: any;diffThuEveMid: any;
  fri:any;FriDayRequired= [];FriDayGenerated= [];diffFriMid: any;diffFriDay: any;diffFriEve: any;totalFriRequired: any;totalFriGenerated: any;totalFridiff: any;diffFriMidDay: any;diffFriDayEve: any;diffFriEveMid: any;
  sat:any;SatDayRequired= [];SatDayGenerated= [];diffSatMid: any;diffSatDay: any;diffSatEve: any;totalSatRequired: any;totalSatGenerated: any;totalSatdiff: any;diffSatMidDay: any;diffSatDayEve: any;diffSatEveMid: any;

  // defaultSun: any;defaultSunDayRequired= [];defaultSunDayGenerated= [];defaultDiffSunMid: any;defaultDiffSunDay: any;defaultDiffSunEve: any;defaultTotalSunRequired: any;defaultTotalSunGenerated: any;defaultTotalSundiff: any;
  // defaultMon: any;defaultMonDayRequired= [];defaultMonDayGenerated= [];defaultDiffMonMid: any;defaultDiffMonDay: any;defaultDiffMonEve: any;defaultTotalMonRequired: any;defaultTotalMonGenerated: any;defaultTotalMondiff: any;
  // defaultTue: any;defaultTueDayRequired= [];defaultTueDayGenerated= [];defaultDiffTueMid: any;defaultDiffTueDay: any;defaultDiffTueEve: any;defaultTotalTueRequired: any;defaultTotalTueGenerated: any;defaultTotalTuediff: any;
  // defaultWed: any;defaultWedDayRequired= [];defaultWedDayGenerated= [];defaultDiffWedMid: any;defaultDiffWedDay: any;defaultDiffWedEve: any;defaultTotalWedRequired: any;defaultTotalWedGenerated: any;defaultTotalWeddiff: any;
  // defaultThu: any;defaultThuDayRequired= [];defaultThuDayGenerated= [];defaultDiffThuMid: any;defaultDiffThuDay: any;defaultDiffThuEve: any;defaultTotalThuRequired: any;defaultTotalThuGenerated: any;defaultTotalThudiff: any;
  // defaultFri: any;defaultFriDayRequired= [];defaultFriDayGenerated= [];defaultDiffFriMid: any;defaultDiffFriDay: any;defaultDiffFriEve: any;defaultTotalFriRequired: any;defaultTotalFriGenerated: any;defaultTotalFridiff: any;
  // defaultSat: any;defaultSatDayRequired= [];defaultSatDayGenerated= [];defaultDiffSatMid: any;defaultDiffSatDay: any;defaultDiffSatEve: any;defaultTotalSatRequired: any;defaultTotalSatGenerated: any;defaultTotalSatdiff: any;

  exportData=[] as any
  exportScheduleData=[] as any
  sunDay=[] as any
  defscheduleShift: any;
  sundAy= [] as any;mondAy= [] as any;tuedAy= [] as any;weddAy= [] as any;thudAy= [] as any;fridAy= [] as any;satdAy= [] as any;
  def_sundAy= [] as any;def_mondAy= [] as any;def_tuedAy= [] as any;def_weddAy= [] as any;def_thudAy= [] as any;def_fridAy= [] as any;def_satdAy= [] as any;
  req: number=0;
  mon_1=0;mon_2=0;mon_3=0;mon_4=0;mon_5=0;
  tue_1=0;tue_2=0;tue_3=0;tue_4=0;tue_5=0;
  wed_1=0;wed_2=0;wed_3=0;wed_4=0;wed_5=0;
  thu_1=0;thu_2=0;thu_3=0;thu_4=0;thu_5=0;
  fri_1=0;fri_2=0;fri_3=0;fri_4=0;fri_5=0;
  sat_1=0;sat_2=0;sat_3=0;sat_4=0;sat_5=0;
  sun_1=0;sun_2=0;sun_3=0;sun_4=0;sun_5=0;
  def_mon_1=0;def_mon_2=0;def_mon_3=0;def_mon_4=0;def_mon_5=0;
  def_tue_1=0;def_tue_2=0;def_tue_3=0;def_tue_4=0;def_tue_5=0;
  def_wed_1=0;def_wed_2=0;def_wed_3=0;def_wed_4=0;def_wed_5=0;
  def_thu_1=0;def_thu_2=0;def_thu_3=0;def_thu_4=0;def_thu_5=0;
  def_fri_1=0;def_fri_2=0;def_fri_3=0;def_fri_4=0;def_fri_5=0;
  def_sat_1=0;def_sat_2=0;def_sat_3=0;def_sat_4=0;def_sat_5=0;
  def_sun_1=0;def_sun_2=0;def_sun_3=0;def_sun_4=0;def_sun_5=0;
  sun_mid: number=0;sun_day: number=0;sun_eve: number=0;
  mon_mid: number=0;mon_day: number=0;mon_eve: number=0;
  tue_mid: number=0;tue_day: number=0;tue_eve: number=0;
  wed_mid: number=0;wed_day: number=0;wed_eve: number=0;
  thu_mid: number=0;thu_day: number=0;thu_eve: number=0;
  fri_mid: number=0;fri_day: number=0;fri_eve: number=0;
  sat_mid: number=0;sat_day: number=0;sat_eve: number=0;
  sun_mid_day: number=0;sun_day_eve: number=0;sun_eve_mid: number=0;
  mon_mid_day: number=0;mon_day_eve: number=0;mon_eve_mid: number=0;
  tue_mid_day: number=0;tue_day_eve: number=0;tue_eve_mid: number=0;
  wed_mid_day: number=0;wed_day_eve: number=0;wed_eve_mid: number=0;
  thu_mid_day: number=0;thu_day_eve: number=0;thu_eve_mid: number=0;
  fri_mid_day: number=0;fri_day_eve: number=0;fri_eve_mid: number=0;
  sat_mid_day: number=0;sat_day_eve: number=0;sat_eve_mid: number=0;
  // // def_sun_mid: number=0;def_sun_day: number=0;def_sun_eve: number=0;
  // def_mon_mid: number=0;def_mon_day: number=0;def_mon_eve: number=0;
  // def_tue_mid: number=0;def_tue_day: number=0;def_tue_eve: number=0;
  // def_wed_mid: number=0;def_wed_day: number=0;def_wed_eve: number=0;
  // def_thu_mid: number=0;def_thu_day: number=0;def_thu_eve: number=0;
  // def_fri_mid: number=0;def_fri_day: number=0;def_fri_eve: number=0;
  // def_sat_mid: number=0;def_sat_day: number=0;def_sat_eve: number=0;
  workLoadData: any;
  shift: any;
  defRequiredData: any;
  defGeneratedData: any;
  ReqVsGeneTotalData;ReqVsGeneMidData: any;ReqVsGeneDayData: any;ReqVsGeneEveData: any;dayTitleforExcel:any;
  req_shift_1_data;req_shift_2_data;req_shift_3_data;req_shift_4_data;req_shift_5_data;
  gen_shift_1_data;gen_shift_2_data;gen_shift_3_data;gen_shift_4_data;gen_shift_5_data;
  defReqVsGeneTotalData;defReqVsGeneMidData: any;defReqVsGeneDayData: any;defReqVsGeneEveData: any;
  def_gen_shift_1_data;def_gen_shift_2_data;def_gen_shift_3_data;def_gen_shift_4_data;def_gen_shift_5_data
  required_title: any;
  generated_title:any;
  required_vs_generated_title: any;
  customizeScheduleShiftLines=[] as any
  totalCustomizeShiftLine: any;
  customizeShiftData: any;
  testing: any;

  reqData=[] as any
  genData=[] as any
  defGenData=[] as any
  t: string;
  defaultValue=0
  da=[] as any
  updateDefscheduleShiftId: {};
  updatedDefScheduleShiftLines=[] as any
  def=[];defSun=[];defMon=[];defTue=[];defWed=[];defThu=[];defFri=[];defSat=[]
  customized=[];customizedSun=[];customizedMon=[];customizedTue=[];customizedWed=[];customizedThu=[];customizedFri=[];customizedSat=[]
  reqDataShiftTime=[];reqDataSun=[];reqDataMon=[];reqDataTue=[];reqDataWed=[];reqDataThu=[];reqDataFri=[];reqDataSat=[]
  reqvsgenDefDataShiftTime=[];reqvsgenDefDataSun=[];reqvsgenDefDataMon=[];reqvsgenDefDataTue=[];reqvsgenDefDataWed=[];reqvsgenDefDataThu=[];reqvsgenDefDataFri=[];reqvsgenDefDataSat=[]
  reqvsgenDataShiftTime=[];reqvsgenDataSun=[];reqvsgenDataMon=[];reqvsgenDataTue=[];reqvsgenDataWed=[];reqvsgenDataThu=[];reqvsgenDataFri=[];reqvsgenDataSat=[]
  focusShiftLine
  allShiftData: any;
  allShiftName: any[];

  midData=[] as any
 dayData= [] as any
 demo=[] as any
 diffDay_23_sun: number;
 diffDay_23_tue: number;
 diffDay_23_mon: number;
 diffDay_23_wed: number;
 diffDay_23_thu: number;
 diffDay_23_fri: number;
 diffDay_23_sat: number;
 day_summary
 default_value=0
 static urlArray;
 current_day_summary_data:any=[]
 total_current_day_summary_data
 total_current_day_req
 total_current_day_gen
 total_current_day_diff
 addShiftData: any
 gShift: any;
  summary_day_data: any;
  // HighlightRow : Number;
  // ClickedRow:any;
  schedule_id

  chart_data_R=[]
  chart_data_G=[]
  result_R_G=[]
  Req=[]
  Gen=[]
  Shift=[]
  final_dataset=[]

  current_day
  constructor(public modalCtrl: ModalController,
              private route:Router,
              private headerTitleService: HeaderTitleForModalPageService,
              public alertCtrl: AlertController,
              public loadingController: LoadingController,
              public popoverController: PopoverController,
              private scheduleService: ScheduleDataService,
              public navCtrl: NavController,
              public navParams: NavParams,
              private requiredWorkforce: RequiredWorkforceService,
              public actionsheetCtrl: ActionSheetController,
              public dataService:ScheduleDataService,
              ) {
                // this.ClickedRow = function(index){
                //   this.HighlightRow = index;
              // }
              ViewSummaryDayCategoryWisePage.urlArray="false"
              this.day_summary=navParams.get('days')
              this.schedule_id=navParams.get('schedule_id')
              // console.log(this.day_summary)
              if(this.day_summary.id==0){
                this.current_day='Sunday'
              }
              else if(this.day_summary.id==1){
                this.current_day='Monday'
              }
              else if(this.day_summary.id==2){
                this.current_day='Tuesday'
              }
              else if(this.day_summary.id==3){
                this.current_day='Wednesday'
              }
              else if(this.day_summary.id==4){
                this.current_day='Thursday'
              }
              else if(this.day_summary.id==5){
                this.current_day='Friday'
              }
              else if(this.day_summary.id==6){
                this.current_day='Saturday'
              }
              this.headerTitleService.setTitle(this.current_day);
                  // }

              }


   ngOnInit() {
    //  console.log(this.day_summary)
this.exportData=[]
this.customizeShiftData=[]
     this.customizeScheduleShiftLines=[]
     this.defGeneratedData=JSON.parse(localStorage.getItem('requiredEmpData'))
     this.defRequiredData=JSON.parse(localStorage.getItem('requiredEmpData'))
     this.generatedEmpData=JSON.parse(localStorage.getItem('requiredEmpData'))
     this.requiredEmpData=JSON.parse(localStorage.getItem('requiredEmpData'))
     this.scheduleShift=JSON.parse(localStorage.getItem('customizedScheduleShiftLine'))
     this.defscheduleShift=JSON.parse(localStorage.getItem('defaultScheduleShiftLine'))
     // this.workLoadData=JSON.parse(localStorage.getItem('workLoadData'))
     this.focusShiftLine=JSON.parse(localStorage.getItem('focusShiftLine'))
     this.allShiftData=  JSON.parse(localStorage.getItem('allShiftRequiredData'))
this.scheduleShift=this.scheduleShift[this.schedule_id]
  this.defscheduleShift=this.defscheduleShift[this.schedule_id]
this.allShiftName=[]
this.allShiftName.push({"shiftName":'X',"shiftCategory":'X'})
// console.log(this.allShiftData)
for(var i=0;i<this.allShiftData.length;i++){
  // console.log(this.allShiftData[i].shiftName)
  this.allShiftName.push({"shiftName":this.allShiftData[i].shiftName,"shiftCategory":this.allShiftData[i].shiftCategory,"shiftTime":this.allShiftData[i].startTime})
}
// console.log(this.allShiftName)





this.shift=['M',6,7,1,3]
// console.log(this.defscheduleShift)

for(var i=0;i<this.defscheduleShift.length;i++){
  this.updateDefscheduleShiftId=[this.defscheduleShift[i].id+1,this.defscheduleShift[i].Sun,this.defscheduleShift[i].Mon,this.defscheduleShift[i].Tue,this.defscheduleShift[i].Wed,this.defscheduleShift[i].Thu,this.defscheduleShift[i].Fri,this.defscheduleShift[i].Sat,this.defscheduleShift[i].Pattern]
  this.updatedDefScheduleShiftLines.push(this.updateDefscheduleShiftId)
}
for(var i=0;i<this.scheduleShift.length;i++){
  if(this.scheduleShift[i]?.SL  == 'SS' || this.scheduleShift[i]?.SL  == 'SS-A'){
    if(this.scheduleShift[i]?.SL  == 'SS-A'){
      this.customizeShiftData=['SS'+(this.scheduleShift[i].id+ + + 1 )+'-A',this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
    }
    else if(this.scheduleShift[i]?.SL  == 'SS'){
      this.customizeShiftData=['SS'+(this.scheduleShift[i].id+ + + 1 ),this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
    }
  }
  else if(this.scheduleShift[i]?.SL  == 'SM' || this.scheduleShift[i]?.SL  == 'SM-A'){
    if(this.scheduleShift[i]?.SL  == 'SM-A'){
      this.customizeShiftData=['SM'+(this.scheduleShift[i].id+ + + 1 )+'-A',this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
      // console.log(this.gData)
    }
    else if(this.scheduleShift[i]?.SL  == 'SM'){
      this.customizeShiftData=['SM'+(this.scheduleShift[i].id+ + + 1 ),this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
    // console.log(this.gData)
    }
  }
  if(this.scheduleShift[i]?.SL  == 'MT' || this.scheduleShift[i]?.SL  == 'MT-A'){
    if(this.scheduleShift[i]?.SL  == 'MT-A'){
      this.customizeShiftData=['MT'+(this.scheduleShift[i].id+ + + 1 )+'-A',this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
      // console.log(this.gData)
    }
    else if(this.scheduleShift[i]?.SL  == 'MT'){
      this.customizeShiftData=['MT'+(this.scheduleShift[i].id+ + + 1 ),this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
    // console.log(this.gData)
    }
  }
  if(this.scheduleShift[i]?.SL  == 'TW' || this.scheduleShift[i]?.SL  == 'TW-A'){
    if(this.scheduleShift[i]?.SL  == 'TW-A'){
      this.customizeShiftData=['TW'+(this.scheduleShift[i].id+ + + 1 )+'-A',this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
      // console.log(this.gData)
    }
    else if(this.scheduleShift[i]?.SL  == 'TW'){
      this.customizeShiftData=['TW'+(this.scheduleShift[i].id+ + + 1 ),this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
    // console.log(this.gData)
    }
  }
  if(this.scheduleShift[i]?.SL  == 'WT' || this.scheduleShift[i]?.SL  == 'WT-A'){
    if(this.scheduleShift[i]?.SL  == 'WT-A'){
      this.customizeShiftData=['WT'+(this.scheduleShift[i].id+ + + 1 )+'-A',this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
      // console.log(this.gData)
    }
    else if(this.scheduleShift[i]?.SL  == 'WT'){
      this.customizeShiftData=['WT'+(this.scheduleShift[i].id+ + + 1 ),this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
    // console.log(this.gData)
    }
  }
  if(this.scheduleShift[i]?.SL  == 'TF' || this.scheduleShift[i]?.SL  == 'TF-A'){
    if(this.scheduleShift[i]?.SL  == 'TF-A'){
      this.customizeShiftData=['TF'+(this.scheduleShift[i].id+ + + 1 )+'-A',this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
      // console.log(this.gData)
    }
    else if(this.scheduleShift[i]?.SL  == 'TF'){
      this.customizeShiftData=['TF'+(this.scheduleShift[i].id+ + + 1 ),this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
    // console.log(this.gData)
    }
  }
  if(this.scheduleShift[i]?.SL  == 'FS' || this.scheduleShift[i]?.SL  == 'FS-A'){
    if(this.scheduleShift[i]?.SL  == 'FS-A'){
      this.customizeShiftData=['FS'+(this.scheduleShift[i].id+ + + 1 )+'-A',this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
      // console.log(this.gData)
    }
    else if(this.scheduleShift[i]?.SL  == 'FS'){
      this.customizeShiftData=['FS'+(this.scheduleShift[i].id+ + + 1 ),this.scheduleShift[i].Sun,this.scheduleShift[i].Mon,this.scheduleShift[i].Tue,this.scheduleShift[i].Wed,this.scheduleShift[i].Thu,this.scheduleShift[i].Fri,this.scheduleShift[i].Sat,this.scheduleShift[i].Pattern]
    // console.log(this.gData)
    }
  }
  this.customizeScheduleShiftLines.push(this.customizeShiftData)
  // console.log(this.customizeScheduleShiftLines)
}



this.sundAy=[]
this.mondAy=[]
this.tuedAy=[]
this.weddAy=[]
this.thudAy=[]
this.fridAy=[]
this.satdAy=[]
for(var i=0;i<this.scheduleShift.length;i++){
  this.sundAy.push(this.scheduleShift[i].Sun)
  this.mondAy.push(this.scheduleShift[i].Mon)
  this.tuedAy.push(this.scheduleShift[i].Tue)
  this.weddAy.push(this.scheduleShift[i].Wed)
  this.thudAy.push(this.scheduleShift[i].Thu)
  this.fridAy.push(this.scheduleShift[i].Fri)
  this.satdAy.push(this.scheduleShift[i].Sat)

}

const countsCustomizedSunDay = {};
this.sundAy.forEach(function (x) { countsCustomizedSunDay[x] = (countsCustomizedSunDay[x] || 0) + 1; });

const countsCustomizedMonDay = {};
this.mondAy.forEach(function (x) { countsCustomizedMonDay[x] = (countsCustomizedMonDay[x] || 0) + 1; });

const countsCustomizedTueDay = {}
this.tuedAy.forEach(function (x) { countsCustomizedTueDay[x] = (countsCustomizedTueDay[x] || 0) + 1; });

const countsCustomizedWedDay = {};
this.weddAy.forEach(function (x) { countsCustomizedWedDay[x] = (countsCustomizedWedDay[x] || 0) + 1; });

const countsCustomizedThuDay = {};
this.thudAy.forEach(function (x) { countsCustomizedThuDay[x] = (countsCustomizedThuDay[x] || 0) + 1; });

const countsCustomizedFriDay = {};
this.fridAy.forEach(function (x) { countsCustomizedFriDay[x] = (countsCustomizedFriDay[x] || 0) + 1; });

const countsCustomizedSatDay = {};
this.satdAy.forEach(function (x) { countsCustomizedSatDay[x] = (countsCustomizedSatDay[x] || 0) + 1; });

let arrSun = [];let arrMon = [];let arrTue = [];let arrWed = [];let arrThu = [];let arrFri = [];let arrSat = [];

Object.keys(countsCustomizedSunDay).map(function(key){
  arrSun.push({"shiftName":[key],"totalEmp":countsCustomizedSunDay[key]})
  return arrSun;
});

Object.keys(countsCustomizedMonDay).map(function(key){
  arrMon.push({"shiftName":[key],"totalEmp":countsCustomizedMonDay[key]})
  return arrMon;
});


Object.keys(countsCustomizedTueDay).map(function(key){
  arrTue.push({"shiftName":[key],"totalEmp":countsCustomizedTueDay[key]})
  return arrTue;
});
Object.keys(countsCustomizedWedDay).map(function(key){
  arrWed.push({"shiftName":[key],"totalEmp":countsCustomizedWedDay[key]})
  return arrWed;
});
Object.keys(countsCustomizedThuDay).map(function(key){
  arrThu.push({"shiftName":[key],"totalEmp":countsCustomizedThuDay[key]})
  return arrThu;
});
Object.keys(countsCustomizedFriDay).map(function(key){
  arrFri.push({"shiftName":[key],"totalEmp":countsCustomizedFriDay[key]})
  return arrFri;
});
Object.keys(countsCustomizedSatDay).map(function(key){
  arrSat.push({"shiftName":[key],"totalEmp":countsCustomizedSatDay[key]})
  return arrSat;
});
let sunTotalEmp=[];let monTotalEmp=[];let tueTotalEmp=[];let wedTotalEmp=[];let thuTotalEmp=[];let friTotalEmp=[];let satTotalEmp=[]
for(var i=0;i<this.allShiftName.length;i++){
  for(var j=0;j<arrSun.length;j++){
    // console.log(arrTue[j].start)
    if(this.allShiftName[i].shiftName==arrSun[j].shiftName)
    {
      if(arrSun[j].shiftName!='X')
      {
      sunTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory ,"totalEmp":arrSun[j].totalEmp})
      }
    }
  }
  for(var j=0;j<arrMon.length;j++){
    // console.log(arrTue[j].start)
    if(this.allShiftName[i].shiftName==arrMon[j].shiftName)
    {
      if(arrMon[j].shiftName!='X')
      {
        monTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrMon[j].totalEmp})
      }


    }
  }
  for(var j=0;j<arrTue.length;j++){
    // console.log(arrTue[j].start)
    if(this.allShiftName[i].shiftName==arrTue[j].shiftName)
    {
      if(arrTue[j].shiftName!='X')
      {
      tueTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrTue[j].totalEmp})
      }
    }
  }
  for(var j=0;j<arrWed.length;j++){
    // console.log(arrTue[j].start)
    if(this.allShiftName[i].shiftName==arrWed[j].shiftName)
    {
      if(arrWed[j].shiftName!='X')
      {
      wedTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrWed[j].totalEmp})
      }
    }
  }
  for(var j=0;j<arrThu.length;j++){
    // console.log(arrTue[j].start)
    if(this.allShiftName[i].shiftName==arrThu[j].shiftName)
    {
      if(arrThu[j].shiftName!='X')
      {
      thuTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrThu[j].totalEmp})
      }
    }
  }
  for(var j=0;j<arrFri.length;j++){
    // console.log(arrTue[j].start)
    if(this.allShiftName[i].shiftName==arrFri[j].shiftName)
    {
      if(arrFri[j].shiftName!='X')
      {
      friTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrFri[j].totalEmp})
      }
    }
  }
  for(var j=0;j<arrSat.length;j++){
    // console.log(arrTue[j].start)
    if(this.allShiftName[i].shiftName==arrSat[j].shiftName)
    {
      if(arrSat[j].shiftName!='X')
      {
      satTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrSat[j].totalEmp})
      }
    }
  }
}

for(var i=0;i<sunTotalEmp.length;i++){
  if(sunTotalEmp[i].shiftCategory=='1'){
    this.sun_mid=this.sun_mid+ + +sunTotalEmp[i].totalEmp
  }
  else if(sunTotalEmp[i].shiftCategory=='3'){
    this.sun_day=this.sun_day+ + +sunTotalEmp[i].totalEmp
  }
  else if(sunTotalEmp[i].shiftCategory=='2'){
    this.sun_eve=this.sun_eve+ + +sunTotalEmp[i].totalEmp
  }
  else if(sunTotalEmp[i].shiftCategory=='4'){
    this.sun_mid_day=this.sun_mid_day+ + +sunTotalEmp[i].totalEmp
  }
  else if(sunTotalEmp[i].shiftCategory=='5'){
    this.sun_day_eve=this.sun_day_eve+ + +sunTotalEmp[i].totalEmp
  }
  else if(sunTotalEmp[i].shiftCategory=='6'){
    this.sun_eve_mid=this.sun_eve_mid+ + +sunTotalEmp[i].totalEmp
  }
}

// Mon
for(var i=0;i<monTotalEmp.length;i++){
  if(monTotalEmp[i].shiftCategory=='1'){
    this.mon_mid=this.mon_mid+ + +monTotalEmp[i].totalEmp
  }
  else if(monTotalEmp[i].shiftCategory=='3'){
    this.mon_day=this.mon_day+ + +monTotalEmp[i].totalEmp
  }
  else if(monTotalEmp[i].shiftCategory=='2'){
    this.mon_eve=this.mon_eve+ + +monTotalEmp[i].totalEmp
  }
  else if(monTotalEmp[i].shiftCategory=='4'){
    this.mon_mid_day=this.mon_mid_day+ + +monTotalEmp[i].totalEmp
  }
  else if(monTotalEmp[i].shiftCategory=='5'){
    this.mon_day_eve=this.mon_day_eve+ + +monTotalEmp[i].totalEmp
  }
  else if(monTotalEmp[i].shiftCategory=='6'){
    this.mon_eve_mid=this.mon_eve_mid+ + +monTotalEmp[i].totalEmp
  }
}
// Tue
for(var i=0;i<tueTotalEmp.length;i++){
  if(tueTotalEmp[i].shiftCategory=='1'){
    this.tue_mid=this.tue_mid+ + +tueTotalEmp[i].totalEmp
  }
  else if(tueTotalEmp[i].shiftCategory=='3'){
    this.tue_day=this.tue_day+ + +tueTotalEmp[i].totalEmp
  }
  else if(tueTotalEmp[i].shiftCategory=='2'){
    this.tue_eve=this.tue_eve+ + +tueTotalEmp[i].totalEmp
  }
  else if(tueTotalEmp[i].shiftCategory=='4'){
    this.tue_mid_day=this.tue_mid_day+ + +tueTotalEmp[i].totalEmp
  }
  else if(tueTotalEmp[i].shiftCategory=='5'){
    this.tue_day_eve=this.tue_day_eve+ + +tueTotalEmp[i].totalEmp
  }
  else if(tueTotalEmp[i].shiftCategory=='6'){
    this.tue_eve_mid=this.tue_eve_mid+ + +tueTotalEmp[i].totalEmp
  }
}
// console.log(tueTotalEmp)
// console.log(this.tue_mid)
// Wed
for(var i=0;i<wedTotalEmp.length;i++){
  if(wedTotalEmp[i].shiftCategory=='1'){
    this.wed_mid=this.wed_mid+ + +wedTotalEmp[i].totalEmp
  }
  else if(wedTotalEmp[i].shiftCategory=='3'){
    this.wed_day=this.wed_day+ + +wedTotalEmp[i].totalEmp
  }
  else if(wedTotalEmp[i].shiftCategory=='2'){
    this.wed_eve=this.wed_eve+ + +wedTotalEmp[i].totalEmp
  }
  else if(wedTotalEmp[i].shiftCategory=='4'){
    this.wed_mid_day=this.wed_mid_day+ + +wedTotalEmp[i].totalEmp
  }
  else if(wedTotalEmp[i].shiftCategory=='5'){
    this.wed_day_eve=this.wed_day_eve+ + +wedTotalEmp[i].totalEmp
  }
  else if(wedTotalEmp[i].shiftCategory=='6'){
    this.wed_eve_mid=this.wed_eve_mid+ + +wedTotalEmp[i].totalEmp
  }
}

// Thu
for(var i=0;i<thuTotalEmp.length;i++){
  if(thuTotalEmp[i].shiftCategory=='1'){
    this.thu_mid=this.thu_mid+ + +thuTotalEmp[i].totalEmp
  }
  else if(thuTotalEmp[i].shiftCategory=='3'){
    this.thu_day=this.thu_day+ + +thuTotalEmp[i].totalEmp
  }
  else if(thuTotalEmp[i].shiftCategory=='2'){
    this.thu_eve=this.thu_eve+ + +thuTotalEmp[i].totalEmp
  }
  else if(thuTotalEmp[i].shiftCategory=='4'){
    this.thu_mid_day=this.thu_mid_day+ + +thuTotalEmp[i].totalEmp
  }
  else if(thuTotalEmp[i].shiftCategory=='5'){
    this.thu_day_eve=this.thu_day_eve+ + +thuTotalEmp[i].totalEmp
  }
  else if(thuTotalEmp[i].shiftCategory=='6'){
    this.thu_eve_mid=this.thu_eve_mid+ + +thuTotalEmp[i].totalEmp
  }
}

// Fri
for(var i=0;i<friTotalEmp.length;i++){
  if(friTotalEmp[i].shiftCategory=='1'){
    this.fri_mid=this.fri_mid+ + +friTotalEmp[i].totalEmp
  }
  else if(friTotalEmp[i].shiftCategory=='3'){
    this.fri_day=this.fri_day+ + +friTotalEmp[i].totalEmp
  }
  else if(friTotalEmp[i].shiftCategory=='2'){
    this.fri_eve=this.fri_eve+ + +friTotalEmp[i].totalEmp
  }
  else if(friTotalEmp[i].shiftCategory=='4'){
    this.fri_mid_day=this.fri_mid_day+ + +friTotalEmp[i].totalEmp
  }
  else if(friTotalEmp[i].shiftCategory=='5'){
    this.fri_day_eve=this.fri_day_eve+ + +friTotalEmp[i].totalEmp
  }
  else if(friTotalEmp[i].shiftCategory=='6'){
    this.fri_eve_mid=this.fri_eve_mid+ + +friTotalEmp[i].totalEmp
  }
}

//Sat
for(var i=0;i<satTotalEmp.length;i++){
  if(satTotalEmp[i].shiftCategory=='1'){
    this.sat_mid=this.sat_mid+ + +satTotalEmp[i].totalEmp
  }
  else if(satTotalEmp[i].shiftCategory=='3'){
    this.sat_day=this.sat_day+ + +satTotalEmp[i].totalEmp
  }
  else if(satTotalEmp[i].shiftCategory=='2'){
    this.sat_eve=this.sat_eve+ + +satTotalEmp[i].totalEmp
  }
  else if(satTotalEmp[i].shiftCategory=='4'){
    this.sat_mid_day=this.sat_mid_day+ + +satTotalEmp[i].totalEmp
  }
  else if(satTotalEmp[i].shiftCategory=='5'){
    this.sat_day_eve=this.sat_day_eve+ + +satTotalEmp[i].totalEmp
  }
  else if(satTotalEmp[i].shiftCategory=='6'){
    this.sat_eve_mid=this.sat_eve_mid+ + +satTotalEmp[i].totalEmp
  }
}







let allShift=[]
for(var i=0;i<this.allShiftName.length;i++){
  if(this.allShiftName[i].shiftName!='X'){
    allShift.push(this.allShiftName[i])
  }
}
    // Mon
    let allMidData1=[]
    let allSunData=[]
    let allMidData=[]
    let mon=[]; let monDay=[];let monEve=[];let monMid=[];let monMD=[];let monDE=[];let monEM=[];
    for(var i=0;i<monTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==monTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime)
            {
              if(monTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime && (monTotalEmp[i].totalEmp!=0 || monTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"}
                monMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
              }
              else if(monTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime){
                monMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
              }
              else if(monTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime && (monTotalEmp[i].totalEmp!=0 || monTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"}
                  monDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(monTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime){
                  monDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(monTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime && (monTotalEmp[i].totalEmp!=0 || monTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"}
                  monEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                  }
                  else if(monTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime){
                    monEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                  }
                  else if(monTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime && (monTotalEmp[i].totalEmp!=0 || monTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"}
                    monMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                    }
                    else if(monTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime){
                      monMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                    }
                    else if(monTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime && (monTotalEmp[i].totalEmp!=0 || monTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"}
                      monDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                      }
                      else if(monTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime){
                        monDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                      }
                      else if(monTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime && (monTotalEmp[i].totalEmp!=0 || monTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"}
                        monEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                        }
                        else if(monTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime){
                          monEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                        }
             }

        }

      }
      let allShiftMonMid=[];let allShiftMonDay=[];let allShiftMonEve=[]
      let allShiftMonMD=[];let allShiftMonDE=[];let allShiftMonEM=[]
      let finalMonMidData;let finalMonDayData;let finalMonEveData
      let finalMonMDData;let finalMonDEData;let finalMonEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          allShiftMonMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftMonMid.length;j++){
        this.addShiftData={"shiftTime":allShiftMonMid[j].shiftTime,"totalEmp":0,"day":"Mon"}
        monMid.push(this.addShiftData)
      }
      finalMonMidData=monMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          allShiftMonDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftMonDay.length;j++){
        this.addShiftData={"shiftTime":allShiftMonDay[j].shiftTime,"totalEmp":0,"day":"Mon"}
        monDay.push(this.addShiftData)
      }
      finalMonDayData=  monDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          allShiftMonEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftMonEve.length;j++){
        this.addShiftData={"shiftTime":allShiftMonEve[j].shiftTime,"totalEmp":0,"day":"Mon"}
        monEve.push(this.addShiftData)
      }
      finalMonEveData=monEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Day
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='4' ){
          allShiftMonMD.push(this.allShiftName[i])
        }
      }
      // console.log(allShiftMonMD)
      for(var j=0;j<allShiftMonMD.length;j++){
        this.addShiftData={"shiftTime":allShiftMonMD[j].shiftTime,"totalEmp":0,"day":"Mon"}
        monMD.push(this.addShiftData)
      }
      // console.log(monMD)
      finalMonMDData=monMD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
    // console.log(finalMonMDData)
      //Day-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='5' ){
          allShiftMonDE.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftMonDE.length;j++){
        this.addShiftData={"shiftTime":allShiftMonDE[j].shiftTime,"totalEmp":0,"day":"Mon"}
        monDE.push(this.addShiftData)
      }
      finalMonDEData=monDE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='6' ){
          allShiftMonEM.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftMonEM.length;j++){
        this.addShiftData={"shiftTime":allShiftMonEM[j].shiftTime,"totalEmp":0,"day":"Mon"}
        monEM.push(this.addShiftData)
      }
      finalMonEMData=monEM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

    // // Tue
    let tue=[]; let tueDay=[];let tueEve=[];let tueMid=[];let tueMD=[];let tueDE=[];let tueEM=[];
    for(var i=0;i<tueTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==tueTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime)
            {
              if(tueTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime && (tueTotalEmp[i].totalEmp!=0 || tueTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"}
                tueMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
              }
              else if(tueTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime){
                tueMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
              }
              else if(tueTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime && (tueTotalEmp[i].totalEmp!=0 || tueTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"}
                  tueDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(tueTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime){
                  tueDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(tueTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime && (tueTotalEmp[i].totalEmp!=0 || tueTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"}
                  tueEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                  }
                  else if(tueTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime){
                    tueEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                  }
                  else if(tueTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime && (tueTotalEmp[i].totalEmp!=0 || tueTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"}
                    tueMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                    }
                    else if(tueTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime){
                      tueMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                    }
                    else if(tueTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime && (tueTotalEmp[i].totalEmp!=0 || tueTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"}
                      tueDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                      }
                      else if(tueTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime){
                        tueDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                      }
                      else if(tueTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime && (tueTotalEmp[i].totalEmp!=0 || tueTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"}
                        tueEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                        }
                        else if(tueTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime){
                          tueEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                        }
             }

        }

      }
      let allShiftTueMid=[];let allShiftTueDay=[];let allShiftTueEve=[]
      let allShiftTueMD=[];let allShiftTueDE=[];let allShiftTueEM=[]
      let finalTueMidData;let finalTueDayData;let finalTueEveData
      let finalTueMDData;let finalTueDEData;let finalTueEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          allShiftTueMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftTueMid.length;j++){
        this.addShiftData={"shiftTime":allShiftTueMid[j].shiftTime,"totalEmp":0,"day":"Tue"}
        tueMid.push(this.addShiftData)
      }
      finalTueMidData=tueMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          allShiftTueDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftTueDay.length;j++){
        this.addShiftData={"shiftTime":allShiftTueDay[j].shiftTime,"totalEmp":0,"day":"Tue"}
        tueDay.push(this.addShiftData)
      }
      finalTueDayData=  tueDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          allShiftTueEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftTueEve.length;j++){
        this.addShiftData={"shiftTime":allShiftTueEve[j].shiftTime,"totalEmp":0,"day":"Tue"}
        tueEve.push(this.addShiftData)
      }
      finalTueEveData=tueEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Day
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='4' ){
          allShiftTueMD.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftTueMD.length;j++){
        this.addShiftData={"shiftTime":allShiftTueMD[j].shiftTime,"totalEmp":0,"day":"Tue"}
        tueMD.push(this.addShiftData)
      }
      finalTueMDData=tueMD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Day-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='5' ){
          allShiftTueDE.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftTueDE.length;j++){
        this.addShiftData={"shiftTime":allShiftTueDE[j].shiftTime,"totalEmp":0,"day":"Tue"}
        tueDE.push(this.addShiftData)
      }
      finalTueDEData=tueDE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='6' ){
          allShiftTueEM.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftTueEM.length;j++){
        this.addShiftData={"shiftTime":allShiftTueEM[j].shiftTime,"totalEmp":0,"day":"Tue"}
        tueEM.push(this.addShiftData)
      }
      finalTueEMData=tueEM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
    // //Wed
    let wed=[]; let wedDay=[];let wedEve=[];let wedMid=[];let wedMD=[];let wedDE=[];let wedEM=[];
    for(var i=0;i<wedTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==wedTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime)
            {
              if(wedTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime && (wedTotalEmp[i].totalEmp!=0 || wedTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"}
                wedMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
              }
              else if(wedTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime){
                wedMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
              }
              else if(wedTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime && (wedTotalEmp[i].totalEmp!=0 || wedTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"}
                  wedDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(wedTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime){
                  wedDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(wedTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime && (wedTotalEmp[i].totalEmp!=0 || wedTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"}
                  wedEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                  }
                  else if(wedTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime){
                    wedEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                  }
                  else if(wedTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime && (wedTotalEmp[i].totalEmp!=0 || wedTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"}
                    wedMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                    }
                    else if(wedTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime){
                      wedMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                    }
                    else if(wedTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime && (wedTotalEmp[i].totalEmp!=0 || wedTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"}
                      wedDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                      }
                      else if(wedTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime){
                        wedDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                      }
                      else if(wedTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime && (wedTotalEmp[i].totalEmp!=0 || wedTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"}
                        wedEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                        }
                        else if(wedTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime){
                          wedEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                        }
             }

        }

      }
      let allShiftWedMid=[];let allShiftWedDay=[];let allShiftWedEve=[]
      let allShiftWedMD=[];let allShiftWedDE=[];let allShiftWedEM=[]
      let finalWedMidData;let finalWedDayData;let finalWedEveData
      let finalWedMDData;let finalWedDEData;let finalWedEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          allShiftWedMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftWedMid.length;j++){
        this.addShiftData={"shiftTime":allShiftWedMid[j].shiftTime,"totalEmp":0,"day":"Wed"}
        wedMid.push(this.addShiftData)
      }
      finalWedMidData=wedMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          allShiftWedDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftWedDay.length;j++){
        this.addShiftData={"shiftTime":allShiftWedDay[j].shiftTime,"totalEmp":0,"day":"Wed"}
        wedDay.push(this.addShiftData)
      }
      finalWedDayData=  wedDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          allShiftWedEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftWedEve.length;j++){
        this.addShiftData={"shiftTime":allShiftWedEve[j].shiftTime,"totalEmp":0,"day":"Wed"}
        wedEve.push(this.addShiftData)
      }
      finalWedEveData=wedEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Day
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='4' ){
          allShiftWedMD.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftWedMD.length;j++){
        this.addShiftData={"shiftTime":allShiftWedMD[j].shiftTime,"totalEmp":0,"day":"Wed"}
        wedMD.push(this.addShiftData)
      }
      finalWedMDData=wedMD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Day-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='5' ){
          allShiftWedDE.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftWedDE.length;j++){
        this.addShiftData={"shiftTime":allShiftWedDE[j].shiftTime,"totalEmp":0,"day":"Wed"}
        wedDE.push(this.addShiftData)
      }
      finalWedDEData=wedDE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='6' ){
          allShiftWedEM.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftWedEM.length;j++){
        this.addShiftData={"shiftTime":allShiftWedEM[j].shiftTime,"totalEmp":0,"day":"Wed"}
        wedEM.push(this.addShiftData)
      }
      finalWedEMData=wedEM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

    // //Thu
    let thu=[]; let thuDay=[];let thuEve=[];let thuMid=[];let thuMD=[];let thuDE=[];let thuEM=[];
    for(var i=0;i<thuTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==thuTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime)
            {
              if(thuTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime && (thuTotalEmp[i].totalEmp!=0 || thuTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"}
                thuMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
              }
              else if(thuTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime){
                thuMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
              }
              else if(thuTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime && (thuTotalEmp[i].totalEmp!=0 || thuTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"}
                  thuDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(thuTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime){
                  thuDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(thuTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime && (thuTotalEmp[i].totalEmp!=0 || thuTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"}
                  thuEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                  }
                  else if(thuTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime){
                    thuEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                  }
                  else if(thuTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime && (thuTotalEmp[i].totalEmp!=0 || thuTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"}
                    thuMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                    }
                    else if(thuTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime){
                      thuMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                    }
                    else if(thuTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime && (thuTotalEmp[i].totalEmp!=0 || thuTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"}
                      thuDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                      }
                      else if(thuTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime){
                        thuDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                      }
                      else if(thuTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime && (thuTotalEmp[i].totalEmp!=0 || thuTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"}
                        thuEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                        }
                        else if(thuTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime){
                          thuEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                        }
             }

        }

      }
      let allShiftThuMid=[];let allShiftThuDay=[];let allShiftThuEve=[]
      let allShiftThuMD=[];let allShiftThuDE=[];let allShiftThuEM=[]
      let finalThuMidData;let finalThuDayData;let finalThuEveData
      let finalThuMDData;let finalThuDEData;let finalThuEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          allShiftThuMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftThuMid.length;j++){
        this.addShiftData={"shiftTime":allShiftThuMid[j].shiftTime,"totalEmp":0,"day":"Thu"}
        thuMid.push(this.addShiftData)
      }
      finalThuMidData=thuMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          allShiftThuDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftThuDay.length;j++){
        this.addShiftData={"shiftTime":allShiftThuDay[j].shiftTime,"totalEmp":0,"day":"Thu"}
        thuDay.push(this.addShiftData)
      }
      finalThuDayData=  thuDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          allShiftThuEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftThuEve.length;j++){
        this.addShiftData={"shiftTime":allShiftThuEve[j].shiftTime,"totalEmp":0,"day":"Thu"}
        thuEve.push(this.addShiftData)
      }
      finalThuEveData=thuEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Day
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='4' ){
          allShiftThuMD.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftThuMD.length;j++){
        this.addShiftData={"shiftTime":allShiftThuMD[j].shiftTime,"totalEmp":0,"day":"Thu"}
        thuMD.push(this.addShiftData)
      }
      finalThuMDData=thuMD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      //Day-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='5' ){
          allShiftThuDE.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftThuDE.length;j++){
        this.addShiftData={"shiftTime":allShiftThuDE[j].shiftTime,"totalEmp":0,"day":"Thu"}
        thuDE.push(this.addShiftData)
      }
      finalThuDEData=thuDE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      //Mid-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='6' ){
          allShiftThuEM.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftThuEM.length;j++){
        this.addShiftData={"shiftTime":allShiftThuEM[j].shiftTime,"totalEmp":0,"day":"Thu"}
        thuEM.push(this.addShiftData)
      }
      finalThuEMData=thuEM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

    // //Fri
    let fri=[]; let friDay=[];let friEve=[];let friMid=[];let friMD=[];let friDE=[];let friEM=[];
    for(var i=0;i<friTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==friTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime)
            {
              if(friTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime && (friTotalEmp[i].totalEmp!=0 || friTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"}
                friMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
              }
              else if(friTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime){
                friMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
              }
              else if(friTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime && (friTotalEmp[i].totalEmp!=0 || friTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"}
                  friDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(friTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime){
                  friDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(friTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime && (friTotalEmp[i].totalEmp!=0 || friTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"}
                  friEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                  }
                  else if(friTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime){
                    friEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                  }
                  else if(friTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime && (friTotalEmp[i].totalEmp!=0 || friTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"}
                    friMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                    }
                    else if(friTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime){
                      friMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                    }
                    else if(friTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime && (friTotalEmp[i].totalEmp!=0 || friTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"}
                      friDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                      }
                      else if(friTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime){
                        friDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                      }
                      else if(friTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime && (friTotalEmp[i].totalEmp!=0 || friTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"}
                        friEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                        }
                        else if(friTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime){
                          friEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                        }
             }

        }

      }
      let allShiftFriMid=[];let allShiftFriDay=[];let allShiftFriEve=[]
      let allShiftFriMD=[];let allShiftFriDE=[];let allShiftFriEM=[]
      let finalFriMidData;let finalFriDayData;let finalFriEveData
      let finalFriMDData;let finalFriDEData;let finalFriEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          allShiftFriMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftFriMid.length;j++){
        this.addShiftData={"shiftTime":allShiftFriMid[j].shiftTime,"totalEmp":0,"day":"Fri"}
        friMid.push(this.addShiftData)
      }
      finalFriMidData=friMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          allShiftFriDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftFriDay.length;j++){
        this.addShiftData={"shiftTime":allShiftFriDay[j].shiftTime,"totalEmp":0,"day":"Fri"}
        friDay.push(this.addShiftData)
      }
      finalFriDayData=  friDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          allShiftFriEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftFriEve.length;j++){
        this.addShiftData={"shiftTime":allShiftFriEve[j].shiftTime,"totalEmp":0,"day":"Fri"}
        friEve.push(this.addShiftData)
      }
      finalFriEveData=friEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Day
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='4' ){
          allShiftFriMD.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftFriMD.length;j++){
        this.addShiftData={"shiftTime":allShiftFriMD[j].shiftTime,"totalEmp":0,"day":"Fri"}
        friMD.push(this.addShiftData)
      }
      finalFriMDData=friMD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      //Day-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='5' ){
          allShiftFriDE.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftFriDE.length;j++){
        this.addShiftData={"shiftTime":allShiftFriDE[j].shiftTime,"totalEmp":0,"day":"Fri"}
        friDE.push(this.addShiftData)
      }
      finalFriDEData=friDE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      //Mid-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='6' ){
          allShiftFriEM.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftFriEM.length;j++){
        this.addShiftData={"shiftTime":allShiftFriEM[j].shiftTime,"totalEmp":0,"day":"Fri"}
        friEM.push(this.addShiftData)
      }
      finalFriEMData=friEM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

    // //Sat
    let sat=[]; let satDay=[];let satEve=[];let satMid=[];let satMD=[];let satDE=[];let satEM=[];
    for(var i=0;i<satTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==satTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime)
            {
              if(satTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime && (satTotalEmp[i].totalEmp!=0 || satTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"}
                satMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
              }
              else if(satTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime){
                satMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
              }
              else if(satTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime && (satTotalEmp[i].totalEmp!=0 || satTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"}
                  satDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(satTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime){
                  satDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(satTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime && (satTotalEmp[i].totalEmp!=0 || satTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"}
                  satEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                  }
                  else if(satTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime){
                    satEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                  }
                  else if(satTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime && (satTotalEmp[i].totalEmp!=0 || satTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"}
                    satMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                    }
                    else if(satTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime){
                      satMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                    }
                    else if(satTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime && (satTotalEmp[i].totalEmp!=0 || satTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"}
                      satDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                      }
                      else if(satTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime){
                        satDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                      }
                      else if(satTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime && (satTotalEmp[i].totalEmp!=0 || satTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"}
                        satEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                        }
                        else if(satTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime){
                          satEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                        }
             }

        }

      }

      let allShiftSatMid=[];let allShiftSatDay=[];let allShiftSatEve=[]
      let allShiftSatMD=[];let allShiftSatDE=[];let allShiftSatEM=[]
      let finalSatMidData;let finalSatDayData;let finalSatEveData
      let finalSatMDData;let finalSatDEData;let finalSatEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          allShiftSatMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSatMid.length;j++){
        this.addShiftData={"shiftTime":allShiftSatMid[j].shiftTime,"totalEmp":0,"day":"Sat"}
        satMid.push(this.addShiftData)
      }
      finalSatMidData=satMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          allShiftSatDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSatDay.length;j++){
        this.addShiftData={"shiftTime":allShiftSatDay[j].shiftTime,"totalEmp":0,"day":"Sat"}
        satDay.push(this.addShiftData)
      }
      finalSatDayData=  satDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          allShiftSatEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSatEve.length;j++){
        this.addShiftData={"shiftTime":allShiftSatEve[j].shiftTime,"totalEmp":0,"day":"Sat"}
        satEve.push(this.addShiftData)
      }
      finalSatEveData=satEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Day
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='4' ){
          allShiftSatMD.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSatMD.length;j++){
        this.addShiftData={"shiftTime":allShiftSatMD[j].shiftTime,"totalEmp":0,"day":"Sat"}
        satMD.push(this.addShiftData)
      }
      finalSatMDData=satMD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      //Day-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='5' ){
          allShiftSatDE.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSatDE.length;j++){
        this.addShiftData={"shiftTime":allShiftSatDE[j].shiftTime,"totalEmp":0,"day":"Sat"}
        satDE.push(this.addShiftData)
      }
      finalSatDEData=satDE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      //Mid-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='6' ){
          allShiftSatEM.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSatEM.length;j++){
        this.addShiftData={"shiftTime":allShiftSatEM[j].shiftTime,"totalEmp":0,"day":"Sat"}
        satEM.push(this.addShiftData)
      }
      finalSatEMData=satEM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

    // //Sun
    let sun=[]; let sunDay=[];let sunEve=[];let sunMid=[];let sunMD=[];let sunDE=[];let sunEM=[];
    for(var i=0;i<sunTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==sunTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime)
            {
              if(sunTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime && (sunTotalEmp[i].totalEmp!=0 || sunTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"}
                sunMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
              }
              else if(sunTotalEmp[i].shiftCategory=='1' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime){
                sunMid.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
              }
              else if(sunTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime && (sunTotalEmp[i].totalEmp!=0 || sunTotalEmp[i].totalEmp!=null)){
                this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"}
                  sunDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(sunTotalEmp[i].shiftCategory=='3' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime){
                  sunDay.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                  // allDayData1.push(this.addShiftData)
                }
                else if(sunTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime && (sunTotalEmp[i].totalEmp!=0 || sunTotalEmp[i].totalEmp!=null)){
                  this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"}
                  sunEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                  }
                  else if(sunTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime){
                    sunEve.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                  }
                  else if(sunTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime && (sunTotalEmp[i].totalEmp!=0 || sunTotalEmp[i].totalEmp!=null)){
                    this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"}
                    sunMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                    }
                    else if(sunTotalEmp[i].shiftCategory=='4' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime){
                      sunMD.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                    }
                    else if(sunTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime && (sunTotalEmp[i].totalEmp!=0 || sunTotalEmp[i].totalEmp!=null)){
                      this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"}
                      sunDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                      }
                      else if(sunTotalEmp[i].shiftCategory=='5' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime){
                        sunDE.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                      }
                      else if(sunTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime && (sunTotalEmp[i].totalEmp!=0 || sunTotalEmp[i].totalEmp!=null)){
                        this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"}
                        sunEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                        }
                        else if(sunTotalEmp[i].shiftCategory=='6' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime){
                          sunEM.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                        }
             }

        }

      }
      let allShiftSunMid=[];let allShiftSunDay=[];let allShiftSunEve=[]
      let allShiftSunMD=[];let allShiftSunDE=[];let allShiftSunEM=[]
      let finalSunMidData;let finalSunDayData;let finalSunEveData
      let finalSunMDData;let finalSunDEData;let finalSunEMData
      // MID
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='1' ){
          allShiftSunMid.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSunMid.length;j++){
        this.addShiftData={"shiftTime":allShiftSunMid[j].shiftTime,"totalEmp":0,"day":"Sun"}
        sunMid.push(this.addShiftData)
      }
      finalSunMidData=sunMid.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      // DAY
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='3' ){
          allShiftSunDay.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSunDay.length;j++){
        this.addShiftData={"shiftTime":allShiftSunDay[j].shiftTime,"totalEmp":0,"day":"Sun"}
        sunDay.push(this.addShiftData)
      }
      finalSunDayData=  sunDay.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      // EVE
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='2' ){
          allShiftSunEve.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSunEve.length;j++){
        this.addShiftData={"shiftTime":allShiftSunEve[j].shiftTime,"totalEmp":0,"day":"Sun"}
        sunEve.push(this.addShiftData)
      }
      finalSunEveData=sunEve.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
      //Mid-Day
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='4' ){
          allShiftSunMD.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSunMD.length;j++){
        this.addShiftData={"shiftTime":allShiftSunMD[j].shiftTime,"totalEmp":0,"day":"Sun"}
        sunMD.push(this.addShiftData)
      }
      finalSunMDData=sunMD.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      //Day-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='5' ){
          allShiftSunDE.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSunDE.length;j++){
        this.addShiftData={"shiftTime":allShiftSunDE[j].shiftTime,"totalEmp":0,"day":"Sun"}
        sunDE.push(this.addShiftData)
      }
      finalSunDEData=sunDE.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

      //Mid-Eve
      for(var i=0;i<this.allShiftName.length;i++){
        if(this.allShiftName[i].shiftCategory=='6' ){
          allShiftSunEM.push(this.allShiftName[i])
        }
      }
      for(var j=0;j<allShiftSunEM.length;j++){
        this.addShiftData={"shiftTime":allShiftSunEM[j].shiftTime,"totalEmp":0,"day":"Sun"}
        sunEM.push(this.addShiftData)
      }
      finalSunEMData=sunEM.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)




// console.log(finalMonMDData)
// console.log(def_finalMonMidData)
// console.log(def_finalTueMidData)
// console.log(def_finalWedMidData)
// console.log(def_finalThuMidData)
// console.log(def_finalFriMidData)
// console.log(def_finalSatMidData)

// console.log("/")
// console.log(finalSunMidData)
// console.log(finalMonMidData)
// console.log(finalTueMidData)
// console.log(finalWedMidData)
// console.log(finalThuMidData)
// console.log(finalFriMidData)
// console.log(finalSatMidData)

this.generatedEmpData.SUN_MID=this.sun_mid
this.generatedEmpData.SUN_DAY=this.sun_day
this.generatedEmpData.SUN_EVE=this.sun_eve
this.generatedEmpData.SUN_MID_DAY=this.sun_mid_day
this.generatedEmpData.SUN_DAY_EVE=this.sun_day_eve
this.generatedEmpData.SUN_EVE_MID=this.sun_eve_mid
this.generatedEmpData.MON_MID=this.mon_mid
this.generatedEmpData.MON_DAY=this.mon_day
this.generatedEmpData.MON_EVE=this.mon_eve
this.generatedEmpData.MON_MID_DAY=this.mon_mid_day
this.generatedEmpData.MON_DAY_EVE=this.mon_day_eve
this.generatedEmpData.MON_EVE_MID=this.mon_eve_mid
this.generatedEmpData.TUE_MID=this.tue_mid
this.generatedEmpData.TUE_DAY=this.tue_day
// console.log(this.tue_mid)
this.generatedEmpData.TUE_EVE=this.tue_eve
this.generatedEmpData.TUE_MID_DAY=this.tue_mid_day
this.generatedEmpData.TUE_DAY_EVE=this.tue_day_eve
this.generatedEmpData.TUE_EVE_MID=this.tue_eve_mid
this.generatedEmpData.WED_MID=this.wed_mid
this.generatedEmpData.WED_DAY=this.wed_day
this.generatedEmpData.WED_EVE=this.wed_eve
this.generatedEmpData.WED_MID_DAY=this.wed_mid_day
this.generatedEmpData.WED_DAY_EVE=this.wed_day_eve
this.generatedEmpData.WED_EVE_MID=this.wed_eve_mid
this.generatedEmpData.THU_MID=this.thu_mid
this.generatedEmpData.THU_DAY=this.thu_day
this.generatedEmpData.THU_EVE=this.thu_eve
this.generatedEmpData.THU_MID_DAY=this.thu_mid_day
this.generatedEmpData.THU_DAY_EVE=this.thu_day_eve
this.generatedEmpData.THU_EVE_MID=this.thu_eve_mid
this.generatedEmpData.FRI_MID=this.fri_mid
this.generatedEmpData.FRI_DAY=this.fri_day
this.generatedEmpData.FRI_EVE=this.fri_eve
this.generatedEmpData.FRI_MID_DAY=this.fri_mid_day
this.generatedEmpData.FRI_DAY_EVE=this.fri_day_eve
this.generatedEmpData.FRI_EVE_MID=this.fri_eve_mid
this.generatedEmpData.SAT_MID=this.sat_mid
this.generatedEmpData.SAT_DAY=this.sat_day
this.generatedEmpData.SAT_EVE=this.sat_eve
this.generatedEmpData.SAT_MID_DAY=this.sat_mid_day
this.generatedEmpData.SAT_DAY_EVE=this.sat_day_eve
this.generatedEmpData.SAT_EVE_MID=this.sat_eve_mid
// console.log(this.mon_day)
// console.log(this.sundAy)
this.SunDayRequired.push(this.requiredEmpData.SUN_MID)
this.SunDayRequired.push(this.requiredEmpData.SUN_DAY)
this.SunDayRequired.push(this.requiredEmpData.SUN_EVE)
this.SunDayRequired.push(this.requiredEmpData.SUN_MID_DAY)
this.SunDayRequired.push(this.requiredEmpData.SUN_DAY_EVE)
this.SunDayRequired.push(this.requiredEmpData.SUN_EVE_MID)
this.SunDayGenerated.push(this.generatedEmpData.SUN_MID)
this.SunDayGenerated.push(this.generatedEmpData.SUN_DAY)
this.SunDayGenerated.push(this.generatedEmpData.SUN_EVE)
this.SunDayGenerated.push(this.generatedEmpData.SUN_MID_DAY)
this.SunDayGenerated.push(this.generatedEmpData.SUN_DAY_EVE)
this.SunDayGenerated.push(this.generatedEmpData.SUN_EVE_MID)
this.diffSunMid=this.SunDayGenerated[0] + - + this.SunDayRequired[0]
this.diffSunDay=this.SunDayGenerated[1] + - + this.SunDayRequired[1]
this.diffSunEve=this.SunDayGenerated[2] + - + this.SunDayRequired[2]
this.diffSunMidDay=this.SunDayGenerated[3] + - + this.SunDayRequired[3]
this.diffSunDayEve=this.SunDayGenerated[4] + - + this.SunDayRequired[4]
this.diffSunEveMid=this.SunDayGenerated[5] + - + this.SunDayRequired[5]
this.totalSunRequired= this.SunDayRequired[0] + + + this.SunDayRequired[1] + + + this.SunDayRequired[2]+ + +this.SunDayRequired[3] + + + this.SunDayRequired[4] + + + this.SunDayRequired[5]
this.totalSunGenerated= this.SunDayGenerated[0] + + + this.SunDayGenerated[1] + + + this.SunDayGenerated[2]+ + +this.SunDayGenerated[3] + + + this.SunDayGenerated[4] + + + this.SunDayGenerated[5]
this.totalSundiff=this.totalSunGenerated+ - + this.totalSunRequired
// console.log(this.totalSunRequired+ "/" +this.totalSunGenerated)
this.MonDayRequired.push(this.requiredEmpData.MON_MID)
this.MonDayRequired.push(this.requiredEmpData.MON_DAY)
this.MonDayRequired.push(this.requiredEmpData.MON_EVE)
this.MonDayGenerated.push(this.generatedEmpData.MON_MID)
this.MonDayGenerated.push(this.generatedEmpData.MON_DAY)
this.MonDayGenerated.push(this.generatedEmpData.MON_EVE)
this.MonDayRequired.push(this.requiredEmpData.MON_MID_DAY)
this.MonDayRequired.push(this.requiredEmpData.MON_DAY_EVE)
this.MonDayRequired.push(this.requiredEmpData.MON_EVE_MID)
this.MonDayGenerated.push(this.generatedEmpData.MON_MID_DAY)
this.MonDayGenerated.push(this.generatedEmpData.MON_DAY_EVE)
this.MonDayGenerated.push(this.generatedEmpData.MON_EVE_MID)
this.diffMonMid=this.MonDayGenerated[0] + - + this.MonDayRequired[0]
this.diffMonDay=this.MonDayGenerated[1] + - + this.MonDayRequired[1]
this.diffMonEve=this.MonDayGenerated[2] + - + this.MonDayRequired[2]
this.diffMonMidDay=this.MonDayGenerated[3] + - + this.MonDayRequired[3]
this.diffMonDayEve=this.MonDayGenerated[4] + - + this.MonDayRequired[4]
this.diffMonEveMid=this.MonDayGenerated[5] + - + this.MonDayRequired[5]
this.totalMonRequired= this.MonDayRequired[0] + + + this.MonDayRequired[1] + + + this.MonDayRequired[2]+ + +this.MonDayRequired[3] + + + this.MonDayRequired[4] + + + this.MonDayRequired[5]
this.totalMonGenerated= this.MonDayGenerated[0] + + + this.MonDayGenerated[1] + + + this.MonDayGenerated[2]+ + +this.MonDayGenerated[3] + + + this.MonDayGenerated[4] + + + this.MonDayGenerated[5]
this.totalMondiff=this.totalMonGenerated+ - + this.totalMonRequired

this.TueDayRequired.push(this.requiredEmpData.TUE_MID)
this.TueDayRequired.push(this.requiredEmpData.TUE_DAY)
this.TueDayRequired.push(this.requiredEmpData.TUE_EVE)
this.TueDayGenerated.push(this.generatedEmpData.TUE_MID)
this.TueDayGenerated.push(this.generatedEmpData.TUE_DAY)
this.TueDayGenerated.push(this.generatedEmpData.TUE_EVE)
this.TueDayRequired.push(this.requiredEmpData.TUE_MID_DAY)
this.TueDayRequired.push(this.requiredEmpData.TUE_DAY_EVE)
this.TueDayRequired.push(this.requiredEmpData.TUE_EVE_MID)
this.TueDayGenerated.push(this.generatedEmpData.TUE_MID_DAY)
this.TueDayGenerated.push(this.generatedEmpData.TUE_DAY_EVE)
this.TueDayGenerated.push(this.generatedEmpData.TUE_EVE_MID)
this.diffTueMid=this.TueDayGenerated[0] + - + this.TueDayRequired[0]
this.diffTueDay=this.TueDayGenerated[1] + - + this.TueDayRequired[1]
this.diffTueEve=this.TueDayGenerated[2] + - + this.TueDayRequired[2]
this.diffTueMidDay=this.TueDayGenerated[3] + - + this.TueDayRequired[3]
this.diffTueDayEve=this.TueDayGenerated[4] + - + this.TueDayRequired[4]
this.diffTueEveMid=this.TueDayGenerated[5] + - + this.TueDayRequired[5]
this.totalTueRequired= this.TueDayRequired[0] + + + this.TueDayRequired[1] + + + this.TueDayRequired[2]+ + +this.TueDayRequired[3] + + + this.TueDayRequired[4] + + + this.TueDayRequired[5]
this.totalTueGenerated= this.TueDayGenerated[0] + + + this.TueDayGenerated[1] + + + this.TueDayGenerated[2]+ + +this.TueDayGenerated[3] + + + this.TueDayGenerated[4] + + + this.TueDayGenerated[5]
this.totalTuediff=this.totalTueGenerated+ - + this.totalTueRequired
// console.log(this.generatedEmpData.TUE_MID)
this.WedDayRequired.push(this.requiredEmpData.WED_MID)
this.WedDayRequired.push(this.requiredEmpData.WED_DAY)
this.WedDayRequired.push(this.requiredEmpData.WED_EVE)
this.WedDayGenerated.push(this.generatedEmpData.WED_MID)
this.WedDayGenerated.push(this.generatedEmpData.WED_DAY)
this.WedDayGenerated.push(this.generatedEmpData.WED_EVE)
this.WedDayRequired.push(this.requiredEmpData.WED_MID_DAY)
this.WedDayRequired.push(this.requiredEmpData.WED_DAY_EVE)
this.WedDayRequired.push(this.requiredEmpData.WED_EVE_MID)
this.WedDayGenerated.push(this.generatedEmpData.WED_MID_DAY)
this.WedDayGenerated.push(this.generatedEmpData.WED_DAY_EVE)
this.WedDayGenerated.push(this.generatedEmpData.WED_EVE_MID)
this.diffWedMid=this.WedDayGenerated[0] + - + this.WedDayRequired[0]
this.diffWedDay=this.WedDayGenerated[1] + - + this.WedDayRequired[1]
this.diffWedEve=this.WedDayGenerated[2] + - + this.WedDayRequired[2]
this.diffWedMidDay=this.WedDayGenerated[3] + - + this.WedDayRequired[3]
this.diffWedDayEve=this.WedDayGenerated[4] + - + this.WedDayRequired[4]
this.diffWedEveMid=this.WedDayGenerated[5] + - + this.WedDayRequired[5]
this.totalWedRequired= this.WedDayRequired[0] + + + this.WedDayRequired[1] + + + this.WedDayRequired[2]+ + +this.WedDayRequired[3] + + + this.WedDayRequired[4] + + + this.WedDayRequired[5]
this.totalWedGenerated= this.WedDayGenerated[0] + + + this.WedDayGenerated[1] + + + this.WedDayGenerated[2]+ + +this.WedDayGenerated[3] + + + this.WedDayGenerated[4] + + + this.WedDayGenerated[5]
this.totalWeddiff=this.totalWedGenerated+ - + this.totalWedRequired
// console.log(this.WedDayGenerated)
this.ThuDayRequired.push(this.requiredEmpData.THU_MID)
this.ThuDayRequired.push(this.requiredEmpData.THU_DAY)
this.ThuDayRequired.push(this.requiredEmpData.THU_EVE)
this.ThuDayGenerated.push(this.generatedEmpData.THU_MID)
this.ThuDayGenerated.push(this.generatedEmpData.THU_DAY)
this.ThuDayGenerated.push(this.generatedEmpData.THU_EVE)
this.ThuDayRequired.push(this.requiredEmpData.THU_MID_DAY)
this.ThuDayRequired.push(this.requiredEmpData.THU_DAY_EVE)
this.ThuDayRequired.push(this.requiredEmpData.THU_EVE_MID)
this.ThuDayGenerated.push(this.generatedEmpData.THU_MID_DAY)
this.ThuDayGenerated.push(this.generatedEmpData.THU_DAY_EVE)
this.ThuDayGenerated.push(this.generatedEmpData.THU_EVE_MID)
this.diffThuMid=this.ThuDayGenerated[0] + - + this.ThuDayRequired[0]
this.diffThuDay=this.ThuDayGenerated[1] + - + this.ThuDayRequired[1]
this.diffThuEve=this.ThuDayGenerated[2] + - + this.ThuDayRequired[2]
this.diffThuMidDay=this.ThuDayGenerated[3] + - + this.ThuDayRequired[3]
this.diffThuDayEve=this.ThuDayGenerated[4] + - + this.ThuDayRequired[4]
this.diffThuEveMid=this.ThuDayGenerated[5] + - + this.ThuDayRequired[5]
this.totalThuRequired= this.ThuDayRequired[0] + + + this.ThuDayRequired[1] + + + this.ThuDayRequired[2]+ + +this.ThuDayRequired[3] + + + this.ThuDayRequired[4] + + + this.ThuDayRequired[5]
this.totalThuGenerated= this.ThuDayGenerated[0] + + + this.ThuDayGenerated[1] + + + this.ThuDayGenerated[2]+ + +this.ThuDayGenerated[3] + + + this.ThuDayGenerated[4] + + + this.ThuDayGenerated[5]
this.totalThudiff=this.totalThuGenerated+ - + this.totalThuRequired

this.FriDayRequired.push(this.requiredEmpData.FRI_MID)
this.FriDayRequired.push(this.requiredEmpData.FRI_DAY)
this.FriDayRequired.push(this.requiredEmpData.FRI_EVE)
this.FriDayGenerated.push(this.generatedEmpData.FRI_MID)
this.FriDayGenerated.push(this.generatedEmpData.FRI_DAY)
this.FriDayGenerated.push(this.generatedEmpData.FRI_EVE)
this.FriDayRequired.push(this.requiredEmpData.FRI_MID_DAY)
this.FriDayRequired.push(this.requiredEmpData.FRI_DAY_EVE)
this.FriDayRequired.push(this.requiredEmpData.FRI_EVE_MID)
this.FriDayGenerated.push(this.generatedEmpData.FRI_MID_DAY)
this.FriDayGenerated.push(this.generatedEmpData.FRI_DAY_EVE)
this.FriDayGenerated.push(this.generatedEmpData.FRI_EVE_MID)
this.diffFriMid=this.FriDayGenerated[0] + - + this.FriDayRequired[0]
this.diffFriDay=this.FriDayGenerated[1] + - + this.FriDayRequired[1]
this.diffFriEve=this.FriDayGenerated[2] + - + this.FriDayRequired[2]
this.diffFriMidDay=this.FriDayGenerated[3] + - + this.FriDayRequired[3]
this.diffFriDayEve=this.FriDayGenerated[4] + - + this.FriDayRequired[4]
this.diffFriEveMid=this.FriDayGenerated[5] + - + this.FriDayRequired[5]
this.totalFriRequired= this.FriDayRequired[0] + + + this.FriDayRequired[1] + + + this.FriDayRequired[2]+ + +this.FriDayRequired[3] + + + this.FriDayRequired[4] + + + this.FriDayRequired[5]
this.totalFriGenerated= this.FriDayGenerated[0] + + + this.FriDayGenerated[1] + + + this.FriDayGenerated[2]+ + +this.FriDayGenerated[3] + + + this.FriDayGenerated[4] + + + this.FriDayGenerated[5]
this.totalFridiff=this.totalFriGenerated+ - + this.totalFriRequired
// console.log(this.FriDayGenerated)
this.SatDayRequired.push(this.requiredEmpData.SAT_MID)
this.SatDayRequired.push(this.requiredEmpData.SAT_DAY)
this.SatDayRequired.push(this.requiredEmpData.SAT_EVE)
this.SatDayGenerated.push(this.generatedEmpData.SAT_MID)
this.SatDayGenerated.push(this.generatedEmpData.SAT_DAY)
this.SatDayGenerated.push(this.generatedEmpData.SAT_EVE)
this.SatDayRequired.push(this.requiredEmpData.SAT_MID_DAY)
this.SatDayRequired.push(this.requiredEmpData.SAT_DAY_EVE)
this.SatDayRequired.push(this.requiredEmpData.SAT_EVE_MID)
this.SatDayGenerated.push(this.generatedEmpData.SAT_MID_DAY)
this.SatDayGenerated.push(this.generatedEmpData.SAT_DAY_EVE)
this.SatDayGenerated.push(this.generatedEmpData.SAT_EVE_MID)
this.diffSatMid=this.SatDayGenerated[0] + - + this.SatDayRequired[0]
this.diffSatDay=this.SatDayGenerated[1] + - + this.SatDayRequired[1]
this.diffSatEve=this.SatDayGenerated[2] + - + this.SatDayRequired[2]
this.diffSatMidDay=this.SatDayGenerated[3] + - + this.SatDayRequired[3]
this.diffSatDayEve=this.SatDayGenerated[4] + - + this.SatDayRequired[4]
this.diffSatEveMid=this.SatDayGenerated[5] + - + this.SatDayRequired[5]
this.totalSatRequired= this.SatDayRequired[0] + + + this.SatDayRequired[1] + + + this.SatDayRequired[2]+ + +this.SatDayRequired[3] + + + this.SatDayRequired[4] + + + this.SatDayRequired[5]
this.totalSatGenerated= this.SatDayGenerated[0] + + + this.SatDayGenerated[1] + + + this.SatDayGenerated[2]+ + +this.SatDayGenerated[3] + + + this.SatDayGenerated[4] + + + this.SatDayGenerated[5]
this.totalSatdiff=this.totalSatGenerated+ - + this.totalSatRequired


// this.dData=[]
// this.dData.push(this.defRequiredData.SUN_MID)
//       this.dayTitleforExcel={"":"","sun":"SUN","mon":"MON","tue":"TUE","wed":"WED","thu":"THU","fri":"FRI","sat":"SAT"}

      this.def_gen_shift_1_data={"":this.shift[0],"sun":this.def_sun_1,"mon":this.def_mon_1,"tue":this.def_tue_1,"wed":this.def_wed_2,"thu":this.def_thu_1,"fri":this.def_fri_1,"sat":this.def_sat_1}
      this.def_gen_shift_2_data={"":this.shift[1],"sun":this.def_sun_2,"mon":this.def_mon_2,"tue":this.def_tue_2,"wed":this.def_wed_2,"thu":this.def_thu_2,"fri":this.def_fri_2,"sat":this.def_sat_2,}
      this.def_gen_shift_3_data={"":this.shift[2],"sun":this.def_sun_3,"mon":this.def_mon_3,"tue":this.def_tue_3,"wed":this.def_wed_3,"thu":this.def_thu_3,"fri":this.def_fri_3,"sat":this.def_sat_3,}
      this.def_gen_shift_4_data={"":this.shift[3],"sun":this.def_sun_4,"mon":this.def_mon_4,"tue":this.def_tue_4,"wed":this.def_wed_4,"thu":this.def_thu_4,"fri":this.def_fri_4,"sat":this.def_sat_4,}
      this.def_gen_shift_5_data={"":this.shift[4],"sun":this.def_sun_5,"mon":this.def_mon_5,"tue":this.def_tue_5,"wed":this.def_wed_5,"thu":this.def_thu_5,"fri":this.def_fri_5,"sat":this.def_sat_5,}


      for(var i=0;i<this.allShiftData.length;i++){
  this.req_shift_1_data={"shiftTime":this.allShiftData[i].startTime,"sun":this.allShiftData[i].Sun,"mon":this.allShiftData[i].Mon,"tue":this.allShiftData[i].Tue,"wed":this.allShiftData[i].Wed,"thu":this.allShiftData[i].Thu,"fri":this.allShiftData[i].Fri,"sat":this.allShiftData[i].Sat}
  this.reqData.push(this.req_shift_1_data)
}
// console.log(this.reqData.length)


this.reqvsgenDataShiftTime.push("")
this.reqvsgenDataSun.push("Sun")
this.reqvsgenDataMon.push("Mon")
this.reqvsgenDataTue.push("Tue")
this.reqvsgenDataWed.push("Wed")
this.reqvsgenDataThu.push("Thu")
this.reqvsgenDataFri.push("Fri")
this.reqvsgenDataSat.push("Sat")

for(var i=0;i<this.reqData.length;i++){
  this.reqvsgenDataShiftTime.push(String(this.reqData[i].shiftTime))
  //SUN
  for(var j=0;j<finalSunMidData.length;j++){
    if(this.reqData[i].shiftTime===finalSunMidData[j].shiftTime){
      this.reqvsgenDataSun.push({"R":Number(this.reqData[i].sun),"G": Number(finalSunMidData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalSunDayData.length;j++){
    if(this.reqData[i].shiftTime===finalSunDayData[j].shiftTime){
      this.reqvsgenDataSun.push({"R":Number(this.reqData[i].sun),"G": Number(finalSunDayData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalSunEveData.length;j++){
    if(this.reqData[i].shiftTime===finalSunEveData[j].shiftTime){
      this.reqvsgenDataSun.push({"R":Number(this.reqData[i].sun),"G": Number(finalSunEveData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalSunMDData.length;j++){
    if(this.reqData[i].shiftTime===finalSunMDData[j].shiftTime){
      this.reqvsgenDataSun.push({"R":Number(this.reqData[i].sun),"G": Number(finalSunMDData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalSunDEData.length;j++){
    if(this.reqData[i].shiftTime===finalSunDEData[j].shiftTime){
      this.reqvsgenDataSun.push({"R":Number(this.reqData[i].sun),"G": Number(finalSunDEData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalSunEMData.length;j++){
    if(this.reqData[i].shiftTime===finalSunEMData[j].shiftTime){
      this.reqvsgenDataSun.push({"R":Number(this.reqData[i].sun),"G": Number(finalSunEMData[j].totalEmp)})
    }
  }



//MON
  for(var j=0;j<finalMonMidData.length;j++){
    if(this.reqData[i].shiftTime===finalMonMidData[j].shiftTime){
      this.reqvsgenDataMon.push({"R":Number(this.reqData[i].mon),"G": Number(finalMonMidData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalMonDayData.length;j++){
    if(this.reqData[i].shiftTime===finalMonDayData[j].shiftTime){
      this.reqvsgenDataMon.push({"R":Number(this.reqData[i].mon),"G": Number(finalMonDayData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalMonEveData.length;j++){
    if(this.reqData[i].shiftTime===finalMonEveData[j].shiftTime){
      this.reqvsgenDataMon.push({"R":Number(this.reqData[i].mon),"G": Number(finalMonEveData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalMonMDData.length;j++){
    if(Number(this.reqData[i].shiftTime)===Number(finalMonMDData[j].shiftTime)){
      this.reqvsgenDataMon.push({"R":Number(this.reqData[i].mon),"G": Number(finalMonMDData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalMonDEData.length;j++){
    if(this.reqData[i].shiftTime===finalMonDEData[j].shiftTime){
      this.reqvsgenDataMon.push({"R":Number(this.reqData[i].mon),"G": Number(finalMonDEData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalMonEMData.length;j++){
    if(this.reqData[i].shiftTime===finalMonEMData[j].shiftTime){
      this.reqvsgenDataMon.push({"R":Number(this.reqData[i].mon),"G": Number(finalMonEMData[j].totalEmp)})
    }
  }



//TUE
  for(var j=0;j<finalTueMidData.length;j++){
    if(this.reqData[i].shiftTime===finalTueMidData[j].shiftTime){
      this.reqvsgenDataTue.push({"R":Number(this.reqData[i].tue),"G":Number(finalTueMidData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalTueDayData.length;j++){
    if(this.reqData[i].shiftTime===finalTueDayData[j].shiftTime){
      this.reqvsgenDataTue.push({"R":Number(this.reqData[i].tue),"G": Number(finalTueDayData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalTueEveData.length;j++){
    if(this.reqData[i].shiftTime===finalTueEveData[j].shiftTime){
      this.reqvsgenDataTue.push({"R":Number(this.reqData[i].tue),"G": Number(finalTueEveData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalTueMDData.length;j++){
    if(this.reqData[i].shiftTime===finalTueMDData[j].shiftTime){
      this.reqvsgenDataTue.push({"R":Number(this.reqData[i].tue),"G": Number(finalTueMDData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalTueDEData.length;j++){
    if(this.reqData[i].shiftTime===finalTueDEData[j].shiftTime){
      this.reqvsgenDataTue.push({"R":Number(this.reqData[i].tue),"G": Number(finalTueDEData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalTueEMData.length;j++){
    if(this.reqData[i].shiftTime===finalTueEMData[j].shiftTime){
      this.reqvsgenDataTue.push({"R":Number(this.reqData[i].tue),"G": Number(finalTueEMData[j].totalEmp)})
    }
  }
//WED
  for(var j=0;j<finalWedMidData.length;j++){
    if(this.reqData[i].shiftTime===finalWedMidData[j].shiftTime){
      this.reqvsgenDataWed.push({"R":Number(this.reqData[i].wed),"G": Number(finalWedMidData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalWedDayData.length;j++){
    if(this.reqData[i].shiftTime===finalWedDayData[j].shiftTime){
      this.reqvsgenDataWed.push({"R":Number(this.reqData[i].wed),"G": Number(finalWedDayData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalWedEveData.length;j++){
    if(this.reqData[i].shiftTime===finalWedEveData[j].shiftTime){
      this.reqvsgenDataWed.push({"R":Number(this.reqData[i].wed),"G": Number(finalWedEveData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalWedMDData.length;j++){
    if(this.reqData[i].shiftTime===finalWedMDData[j].shiftTime){
      this.reqvsgenDataWed.push({"R":Number(this.reqData[i].wed),"G": Number(finalWedMDData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalWedDEData.length;j++){
    if(this.reqData[i].shiftTime===finalWedDEData[j].shiftTime){
      this.reqvsgenDataWed.push({"R":Number(this.reqData[i].wed),"G": Number(finalWedDEData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalWedEMData.length;j++){
    if(this.reqData[i].shiftTime===finalWedEMData[j].shiftTime){
      this.reqvsgenDataWed.push({"R":Number(this.reqData[i].wed),"G": Number(finalWedEMData[j].totalEmp)})
    }
  }
//THU
  for(var j=0;j<finalThuMidData.length;j++){
    if(this.reqData[i].shiftTime===finalThuMidData[j].shiftTime){
      this.reqvsgenDataThu.push({"R":Number(this.reqData[i].thu),"G": Number(finalThuMidData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalThuDayData.length;j++){
    if(this.reqData[i].shiftTime===finalThuDayData[j].shiftTime){
      this.reqvsgenDataThu.push({"R":Number(this.reqData[i].thu),"G": Number(finalThuDayData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalThuEveData.length;j++){
    if(this.reqData[i].shiftTime===finalThuEveData[j].shiftTime){+
      this.reqvsgenDataThu.push({"R":Number(this.reqData[i].thu),"G": Number(finalThuEveData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalThuMDData.length;j++){
    if(this.reqData[i].shiftTime===finalThuMDData[j].shiftTime){
      this.reqvsgenDataThu.push({"R":Number(this.reqData[i].thu),"G": Number(finalThuMDData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalThuDEData.length;j++){
    if(this.reqData[i].shiftTime===finalThuDEData[j].shiftTime){
      this.reqvsgenDataThu.push({"R":Number(this.reqData[i].thu),"G": Number(finalThuDEData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalThuEMData.length;j++){
    if(this.reqData[i].shiftTime===finalThuEMData[j].shiftTime){
      this.reqvsgenDataThu.push({"R":Number(this.reqData[i].thu),"G": Number(finalThuEMData[j].totalEmp)})
    }
  }

  //FRI
  for(var j=0;j<finalFriMidData.length;j++){
    if(this.reqData[i].shiftTime===finalFriMidData[j].shiftTime){
      this.reqvsgenDataFri.push({"R":Number(this.reqData[i].fri),"G": Number(finalFriMidData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalFriDayData.length;j++){
    if(this.reqData[i].shiftTime===finalFriDayData[j].shiftTime){
      this.reqvsgenDataFri.push({"R":Number(this.reqData[i].fri),"G": Number(finalFriDayData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalFriEveData.length;j++){
    if(this.reqData[i].shiftTime===finalFriEveData[j].shiftTime){
      this.reqvsgenDataFri.push({"R":Number(this.reqData[i].fri),"G": Number(finalFriEveData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalFriMDData.length;j++){
    if(this.reqData[i].shiftTime===finalFriMDData[j].shiftTime){
      this.reqvsgenDataFri.push({"R":Number(this.reqData[i].fri),"G": Number(finalFriMDData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalFriDEData.length;j++){
    if(this.reqData[i].shiftTime===finalFriDEData[j].shiftTime){
      this.reqvsgenDataFri.push({"R":Number(this.reqData[i].fri),"G": Number(finalFriDEData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalFriEMData.length;j++){
    if(this.reqData[i].shiftTime===finalFriEMData[j].shiftTime){
      this.reqvsgenDataFri.push({"R":Number(this.reqData[i].fri),"G": Number(finalFriEMData[j].totalEmp)})
    }
  }
//SAT
  for(var j=0;j<finalSatMidData.length;j++){
    if(this.reqData[i].shiftTime===finalSatMidData[j].shiftTime){
      this.reqvsgenDataSat.push({"R":Number(this.reqData[i].sat),"G": Number(finalSatMidData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalSatDayData.length;j++){
    if(this.reqData[i].shiftTime===finalSatDayData[j].shiftTime){
      this.reqvsgenDataSat.push({"R":Number(this.reqData[i].sat),"G": Number(finalSatDayData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalSatEveData.length;j++){
    if(this.reqData[i].shiftTime===finalSatEveData[j].shiftTime){
      this.reqvsgenDataSat.push({"R":Number(this.reqData[i].sat),"G": Number(finalSatEveData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalSatMDData.length;j++){
    if(this.reqData[i].shiftTime===finalSatMDData[j].shiftTime){
      this.reqvsgenDataSat.push({"R":Number(this.reqData[i].sat),"G": Number(finalSatMDData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalSatDEData.length;j++){
    if(this.reqData[i].shiftTime===finalSatDEData[j].shiftTime){
      this.reqvsgenDataSat.push({"R":Number(this.reqData[i].sat),"G": Number(finalSatDEData[j].totalEmp)})
    }
  }
  for(var j=0;j<finalSatEMData.length;j++){
    if(this.reqData[i].shiftTime===finalSatEMData[j].shiftTime){
      this.reqvsgenDataSat.push({"R":Number(this.reqData[i].sat),"G": Number(finalSatEMData[j].totalEmp)})
    }
  }

}


// console.log(this.day_summary)
// console.log(this.reqvsgenDataMon)
// console.log(this.reqvsgenDataSun.length)
if(this.day_summary.day=='Sun'){
  this.current_day_summary_data=[]
  for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
    // console.log(this.reqvsgenDataSun[i])
    this.summary_day_data={"shiftName":this.reqvsgenDataShiftTime[i],"shiftData":this.reqvsgenDataSun[i],"diff":Number(this.reqvsgenDataSun[i].G)+ - +Number(this.reqvsgenDataSun[i].R)}
    this.current_day_summary_data.push(this.summary_day_data)
  }

  // console.log(this.current_day_summary_data)
      this.total_current_day_req= this.SunDayRequired[0] + + + this.SunDayRequired[1] + + + this.SunDayRequired[2]
      this.total_current_day_gen= this.SunDayGenerated[0] + + + this.SunDayGenerated[1] + + + this.SunDayGenerated[2]
      this.total_current_day_diff=this.total_current_day_gen+ - + this.total_current_day_req
}else if(this.day_summary.day=='Mon'){
  this.current_day_summary_data=[]
  for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
    this.summary_day_data={"shiftName":this.reqvsgenDataShiftTime[i],"shiftData":this.reqvsgenDataMon[i],"diff":Number(this.reqvsgenDataMon[i].G)+ - +Number(this.reqvsgenDataMon[i].R)}
    this.current_day_summary_data.push(this.summary_day_data)
  }
  this.total_current_day_req= this.MonDayRequired[0] + + + this.MonDayRequired[1] + + + this.MonDayRequired[2]
  this.total_current_day_gen= this.MonDayGenerated[0] + + + this.MonDayGenerated[1] + + + this.MonDayGenerated[2]
  this.total_current_day_diff=this.total_current_day_gen+ - + this.total_current_day_req

}else if(this.day_summary.day=='Tue'){
  this.current_day_summary_data=[]
  for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
    this.summary_day_data={"shiftName":this.reqvsgenDataShiftTime[i],"shiftData":this.reqvsgenDataTue[i],"diff":Number(this.reqvsgenDataTue[i].G)+ - +Number(this.reqvsgenDataTue[i].R)}
    this.current_day_summary_data.push(this.summary_day_data)
  }
  this.total_current_day_req= this.TueDayRequired[0] + + + this.TueDayRequired[1] + + + this.TueDayRequired[2]
  this.total_current_day_gen= this.TueDayGenerated[0] + + + this.TueDayGenerated[1] + + + this.TueDayGenerated[2]
  this.total_current_day_diff=this.total_current_day_gen+ - + this.total_current_day_req

}else if(this.day_summary.day=='Wed'){
  this.current_day_summary_data=[]
  for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
    this.summary_day_data={"shiftName":this.reqvsgenDataShiftTime[i],"shiftData":this.reqvsgenDataWed[i],"diff":Number(this.reqvsgenDataWed[i].G)+ - +Number(this.reqvsgenDataWed[i].R)}
    this.current_day_summary_data.push(this.summary_day_data)
  }
  this.total_current_day_req= this.WedDayRequired[0] + + + this.WedDayRequired[1] + + + this.WedDayRequired[2]
  this.total_current_day_gen= this.WedDayGenerated[0] + + + this.WedDayGenerated[1] + + + this.WedDayGenerated[2]
  this.total_current_day_diff=this.total_current_day_gen+ - + this.total_current_day_req

}else if(this.day_summary.day=='Thu'){
  this.current_day_summary_data=[]
  for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
    this.summary_day_data={"shiftName":this.reqvsgenDataShiftTime[i],"shiftData":this.reqvsgenDataThu[i],"diff":Number(this.reqvsgenDataThu[i].G)+ - +Number(this.reqvsgenDataThu[i].R)}
    this.current_day_summary_data.push(this.summary_day_data)
  }
  this.total_current_day_req= this.ThuDayRequired[0] + + + this.ThuDayRequired[1] + + + this.ThuDayRequired[2]
  this.total_current_day_gen= this.ThuDayGenerated[0] + + + this.ThuDayGenerated[1] + + + this.ThuDayGenerated[2]
  this.total_current_day_diff=this.total_current_day_gen+ - + this.total_current_day_req

}else if(this.day_summary.day=='Fri'){
  this.current_day_summary_data=[]
  for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
    this.summary_day_data={"shiftName":this.reqvsgenDataShiftTime[i],"shiftData":this.reqvsgenDataFri[i],"diff":Number(this.reqvsgenDataFri[i].G)+ - +Number(this.reqvsgenDataFri[i].R)}
    this.current_day_summary_data.push(this.summary_day_data)
  }
  this.total_current_day_req= this.FriDayRequired[0] + + + this.FriDayRequired[1] + + + this.FriDayRequired[2]
  this.total_current_day_gen= this.FriDayGenerated[0] + + + this.FriDayGenerated[1] + + + this.FriDayGenerated[2]
  this.total_current_day_diff=this.total_current_day_gen+ - + this.total_current_day_req
}else if(this.day_summary.day=='Sat'){
  this.current_day_summary_data=[]
  for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
    this.summary_day_data={"shiftName":this.reqvsgenDataShiftTime[i],"shiftData":this.reqvsgenDataSat[i],"diff":Number(this.reqvsgenDataSat[i].G)+ - +Number(this.reqvsgenDataSat[i].R)}
    this.current_day_summary_data.push(this.summary_day_data)
  }
  this.total_current_day_req= this.SatDayRequired[0] + + + this.SatDayRequired[1] + + + this.SatDayRequired[2]
  this.total_current_day_gen= this.SatDayGenerated[0] + + + this.SatDayGenerated[1] + + + this.SatDayGenerated[2]
  this.total_current_day_diff=this.total_current_day_gen+ - + this.total_current_day_req
}

// console.log(this.current_day_summary_data)


      this.gen_shift_1_data={"":this.shift[0],"sun":this.sun_1,"mon":this.mon_1,"tue":this.tue_1,"wed":this.wed_2,"thu":this.thu_1,"fri":this.fri_1,"sat":this.sat_1}
      this.gen_shift_2_data={"":this.shift[1],"sun":this.sun_2,"mon":this.mon_2,"tue":this.tue_2,"wed":this.wed_2,"thu":this.thu_2,"fri":this.fri_2,"sat":this.sat_2,}
      this.gen_shift_3_data={"":this.shift[2],"sun":this.sun_3,"mon":this.mon_3,"tue":this.tue_3,"wed":this.wed_3,"thu":this.thu_3,"fri":this.fri_3,"sat":this.sat_3,}
      this.gen_shift_4_data={"":this.shift[3],"sun":this.sun_4,"mon":this.mon_4,"tue":this.tue_4,"wed":this.wed_4,"thu":this.thu_4,"fri":this.fri_4,"sat":this.sat_4,}
      this.gen_shift_5_data={"":this.shift[4],"sun":this.sun_5,"mon":this.mon_5,"tue":this.tue_5,"wed":this.wed_5,"thu":this.thu_5,"fri":this.fri_5,"sat":this.sat_5,}
// console.log(this.gen_shift_3_data)
      this.ReqVsGeneMidData=["MID",this.requiredEmpData.SUN_MID+'/'+this.generatedEmpData.SUN_MID,this.requiredEmpData.MON_MID+'/'+this.generatedEmpData.MON_MID,this.requiredEmpData.TUE_MID+'/'+this.generatedEmpData.TUE_MID,this.requiredEmpData.WED_MID+'/'+this.generatedEmpData.WED_MID,this.requiredEmpData.THU_MID+'/'+this.generatedEmpData.THU_MID,this.requiredEmpData.FRI_MID+'/'+this.generatedEmpData.FRI_MID,this.requiredEmpData.SAT_MID+'/'+this.generatedEmpData.SAT_MID]
      this.ReqVsGeneDayData=["DAY",this.requiredEmpData.SUN_DAY+'/'+this.generatedEmpData.SUN_DAY,this.requiredEmpData.MON_DAY+'/'+this.generatedEmpData.MON_DAY,this.requiredEmpData.TUE_DAY+'/'+this.generatedEmpData.TUE_DAY,this.requiredEmpData.WED_DAY+'/'+this.generatedEmpData.WED_DAY,this.requiredEmpData.THU_DAY+'/'+this.generatedEmpData.THU_DAY,this.requiredEmpData.FRI_DAY+'/'+this.generatedEmpData.FRI_DAY,this.requiredEmpData.SAT_DAY+'/'+this.generatedEmpData.SAT_DAY]
      this.ReqVsGeneEveData=["EVE",this.requiredEmpData.SUN_EVE+'/'+this.generatedEmpData.SUN_EVE,this.requiredEmpData.MON_EVE+'/'+this.generatedEmpData.MON_EVE,this.requiredEmpData.TUE_EVE+'/'+this.generatedEmpData.TUE_EVE,this.requiredEmpData.WED_EVE+'/'+this.generatedEmpData.WED_EVE,this.requiredEmpData.THU_EVE+'/'+this.generatedEmpData.THU_EVE,this.requiredEmpData.FRI_EVE+'/'+this.generatedEmpData.FRI_EVE,this.requiredEmpData.SAT_EVE+'/'+this.generatedEmpData.SAT_EVE]
      this.ReqVsGeneTotalData=["",(this.requiredEmpData.SUN_MID+this.requiredEmpData.SUN_DAY+this.requiredEmpData.SUN_EVE)+'/'+ (this.generatedEmpData.SUN_MID+ + +this.generatedEmpData.SUN_DAY+ + +this.generatedEmpData.SUN_EVE),(this.requiredEmpData.MON_MID+this.requiredEmpData.MON_DAY+this.requiredEmpData.MON_EVE)+'/'+ (this.generatedEmpData.MON_MID+ + +this.generatedEmpData.MON_DAY+ + +this.generatedEmpData.MON_EVE),(this.requiredEmpData.TUE_MID+this.requiredEmpData.TUE_DAY+this.requiredEmpData.TUE_EVE)+'/'+ (this.generatedEmpData.TUE_MID+ + +this.generatedEmpData.TUE_DAY+ + +this.generatedEmpData.TUE_EVE),(this.requiredEmpData.WED_MID+this.requiredEmpData.WED_DAY+this.requiredEmpData.WED_EVE)+'/'+ (this.generatedEmpData.WED_MID+ + +this.generatedEmpData.WED_DAY+ + +this.generatedEmpData.WED_EVE),(this.requiredEmpData.THU_MID+this.requiredEmpData.THU_DAY+this.requiredEmpData.THU_EVE)+'/'+ (this.generatedEmpData.THU_MID+ + +this.generatedEmpData.THU_DAY+ + +this.generatedEmpData.THU_EVE),(this.requiredEmpData.FRI_MID+this.requiredEmpData.FRI_DAY+this.requiredEmpData.FRI_EVE)+'/'+ (this.generatedEmpData.FRI_MID+ + +this.generatedEmpData.FRI_DAY+ + +this.generatedEmpData.FRI_EVE),(this.requiredEmpData.SAT_MID+this.requiredEmpData.SAT_DAY+this.requiredEmpData.SAT_EVE)+'/'+ (this.generatedEmpData.SAT_MID+ + +this.generatedEmpData.SAT_DAY+ + +this.generatedEmpData.SAT_EVE)]
this.customized=["",this.ReqVsGeneMidData[0],this.ReqVsGeneDayData[0],this.ReqVsGeneEveData[0],this.ReqVsGeneTotalData[0]]
this.customizedSun=["Sun",this.ReqVsGeneMidData[1],this.ReqVsGeneDayData[1],this.ReqVsGeneEveData[1],this.ReqVsGeneTotalData[1]]
this.customizedMon=["Mon",this.ReqVsGeneMidData[2],this.ReqVsGeneDayData[2],this.ReqVsGeneEveData[2],this.ReqVsGeneTotalData[2]]
this.customizedTue=["Tue",this.ReqVsGeneMidData[3],this.ReqVsGeneDayData[3],this.ReqVsGeneEveData[3],this.ReqVsGeneTotalData[3]]
this.customizedWed=["Wed",this.ReqVsGeneMidData[4],this.ReqVsGeneDayData[4],this.ReqVsGeneEveData[4],this.ReqVsGeneTotalData[4]]
this.customizedThu=["Thu",this.ReqVsGeneMidData[5],this.ReqVsGeneDayData[5],this.ReqVsGeneEveData[5],this.ReqVsGeneTotalData[5]]
this.customizedFri=["Fri",this.ReqVsGeneMidData[6],this.ReqVsGeneDayData[6],this.ReqVsGeneEveData[6],this.ReqVsGeneTotalData[6]]
this.customizedSat=["Sat",this.ReqVsGeneMidData[7],this.ReqVsGeneDayData[7],this.ReqVsGeneEveData[7],this.ReqVsGeneTotalData[7]]

      this.defReqVsGeneMidData=["MID",this.defRequiredData.SUN_MID+'/'+this.defGeneratedData.SUN_MID,this.defRequiredData.MON_MID+'/'+this.defGeneratedData.MON_MID,this.defRequiredData.TUE_MID+'/'+this.defGeneratedData.TUE_MID,this.defRequiredData.WED_MID+'/'+this.defGeneratedData.WED_MID,this.defRequiredData.THU_MID+'/'+this.defGeneratedData.THU_MID,this.defRequiredData.FRI_MID+'/'+this.defGeneratedData.FRI_MID,this.defRequiredData.SAT_MID+'/'+this.defGeneratedData.SAT_MID]
      this.defReqVsGeneDayData=["DAY",this.defRequiredData.SUN_DAY+'/'+this.defGeneratedData.SUN_DAY,this.defRequiredData.MON_DAY+'/'+this.defGeneratedData.MON_DAY,this.defRequiredData.TUE_DAY+'/'+this.defGeneratedData.TUE_DAY,this.defRequiredData.WED_DAY+'/'+this.defGeneratedData.WED_DAY,this.defRequiredData.THU_DAY+'/'+this.defGeneratedData.THU_DAY,this.defRequiredData.FRI_DAY+'/'+this.defGeneratedData.FRI_DAY,this.defRequiredData.SAT_DAY+'/'+this.defGeneratedData.SAT_DAY,]
      this.defReqVsGeneEveData=["EVE",this.defRequiredData.SUN_EVE+'/'+this.defGeneratedData.SUN_EVE,this.defRequiredData.MON_EVE+'/'+this.defGeneratedData.MON_EVE,this.defRequiredData.TUE_EVE+'/'+this.defGeneratedData.TUE_EVE,this.defRequiredData.WED_EVE+'/'+this.defGeneratedData.WED_EVE,this.defRequiredData.THU_EVE+'/'+this.defGeneratedData.THU_EVE,this.defRequiredData.FRI_EVE+'/'+this.defGeneratedData.FRI_EVE,this.defRequiredData.SAT_EVE+'/'+this.defGeneratedData.SAT_EVE,]
      this.defReqVsGeneTotalData=["",(this.defRequiredData.SUN_MID+this.defRequiredData.SUN_DAY+this.defRequiredData.SUN_EVE)+'/'+ (this.defGeneratedData.SUN_MID+ + +this.defGeneratedData.SUN_DAY+ + +this.defGeneratedData.SUN_EVE),(this.defRequiredData.MON_MID+this.defRequiredData.MON_DAY+this.defRequiredData.MON_EVE)+'/'+ (this.defGeneratedData.MON_MID+ + +this.defGeneratedData.MON_DAY+ + +this.defGeneratedData.MON_EVE),(this.defRequiredData.TUE_MID+this.defRequiredData.TUE_DAY+this.defRequiredData.TUE_EVE)+'/'+ (this.defGeneratedData.TUE_MID+ + +this.defGeneratedData.TUE_DAY+ + +this.defGeneratedData.TUE_EVE),(this.defRequiredData.WED_MID+this.defRequiredData.WED_DAY+this.defRequiredData.WED_EVE)+'/'+ (this.defGeneratedData.WED_MID+ + +this.defGeneratedData.WED_DAY+ + +this.defGeneratedData.WED_EVE),(this.defRequiredData.THU_MID+this.defRequiredData.THU_DAY+this.defRequiredData.THU_EVE)+'/'+ (this.defGeneratedData.THU_MID+ + +this.defGeneratedData.THU_DAY+ + +this.defGeneratedData.THU_EVE),(this.defRequiredData.FRI_MID+this.defRequiredData.FRI_DAY+this.defRequiredData.FRI_EVE)+'/'+ (this.defGeneratedData.FRI_MID+ + +this.defGeneratedData.FRI_DAY+ + +this.defGeneratedData.FRI_EVE),(this.defRequiredData.SAT_MID+this.defRequiredData.SAT_DAY+this.defRequiredData.SAT_EVE)+'/'+ (this.defGeneratedData.SAT_MID+ + +this.defGeneratedData.SAT_DAY+ + +this.defGeneratedData.SAT_EVE),]
// console.log(this.defGeneratedData.MON_MID)
      this.def=["",this.defReqVsGeneMidData[0],this.defReqVsGeneDayData[0],this.defReqVsGeneEveData[0],this.defReqVsGeneTotalData[0]]
this.defSun=["Sun",this.defReqVsGeneMidData[1],this.defReqVsGeneDayData[1],this.defReqVsGeneEveData[1],this.defReqVsGeneTotalData[1]]
this.defMon=["Mon",this.defReqVsGeneMidData[2],this.defReqVsGeneDayData[2],this.defReqVsGeneEveData[2],this.defReqVsGeneTotalData[2]]
this.defTue=["Tue",this.defReqVsGeneMidData[3],this.defReqVsGeneDayData[3],this.defReqVsGeneEveData[3],this.defReqVsGeneTotalData[3]]
this.defWed=["Wed",this.defReqVsGeneMidData[4],this.defReqVsGeneDayData[4],this.defReqVsGeneEveData[4],this.defReqVsGeneTotalData[4]]
this.defThu=["Thu",this.defReqVsGeneMidData[5],this.defReqVsGeneDayData[5],this.defReqVsGeneEveData[5],this.defReqVsGeneTotalData[5]]
this.defFri=["Fri",this.defReqVsGeneMidData[6],this.defReqVsGeneDayData[6],this.defReqVsGeneEveData[6],this.defReqVsGeneTotalData[6]]
this.defSat=["Sat",this.defReqVsGeneMidData[7],this.defReqVsGeneDayData[7],this.defReqVsGeneEveData[7],this.defReqVsGeneTotalData[7]]

      // End Comparison of Required and Generated Emp data


//System Generated Schedule Lines

  this.totalDefaultScheduleLine=i

// this.totalShiftLine={"Total Shift Lines":String(this.defscheduleShift.length)}
this.totalShiftLine=String(this.defscheduleShift.length)
this.totalCustomizeShiftLine=this.scheduleShift.length
this.required_title={"Required Workforce":"Required Workforce"}
this.generated_title={'System Generated Workforce':'System Generated Workforc'}
this.required_vs_generated_title={"Required vs System Generated Workforce":"Required vs System Generated Workforce"}
// console.log(this.totalCustomizeShiftLine  )
this.defaultScheduleShift.push(this.totalShiftLine)


// for(var i=0;i<this.defscheduleShift.length;i++){

//   this.defaultScheduleShift.push(this.defscheduleShift[i])

// }

for(var i=0; i<=this.scheduleShift.length;i++)
{
  if(this.scheduleShift[i]?.SL  == 'SS' || this.scheduleShift[i]?.SL  == 'SS-A'){
    this.countSunSat++
  }
  else if(this.scheduleShift[i]?.SL  == 'SM' || this.scheduleShift[i]?.SL  == 'SM-A'){
    this.countSunMon++
  }
  else if(this.scheduleShift[i]?.SL  == 'MT' || this.scheduleShift[i]?.SL  == 'MT-A'){
    this.countMonTue++
  }
  else if(this.scheduleShift[i]?.SL  == 'TW' || this.scheduleShift[i]?.SL  == 'TW-A'){
    this.countTueWed++
  }
  else if(this.scheduleShift[i]?.SL  == 'WT' || this.scheduleShift[i]?.SL  == 'WT-A'){
    this.countWedThu++
  }
  else if(this.scheduleShift[i]?.SL  == 'TF' || this.scheduleShift[i]?.SL  == 'TF-A'){
    this.countThuFri++
  }
  else if(this.scheduleShift[i]?.SL  == 'FS' || this.scheduleShift[i]?.SL  == 'FS-A'){
    this.countFriSat++
  }
  this.totalCount = this.countSunSat + this.countSunMon + this.countMonTue + this.countTueWed + this.countWedThu + this.countThuFri +this.countFriSat
  // console.log(this.totalCount)
}
for(var j=0; j<=this.scheduleShift.length;j++)
{
  if(this.scheduleShift[j]?.Sun == 'X' && this.scheduleShift[j]?.Sat == 'X'){
    this.result1.push(this.scheduleShift[j]);
  }
  else if(this.scheduleShift[j]?.Sun == 'X' && this.scheduleShift[j]?.Mon == 'X'){
    this.result2.push(this.scheduleShift[j]);
  }
}



this.result_R_G=[]
var all_Shift=["0000","0100","0200","0300","0400","0500","0600","0700","0800","0900","1000","1100","1200","1300","1400","1500","1600","1700","1800","1900","2000","2100","2200","2300"]
var all_char_data=[],all_char_data_sun=[],all_char_data_mon=[],all_char_data_tue=[],all_char_data_wed=[],all_char_data_thu=[],all_char_data_fri=[],all_char_data_sat=[]
for(var i=0;i<all_Shift.length;i++){
      all_char_data_sun.push({'shiftName':(all_Shift[i]),'R':0,'G':0,'day':'sun'})
      all_char_data_mon.push({'shiftName':(all_Shift[i]),'R':0,'G':0,'day':'mon'})
      all_char_data_tue.push({'shiftName':(all_Shift[i]),'R':0,'G':0,'day':'tue'})
      all_char_data_wed.push({'shiftName':(all_Shift[i]),'R':0,'G':0,'day':'wed'})
      all_char_data_thu.push({'shiftName':(all_Shift[i]),'R':0,'G':0,'day':'thu'})
      all_char_data_fri.push({'shiftName':(all_Shift[i]),'R':0,'G':0,'day':'fri'})
      all_char_data_sat.push({'shiftName':(all_Shift[i]),'R':0,'G':0,'day':'sat'})
}
for(var i=0;i<all_Shift.length;i++){
  all_char_data.push({'shiftName':(all_Shift[i]),'R':0,'G':0})
}
// console.log(all_char_data)

var all_week_day_data=[],all_week_day_data_sun=[],result_R_G_sun=[],f_sun
var temp_time
//Sun
console.log(this.reqvsgenDataSun)
console.log(this.reqvsgenDataSun)

for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
  all_week_day_data_sun.push({"shiftName":this.reqvsgenDataShiftTime[i],"shiftData":this.reqvsgenDataSun[i],"diff":Number(this.reqvsgenDataSun[i].G)+ - +Number(this.reqvsgenDataSun[i].R)})
}
console.log(all_week_day_data_sun)
for(var i=0;i<all_week_day_data_sun.length;i++){
  // console.log(this.current_day_summary_data[i])
  result_R_G_sun.push({'shiftName':all_week_day_data_sun[i].shiftName,'R':all_week_day_data_sun[i].shiftData.R,'G':all_week_day_data_sun[i].shiftData.G})
}
console.log(this.reqvsgenDataSun)
for(var i=0;i<all_char_data.length;i++){
    result_R_G_sun.push(all_char_data[i])
}
f_sun=result_R_G_sun.filter((v,i,a)=>a.findIndex(t=>(t.shiftName === v.shiftName ))===i)
result_R_G_sun=f_sun
// console.log(result_R_G_sun)
//Mon
var all_week_day_data_mon=[],result_R_G_mon=[],f_mon
for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
  all_week_day_data_mon.push({"shiftName":this.reqvsgenDataShiftTime[i],"shiftData":this.reqvsgenDataMon[i],"diff":Number(this.reqvsgenDataMon[i].G)+ - +Number(this.reqvsgenDataMon[i].R)})
}
// console.log(all_week_day_data_mon)
for(var i=0;i<all_week_day_data_mon.length;i++){
  // console.log(this.current_day_summary_data[i])
  result_R_G_mon.push({'shiftName':all_week_day_data_mon[i].shiftName,'R':all_week_day_data_mon[i].shiftData.R,'G':all_week_day_data_mon[i].shiftData.G})
}
// console.log(result_R_G_mon)
for(var i=0;i<all_char_data.length;i++){
    result_R_G_mon.push(all_char_data[i])
}
f_mon=result_R_G_mon.filter((v,i,a)=>a.findIndex(t=>(t.shiftName === v.shiftName ))===i)
result_R_G_mon=[]

for(var i=0;i<f_mon.length;i++){
  temp_time=Number(f_mon[i].shiftName)+ + + 2400;
  result_R_G_mon.push({'shiftName':temp_time,'R':f_mon[i].R,'G':f_mon[i].G})
}
// console.log(result_R_G_mon)

//Tue
var all_week_day_data_tue=[],result_R_G_tue=[],f_tue
for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
  all_week_day_data_tue.push({"shiftName":this.reqvsgenDataShiftTime[i],"shiftData":this.reqvsgenDataTue[i],"diff":Number(this.reqvsgenDataTue[i].G)+ - +Number(this.reqvsgenDataTue[i].R)})
}
for(var i=0;i<all_week_day_data_tue.length;i++){
  // console.log(this.current_day_summary_data[i])
  result_R_G_tue.push({'shiftName':all_week_day_data_tue[i].shiftName,'R':all_week_day_data_tue[i].shiftData.R,'G':all_week_day_data_tue[i].shiftData.G})
}
for(var i=0;i<all_char_data.length;i++){
    result_R_G_tue.push(all_char_data[i])
}
f_tue=result_R_G_tue.filter((v,i,a)=>a.findIndex(t=>(t.shiftName === v.shiftName ))===i)
result_R_G_tue=[]

for(var i=0;i<f_tue.length;i++){
  temp_time=Number(f_tue[i].shiftName)+ + + 4800;
  result_R_G_tue.push({'shiftName':temp_time,'R':f_tue[i].R,'G':f_tue[i].G})
}

// console.log(result_R_G_tue)
//Wed
var all_week_day_data_wed=[],result_R_G_wed=[],f_wed
for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
  all_week_day_data_wed.push({"shiftName":this.reqvsgenDataShiftTime[i],"shiftData":this.reqvsgenDataWed[i],"diff":Number(this.reqvsgenDataWed[i].G)+ - +Number(this.reqvsgenDataWed[i].R)})
}
for(var i=0;i<all_week_day_data_wed.length;i++){
  // console.log(this.current_day_summary_data[i])
  result_R_G_wed.push({'shiftName':all_week_day_data_wed[i].shiftName,'R':all_week_day_data_wed[i].shiftData.R,'G':all_week_day_data_wed[i].shiftData.G})
}
for(var i=0;i<all_char_data.length;i++){
    result_R_G_wed.push(all_char_data[i])
}
f_wed=result_R_G_wed.filter((v,i,a)=>a.findIndex(t=>(t.shiftName === v.shiftName ))===i)
result_R_G_wed=[]

for(var i=0;i<f_wed.length;i++){
  temp_time=Number(f_wed[i].shiftName)+ + + 7200;
  result_R_G_wed.push({'shiftName':temp_time,'R':f_wed[i].R,'G':f_wed[i].G})
}
// console.log(result_R_G_wed)
//Thu
var all_week_day_data_thu=[],result_R_G_thu=[],f_thu
for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
  all_week_day_data_thu.push({"shiftName":this.reqvsgenDataShiftTime[i],"shiftData":this.reqvsgenDataThu[i],"diff":Number(this.reqvsgenDataSun[i].G)+ - +Number(this.reqvsgenDataThu[i].R)})
}
for(var i=0;i<all_week_day_data_thu.length;i++){
  // console.log(this.current_day_summary_data[i])
  result_R_G_thu.push({'shiftName':all_week_day_data_thu[i].shiftName,'R':all_week_day_data_thu[i].shiftData.R,'G':all_week_day_data_thu[i].shiftData.G})
}
for(var i=0;i<all_char_data.length;i++){
    result_R_G_thu.push(all_char_data[i])
}
f_thu=result_R_G_thu.filter((v,i,a)=>a.findIndex(t=>(t.shiftName === v.shiftName ))===i)
result_R_G_thu=[]

for(var i=0;i<f_thu.length;i++){
  temp_time=Number(f_thu[i].shiftName)+ + + 9600;
  result_R_G_thu.push({'shiftName':temp_time,'R':f_thu[i].R,'G':f_thu[i].G})
}
// console.log(result_R_G_thu)
//Fri
var all_week_day_data_fri=[],result_R_G_fri=[],f_fri
for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
  all_week_day_data_fri.push({"shiftName":this.reqvsgenDataShiftTime[i],"shiftData":this.reqvsgenDataFri[i],"diff":Number(this.reqvsgenDataFri[i].G)+ - +Number(this.reqvsgenDataFri[i].R)})
}
for(var i=0;i<all_week_day_data_fri.length;i++){
  // console.log(this.current_day_summary_data[i])
  result_R_G_fri.push({'shiftName':all_week_day_data_fri[i].shiftName,'R':all_week_day_data_fri[i].shiftData.R,'G':all_week_day_data_fri[i].shiftData.G})
}
for(var i=0;i<all_char_data.length;i++){
    result_R_G_fri.push(all_char_data[i])
}
f_fri=result_R_G_fri.filter((v,i,a)=>a.findIndex(t=>(t.shiftName === v.shiftName ))===i)
result_R_G_fri=[]

for(var i=0;i<f_fri.length;i++){
  temp_time=Number(f_fri[i].shiftName)+ + + 12000;
  result_R_G_fri.push({'shiftName':temp_time,'R':f_fri[i].R,'G':f_fri[i].G})
}
// console.log(result_R_G_fri)
//Sat
var all_week_day_data_sat=[],result_R_G_sat=[],f_sat
for(var i=1;i<this.reqvsgenDataShiftTime.length;i++){
  all_week_day_data_sat.push({"shiftName":this.reqvsgenDataShiftTime[i],"shiftData":this.reqvsgenDataSat[i],"diff":Number(this.reqvsgenDataSat[i].G)+ - +Number(this.reqvsgenDataSat[i].R)})
}
for(var i=0;i<all_week_day_data_sat.length;i++){
  // console.log(this.current_day_summary_data[i])
  result_R_G_sat.push({'shiftName':all_week_day_data_sat[i].shiftName,'R':all_week_day_data_sat[i].shiftData.R,'G':all_week_day_data_sat[i].shiftData.G})
}
for(var i=0;i<all_char_data.length;i++){
    result_R_G_sat.push(all_char_data[i])
}
f_sat=result_R_G_sat.filter((v,i,a)=>a.findIndex(t=>(t.shiftName === v.shiftName ))===i)
result_R_G_sat=[]

for(var i=0;i<f_sat.length;i++){
  temp_time=Number(f_sat[i].shiftName)+ + + 14400;
  result_R_G_sat.push({'shiftName':temp_time,'R':f_sat[i].R,'G':f_sat[i].G})
}
result_R_G_sat.push({"shiftName":16800,"R":0,"G":0})
// console.log(result_R_G_sat)
for(var i=0;i<result_R_G_sun.length;i++){
  all_week_day_data.push(result_R_G_sun[i])
}
for(var i=0;i<result_R_G_mon.length;i++){
  all_week_day_data.push(result_R_G_mon[i])
}
for(var i=0;i<result_R_G_tue.length;i++){
  all_week_day_data.push(result_R_G_tue[i])
}
for(var i=0;i<result_R_G_wed.length;i++){
  all_week_day_data.push(result_R_G_wed[i])
}
for(var i=0;i<result_R_G_thu.length;i++){
  all_week_day_data.push(result_R_G_thu[i])
}
for(var i=0;i<result_R_G_fri.length;i++){
  all_week_day_data.push(result_R_G_fri[i])
}
for(var i=0;i<result_R_G_sat.length;i++){
  all_week_day_data.push(result_R_G_sat[i])
}
// console.log(all_week_day_data)



var chart_data=[]

for(var i=0;i<all_week_day_data.length;i++){
  if(Number(all_week_day_data[i].shiftName) % 100 ==0 ){
  diff_G=Number(all_week_day_data[i].shiftName)+ - +700
  var sum1=0
  var result
  for(var j=0;j<all_week_day_data.length;j++){

    if(Number(all_week_day_data[j].shiftName)>=diff_G){
      if(Number(all_week_day_data[i].shiftName)>=Number(all_week_day_data[j].shiftName)){
        if((Number(all_week_day_data[i].shiftName) % 100 ==0) || Number(all_week_day_data[i].shiftName)===0 ){
        sum1=sum1+ + +all_week_day_data[j].G
        // if(Number(all_week_day_data[j].shiftName)>2300 && Number(all_week_day_data[j].shiftName)<4800 && Number(all_week_day_data[i].shiftName)>2300 && Number(all_week_day_data[i].shiftName)<4800){
        //   console.log(all_week_day_data[j], sum1)
        // }

        result={'shiftName':all_week_day_data[i].shiftName,'sum':sum1}
        }
      }
    }
  }
  chart_data.push({'shiftName':all_week_day_data[i].shiftName,'sum':sum1})
}
}

var chart_data_req=[]
for(var i=0;i<all_week_day_data.length;i++){
  if(Number(all_week_day_data[i].shiftName) % 100 ==0 ){
  diff_G=Number(all_week_day_data[i].shiftName)+ - +700
  var sum=0
  var result
  for(var j=0;j<all_week_day_data.length;j++){

    if(Number(all_week_day_data[j].shiftName)>=diff_G){
      if(Number(all_week_day_data[i].shiftName)>=Number(all_week_day_data[j].shiftName)){
        if((Number(all_week_day_data[i].shiftName) % 100 ==0) || Number(all_week_day_data[i].shiftName)===0 ){
        sum=sum+ + +all_week_day_data[j].R
        // if(Number(all_week_day_data[j].shiftName)>2300 && Number(all_week_day_data[j].shiftName)<4800 && Number(all_week_day_data[i].shiftName)>2300 && Number(all_week_day_data[i].shiftName)<4800){
        //   console.log(all_week_day_data[j], sum1)
        // }

        result={'shiftName':all_week_day_data[i].shiftName,'sum':sum}
        }
      }
    }
  }
  chart_data_req.push({'shiftName':all_week_day_data[i].shiftName,'sum':sum})
}
}



var sun_chart_data=[],mon_chart_data=[],tue_chart_data=[],wed_chart_data=[],thu_chart_data=[],fri_chart_data=[],sat_chart_data=[]
var sun_chart_data_req=[],mon_chart_data_req=[],tue_chart_data_req=[],wed_chart_data_req=[],thu_chart_data_req=[],fri_chart_data_req=[],sat_chart_data_req=[]
for(var i=0;i<24;i++){
  sun_chart_data.push(chart_data[i])
  mon_chart_data.push(chart_data[i+24])
  tue_chart_data.push(chart_data[i+48])
  wed_chart_data.push(chart_data[i+72])
  thu_chart_data.push(chart_data[i+96])
  fri_chart_data.push(chart_data[i+120])
  sat_chart_data.push(chart_data[i+144])

}
sat_chart_data.push(chart_data[168])
sun_chart_data=sun_chart_data.sort(function(a, b){return a.shiftName - b.shiftName});
mon_chart_data=mon_chart_data.sort(function(a, b){return a.shiftName - b.shiftName});
tue_chart_data=tue_chart_data.sort(function(a, b){return a.shiftName - b.shiftName});
wed_chart_data=wed_chart_data.sort(function(a, b){return a.shiftName - b.shiftName});
thu_chart_data=thu_chart_data.sort(function(a, b){return a.shiftName - b.shiftName});
fri_chart_data=fri_chart_data.sort(function(a, b){return a.shiftName - b.shiftName});
sat_chart_data=sat_chart_data.sort(function(a, b){return a.shiftName - b.shiftName});

for(var i=0;i<24;i++){
  sun_chart_data_req.push(chart_data_req[i])
  mon_chart_data_req.push(chart_data_req[i+24])
  tue_chart_data_req.push(chart_data_req[i+48])
  wed_chart_data_req.push(chart_data_req[i+72])
  thu_chart_data_req.push(chart_data_req[i+96])
  fri_chart_data_req.push(chart_data_req[i+120])
  sat_chart_data_req.push(chart_data_req[i+144])

}sat_chart_data_req.push(chart_data_req[168])
sun_chart_data_req=sun_chart_data_req.sort(function(a, b){return a.shiftName - b.shiftName});
mon_chart_data_req=mon_chart_data_req.sort(function(a, b){return a.shiftName - b.shiftName});
tue_chart_data_req=tue_chart_data_req.sort(function(a, b){return a.shiftName - b.shiftName});
wed_chart_data_req=wed_chart_data_req.sort(function(a, b){return a.shiftName - b.shiftName});
thu_chart_data_req=thu_chart_data_req.sort(function(a, b){return a.shiftName - b.shiftName});
fri_chart_data_req=fri_chart_data_req.sort(function(a, b){return a.shiftName - b.shiftName});
sat_chart_data_req=sat_chart_data_req.sort(function(a, b){return a.shiftName - b.shiftName});



for(var i=0;i<this.current_day_summary_data.length;i++){
  // console.log(this.current_day_summary_data[i])
  this.result_R_G.push({'shiftName':this.current_day_summary_data[i].shiftName,'R':this.current_day_summary_data[i].shiftData.R,'G':this.current_day_summary_data[i].shiftData.G})
}
for(var i=0;i<all_char_data.length;i++){
  this.result_R_G.push(all_char_data[i])
}
var f
f=this.result_R_G.filter((v,i,a)=>a.findIndex(t=>(t.shiftName === v.shiftName ))===i)
this.result_R_G=f
// console.log(this.result_R_G)
var diff_G
for(var i=0;i<this.result_R_G.length;i++){
  if(Number(this.result_R_G[i].shiftName) % 100 ==0 ){
  diff_G=Number(this.result_R_G[i].shiftName)+ - +700
  var sum1=0
  var result
  for(var j=0;j<this.result_R_G.length;j++){

    if(Number(this.result_R_G[j].shiftName)>=diff_G){
      if(Number(this.result_R_G[i].shiftName)>=Number(this.result_R_G[j].shiftName)){
        if((Number(this.result_R_G[i].shiftName) % 100 ==0) || Number(this.result_R_G[i].shiftName)===0 ){
        sum1=sum1+ + +this.result_R_G[j].G
        result={'shiftName':this.result_R_G[i].shiftName,'sum':sum1}
        }
      }
    }
  }
  this.chart_data_G.push({'shiftName':this.result_R_G[i].shiftName,'sum':sum1})
}
}
// console.log(this.chart_data_G)
var diff_R
for(var i=0;i<this.result_R_G.length;i++){
  if(Number(this.result_R_G[i].shiftName) % 100 ==0 ){
  diff_R=Number(this.result_R_G[i].shiftName)+ - +700
  var sum2=0
  var result
  for(var j=0;j<this.result_R_G.length;j++){
    if(Number(this.result_R_G[j].shiftName)>=diff_R){
      if(Number(this.result_R_G[i].shiftName)>=Number(this.result_R_G[j].shiftName)){
        if((Number(this.result_R_G[i].shiftName) % 100 ==0  ) || Number(this.result_R_G[i].shiftName)===0 ){
        sum2=sum2+ + +this.result_R_G[j].R
        result={'shiftName':this.result_R_G[i].shiftName,'sum':sum2}
        }
      }
    }
  }
  this.chart_data_R.push({'shiftName':this.result_R_G[i].shiftName,'sum':sum2})
}
}



if(this.day_summary.id==0){
  this.chart_data_G=sun_chart_data
  this.chart_data_R=sun_chart_data_req
  this.chart_data_G.push(mon_chart_data[0])
  this.chart_data_R.push(mon_chart_data_req[0])
}
if(this.day_summary.id==1){
  this.chart_data_G=mon_chart_data
  this.chart_data_R=mon_chart_data_req
  this.chart_data_G.push(tue_chart_data[0])
  this.chart_data_R.push(tue_chart_data_req[0])
}
if(this.day_summary.id==2){
  this.chart_data_G=tue_chart_data
  this.chart_data_R=tue_chart_data_req
  this.chart_data_G.push(wed_chart_data[0])
  this.chart_data_R.push(wed_chart_data_req[0])
}
if(this.day_summary.id==3){
  this.chart_data_G=wed_chart_data
  this.chart_data_R=wed_chart_data_req
  this.chart_data_G.push(thu_chart_data[0])
  this.chart_data_R.push(thu_chart_data_req[0])
}
if(this.day_summary.id==4){
  this.chart_data_G=thu_chart_data
  this.chart_data_R=thu_chart_data_req
  this.chart_data_G.push(fri_chart_data[0])
  this.chart_data_R.push(fri_chart_data_req[0])
}
if(this.day_summary.id==5){
  this.chart_data_G=fri_chart_data
  this.chart_data_R=fri_chart_data_req
  this.chart_data_G.push(sat_chart_data[0])
  this.chart_data_R.push(sat_chart_data_req[0])
}
if(this.day_summary.id==6){
  this.chart_data_G=sat_chart_data
  this.chart_data_R=sat_chart_data_req
}

      this.chart_data_R.sort(function(a, b){return a.shiftName - b.shiftName});
      this.chart_data_G.sort(function(a, b){return a.shiftName - b.shiftName});
      // console.log(this.chart_data_R)
      // console.log(this.chart_data_G)
      this.Gen=[],this.Shift=[]
      for(var i=0;i<this.chart_data_G.length;i++){

        this.Gen.push(Number(this.chart_data_G[i].sum))
        if(this.day_summary.id==0){
          this.Shift.push(this.chart_data_G[i].shiftName)

        }
        else if(this.day_summary.id==1){
            temp_time=(Number(this.chart_data_G[i].shiftName+ - +2400)).toString()
            if(temp_time.length==1){
              temp_time='000'+temp_time
            }else if(temp_time.length==2){
              temp_time='00'+temp_time
            }else if(temp_time.length==3){
              temp_time='0'+temp_time
            }
            this.Shift.push(temp_time)
        }
        else if(this.day_summary.id==2){
          temp_time=(Number(this.chart_data_G[i].shiftName+ - +4800)).toString()
          if(temp_time.length==1){
            temp_time='000'+temp_time
          }else if(temp_time.length==2){
            temp_time='00'+temp_time
          }else if(temp_time.length==3){
            temp_time='0'+temp_time
          }
          this.Shift.push(temp_time)
        }
        else if(this.day_summary.id==3){
          temp_time=(Number(this.chart_data_G[i].shiftName+ - +7200)).toString()
          if(temp_time.length==1){
            temp_time='000'+temp_time
          }else if(temp_time.length==2){
            temp_time='00'+temp_time
          }else if(temp_time.length==3){
            temp_time='0'+temp_time
          }
          this.Shift.push(temp_time)
        }
        else if(this.day_summary.id==4){
          temp_time=(Number(this.chart_data_G[i].shiftName+ - +9600)).toString()
          if(temp_time.length==1){
            temp_time='000'+temp_time
          }else if(temp_time.length==2){
            temp_time='00'+temp_time
          }else if(temp_time.length==3){
            temp_time='0'+temp_time
          }
          this.Shift.push(temp_time)
        }
        else if(this.day_summary.id==5){
          temp_time=(Number(this.chart_data_G[i].shiftName+ - +12000)).toString()
          if(temp_time.length==1){
            temp_time='000'+temp_time
          }else if(temp_time.length==2){
            temp_time='00'+temp_time
          }else if(temp_time.length==3){
            temp_time='0'+temp_time
          }
          this.Shift.push(temp_time)
        }
        else if(this.day_summary.id==6){
          temp_time=(Number(this.chart_data_G[i].shiftName+ - +14400)).toString()
          if(temp_time.length==1){
            temp_time='000'+temp_time
          }else if(temp_time.length==2){
            temp_time='00'+temp_time
          }else if(temp_time.length==3){
            temp_time='0'+temp_time
          }
          this.Shift.push(temp_time)
        }
      }
      this.Req=[]
      for(var i=0;i<this.chart_data_R.length;i++){

        this.Req.push(Number(this.chart_data_R[i].sum))

      }

      // if(this.day_summary.id==0){
      //   this.Shift.push("2400")
      //     this.Req.push(Number(this.Req[0]))
      //     this.Gen.push(Number(this.Gen[0]))
      // }
      // console.log(this.Shift)
      // console.log(this.Req)
      // console.log(this.Gen)
this.chartUI()



        return this.totalCount,this.countSunSat,this.countSunMon,this.countMonTue,this.countTueWed,this.countWedThu,this.countThuFri,this.countFriSat,this.SunSat,this.SunMon,this.MonTue,this.TueWed,this.WedThu,this.ThuFri,this.FriSat


  }
  dismiss(){
    this.modalCtrl.dismiss();
  }
  chartUI(){

   const  lineChartOptions:ChartOptions = {
    responsive: true,
    layout: {

      padding: {
        top:0,
          bottom: 0,
      }
  },
    scales: { xAxes: [{

      gridLines: {

        display: true,


      },
      ticks: {
        beginAtZero: true,
        // autoSkip: false,
      },

    }],
    yAxes: [{

      gridLines: {
        display: true,

      },
      ticks: {
        beginAtZero: true,


      }
    }] }
  };
// this.data2=this.S;

 const lineChartData:ChartDataSets[] = [

  { data:this.Req,
    label:'Required',
    backgroundColor:'rgba(135,110,235,0)',
    borderColor: 'rgba(135,110,235,0.8)',
    steppedLine:true,
    fill:false,
    pointBackgroundColor:'rgba(135,110,235)'},
  { data: this.Gen,
    label:'Generated',
    backgroundColor:'rgba(255,0,0,0.2)',
    borderColor: 'rgba(255,0,0,0.2)',
    steppedLine:true,
    fill:true,
    pointBackgroundColor:'rgba(255,0,0)'}
];
   const lineChartLabels: Label[] =this.Shift;


 const lineChartLegend = true;
 const lineChartType:ChartType = 'line';
 this.final_dataset=[lineChartData , lineChartLabels ,lineChartOptions ,lineChartType ,lineChartLegend]
//  this.final_dataset.push({"day_name":this.day_summary})

 return this.final_dataset
  }
  async zoom(){

      const modal = await this.modalCtrl.create({
        component: FullscreenChartPage,
        cssClass: 'my-css',
        componentProps: { chartData: [this.final_dataset[0],this.final_dataset[1],this.final_dataset[2],this.final_dataset[3],this.final_dataset[4],this.day_summary,this.current_day_summary_data]},
        swipeToClose:true
        // componentProps: { scheduleData: scheduleShift }

      });
      // this.scheduleShift=EditScheduleDataPage.data5
      // console.log(this.scheduleShift)
      return await modal.present();

    }
  //   if(this.hideChart==true){
  //     this.hideChart=false
  //   }else{
  //     this.hideChart=true
  //   }
  // }
  changeShiftToPlot(){
    if(this.hide_chart_and_plot==true){
      this.hide_chart_and_plot=false
    }else{
      this.hide_chart_and_plot=true
    }
  }

}
