import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController, NavParams } from '@ionic/angular';
import { HeaderTitleForModalPageService } from 'src/app/dashboard/nav-bar-footer/header-title-for-modal-page.service';
import { WorkLoadService } from 'src/app/services/work-load.service';

@Component({
  selector: 'app-view-total-eve-shift-lines-data',
  templateUrl: './view-total-eve-shift-lines-data.page.html',
  styleUrls: ['./view-total-eve-shift-lines-data.page.scss'],
})
export class ViewTotalEveShiftLinesDataPage implements OnInit {
  result1:any=[];
  result2:any=[];
  gData:any=[]
  totalShiftLine:any=[]
  ishidden = true;
  countSunSat=0
  countSunMon=0
  countMonTue=0
  countTueWed=0
  countWedThu=0
  countThuFri=0
  countFriSat=0
  SunSat=0
  SunMon=0
  MonTue=0
  TueWed=0
  WedThu=0
  ThuFri=0
  FriSat=0
  coun: any;
  showRDOinfo=false
  excelHeaders:string[] = ["Id","Mon","Tue","Wed","Thu","Fri","Sat"];
  templateToExcel:string[][] = [this.excelHeaders,[]];
  totalCount: any;
  totalDefaultScheduleLine=0
  scheduleShift: any []=[]
  afterdeleteShiftLines:any []=[]
  deleteShiftLines:any []=[]
  defaultscheduleShift: any []=[]
  defaultScheduleShift: any []=[]
  gDatasun: any;
  gDatamon: any;
  gDatatue: any;
  gDatawed: any;
  gDatathu: any;
  gDatafri: any;
  gDatasat: any;
  gDataPattern: any;
  generatedComparisonData: any []=[]
  generatedShiftLines:any []=[]
  generatedScheduleData:any []=[]
  requiredEmpData:any
  generatedEmpData
  SunDayRequired = [];
  SunDayGenerated = [];
  totalSundiff: any;
  // Run = [];
  totalSunGenerated: any;
  totalSunRequired: any;
  diffSunMid: any;
  diffSunDay: any;
  diffSunEve: any;
  validSunMid: boolean;
  validSunDay: boolean;
  validSunEve: boolean;
  mon: any;
  MonDayRequired= [];
  MonDayGenerated= [];
  diffMonMid: any;
  diffMonDay: any;
  diffMonEve: any;
  totalMonRequired: any;
  totalMonGenerated: any;
  totalMondiff: any;
  tue:any
  TueDayRequired= [];
  TueDayGenerated= [];
  diffTueMid: any;
  diffTueDay: any;
  diffTueEve: any;
  totalTueRequired: any;
  totalTueGenerated: any;
  totalTuediff: any;
  wed:any
  WedDayRequired= [];
  WedDayGenerated= [];
  diffWedMid: any;
  diffWedDay: any;
  diffWedEve: any;
  totalWedRequired: any;
  totalWedGenerated: any;
  totalWeddiff: any;
  thu:any
  ThuDayRequired= [];
  ThuDayGenerated= [];
  diffThuMid: any;
  diffThuDay: any;
  diffThuEve: any;
  totalThuRequired: any;
  totalThuGenerated: any;
  totalThudiff: any;
  fri:any
  FriDayRequired= [];
  FriDayGenerated= [];
  diffFriMid: any;
  diffFriDay: any;
  diffFriEve: any;
  totalFriRequired: any;
  totalFriGenerated: any;
  totalFridiff: any;
  sat:any
  SatDayRequired= [];
  SatDayGenerated= [];
  diffSatMid: any;
  diffSatDay: any;
  diffSatEve: any;
  totalSatRequired: any;
  totalSatGenerated: any;
  totalSatdiff: any;
  exportData=[] as any
  exportScheduleData=[] as any
  sunDay=[] as any
  defscheduleShift: any;
  sundAy= [] as any;
  mondAy= [] as any;
  tuedAy= [] as any;
  weddAy= [] as any;
  thudAy= [] as any;
  fridAy= [] as any;
  satdAy= [] as any;
  req: number=0;
  mon_1=0;mon_2=0;mon_3=0;mon_4=0;mon_5=0;diffDay_13_sun=0;diffDay_15_sun=0
  tue_1=0;tue_2=0;tue_3=0;tue_4=0;tue_5=0;diffDay_13_mon=0;diffDay_15_mon=0
  wed_1=0;wed_2=0;wed_3=0;wed_4=0;wed_5=0;diffDay_13_tue=0;diffDay_15_tue=0
  thu_1=0;thu_2=0;thu_3=0;thu_4=0;thu_5=0;diffDay_13_wed=0;diffDay_15_wed=0
  fri_1=0;fri_2=0;fri_3=0;fri_4=0;fri_5=0;diffDay_13_thu=0;diffDay_15_thu=0
  sat_1=0;sat_2=0;sat_3=0;sat_4=0;sat_5=0;diffDay_13_fri=0;diffDay_15_fri=0
  sun_1=0;sun_2=0;sun_3=0;sun_4=0;sun_5=0;diffDay_13_sat=0;diffDay_15_sat=0
  sun_mid: number=0;sun_day: number=0;sun_eve: number=0;
  mon_mid: number=0;mon_day: number=0;mon_eve: number=0;
  tue_mid: number=0;tue_day: number=0;tue_eve: number=0;
  wed_mid: number=0;wed_day: number=0;wed_eve: number=0;
  thu_mid: number=0;thu_day: number=0;thu_eve: number=0;
  fri_mid: number=0;fri_day: number=0;fri_eve: number=0;
  sat_mid: number=0;sat_day: number=0;sat_eve: number=0;
  workLoadData: any;
  shift: any;
  dayData=[] as any
  demo=[] as any
  default_value=0
  testing
  allShiftData: any;
  allShiftName: any[];
  addShiftData: any
  gShift: any;
  schedule_id
  constructor(
    public modalCtrl: ModalController,
    public navParams: NavParams,
    private route:Router,
    private headerTitleService: HeaderTitleForModalPageService,
    public viewCtrl: ModalController,
    public dataService:WorkLoadService
  ) {
    this.schedule_id=navParams.get('schedule_id')
    // console.log(this.schedule_id)
   }

  ngOnInit() {
    this.headerTitleService.setTitle('Eve Shift');
    this.exportData=[]

    this.generatedEmpData=JSON.parse(localStorage.getItem('requiredEmpData'))
    this.requiredEmpData=JSON.parse(localStorage.getItem('requiredEmpData'))
    this.scheduleShift=JSON.parse(localStorage.getItem('customizedScheduleShiftLine'))
    this.defscheduleShift=JSON.parse(localStorage.getItem('defaultScheduleShiftLine'))
    this.allShiftData=  JSON.parse(localStorage.getItem('allShiftRequiredData'))
    this.scheduleShift=this.scheduleShift[this.schedule_id]
    this.defscheduleShift=this.defscheduleShift[this.schedule_id]
this.allShiftName=[]
this.allShiftName.push({"shiftName":'X',"shiftCategory":'X'})
for(var i=0;i<this.allShiftData.length;i++){

  this.allShiftName.push({"shiftName":this.allShiftData[i].shiftName,"shiftCategory":this.allShiftData[i].shiftCategory,"shiftTime":this.allShiftData[i].startTime})
}

    this.shift=['M',6,7,1,3]

    this.sundAy=[]
    this.mondAy=[]
    this.tuedAy=[]
    this.weddAy=[]
    this.thudAy=[]
    this.fridAy=[]
    this.satdAy=[]
    for(var i=0;i<this.scheduleShift.length;i++){
      this.sundAy.push(this.scheduleShift[i].Sun)
      this.mondAy.push(this.scheduleShift[i].Mon)
      this.tuedAy.push(this.scheduleShift[i].Tue)
      this.weddAy.push(this.scheduleShift[i].Wed)
      this.thudAy.push(this.scheduleShift[i].Thu)
      this.fridAy.push(this.scheduleShift[i].Fri)
      this.satdAy.push(this.scheduleShift[i].Sat)

    }

    const countsCustomizedSunDay = {};
    this.sundAy.forEach(function (x) { countsCustomizedSunDay[x] = (countsCustomizedSunDay[x] || 0) + 1; });

    const countsCustomizedMonDay = {};
    this.mondAy.forEach(function (x) { countsCustomizedMonDay[x] = (countsCustomizedMonDay[x] || 0) + 1; });

    let countsCustomizedTueDay = {}
    this.tuedAy.forEach(function (x) { countsCustomizedTueDay[x] = (countsCustomizedTueDay[x] || 0) + 1; });

    const countsCustomizedWedDay = {};
    this.weddAy.forEach(function (x) { countsCustomizedWedDay[x] = (countsCustomizedWedDay[x] || 0) + 1; });

    const countsCustomizedThuDay = {};
    this.thudAy.forEach(function (x) { countsCustomizedThuDay[x] = (countsCustomizedThuDay[x] || 0) + 1; });

    const countsCustomizedFriDay = {};
    this.fridAy.forEach(function (x) { countsCustomizedFriDay[x] = (countsCustomizedFriDay[x] || 0) + 1; });

    const countsCustomizedSatDay = {};
    this.satdAy.forEach(function (x) { countsCustomizedSatDay[x] = (countsCustomizedSatDay[x] || 0) + 1; });

    let arrSun = [];let arrMon = [];let arrTue = [];let arrWed = [];let arrThu = [];let arrFri = [];let arrSat = [];

    Object.keys(countsCustomizedSunDay).map(function(key){
      arrSun.push({"shiftName":[key],"totalEmp":countsCustomizedSunDay[key]})
      return arrSun;
    });
    // console.log(arrSun)
    Object.keys(countsCustomizedMonDay).map(function(key){
      arrMon.push({"shiftName":[key],"totalEmp":countsCustomizedMonDay[key]})
      return arrMon;
    });
    // console.log(arrMon)

    Object.keys(countsCustomizedTueDay).map(function(key){
      arrTue.push({"shiftName":[key],"totalEmp":countsCustomizedTueDay[key]})
      return arrTue;
    });
    // console.log(arrTue)
    Object.keys(countsCustomizedWedDay).map(function(key){
      arrWed.push({"shiftName":[key],"totalEmp":countsCustomizedWedDay[key]})
      return arrWed;
    });
    // console.log(arrWed)
    Object.keys(countsCustomizedThuDay).map(function(key){
      arrThu.push({"shiftName":[key],"totalEmp":countsCustomizedThuDay[key]})
      return arrThu;
    });
    // console.log(arrThu)
    Object.keys(countsCustomizedFriDay).map(function(key){
      arrFri.push({"shiftName":[key],"totalEmp":countsCustomizedFriDay[key]})
      return arrFri;
    });
    // console.log(arrFri)
    Object.keys(countsCustomizedSatDay).map(function(key){
      arrSat.push({"shiftName":[key],"totalEmp":countsCustomizedSatDay[key]})
      return arrSat;
    });
    // console.log(arrSat)
    let sunTotalEmp=[];let monTotalEmp=[];let tueTotalEmp=[];let wedTotalEmp=[];let thuTotalEmp=[];let friTotalEmp=[];let satTotalEmp=[]
  // console.log(this.allShiftName)
    for(var i=0;i<this.allShiftName.length;i++){
      for(var j=0;j<arrSun.length;j++){
        // console.log(arrTue[j].start)
        if(this.allShiftName[i].shiftName==arrSun[j].shiftName)
        {
          if(arrSun[j].shiftName!='X')
          {
          sunTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory ,"totalEmp":arrSun[j].totalEmp})
          }
        }
      }
      for(var j=0;j<arrMon.length;j++){
        // console.log(arrTue[j].start)
        if(this.allShiftName[i].shiftName==arrMon[j].shiftName)
        {
          if(arrMon[j].shiftName!='X')
          {
            monTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrMon[j].totalEmp})
          }


        }
      }

      for(var j=0;j<arrTue.length;j++){
        // console.log(arrTue[j].start)
        if(this.allShiftName[i].shiftName==arrTue[j].shiftName  && this.allShiftName[i].shiftCategory=='2')
        {
          if(arrTue[j].shiftName!='X')
          {
          tueTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrTue[j].totalEmp})
          }
        }
      }
      for(var j=0;j<arrWed.length;j++){

        if(this.allShiftName[i].shiftName==arrWed[j].shiftName)
        {

          if(arrWed[j].shiftName!='X')
          {
          wedTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrWed[j].totalEmp})
          }
        }
      }
      for(var j=0;j<arrThu.length;j++){
        // console.log(arrTue[j].start)
        if(this.allShiftName[i].shiftName==arrThu[j].shiftName)
        {

          if(arrThu[j].shiftName!='X')
          {
          thuTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrThu[j].totalEmp})

          }
        }
      }
      for(var j=0;j<arrFri.length;j++){
        // console.log(arrTue[j].start)
        if(this.allShiftName[i].shiftName==arrFri[j].shiftName)
        {
          if(arrFri[j].shiftName!='X')
          {
          friTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrFri[j].totalEmp})
          }
        }
      }
      for(var j=0;j<arrSat.length;j++){
        // console.log(arrTue[j].start)
        if(this.allShiftName[i].shiftName==arrSat[j].shiftName)
        {
          if(arrSat[j].shiftName!='X')
          {
          satTotalEmp.push({"shiftName":this.allShiftName[i].shiftName ,"shiftTime":this.allShiftName[i].shiftTime,"shiftCategory":this.allShiftName[i].shiftCategory,"totalEmp":arrSat[j].totalEmp})
          }
        }
      }
    }

// console.log(thuTotalEmp)
    for(var i=0;i<sunTotalEmp.length;i++){
      if(sunTotalEmp[i].shiftCategory=='3'){
        this.sun_mid=this.sun_mid+ + +sunTotalEmp[i].totalEmp

      }
      else if(sunTotalEmp[i].shiftCategory=='1'){
        this.sun_day=this.sun_day+ + +sunTotalEmp[i].totalEmp
      }
      else if(sunTotalEmp[i].shiftCategory=='2'){
        this.sun_eve=this.sun_eve+ + +sunTotalEmp[i].totalEmp
      }
    }

    // Mon
    for(var i=0;i<monTotalEmp.length;i++){
      if(monTotalEmp[i].shiftCategory=='3'){
        this.mon_mid=this.mon_mid+ + +monTotalEmp[i].totalEmp
      }
      else if(monTotalEmp[i].shiftCategory=='1'){
        this.mon_day=this.mon_day+ + +monTotalEmp[i].totalEmp
      }
      else if(monTotalEmp[i].shiftCategory=='2'){
        this.mon_eve=this.mon_eve+ + +monTotalEmp[i].totalEmp
      }
    }
    // Tue
    for(var i=0;i<tueTotalEmp.length;i++){
      if(tueTotalEmp[i].shiftCategory=='3'){
        this.tue_mid=this.tue_mid+ + +tueTotalEmp[i].totalEmp
      }
      else if(tueTotalEmp[i].shiftCategory=='1'){
        this.tue_day=this.tue_day+ + +tueTotalEmp[i].totalEmp
      }
      else if(tueTotalEmp[i].shiftCategory=='2'){
        this.tue_eve=this.tue_eve+ + +tueTotalEmp[i].totalEmp
      }
    }

    // Wed
    for(var i=0;i<wedTotalEmp.length;i++){
      if(wedTotalEmp[i].shiftCategory=='3'){
        this.wed_mid=this.wed_mid+ + +wedTotalEmp[i].totalEmp
      }
      else if(wedTotalEmp[i].shiftCategory=='1'){
        this.wed_day=this.wed_day+ + +wedTotalEmp[i].totalEmp
      }
      else if(wedTotalEmp[i].shiftCategory=='2'){
        this.wed_eve=this.wed_eve+ + +wedTotalEmp[i].totalEmp
      }
    }

    // Thu
    for(var i=0;i<thuTotalEmp.length;i++){
      if(thuTotalEmp[i].shiftCategory=='3'){
        this.thu_mid=this.thu_mid+ + +thuTotalEmp[i].totalEmp
      }
      else if(thuTotalEmp[i].shiftCategory=='1'){
        this.thu_day=this.thu_day+ + +thuTotalEmp[i].totalEmp
      }
      else if(thuTotalEmp[i].shiftCategory=='2'){
        this.thu_eve=this.thu_eve+ + +thuTotalEmp[i].totalEmp
      }
    }

    // Fri
    for(var i=0;i<friTotalEmp.length;i++){
      if(friTotalEmp[i].shiftCategory=='3'){
        this.fri_mid=this.fri_mid+ + +friTotalEmp[i].totalEmp
      }
      else if(friTotalEmp[i].shiftCategory=='1'){
        this.fri_day=this.fri_day+ + +friTotalEmp[i].totalEmp
      }
      else if(friTotalEmp[i].shiftCategory=='2'){
        this.fri_eve=this.fri_eve+ + +friTotalEmp[i].totalEmp
      }
    }

    //Sat
    for(var i=0;i<satTotalEmp.length;i++){
      if(satTotalEmp[i].shiftCategory=='3'){
        this.sat_mid=this.sat_mid+ + +satTotalEmp[i].totalEmp
      }
      else if(satTotalEmp[i].shiftCategory=='1'){
        this.sat_day=this.sat_day+ + +satTotalEmp[i].totalEmp
      }
      else if(satTotalEmp[i].shiftCategory=='2'){
        this.sat_eve=this.sat_eve+ + +satTotalEmp[i].totalEmp
      }
    }

    let allShift=[]
for(var i=0;i<this.allShiftName.length;i++){
  if(this.allShiftName[i].shiftCategory=='2'){
    allShift.push(this.allShiftName[i])
  }
}
    // Mon
    let allDayData1=[]

    let allDayData=[]
    let mon=[]
    for(var i=0;i<monTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==monTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime)
            {
              if(monTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime && (monTotalEmp[i].totalEmp!=0 || monTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"}
                mon.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                allDayData1.push(this.addShiftData)
              }
              else if(monTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==monTotalEmp[i].shiftTime){
                mon.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":monTotalEmp[i].totalEmp,"day":"Mon"})
                allDayData1.push(this.addShiftData)
              }
             }
        }
      }
      for(var j=0;j<allShift.length;j++){
        this.addShiftData={"shiftTime":allShift[j].shiftTime,"totalEmp":0,"day":"Mon"}
                  mon.push(this.addShiftData)
      }
      let finalMonData
       finalMonData=mon.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

    // // Tue
    let tue=[]
    for(var i=0;i<tueTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==tueTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime)
            {
              if(tueTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime && (tueTotalEmp[i].totalEmp!=0 || tueTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"}
                tue.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                allDayData1.push(this.addShiftData)
              }
              else if(tueTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==tueTotalEmp[i].shiftTime){
                tue.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":tueTotalEmp[i].totalEmp,"day":"Tue"})
                allDayData1.push(this.addShiftData)
              }
             }
        }
      }
    for(var j=0;j<allShift.length;j++){
      this.addShiftData={"shiftTime":allShift[j].shiftTime,"totalEmp":0,"day":"Tue"}
                tue.push(this.addShiftData)
    }
    let finalTueData
     finalTueData=tue.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)
    // //Wed
    let wed=[]
    for(var i=0;i<wedTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==wedTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime)
            {
              if(wedTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime && (wedTotalEmp[i].totalEmp!=0 || wedTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"}
                wed.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                allDayData1.push(this.addShiftData)
              }
              else if(wedTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==wedTotalEmp[i].shiftTime){
                wed.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":wedTotalEmp[i].totalEmp,"day":"Wed"})
                allDayData1.push(this.addShiftData)
              }
             }
        }
      }
      for(var j=0;j<allShift.length;j++){
        this.addShiftData={"shiftTime":allShift[j].shiftTime,"totalEmp":0,"day":"Wed"}
                  wed.push(this.addShiftData)
      }
    let finalWedData
    finalWedData= wed.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

    // //Thu
    let thu=[]
    for(var i=0;i<thuTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==thuTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime)
            {
              if(thuTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime && (thuTotalEmp[i].totalEmp!=0 || thuTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"}
                thu.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                allDayData1.push(this.addShiftData)
              }
              else if(thuTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==thuTotalEmp[i].shiftTime){
                thu.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":thuTotalEmp[i].totalEmp,"day":"Thu"})
                allDayData1.push(this.addShiftData)
              }
             }
        }
      }
      for(var j=0;j<allShift.length;j++){
        this.addShiftData={"shiftTime":allShift[j].shiftTime,"totalEmp":0,"day":"Thu"}
                  thu.push(this.addShiftData)
      }
    let finalThuData
    finalThuData=thu.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

    // //Fri
    let fri=[]
    for(var i=0;i<friTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==friTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime)
            {
              if(friTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime && (friTotalEmp[i].totalEmp!=0 || friTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"}
                fri.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                allDayData1.push(this.addShiftData)
              }
              else if(friTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==friTotalEmp[i].shiftTime){
                fri.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":friTotalEmp[i].totalEmp,"day":"Fri"})
                allDayData1.push(this.addShiftData)
              }
             }
        }
      }
      for(var j=0;j<allShift.length;j++){
        this.addShiftData={"shiftTime":allShift[j].shiftTime,"totalEmp":0,"day":"Fri"}
                  fri.push(this.addShiftData)
      }
    let finalFriData
    finalFriData=fri.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

    // //Sat
    let sat=[]
    for(var i=0;i<satTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==satTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime)
            {
              if(satTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime && (satTotalEmp[i].totalEmp!=0 || satTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"}
                sat.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                allDayData1.push(this.addShiftData)
              }
              else if(satTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==satTotalEmp[i].shiftTime){
                sat.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":satTotalEmp[i].totalEmp,"day":"Sat"})
                allDayData1.push(this.addShiftData)
              }
             }

        }
      }
      for(var j=0;j<allShift.length;j++){
        this.addShiftData={"shiftTime":allShift[j].shiftTime,"totalEmp":0,"day":"Sat"}
                  sat.push(this.addShiftData)
      }
    let finalSatData
    finalSatData=sat.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)

    // //Sun
    let sun=[]
    for(var i=0;i<sunTotalEmp.length;i++){
      for(var j=0;j<this.allShiftName.length;j++){
          if(this.allShiftName[j].shiftCategory==sunTotalEmp[i].shiftCategory && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime)
            {
              if(sunTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime && (sunTotalEmp[i].totalEmp!=0 || sunTotalEmp[i].totalEmp!=null)){
              this.addShiftData={"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"}
                sun.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                allDayData1.push(this.addShiftData)
              }
              else if(sunTotalEmp[i].shiftCategory=='2' && this.allShiftName[j].shiftTime==sunTotalEmp[i].shiftTime){
                sun.push({"shiftTime":this.allShiftName[j].shiftTime,"totalEmp":sunTotalEmp[i].totalEmp,"day":"Sun"})
                allDayData1.push(this.addShiftData)
              }
             }
        }
      }
      for(var j=0;j<allShift.length;j++){
        this.addShiftData={"shiftTime":allShift[j].shiftTime,"totalEmp":0,"day":"Sun"}
                  sun.push(this.addShiftData)
      }
    let finalSunData
    finalSunData=sun.filter((v,i,a)=>a.findIndex(t=>(t.shiftTime === v.shiftTime && t.day===v.day))===i)



let allSunDayShifts
let allS=[]
for(var i=0;i<finalSunData.length;i++){

  allDayData.push(finalSunData[i])
}
for(var i=0;i<finalMonData.length;i++){

  allDayData.push(finalMonData[i])
}for(var i=0;i<finalTueData.length;i++){

  allDayData.push(finalTueData[i])
}for(var i=0;i<finalWedData.length;i++){

  allDayData.push(finalWedData[i])
}for(var i=0;i<finalThuData.length;i++){

  allDayData.push(finalThuData[i])
}for(var i=0;i<finalFriData.length;i++){

  allDayData.push(finalFriData[i])
}for(var i=0;i<finalSunData.length;i++){

  allDayData.push(finalSatData[i])
}
// console.log(allDayData)
let temp=[]
let result=[]
allShift=[]

let all_shift_data=[]
for(var i=0;i<this.allShiftData.length;i++){
  if(this.allShiftData[i].shiftCategory=='2'){
    allShift.push(this.allShiftData[i])
  }
}
// console.log(allShift)
for(var k=0;k<allShift.length;k++){
temp=[]
  for(var i=0;i<allDayData.length;i++){
    if(allDayData[i].shiftTime==allShift[k].startTime){
     temp.push( allDayData[i])
    }

  }

  result=[temp]
  // console.log(result)
  // console.log(allShift[k])
  this.dayData={
    "shift":{
      "shiftTime":allShift[k].startTime
    },
    "midData23R":{
      "sun":allShift[k].Sun,
      "mon":allShift[k].Mon,
      "tue":allShift[k].Tue,
      "wed":allShift[k].Wed,
      "thu":allShift[k].Thu,
      "fri":allShift[k].Fri,
      "sat":allShift[k].Sat,
  },
  "midData23G":{
    "sun":result?.[0][0].totalEmp,
    "mon":result?.[0][1].totalEmp,
    "tue":result?.[0][2].totalEmp,
    "wed":result?.[0][3].totalEmp,
    "thu":result?.[0][4].totalEmp,
    "fri":result?.[0][5].totalEmp,
    "sat":result?.[0][6].totalEmp
},
"diff":{
  "sun":this.diffDay_13_sun=result?.[0][0].totalEmp+ - +allShift[k].Sun,
    "mon":this.diffDay_13_mon=result?.[0][1].totalEmp+ - +allShift[k].Mon,
    "tue":this.diffDay_13_tue=result?.[0][2].totalEmp+ - +allShift[k].Tue,
    "wed":this.diffDay_13_wed=result?.[0][3].totalEmp+ - +allShift[k].Wed,
    "thu":this.diffDay_13_thu=result?.[0][4].totalEmp+ - +allShift[k].Thu,
    "fri":this.diffDay_13_fri=result?.[0][5].totalEmp+ - +allShift[k].Fri,
    "sat":this.diffDay_13_sat=result?.[0][6].totalEmp+ - +allShift[k].Sat,
}
}
// console.log(this.dayData)
this.demo.push(this.dayData)
// console.log(this.demo)






all_shift_data.push(result)

  }
  // console.log(all_shift_data)









    this.generatedEmpData.SUN_MID=this.sun_mid
    this.generatedEmpData.SUN_DAY=this.sun_day
    this.generatedEmpData.SUN_EVE=this.sun_eve
    this.generatedEmpData.MON_MID=this.mon_mid
    this.generatedEmpData.MON_DAY=this.mon_day
    this.generatedEmpData.MON_EVE=this.mon_eve
    this.generatedEmpData.TUE_MID=this.tue_mid
    this.generatedEmpData.TUE_DAY=this.tue_day
    this.generatedEmpData.TUE_EVE=this.tue_eve
    this.generatedEmpData.WED_MID=this.wed_mid
    this.generatedEmpData.WED_DAY=this.wed_day
    this.generatedEmpData.WED_EVE=this.wed_eve
    this.generatedEmpData.THU_MID=this.thu_mid
    this.generatedEmpData.THU_DAY=this.thu_day
    this.generatedEmpData.THU_EVE=this.thu_eve
    this.generatedEmpData.FRI_MID=this.fri_mid
    this.generatedEmpData.FRI_DAY=this.fri_day
    this.generatedEmpData.FRI_EVE=this.fri_eve
    this.generatedEmpData.SAT_MID=this.sat_mid
    this.generatedEmpData.SAT_DAY=this.sat_day
    this.generatedEmpData.SAT_EVE=this.sat_eve
    // console.log(this.mon_day)
    // console.log(this.sundAy)
    this.SunDayRequired.push(this.requiredEmpData.SUN_MID)
    this.SunDayRequired.push(this.requiredEmpData.SUN_DAY)
    this.SunDayRequired.push(this.requiredEmpData.SUN_EVE)
    this.SunDayGenerated.push(this.generatedEmpData.SUN_MID)
    this.SunDayGenerated.push(this.generatedEmpData.SUN_DAY)
    this.SunDayGenerated.push(this.generatedEmpData.SUN_EVE)
    this.diffSunMid=this.SunDayGenerated[0] + - + this.SunDayRequired[0]
    this.diffSunDay=this.SunDayGenerated[1] + - + this.SunDayRequired[1]
    this.diffSunEve=this.SunDayGenerated[2] + - + this.SunDayRequired[2]
    this.totalSunRequired= this.SunDayRequired[0] + + + this.SunDayRequired[1] + + + this.SunDayRequired[2]
    this.totalSunGenerated= this.SunDayGenerated[0] + + + this.SunDayGenerated[1] + + + this.SunDayGenerated[2]
    this.totalSundiff=this.totalSunGenerated+ - + this.totalSunRequired

    this.MonDayRequired.push(this.requiredEmpData.MON_MID)
    this.MonDayRequired.push(this.requiredEmpData.MON_DAY)
    this.MonDayRequired.push(this.requiredEmpData.MON_EVE)
    this.MonDayGenerated.push(this.generatedEmpData.MON_MID)
    this.MonDayGenerated.push(this.generatedEmpData.MON_DAY)
    this.MonDayGenerated.push(this.generatedEmpData.MON_EVE)
    this.diffMonMid=this.MonDayGenerated[0] + - + this.MonDayRequired[0]
    this.diffMonDay=this.MonDayGenerated[1] + - + this.MonDayRequired[1]
    this.diffMonEve=this.MonDayGenerated[2] + - + this.MonDayRequired[2]
    this.totalMonRequired= this.MonDayRequired[0] + + + this.MonDayRequired[1] + + + this.MonDayRequired[2]
    this.totalMonGenerated= this.MonDayGenerated[0] + + + this.MonDayGenerated[1] + + + this.MonDayGenerated[2]
    this.totalMondiff=this.totalMonGenerated+ - + this.totalMonRequired

    this.TueDayRequired.push(this.requiredEmpData.TUE_MID)
    this.TueDayRequired.push(this.requiredEmpData.TUE_DAY)
    this.TueDayRequired.push(this.requiredEmpData.TUE_EVE)
    this.TueDayGenerated.push(this.generatedEmpData.TUE_MID)
    this.TueDayGenerated.push(this.generatedEmpData.TUE_DAY)
    this.TueDayGenerated.push(this.generatedEmpData.TUE_EVE)
    this.diffTueMid=this.TueDayGenerated[0] + - + this.TueDayRequired[0]
    this.diffTueDay=this.TueDayGenerated[1] + - + this.TueDayRequired[1]
    this.diffTueEve=this.TueDayGenerated[2] + - + this.TueDayRequired[2]
    this.totalTueRequired= this.TueDayRequired[0] + + + this.TueDayRequired[1] + + + this.TueDayRequired[2]
    this.totalTueGenerated= this.TueDayGenerated[0] + + + this.TueDayGenerated[1] + + + this.TueDayGenerated[2]
    this.totalTuediff=this.totalTueGenerated+ - + this.totalTueRequired

    this.WedDayRequired.push(this.requiredEmpData.WED_MID)
    this.WedDayRequired.push(this.requiredEmpData.WED_DAY)
    this.WedDayRequired.push(this.requiredEmpData.WED_EVE)
    this.WedDayGenerated.push(this.generatedEmpData.WED_MID)
    this.WedDayGenerated.push(this.generatedEmpData.WED_DAY)
    this.WedDayGenerated.push(this.generatedEmpData.WED_EVE)
    this.diffWedMid=this.WedDayGenerated[0] + - + this.WedDayRequired[0]
    this.diffWedDay=this.WedDayGenerated[1] + - + this.WedDayRequired[1]
    this.diffWedEve=this.WedDayGenerated[2] + - + this.WedDayRequired[2]
    this.totalWedRequired= this.WedDayRequired[0] + + + this.WedDayRequired[1] + + + this.WedDayRequired[2]
    this.totalWedGenerated= this.WedDayGenerated[0] + + + this.WedDayGenerated[1] + + + this.WedDayGenerated[2]
    this.totalWeddiff=this.totalWedGenerated+ - + this.totalWedRequired

    this.ThuDayRequired.push(this.requiredEmpData.THU_MID)
    this.ThuDayRequired.push(this.requiredEmpData.THU_DAY)
    this.ThuDayRequired.push(this.requiredEmpData.THU_EVE)
    this.ThuDayGenerated.push(this.generatedEmpData.THU_MID)
    this.ThuDayGenerated.push(this.generatedEmpData.THU_DAY)
    this.ThuDayGenerated.push(this.generatedEmpData.THU_EVE)
    this.diffThuMid=this.ThuDayGenerated[0] + - + this.ThuDayRequired[0]
    this.diffThuDay=this.ThuDayGenerated[1] + - + this.ThuDayRequired[1]
    this.diffThuEve=this.ThuDayGenerated[2] + - + this.ThuDayRequired[2]
    this.totalThuRequired= this.ThuDayRequired[0] + + + this.ThuDayRequired[1] + + + this.ThuDayRequired[2]
    this.totalThuGenerated= this.ThuDayGenerated[0] + + + this.ThuDayGenerated[1] + + + this.ThuDayGenerated[2]
    this.totalThudiff=this.totalThuGenerated+ - + this.totalThuRequired

    this.FriDayRequired.push(this.requiredEmpData.FRI_MID)
    this.FriDayRequired.push(this.requiredEmpData.FRI_DAY)
    this.FriDayRequired.push(this.requiredEmpData.FRI_EVE)
    this.FriDayGenerated.push(this.generatedEmpData.FRI_MID)
    this.FriDayGenerated.push(this.generatedEmpData.FRI_DAY)
    this.FriDayGenerated.push(this.generatedEmpData.FRI_EVE)
    this.diffFriMid=this.FriDayGenerated[0] + - + this.FriDayRequired[0]
    this.diffFriDay=this.FriDayGenerated[1] + - + this.FriDayRequired[1]
    this.diffFriEve=this.FriDayGenerated[2] + - + this.FriDayRequired[2]
    this.totalFriRequired= this.FriDayRequired[0] + + + this.FriDayRequired[1] + + + this.FriDayRequired[2]
    this.totalFriGenerated= this.FriDayGenerated[0] + + + this.FriDayGenerated[1] + + + this.FriDayGenerated[2]
    this.totalFridiff=this.totalFriGenerated+ - + this.totalFriRequired

    this.SatDayRequired.push(this.requiredEmpData.SAT_MID)
    this.SatDayRequired.push(this.requiredEmpData.SAT_DAY)
    this.SatDayRequired.push(this.requiredEmpData.SAT_EVE)
    this.SatDayGenerated.push(this.generatedEmpData.SAT_MID)
    this.SatDayGenerated.push(this.generatedEmpData.SAT_DAY)
    this.SatDayGenerated.push(this.generatedEmpData.SAT_EVE)
    this.diffSatMid=this.SatDayGenerated[0] + - + this.SatDayRequired[0]
    this.diffSatDay=this.SatDayGenerated[1] + - + this.SatDayRequired[1]
    this.diffSatEve=this.SatDayGenerated[2] + - + this.SatDayRequired[2]
    this.totalSatRequired= this.SatDayRequired[0] + + + this.SatDayRequired[1] + + + this.SatDayRequired[2]
    this.totalSatGenerated= this.SatDayGenerated[0] + + + this.SatDayGenerated[1] + + + this.SatDayGenerated[2]
    this.totalSatdiff=this.totalSatGenerated+ - + this.totalSatRequired
  }
  dismiss(){
    this.modalCtrl.dismiss();
  }

}

