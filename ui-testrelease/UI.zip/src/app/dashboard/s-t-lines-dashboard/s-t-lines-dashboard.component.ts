import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import straightlines_io_apis from 'src/app/json/apis.json';
import { GeneratedScheduleService } from 'src/app/services/schedule/generated-schedule.service';
import { HeaderTitleService } from '../nav-bar-footer/header-title.service';
@Component({
  selector: 'app-s-t-lines-dashboard',
  templateUrl: './s-t-lines-dashboard.component.html',
  styleUrls: ['./s-t-lines-dashboard.component.scss'],
})
export class STLinesDashboardComponent implements OnInit {
id=0
all_schedule=[]
// allShiftData=[]
  user_data: any;
  all_Schedule=[];
  constructor(public navCtrl: NavController,
    private scheduleService:GeneratedScheduleService,
    private headerTitleService: HeaderTitleService,) { }

  ngOnInit() {
    this.headerTitleService.setTitle('Welcome!');
    this.headerTitleService.setBackUrl(null);
    this.headerTitleService.setDefaultHeader(true)
this.headerTitleService.setForwardUrl(null);
this.user_data=JSON.parse(localStorage.getItem('userData'))
this.getSchedule()
  }
  getSchedule(){
    var tempObj={}
    var tempArr=[]
    var all_shift_data=[]

    this.scheduleService.getAllSchedule().subscribe((res)=>{
      for(var i=0;i<res.length;i++){
        if(Number(this.user_data.id)===Number(res[i].userid)){

          tempArr.push(res[i])
        }
      }
      // console.log(tempArr)
      var getAllScheduleName=[]
      for(var i=0;i<tempArr.length;i++){
        for(var j=0;j<tempArr.length;j++){
          if(getAllScheduleName[i]!==tempArr[j].schedulename){
            getAllScheduleName.push(tempArr[j].schedulename)

          }
        }
      }var unique = getAllScheduleName.filter(this.onlyUnique);

var tempArray=[],finalData=[]
var ob
      for(var i=0;i<unique.length;i++){
        tempArray=[]
        for(var j=0;j<tempArr.length;j++){
          if(tempArr[j].schedulename===unique[i]){
            tempArray.push(tempArr[j])
          }
        }
        ob={"schedule_name":unique[i],"customizedScheduleShiftLine":tempArray,"defaultScheduleShiftLine":tempArray,"allShiftRequiredData":all_shift_data}
        finalData.push(ob)

      }
      this.all_Schedule=[]
      for(var i=0;i<finalData.length;i++){
      if(this.all_Schedule==null){
          this.all_Schedule.push(finalData[i])
        }
        else{
          this.all_Schedule.push(finalData[i])
        }
      }

      this.all_schedule=this.all_Schedule
      return this.all_schedule

    },(error)=>{
      console.log(error)
    },()=>{
    })
  }
   onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
  }
  start(){
    if(this.all_schedule.length>0){
      this.navCtrl.navigateForward([straightlines_io_apis.apis.manage_shift_line_schedule])
    }else{
      this.navCtrl.navigateForward([straightlines_io_apis.apis.enter_Work_load_api])
    }

  }
  bidding(){
    this.navCtrl.navigateForward([straightlines_io_apis.apis.my_bidding])
  }
}
