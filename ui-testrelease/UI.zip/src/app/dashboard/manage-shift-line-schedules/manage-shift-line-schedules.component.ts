import { Component, OnInit } from '@angular/core';
import straightlines_io_apis from 'src/app/json/apis.json';
import { HeaderTitleService } from '../nav-bar-footer/header-title.service';
@Component({
  selector: 'app-manage-shift-line-schedules',
  templateUrl: './manage-shift-line-schedules.component.html',
  styleUrls: ['./manage-shift-line-schedules.component.scss'],
})
export class ManageShiftLineSchedulesComponent implements OnInit {

  constructor(
    private headerTitleService: HeaderTitleService,
  ) { }

  ngOnInit() {
    this.headerTitleService.setTitle('');
this.headerTitleService.setDefaultHeader(true)
this.headerTitleService.setBackUrl(straightlines_io_apis.apis.dashboard);
this.headerTitleService.setForwardUrl(straightlines_io_apis.apis.enter_Work_load_api);
  }

}
