import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-shift-line-schedule',
  templateUrl: './add-shift-line-schedule.component.html',
  styleUrls: ['./add-shift-line-schedule.component.scss'],
})
export class AddShiftLineScheduleComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
