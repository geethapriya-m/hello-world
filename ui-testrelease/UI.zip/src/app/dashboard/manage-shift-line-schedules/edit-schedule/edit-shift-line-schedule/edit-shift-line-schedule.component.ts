import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { NavController, ModalController, NavParams } from '@ionic/angular';
import { EditScheduleDataPage } from 'src/app/dashboard/generated_schedule/add-edit-shift-lines/edit-schedule-data/edit-schedule-data.page';
import { HeaderTitleForModalPageService } from 'src/app/dashboard/nav-bar-footer/header-title-for-modal-page.service';
import { BusinessRulesValidationService } from 'src/app/services/business-rules-validation.service';
import { ScheduleDataService } from 'src/app/services/schedule-data.service';
import { WorkLoadService } from 'src/app/services/work-load.service';
import defData from 'src/app//json/work-load-data.json';
@Component({
  selector: 'app-edit-shift-line-schedule',
  templateUrl: './edit-shift-line-schedule.component.html',
  styleUrls: ['./edit-shift-line-schedule.component.scss'],
})
export class EditShiftLineScheduleComponent implements OnInit {

  // worData=GeneratedScheduleData
  workShiftLine=[] as any;
  resultShiftLine=[] as any
  finalResultShiftLine=[]as any
  scheduleDataId: any;
  scheduleData: any;
  errorMsg: any;
  scheduleDataSunSat: any;
  // workLoadData: any;
da1=[] as any
  wDataThree: any;
  wDataTwelve: any;
  wDataOne: any;
  wDataTwo: any;
  wDataFour: any;
  wDataElevenNight: any;
  wDataEleven: any;
  wDataTen: any;
  wDataNine: any;
  wDataEight: any;
  wDataSeven: any;
  wDataSix: any;
  wDataFive: any;
  ishidden = false;
  x
  status: boolean = true;
  editScheduleDataForm: FormGroup;

  public HideId: boolean = false;
  public showHideText: boolean = false;
  editData: any;
   exampleArray = []
  valid: any =true;
  tempScheduleDataStored: any[];
  data1: any[];
  gapBetweenshift: any;
  da: any[];
  static urlArray;
  workD: any;
  scheduleShiftLine: any;
  scheduleLData: any;
  workLoadData: any=defData;
  testing: any[];
  static data5;
  data2: any;
  pattern
  work_Pattern: any;
  dat1: any;
  WED: any;
  workPattern
  workPatternResult
  convertStringToCharLeft
  convertStringToCharRight
  patternLeft
  patternRight
  allShiftName=[] as any
  allShiftData
  shift_Pattern
  shift_line: {};
  temp: any;
  schedule_id
  all_Schedule: any;
  scheduleShift: any;
  edit_schedule_id: any;
  // workloadData=data222
  constructor(private route:Router,
              public workLoadDataService:WorkLoadService,
              public navCtrl: NavController,
              public dataService:ScheduleDataService,
              public busniessRulesValidation:BusinessRulesValidationService,
              public modalCtrl: ModalController,
              public navParams: NavParams,
              public viewCtrl: ModalController,
              private headerTitleService: HeaderTitleForModalPageService,
             public formBuilder: FormBuilder
    ) {

      EditScheduleDataPage.urlArray ="false";
      this.scheduleData=navParams.get('scheduleData')
      this.headerTitleService.setTitle('Edit Shift Line');
      this.edit_schedule_id=navParams.get('schedule_id')
    // console.log(this.schedule_id)

    let countValueOfX=0
    let countValueOfM=0
    // for(var i=0;i<=this.scheduleData.length;i++){
    //   this.da.push(this.scheduleData[i])
    // }
    this.da =[this.scheduleData.seq_id,this.scheduleData.Sun,this.scheduleData.Mon,this.scheduleData.Tue,this.scheduleData.Wed,this.scheduleData.Thu,this.scheduleData.Fri,this.scheduleData.Sat,"EEDDM",this.scheduleData.SL]
      // console.log(this.da[4])

      this.tempScheduleDataStored = [this.scheduleData.Sun,this.scheduleData.Mon,this.scheduleData.Tue,this.scheduleData.Wed,this.scheduleData.Thu,this.scheduleData.Fri,this.scheduleData.Sat]
      this.shift_Pattern=''
     for(var j=0;j<this.tempScheduleDataStored.length;j++){
           this.shift_Pattern=this.shift_Pattern+this.tempScheduleDataStored[j]
     }

      var right_text = this.shift_Pattern.substring(7, this.shift_Pattern.indexOf("X"),this.shift_Pattern.indexOf("X"));
      var left_text = this.shift_Pattern.substring(0, this.shift_Pattern.indexOf("X"),this.shift_Pattern.indexOf("X"));
      this.convertStringToCharLeft=Array.from(left_text)
      this.convertStringToCharRight=Array.from(right_text)
      this.patternRight=''
      this.patternLeft=''
     for(var i=0;i<this.convertStringToCharRight.length;i++){
       if(this.convertStringToCharRight[i]!=='X'){
         this.patternRight=this.patternRight+this.convertStringToCharRight[i]
       }
     }
     for(var i=0;i<this.convertStringToCharLeft.length;i++){
       if(this.convertStringToCharLeft[i]!=='X'){
         this.patternLeft=this.patternLeft+this.convertStringToCharLeft[i]
       }
     }
     this.shift_Pattern=this.patternRight+this.patternLeft
     this.workPattern=''
     this.convertStringToCharLeft=Array.from(this.shift_Pattern)
    //  console.log(this.shift_Pattern)
     this.da1=[]
        for(var i=0;i<this.da.length;i++){
        this.da1.push(String(this.da[i]))
        }
      if(this.scheduleData.Sun ===  "M" && this.scheduleData.Mon === "6" ){
        this.gapBetweenshift=false
      }
      else if(this.scheduleData.Mon ===  "M" && this.scheduleData.Tue === "6" ){
        this.gapBetweenshift=false
      }
      else if(this.scheduleData.Tue ===  "M" && this.scheduleData.Wed === "6" ){
        this.gapBetweenshift=false
      }
      else if(this.scheduleData.Wed ===  "M" && this.scheduleData.Thu === "6" ){
        this.gapBetweenshift=false
      }
      else if(this.scheduleData.Thu ===  "M" && this.scheduleData.Fri === "6" ){
        this.gapBetweenshift=false
      }
      else if(this.scheduleData.Fri ===  "M" && this.scheduleData.Sat === "6" ){
        this.gapBetweenshift=false
      }
      else if(this.scheduleData.Sat ===  "M" && this.scheduleData.Sun === "6" ){
        this.gapBetweenshift=false
      }
      else{
        this.gapBetweenshift=true
      }

        // for(var i=0;this.da.length;i++)
        // {
        //   if(this.da[i]==3||this.da[i]==1){
        //     this.pattern=this.pattern+"E"
        //   }
        //   else if(this.da[i]==6||this.da[i]==7){
        //     this.pattern=this.pattern+"D"
        //   }
        //   else if(this.da[i]=='M'){
        //     this.pattern=this.pattern+"D"
        //   }
        // }
        // console.log(this.pattern)

      // for(let i=0;i<=this.da.length;i++){
      //   if(this.da[i]=="X")
      //   {
      //     countValueOfX=countValueOfX+1

      //   }
      //   else if(this.da[i]=="M"){
      //     countValueOfM=countValueOfM+1
      //   }
      // }

      // if(countValueOfX>2 || countValueOfM>1 || this.gapBetweenshift ==false){
      //    this.valid =false
      // }else{
      //    this.valid =true
      // }







    }

    get staticUrlArray() {
      // console.log( EditScheduleDataPage.urlArray);
      return EditScheduleDataPage.urlArray
    }
  ngOnInit() {
//     const str = 'sometext-20202';
//     const slug = str.split('o$e').pop();
// console.log(slug)


this.all_Schedule=JSON.parse(localStorage.getItem('allSchedule'))
this.scheduleShift=JSON.parse(localStorage.getItem('editCustomizedScheduleShiftLine'))
this.allShiftData= JSON.parse(localStorage.getItem('allShiftRequiredDataForEditSchedule'))
this.data2=JSON.parse(localStorage.getItem('workData'))
// this.workLoadData=this.data2.required
// console.log(this.workLoadData)
this.allShiftName=[]
// this.allShiftName.push({"shiftName":'X',"shiftCategory":'X',"shift_StartTime":'X'})
for(var i=0;i<this.allShiftData.length;i++){
// console.log(this.allShiftData[i].shiftName)
// console.log( )
if(isNaN(this.allShiftData[i].shiftName)==false){

  if(this.allShiftData[i].shiftCategory==1){
    this.allShiftName.push({"shiftName":Number(this.allShiftData[i].shiftName),"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'MID'})
  }
  else if(this.allShiftData[i].shiftCategory==2){
    this.allShiftName.push({"shiftName":Number(this.allShiftData[i].shiftName),"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'EVE'})
  }
  else if(this.allShiftData[i].shiftCategory==3){
    this.allShiftName.push({"shiftName":Number(this.allShiftData[i].shiftName),"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'DAY'})
  }
  else if(this.allShiftData[i].shiftCategory==4){
    this.allShiftName.push({"shiftName":Number(this.allShiftData[i].shiftName),"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'M/D'})
  }
  else if(this.allShiftData[i].shiftCategory==5){
    this.allShiftName.push({"shiftName":Number(this.allShiftData[i].shiftName),"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'D/E'})
  }
  else if(this.allShiftData[i].shiftCategory==6){
    this.allShiftName.push({"shiftName":Number(this.allShiftData[i].shiftName),"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'E/M'})
  }

}else{
  if(this.allShiftData[i].shiftCategory==1){
    this.allShiftName.push({"shiftName":this.allShiftData[i].shiftName,"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'MID'})
  }
  else if(this.allShiftData[i].shiftCategory==2){
    this.allShiftName.push({"shiftName":this.allShiftData[i].shiftName,"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'EVE'})
  }
  else if(this.allShiftData[i].shiftCategory==3){
    this.allShiftName.push({"shiftName":this.allShiftData[i].shiftName,"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'DAY'})
  }
  else if(this.allShiftData[i].shiftCategory==4){
    this.allShiftName.push({"shiftName":this.allShiftData[i].shiftName,"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'M/D'})
  }
  else if(this.allShiftData[i].shiftCategory==5){
    this.allShiftName.push({"shiftName":this.allShiftData[i].shiftName,"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'D/E'})
  }
  else if(this.allShiftData[i].shiftCategory==6){
    this.allShiftName.push({"shiftName":this.allShiftData[i].shiftName,"shiftCategory":this.allShiftData[i].shiftCategory,"shift_StartTime":this.allShiftData[i].startTime,"shift_category_name":'E/M'})
  }

}
// console.log(this.allShiftName)
}
const test=[]

for(var j = 0;j<this.tempScheduleDataStored.length;j++){
  for(var i=0;i<this.allShiftName.length;i++){
  if(this.allShiftName[i].shiftName==this.tempScheduleDataStored[j]){
    // console.log(this.allShiftName[i].shift_StartTime)
    this.temp =this.allShiftName[i].shift_StartTime
  }else if(this.tempScheduleDataStored[j]=='X'){
    // console.log('X')
    this.temp='X'
  }
}
test.push(this.temp)
}


this.shift_line={
  "shift_line": test,
    "shift_length":8
}

this.busniessRulesValidation.businessRulesCheck(this.shift_line).subscribe(
  async (response)=>{
    this.valid=response['business_rules']
    // console.log(this.valid)
},
(error: any)=>{this.errorMsg=error;console.log(this.errorMsg)},
async () => {
}
);

// console.log(this.allShiftName)
    this.scheduleShiftLine=JSON.parse(localStorage.getItem('editCustomizedScheduleShiftLine'))
    // this.scheduleShiftLine=this.scheduleShiftLine[this.schedule_id]
    // this.data2=JSON.parse(localStorage.getItem('workData'))
    // this.workLoadData=this.data2.required
    // console.log(this.workLoadData)
// console.log(this.scheduleData.Pattern[1])
this.WED=this.scheduleData.Wed
 this.editScheduleDataForm = this.formBuilder.group({
  id:[this.scheduleData.seq_id],
  Mon: [this.da1[2]],
  Tue:[this.da1[3]],
  Wed: [this.da1[4]],
  Thu: [this.da1[5]],
  Fri: [this.da1[6]],
  Sat: [this.da1[7]],
  Sun: [this.da1[1]],
  Pattern:[this.da1[8]],
  BMLRule: [this.valid],
  SL:[this.scheduleData.SL]

 })
 return  this.wDataOne,this.wDataTwo,this.wDataThree,this.wDataFour,this.wDataFive,this.wDataSix,this.wDataSeven,this.wDataEight,this.wDataNine,this.wDataTen,this.wDataEleven,this.wDataElevenNight, this.wDataTwelve

  }


 businessRuleValidation(){

  this.tempScheduleDataStored = [this.Sun.value,this.Mon.value,this.Tue.value,this.Wed.value,this.Thu.value,this.Fri.value,this.Sat.value];
  this.work_Pattern=''
 for(var j=0;j<this.tempScheduleDataStored.length;j++){
   for(var k=0;k<this.allShiftName.length;k++){
     if(this.tempScheduleDataStored[j]==this.allShiftName[k].shiftName){
       // console.log(this.allShiftName[j].shiftName,this.allShiftName[j].shiftCategory)
       this.work_Pattern=this.work_Pattern+this.allShiftName[k].shiftCategory
      //  console.log(this.work_Pattern)
     }
   }
   // console.log(this.allShiftName[j].shiftName)
 }

 //  for(var i=0;i<this.tempScheduleDataStored.length;i++){
 //   // console.log(this.tempScheduleDataStored[i])

 //   if(this.tempScheduleDataStored[i]==='X'){
 //     this.work_Pattern=this.work_Pattern+'X'
 //   }else if(this.tempScheduleDataStored[i]==='1'||this.tempScheduleDataStored[i]===1){
 //     // console.log(this.tempScheduleDataStored[i])
 //     this.work_Pattern=this.work_Pattern+'D'
 //   }
 //   else if(this.tempScheduleDataStored[i]==='2'||this.tempScheduleDataStored[i]===2){
 //     // console.log(this.tempScheduleDataStored[i])
 //     this.work_Pattern=this.work_Pattern+'E'
 //   }
 //   else if(this.tempScheduleDataStored[i]==='3' ||this.tempScheduleDataStored[i]===3){
 //     // console.log(this.tempScheduleDataStored[i])
 //     this.work_Pattern=this.work_Pattern+'M'
 //   }
 //  }
 //  console.log(this.work_Pattern)
 var right_text = this.work_Pattern.substring(7, this.work_Pattern.indexOf("X"),this.work_Pattern.indexOf("X"));
  var left_text = this.work_Pattern.substring(0, this.work_Pattern.indexOf("X"),this.work_Pattern.indexOf("X"));
  this.convertStringToCharLeft=Array.from(left_text)
  // console.log(right_text)
  // console.log(left_text)
  this.convertStringToCharRight=Array.from(right_text)
 //  console.log(this.work_Pattern)
 //  console.log(this.convertStringToCharRight,this.convertStringToCharLeft)
 this.patternRight=''
 this.patternLeft=''
 for(var i=0;i<this.convertStringToCharRight.length;i++){
   if(this.convertStringToCharRight[i]!=='X'){
     this.patternRight=this.patternRight+this.convertStringToCharRight[i]
   }
 }
 for(var i=0;i<this.convertStringToCharLeft.length;i++){
   if(this.convertStringToCharLeft[i]!=='X'){
     this.patternLeft=this.patternLeft+this.convertStringToCharLeft[i]
   }
 }
 this.work_Pattern=this.patternRight+this.patternLeft
 this.workPattern=''
 this.convertStringToCharLeft=Array.from(this.work_Pattern)
 for(var i=0;i<this.convertStringToCharLeft.length;i++){
   if(this.convertStringToCharLeft[i]=='1'||this.convertStringToCharLeft[i]==1){
     this.workPattern=this.workPattern+'M'
   }
   else if(this.convertStringToCharLeft[i]=='2'||this.convertStringToCharLeft[i]==2){
     this.workPattern=this.workPattern+'E'
   }
   else if(this.convertStringToCharLeft[i]=='3'||this.convertStringToCharLeft[i]==3){
     this.workPattern=this.workPattern+'D'
   }
   else if(this.convertStringToCharLeft[i]=='4'||this.convertStringToCharLeft[i]==4){
    this.workPattern=this.workPattern+'S'
  }
  else if(this.convertStringToCharLeft[i]=='5'||this.convertStringToCharLeft[i]==5){
    this.workPattern=this.workPattern+'S'
  }else if(this.convertStringToCharLeft[i]=='6'||this.convertStringToCharLeft[i]==6){
    this.workPattern=this.workPattern+'S'
  }

 }
 this.work_Pattern=this.workPattern






this.scheduleData.Pattern=this.work_Pattern

const test=[]

  for(var j = 0;j<this.tempScheduleDataStored.length;j++){
    for(var i=0;i<this.allShiftName.length;i++){
    if(this.allShiftName[i].shiftName==this.tempScheduleDataStored[j]){
      // console.log(this.allShiftName[i].shift_StartTime)
      this.temp =this.allShiftName[i].shift_StartTime
    }else if(this.tempScheduleDataStored[j]=='X'){
      // console.log('X')
      this.temp='X'
    }
  }
  test.push(this.temp)
}


this.shift_line={
  "shift_line": test,
    "shift_length":8
}

this.busniessRulesValidation.businessRulesCheck(this.shift_line).subscribe(
  async (response)=>{
    this.valid=response['business_rules']
    // console.log(this.valid)
},
(error: any)=>{this.errorMsg=error;console.log(this.errorMsg)},
async () => {
}
);


//  let countValueOfX=0
//     let countValueOfM=0

//       if(this.Sun.value ===  "M" && this.Mon.value === "6" ){
//         this.gapBetweenshift=false
//       }
//       else if(this.Mon.value ===  "M" && this.Tue.value === "6" ){
//         this.gapBetweenshift=false
//       }
//       else if(this.Tue.value ===  "M" && this.Wed.value === "6" ){
//         this.gapBetweenshift=false
//       }
//       else if(this.Wed.value ===  "M" && this.Thu.value === "6" ){
//         this.gapBetweenshift=false
//       }
//       else if(this.Thu.value ===  "M" && this.Fri.value === "6" ){
//         this.gapBetweenshift=false
//       }
//       else if(this.Fri.value ===  "M" && this.Sat.value === "6" ){
//         this.gapBetweenshift=false
//       }
//       else if(this.Sat.value ===  "M" && this.Sun.value === "6" ){
//         this.gapBetweenshift=false
//       }
//       else{
//         this.gapBetweenshift=true
//       }
//     for(let i=0;i<=this.tempScheduleDataStored.length;i++){
//       if(this.tempScheduleDataStored[i]=="X")
//       {
//         countValueOfX=countValueOfX+1

//       }
//       else if(this.tempScheduleDataStored[i]=="M"){
//         countValueOfM=countValueOfM+1
//       }
//     }
//     // console.log(countValueOfX,countValueOfM)

//     if(countValueOfX>2 || this.gapBetweenshift ==false){
//        this.valid =false
//     }else{
//        this.valid =true
//     }
//      return this.valid
}
get Mon(){
  return this.editScheduleDataForm.get('Mon')
}

get Tue(){
  return this.editScheduleDataForm.get('Tue')
}
get Wed(){
  return this.editScheduleDataForm.get('Wed')
}
get Thu(){
  return this.editScheduleDataForm.get('Thu')
}
get Fri(){
  return this.editScheduleDataForm.get('Fri')
}
get Sat(){
  return this.editScheduleDataForm.get('Sat')
}
get Sun(){
  return this.editScheduleDataForm.get('Sun')
}
get BMRule(){
  return this.editScheduleDataForm.get('BMRule')
}
get Pattern(){
  return this.editScheduleDataForm.get('Pattern')
}


  update(index){
    // console.log(this.Sun.value);
    this.editData=this.editScheduleDataForm.value
    this.editData.BMLRule=this.valid
if(isNaN(this.editData.Sun)==false){
  this.editData.Sun=Number(this.editData.Sun)
}else{
  this.editData.Sun=this.editData.Sun
}
if(isNaN(this.editData.Mon)==false){
  this.editData.Mon=Number(this.editData.Mon)
}else{
  this.editData.Mon=this.editData.Mon
}
if(isNaN(this.editData.Tue)==false){
  this.editData.Tue=Number(this.editData.Tue)
}else{
  this.editData.Tue=this.editData.Tue
}
if(isNaN(this.editData.Wed)==false){
  this.editData.Wed=Number(this.editData.Wed)
}else{
  this.editData.Wed=this.editData.Wed
}
if(isNaN(this.editData.Thu)==false){
  this.editData.Thu=Number(this.editData.Thu)
}else{
  this.editData.Thu=this.editData.Thu
}
if(isNaN(this.editData.Fri)==false){
  this.editData.Fri=Number(this.editData.Fri)
}else{
  this.editData.Fri=this.editData.Fri
}
if(isNaN(this.editData.Sat)==false){
  this.editData.Sat=Number(this.editData.Sat)
}else{
  this.editData.Sat=this.editData.Sat
}

console.log(this.editData)
this.finalResultShiftLine=[]
        var ob,tempArr=[]
    // for(var i=0;i<selectScheduleData.length;i++){
      ob={
        "areaid": this.scheduleData.areaid,
          "Fri":this.editData.Fri,
          "id":this.scheduleData.id,
          "Mon":this.editData.Mon,
          "Sat": this.editData.Sat,
          "schedulename": this.scheduleData.schedulename,
          "seq_id":this.scheduleData.seq_id,
          "SL": this.scheduleData.SL,
          "Sun": this.editData.Sun,
          "Thu": this.editData.Thu,
          "Tue": this.editData.Tue,
          "userid": this.scheduleData.userid,
          "Wed":this.editData.Wed,
          "Pattern":this.editData.Pattern,
        "BMLRule":this.editData.BMLRule
      }
      console.log(ob)
      for(var i=0;i<this.scheduleShiftLine.length;i++)
        {
          if(this.scheduleShiftLine[i]?.id!=ob.id)
          {
            this.finalResultShiftLine.push(this.scheduleShiftLine[i])
          }
          else{
            this.finalResultShiftLine.push(ob)
          }
        }
  // this.resultShiftLine =Object.assign(this.finalResultShiftLine,this.editData)
    console.log(this.finalResultShiftLine)
  //   var current_customized_schedule=JSON.parse(localStorage.getItem('customizedScheduleShiftLine'))
  //   var temp_schedule,after_edit=[]

    // for(var i=0;i<current_customized_schedule.length;i++){
    //   if(i==Number(this.schedule_id)){
    //     temp_schedule=this.finalResultShiftLine
    //   }else{
    //     temp_schedule=current_customized_schedule[i]
    //   }
    //   after_edit.push(temp_schedule)
    // }
            // localStorage.removeItem('editCustomizedScheduleShiftLine')
            localStorage.setItem('editCustomizedScheduleShiftLine',JSON.stringify(this.finalResultShiftLine))
            // location.reload()

        // localStorage.removeItem('customizedScheduleShiftLine')
        // localStorage.setItem('focusShiftLine',JSON.stringify({"shift_line":this.editData,"schedule_id":this.schedule_id}))
        // localStorage.setItem('customizedScheduleShiftLine',JSON.stringify(this.finalResultShiftLine))
        localStorage.setItem('hideBLrulesLabels',JSON.stringify({"hideBLrulesLabels":true}))

              this.modalCtrl.dismiss();
                  location.reload()
          // this.modalCtrl.dismiss();
  }
  dismiss() {
    this.modalCtrl.dismiss();
  }
  async BusinessRulesPdf(){
// window.open(this.pdfSrc)
// this.navCtrl.navigateForward(['business-rules-pdf'])
    this.showHideText = !this.showHideText;
    // const modal = await this.modalCtrl.create({
    //   component:BusinessRulesPdfPage,
    //   // componentProps:{ BusinessRulesPdfPage},
    //   cssClass: 'BL',
    //   swipeToClose:true
    //   // componentProps: { scheduleData: scheduleShift }

    // });
    // this.scheduleShift=EditScheduleDataPage.data5
    // console.log(this.scheduleShift)
    // return await modal.present();

  }


  reset(){
    // console.log(this.da)
    this.scheduleData.Pattern=this.da[8]
    this.editScheduleDataForm = this.formBuilder.group({
      id:[this.scheduleData.id],
      Mon: [this.da1[2]],
      Tue:[this.da1[3]],
      Wed: [this.da1[4]],
      Thu: [this.da1[5]],
      Fri: [this.da1[6]],
      Sat: [this.da1[7]],
      Sun: [this.da1[1]],
      Pattern:[this.scheduleData.Pattern],
      BMLRule: [this.valid],
      SL:[this.scheduleData.SL]

    })
  }
  // static sayHello(user: string): any {
  //   // console.log( EditScheduleDataPage.urlArray);
  //   EditScheduleDataPage.urlArray=this.urlArray="false"
  //   console.log(EditScheduleDataPage.urlArray)
  //   return "Hello " + user+ "!";
  //   //throw new Error('Method not implemented.');
  // }

     sayHello(user: string): any {
    // console.log( EditScheduleDataPage.urlArray);

    // console.log(EditScheduleDataPage.urlArray)
    return "Hello "
    //throw new Error('Method not implemented.');
  }
}
export function someFunction(){

}
// export function  sayHello(user){
//   return "Hello " + user+ "!";
// }












