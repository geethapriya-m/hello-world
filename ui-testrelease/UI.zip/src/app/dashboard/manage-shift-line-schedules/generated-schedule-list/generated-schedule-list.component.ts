import { Component, OnInit } from '@angular/core';
import { HeaderTitleService } from '../../nav-bar-footer/header-title.service';
import straightlines_io_apis from 'src/app/json/apis.json';
import { AlertController, NavController } from '@ionic/angular';
import { GeneratedScheduleService } from 'src/app/services/schedule/generated-schedule.service';
import Swal from 'sweetalert2';
import workloadData from 'src/app/json/work-load-data.json';
import { WorkLoadService } from 'src/app/services/work-load.service';
import { BidScheduleService } from 'src/app/services/manage-bid-schedule/bid-schedule/bid-schedule.service';
@Component({
  selector: 'app-generated-schedule-list',
  templateUrl: './generated-schedule-list.component.html',
  styleUrls: ['./generated-schedule-list.component.scss'],
})
export class GeneratedScheduleListComponent implements OnInit {
all_schedule=[]
allShiftData=[]
allShift=[]
  user_data: any;
  all_Schedule=[];
  default_work_load_data=workloadData
  work_load_data=[]
  errorMsg: any;
  userDefinedShift=[]
  reqShift: any[];
  all_shift: any[];
  convertTimetoString=[];
  arrangeShiftdefintionL: any[];
  arrangeShiftdefintionG: any[];
  all_bid_schedule
  bid_schedule=[]
  usedScheduleInBidSchedule=[]
  allScheduleName: any[];
  constructor(public navCtrl: NavController,
    public alertCtrl: AlertController,
    private scheduleService:GeneratedScheduleService,
    private headerTitleService: HeaderTitleService,
    private bidSer:BidScheduleService,
    public shiftDefSer:WorkLoadService
  ) { }

  ngOnInit() {
    this.headerTitleService.setTitle('Manage Shiftline Schedules');
    this.headerTitleService.setDefaultHeader(true)
    this.headerTitleService.setBackUrl(straightlines_io_apis.apis.dashboard);
    this.headerTitleService.setForwardUrl(straightlines_io_apis.apis.enter_Work_load_api);
    this.allShiftData=  JSON.parse(localStorage.getItem('allShiftRequiredData'))

    this.user_data=JSON.parse(localStorage.getItem('userData'))
    // for(var i=0;i<this.saveSchedule.length;i++){
    //   tempObj={
    //       "seq_id": this.saveSchedule[i].id,
    //       "mon": this.saveSchedule[i].Mon,
    //       "tue": this.saveSchedule[i].Tue,
    //       "wed": this.saveSchedule[i].Wed,
    //       "thu": this.saveSchedule[i].Thu,
    //       "fri": this.saveSchedule[i].Fri,
    //       "sat": this.saveSchedule[i].Sat,
    //       "sun": this.saveSchedule[i].Sun,
    //       "schedulename": this.scheduleNameForm.value.schedule_name,
    //       "shiftname": this.saveSchedule[i].SL,
    //       "areaid": 4,
    //       "userid": this.user_data.id
    //   }
    //   tempArr.push(tempObj)
    // }
    // console.log(tempArr)
this.getSchedule()
this.getUserDefinedShift()
this.getAllBidSchedule()
// console.log("test")
  }
  getSchedule(){
    var tempObj={}
    var tempArr=[]
    var all_shift_data=[]
    for(var i=0;i<this.allShiftData.length;i++){

  all_shift_data.push({
  "id": this.allShiftData[i].id,
  "shiftCategory": this.allShiftData[i].shiftCategory,
  "shiftName": this.allShiftData[i].shiftName,
  "startTime": this.allShiftData[i].startTime})
}
    this.scheduleService.getAllSchedule().subscribe((res)=>{
      for(var i=0;i<res.length;i++){
        if(Number(this.user_data.id)===Number(res[i].userid)){

          tempArr.push(res[i])
        }
      }
      // console.log(tempArr)
      var getAllScheduleName=[]
      for(var i=0;i<tempArr.length;i++){
        for(var j=0;j<tempArr.length;j++){
          if(getAllScheduleName[i]!==tempArr[j].schedulename){
            getAllScheduleName.push(tempArr[j].schedulename)

          }
        }
      }var unique = getAllScheduleName.filter(this.onlyUnique);

var tempArray=[],finalData=[]
var ob
      for(var i=0;i<unique.length;i++){
        tempArray=[]
        for(var j=0;j<tempArr.length;j++){
          if(tempArr[j].schedulename===unique[i]){
            tempArray.push(tempArr[j])
          }
        }
        ob={"schedule_name":unique[i],"customizedScheduleShiftLine":tempArray,"defaultScheduleShiftLine":tempArray,"allShiftRequiredData":all_shift_data}
        finalData.push(ob)

      }
      this.all_Schedule=[]
      for(var i=0;i<finalData.length;i++){
      if(this.all_Schedule==null){
          this.all_Schedule.push(finalData[i])
        }
        else{
          this.all_Schedule.push(finalData[i])
        }
      }

      this.all_schedule=this.all_Schedule
      // localStorage.setItem('allSchedule',JSON.stringify(this.all_schedule))
      return this.all_schedule

    },(error)=>{
      console.log(error)
    },()=>{
    })
  }
   onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
  }

  addNewSchedule(){
    this.navCtrl.navigateForward([straightlines_io_apis.apis.enter_Work_load_api])
  }
  async removeSchedule(index){
    var count=0
for(var i=0;i<this.allScheduleName.length;i++){
  if(this.allScheduleName[i]==index.schedule_name){
    count++

  }
}
if(count<1){
    const confirm = await this.alertCtrl.create({
      header: 'Are you sure?',
      message: 'Are you sure you want to delete the record?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
          }
        },
        {
          text: 'Delete',
          role: 'delete',
          handler: () => {
            this.scheduleService.deleteScheduleBasedOnName(index.schedule_name).subscribe(
              async (res)=>{console.log(res)

                // this.scheduleService.deleteSaveShiftDefintionDataBasedOnScheduleName(index.schedule_name).subscribe(
                //   async (res)=>{console.log(res)

                    this.ngOnInit()
                const confirm = await this.alertCtrl.create({
                    header: '"Success',
                    message: '"Successfully deleted"',
                    buttons: [
                      {
                        text: 'OK',
                        role: 'cancel',
                        handler: () => {

                        }
                      }]})
                      await confirm.present();
              },async (err)=>{

                Swal.fire({
                  title: 'Error!',
                  html: 'Please try again later!',
                  icon: 'error',
                  showCancelButton: false,
                  confirmButtonColor:'#FF0000',
                  imageHeight:'250px',
                  heightAuto:false,
                }).then((result) => {
                })

                console.log(err)
              },()=>{

              }
            )

          }
        }]
        })
        await confirm.present();
      }else{
        // console.log(count)
        const confirm = await this.alertCtrl.create({
          header: 'Alert',
          message: "Can't delete the Shiftline Schedule because it is included in a Bid Schedule.",
          buttons: [
            {
              text: 'Cancel',
              role: 'cancel',
              handler: () => {
                // console.log('Confirm Cancel');
              }
            }
          ]
        })
        await confirm.present();
      }
  }
  show(showSchedule){

    var selectScheduleData=showSchedule.customizedScheduleShiftLine
    // console.log(selectScheduleData)
    // console.log(showSchedule)
    var ob,tempArr=[],tempAllShiftAlias=[]
    for(var i=0;i<selectScheduleData.length;i++){
      ob={
        "areaid": selectScheduleData[i].areaid,
          "Fri":selectScheduleData[i].fri,
          "id":selectScheduleData[i].id,
          "Mon": selectScheduleData[i].mon,
          "Sat": selectScheduleData[i].sat,
          "schedulename": selectScheduleData[i].schedulename,
          "seq_id":selectScheduleData[i].seq_id,
          "SL": selectScheduleData[i].shiftname,
          "Sun": selectScheduleData[i].sun,
          "Thu": selectScheduleData[i].thu,
          "Tue": selectScheduleData[i].tue,
          "userid": selectScheduleData[i].userid,
          "Wed": selectScheduleData[i].wed,
          "Pattern":selectScheduleData[i].pattern
      }
      tempAllShiftAlias.push(ob.Sun,ob.Mon,ob.Tue,ob.Wed,ob.Thu,ob.Fri,ob.Sat)

      tempArr.push(ob)
    }
    var unique = tempAllShiftAlias.filter((v, i, a) => a.indexOf(v) === i);
//     console.log(unique)
// console.log(tempArr)
this.reqShift=[]

// console.log(this.all_shift)
// console.log(this.all_shift.length)
for(var i=0;i<this.all_shift.length;i++){
  for(var j=0;j<unique.length;j++){
    if(String(this.all_shift[i].shiftName)===String(unique[j])){
      // console.log(this.all_shift[i],unique[j])
      this.reqShift.push(this.all_shift[i])
    }
  }
}
this.arrangeShiftdefintionG=[]
this.arrangeShiftdefintionL=[]
for(var i=0;i<this.reqShift.length;i++){
    if(Number(this.reqShift[i].startTime)>2200){
this.arrangeShiftdefintionG.push(this.reqShift[i])
    }else if(Number(this.reqShift[i].startTime)<=2200){
      this.arrangeShiftdefintionL.push(this.reqShift[i])
    }
  }
  this.arrangeShiftdefintionG.sort((a,b) => a.startTime.localeCompare(b.startTime));
  this.arrangeShiftdefintionL.sort((a,b) => a.startTime.localeCompare(b.startTime));
  // console.log(this.arrangeShiftdefintionG)
  // console.log(this.arrangeShiftdefintionL)
 var finalArr=[]
  for(var i=0;i<this.arrangeShiftdefintionG.length;i++){
    finalArr.push(this.arrangeShiftdefintionG[i])
  }
  for(var i=0;i<this.arrangeShiftdefintionL.length;i++){
    finalArr.push(this.arrangeShiftdefintionL[i])
  }

      localStorage.setItem('editCustomizedScheduleShiftLine',JSON.stringify(tempArr))
      localStorage.setItem('editDefaultScheduleShiftLine',JSON.stringify(tempArr))
      localStorage.setItem('allShiftRequiredDataForEditSchedule',JSON.stringify(finalArr))
      localStorage.setItem('focusShiftLine',JSON.stringify(''))
        this.navCtrl.navigateForward([straightlines_io_apis.apis.edit_schedule_api+'/'+showSchedule.schedule_name])
  }
  getShiftDefintion(scheduleName){
    // console.log(scheduleName)
    this.scheduleService.getSaveShiftDefintionDataBasedOnScheduleName(scheduleName).subscribe((res)=>{
      console.log(res)
    },(err)=>{console.log(err)},()=>{})
  }

  getUserDefinedShift(){
    this.userDefinedShift=[]
    this.shiftDefSer.getAllShiftDefinition(this.user_data.id).subscribe(
      (res)=>{
        this.allShift=res;

        // console.log(this.allShift)
        for(var i=0;i<this.allShift.length;i++){
          if(Number(this.allShift[i].userid)==Number(this.user_data.id)){
            this.userDefinedShift.push(this.allShift[i])
          }
        }
        // return this.userDefinedShift
        var user_shift=this.userDefinedShift
          // console.log(user_shift.length)
          for(var i=0;i<this.default_work_load_data.length;i++){
            this.work_load_data.push(this.default_work_load_data[i])
          }
          // console.log(this.work_load_data)
          var allShift=[]
          for(var i=0;i<this.work_load_data.length;i++){
            allShift.push({
              "id": this.work_load_data[i].id,
              "shiftCategory": this.work_load_data[i].shiftCategory,
              "shiftName": this.work_load_data[i].shiftName,
              "startTime": this.work_load_data[i].startTime})
          }
          // console.log(user_shift)
          if(user_shift.length>0){
            for(var i=0;i<this.userDefinedShift.length;i++){
              this.convertTimetoString=Array.from(this.userDefinedShift[i].sh_starttime)
              var sh_startTime=this.convertTimetoString[0]+this.convertTimetoString[1]+this.convertTimetoString[3]+this.convertTimetoString[4]
              allShift.push({
                "id": this.userDefinedShift[i].sh_id,
                "shiftCategory": this.userDefinedShift[i].sh_category_id,
                "shiftName": this.userDefinedShift[i].sh_name,
                "startTime": sh_startTime})
            }
          }
          // console.log(allShift)
          this.all_shift=[]
          this.all_shift=allShift
      },
    (error: any)=>{this.errorMsg=error
    console.log(this.errorMsg)
    for(var i=0;i<this.default_work_load_data.length;i++){
      this.work_load_data.push(this.default_work_load_data[i])
    }
    var allShift=[]
    for(var i=0;i<this.work_load_data.length;i++){
      allShift.push({
        "id": this.work_load_data[i].id,
        "shiftCategory": this.work_load_data[i].shiftCategory,
        "shiftName": this.work_load_data[i].shiftName,
        "startTime": this.work_load_data[i].startTime})
    }
    this.all_shift=allShift
},
    ()=>{

    }
    );

  }


  getAllBidSchedule(){
    this.bidSer.getAllBidSchedule(this.user_data.id).subscribe((res)=>{
      // this.bid_schedule=this.multiDimensionalUnique(res);
      this.bid_schedule=res
      this.all_bid_schedule=this.bid_schedule
      var tempArr=[]

      if(this.bid_schedule!==null){
          for(var i=0;i<this.bid_schedule.length;i++){
            tempArr.push(this.bid_schedule[i].schedulename)
          }
        }
        var unique = tempArr.filter((v, i, a) => a.indexOf(v) === i);
        this.allScheduleName=[]
        this.allScheduleName=unique
     },(err)=>{
       console.log(err)
     },()=>{})
  }
}
