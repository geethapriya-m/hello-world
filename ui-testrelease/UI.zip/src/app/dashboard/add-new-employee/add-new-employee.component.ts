import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { NavController, AlertController } from '@ionic/angular';
import { EmailValidationService } from 'src/app/services/email-validation.service';
import { AddNewEmployeeService } from 'src/app/services/manage-bid-schedule/add-new-employee/add-new-employee.service';
import { QualificationService } from 'src/app/services/manage-bid-schedule/qualification/qualification.service';
import { RoleService } from 'src/app/services/manage-bid-schedule/role/role.service';
import { PhoneVerificationService } from 'src/app/services/phone-verification/phone-verification.service';
import { RegistrationService } from 'src/app/services/registration.service';
import Swal from 'sweetalert2';
import { HeaderTitleService } from '../nav-bar-footer/header-title.service';
import straightlines_io_apis from 'src/app/json/apis.json';
@Component({
  selector: 'app-add-new-employee',
  templateUrl: './add-new-employee.component.html',
  styleUrls: ['./add-new-employee.component.scss'],
})
export class AddNewEmployeeComponent implements OnInit {
all_role
  addNewEmpForm: FormGroup;
  errorMsg: any;
emailValid
phoneValid
hidePassword=true
hideConfirmPassword=true
classId=0
confirmClassId=0
  emailMessage: any;
  phoneMessage: any;
  all_qualification
  user_data: any;
  checkInitial=false;
constructor(public navCtrl: NavController,
    private fb:FormBuilder,
    private addNewEmp:AddNewEmployeeService,
    public alertCtrl: AlertController,
    private register:RegistrationService,
    private headerTitleService: HeaderTitleService,
    private PV:PhoneVerificationService,
    private role_name:RoleService,
    public alertController: AlertController,
    private qualifiaction_name:QualificationService,
    private EV:EmailValidationService) { }

  ngOnInit() {
    // this.headerTitleService.setTitle('Add New Employee');
    // this.headerTitleService.setDefaultHeader(false)
    // this.headerTitleService.setBackUrl(straightlines_io_apis.apis.setUp_bid_parameters);
    // this.headerTitleService.setForwardUrl(null);
    this.user_data=JSON.parse(localStorage.getItem('userData'))
    this.allRole()
    this.allQualification()
    this.addNewEmpForm = this.fb.group({

      // phone:new FormControl('',Validators.compose([Validators.required,Validators.minLength(10),Validators.maxLength(10)])),
      firstname:new FormControl('',Validators.compose([Validators.required,Validators.minLength(2),Validators.maxLength(128)])),
      lastname:new FormControl('',Validators.compose([Validators.required,Validators.minLength(2),Validators.maxLength(128)])),
      qualification:new FormControl('Fully Qualified',Validators.compose([Validators.required])),
      employee_initial:new FormControl('',Validators.compose([Validators.required,Validators.minLength(2), Validators.pattern('^[_A-Za-z0-9]*$')])),
      role:new FormControl('Employee',Validators.compose([Validators.required])),
      rank:new FormControl('',Validators.compose([Validators.required,Validators.min(1), Validators.pattern('^[0-9]*$')])),
      email:new FormControl('',Validators.compose([Validators.required,Validators.pattern('^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$'),Validators.minLength(6)])),
      vacationLeaveNumber: new FormControl('',Validators.compose([Validators.required, Validators.min(1), Validators.pattern('^[0-9]*$')]))

    })
  }
allRole(){
  this.role_name.getAllRole().subscribe(
     (response)=>{
      // console.log(response)
      this.all_role=response
    // return this.all_role
    },
    (err)=>{console.log(err)},()=>{
      // this.ngOnInit()
      // console.log(this.all_role)
      this.addEmpForm()
    })
}
allQualification(){
  this.qualifiaction_name.getAllQualification().subscribe(
    (res)=>{this.all_qualification=res},
    (err)=>{console.log(err)},()=>{
      // this.ngOnInit()
      // console.log(this.all_role)
      this.addEmpForm()
    })
}
addEmpForm(){

}
  get firstname(){
    return this.addNewEmpForm.get('firstname')
  }

  get lastname(){
   return this.addNewEmpForm.get('lastname')
 }

 get email(){
   return this.addNewEmpForm.get('email')
 }

 get role(){
   return this.addNewEmpForm.get('role')
 }

 get qualification(){
   return this.addNewEmpForm.get('qualification')
 }
 get employee_initial(){
  return this.addNewEmpForm.get('employee_initial')
}
get rank(){
  return this.addNewEmpForm.get('rank')
}
 get vacationLeaveNumber(){
   return this.addNewEmpForm.get('vacationLeaveNumber')
 }
  async onSubmit(data){
    // console.log(data)
    // console.log(this.addNewEmpForm.value)
    var new_emp={

      "fname":this.addNewEmpForm.value.firstname,
      "lname":this.addNewEmpForm.value.lastname,
      "initials":this.addNewEmpForm.value.employee_initial,
      "rank":Number(this.addNewEmpForm.value.rank),
      "phone":"",
      "email":this.addNewEmpForm.value.email,
      "qualification":this.addNewEmpForm.value.qualification,
      "role":this.addNewEmpForm.value.role,
      "userid":this.user_data.id,
      "vacation":this.addNewEmpForm.value.vacationLeaveNumber
    }
    // console.log(new_emp)
    this.addNewEmp.addNewEmployee(new_emp).subscribe(
      async (response)=>{
       console.log(response)

    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      message: 'Do you want to add more Employees?',
      buttons: [
        {
          text: 'No',
          handler: () => {
            this.navCtrl.navigateForward([straightlines_io_apis.apis.setUp_bid_parameters])
          }
        }, {
          text: 'Yes',
          role: 'cancel',
          handler: () => {

          }
        }
      ]
    });

    await alert.present();
       this.addNewEmpForm.reset()
     },
     (err)=>{console.log(err)},()=>{
     })
  }
  checkInitialName(){
    var initial=this.addNewEmpForm.value.employee_initial
    this.addNewEmp.checkDuplicateInitialName(initial).subscribe(
      (response)=>{
       console.log(response)
       if(String(response)=='Initials Exist')
       {this.checkInitial=true}
       else{
        this.checkInitial=false
       }
     // return this.all_role
     },
     (err)=>{console.log(err)},()=>{
       // this.ngOnInit()
     })
  }
  initialName(){
    this.checkInitial=false
  }
}
