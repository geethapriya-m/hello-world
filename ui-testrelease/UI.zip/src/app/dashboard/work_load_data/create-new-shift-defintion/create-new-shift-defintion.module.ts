import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CreateNewShiftDefintionPageRoutingModule } from './create-new-shift-defintion-routing.module';

import { CreateNewShiftDefintionPage } from './create-new-shift-defintion.page';
import { FooterPageModule } from 'src/app/dashboard/nav-bar-footer/footer/footer.module';
import { NavBarPageModule } from 'src/app/dashboard/nav-bar-footer/nav-bar/nav-bar.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FooterPageModule,
    NavBarPageModule,
    CreateNewShiftDefintionPageRoutingModule
  ],
  declarations: [CreateNewShiftDefintionPage]
})
export class CreateNewShiftDefintionPageModule {}
