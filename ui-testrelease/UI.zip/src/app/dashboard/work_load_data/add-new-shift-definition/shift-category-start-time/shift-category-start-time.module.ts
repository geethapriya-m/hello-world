import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ShiftCategoryStartTimePageRoutingModule } from './shift-category-start-time-routing.module';

import { ShiftCategoryStartTimePage } from './shift-category-start-time.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ShiftCategoryStartTimePageRoutingModule
  ],
  declarations: [ShiftCategoryStartTimePage]
})
export class ShiftCategoryStartTimePageModule {}
