import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ShiftCategoryInfoPageRoutingModule } from './shift-category-info-routing.module';

import { ShiftCategoryInfoPage } from './shift-category-info.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ShiftCategoryInfoPageRoutingModule
  ],
  declarations: [ShiftCategoryInfoPage]
})
export class ShiftCategoryInfoPageModule {}
