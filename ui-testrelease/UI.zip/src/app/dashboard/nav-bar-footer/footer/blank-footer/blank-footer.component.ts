import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blank-footer',
  templateUrl: './blank-footer.component.html',
  styleUrls: ['./blank-footer.component.scss'],
})
export class BlankFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
