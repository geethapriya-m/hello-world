import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-module',
  templateUrl: './footer.page.html',
  styleUrls: ['./footer.page.scss'],
})
export class FooterPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
