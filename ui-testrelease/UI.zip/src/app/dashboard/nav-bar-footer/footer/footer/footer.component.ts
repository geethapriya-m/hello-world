import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import straightlines_io_apis from 'src/app/json/apis.json';
@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
})
export class FooterComponent implements OnInit {

  constructor(public navCtrl: NavController,) { }

  ngOnInit() {}
  logOut(){
    localStorage.removeItem('token')
    this.navCtrl.navigateBack(straightlines_io_apis.apis.login_api)
  }
  home(){
    this.navCtrl.navigateBack([straightlines_io_apis.apis.dashboard])
  }
}
