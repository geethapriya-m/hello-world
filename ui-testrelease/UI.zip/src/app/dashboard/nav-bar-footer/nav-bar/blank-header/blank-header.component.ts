import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { HeaderTitleService } from '../../header-title.service';
import straightlines_io_apis from 'src/app/json/apis.json';
@Component({
  selector: 'app-blank-header',
  templateUrl: './blank-header.component.html',
  styleUrls: ['./blank-header.component.scss'],
})
export class BlankHeaderComponent implements OnInit {
title
goBackUrl
hideGoBack
hideForward
forwardUrl
defaultHeader
  constructor( public navCtrl: NavController,
    private headerTitleService: HeaderTitleService,) { }

  ngOnInit() {
    this.headerTitleService.title.subscribe(title => {
      this.title = title;
    });

    this.headerTitleService.goBackUrl.subscribe(goBackUrl => {
      this.goBackUrl = goBackUrl;

      this.checkGoBackUrl(this.goBackUrl )
    });
    this.headerTitleService.forwardUrl.subscribe(forwardUrl => {
      this.forwardUrl = forwardUrl;

      this.checkForward(this.forwardUrl)
    });

    this.headerTitleService.defaultHeader.subscribe(dh=>{
      this.defaultHeader=dh
    })

  }
  checkForward(fUrl){
    this.forwardUrl=fUrl
    if(this.forwardUrl!=null){
      if(this.forwardUrl==straightlines_io_apis.apis.generated_schedule_api || this.forwardUrl==straightlines_io_apis.apis.generated_schedule){
        if(JSON.parse(localStorage.getItem('customizedScheduleShiftLine'))==null){
          this.hideForward=true
        }else{
          this.hideForward=false
        }
      }
    }else{
      this.hideForward=true
    }
  }
  checkGoBackUrl(goBackUrl ){

    this.goBackUrl=goBackUrl

    if(this.goBackUrl!=null){

      this.hideGoBack=false

    }else {
      this.hideGoBack=true

    }

  }
  goBack(){
    // localStorage.clear()
    this.navCtrl.navigateBack(this.goBackUrl)
    // this.route.navigateByUrl('home')
  }
  forwardOldGeneratedShiftLines(){
    this.navCtrl.navigateForward(this.forwardUrl)
  }
}
