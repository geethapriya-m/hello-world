import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AlertController, NavController } from '@ionic/angular';
import { HeaderTitleService } from 'src/app/dashboard/nav-bar-footer/header-title.service';
import { SetUpBidParametersService } from '../../manage-bid-schedule/set-up-bid-parameters/service/set-up-bid-parameters.service';
import straightlines_io_apis from 'src/app/json/apis.json';
import { MyBiddingService } from '../my-bidding.service';
import { BidScheduleService } from 'src/app/services/manage-bid-schedule/bid-schedule/bid-schedule.service';
import { BidLeaveSetupService } from 'src/app/services/manage-bid-schedule/bid-schedule/bid-leave-setup.service';
import { SetupBidRoundService } from 'src/app/services/manage-bid-schedule/bid-schedule/setup-bid-round.service';

@Component({
  selector: 'app-my-bidding-step-one-shift-line',
  templateUrl: './my-bidding-step-one-shift-line.component.html',
  styleUrls: ['./my-bidding-step-one-shift-line.component.scss'],
})
export class MyBiddingStepOneShiftLineComponent implements OnInit {
all_shift_lines=[]
customPopoverOptions: any = {
 cssClass:'custom-popover'
};
all_SBP_rounds=[]
user_data
bid_schedule=[]
bid_scheduleName=[]
years=[]
all_employee=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','P','Q','R']
selectShiftLineForm
schedule_id: number=0;
step_form_name
empName="VP"
  selectYearForm: FormGroup;
  selectBidScheduleNameForm: FormGroup;
  start_date: any;
  end_date: any;
  all_bid_schedule: any[];
  currentSelectedRound: any;
  roundStartTime: any;
  roundStartDate: any;
  roundDuration: any;
  roundStatus: any;
  showPopUp: any;
  bidding_status=0;
  constructor(
    public navCtrl: NavController,
    public formBuilder: FormBuilder,
    private cdref: ChangeDetectorRef,
    public alertCtrl: AlertController,
    private bidSer:BidScheduleService,
    private bidLeaveSer:BidLeaveSetupService,
    private bidRoundSer:SetupBidRoundService,
    private setUPbidRoundSer:SetupBidRoundService,
    private headerTitleService: HeaderTitleService,
    private myBiddingSer:MyBiddingService,
    private fb:FormBuilder
  ) { }

  ngOnInit() {
    this.headerTitleService.setTitle('My Bidding');
    this.headerTitleService.setDefaultHeader(false)
    this.headerTitleService.setBackUrl(straightlines_io_apis.apis.dashboard);
    this.headerTitleService.setForwardUrl(null);
    this.myBiddingSer.setTitle('step-1')
    this.user_data=JSON.parse(localStorage.getItem('userData'))
    this.getAllBidSchedule()

    this.selectShiftLineForm = this.formBuilder.group({
      allShiftLine: this.formBuilder.array([]) ,
  });
  this.selectYearForm = this.formBuilder.group({
    year:new FormControl("select year"),
  })
  this.selectBidScheduleNameForm = this.formBuilder.group({
    bid_schedule_name:new FormControl("select bid schedule name"),
  })
  }

  get allShiftLine() : FormArray {
    return this.selectShiftLineForm.get("allShiftLine") as FormArray
   }
   get year(){
    return  this.selectYearForm.get("year")
    }
    get bid_schedule_name(){
      return  this.selectBidScheduleNameForm.get("bid_schedule_name")
      }
   newWorkLoadData(): FormGroup {
    return this.formBuilder.group({
      selectShiftLine:new FormControl(),
      id:new FormControl(),
      shiftline:new FormControl(),
      emp:new FormControl(),
    })

  }

    next(){

      var temp={
        "bid_schedule_name":this.selectBidScheduleNameForm.value,
        "bid_round_data":this.currentSelectedRound

      }
      localStorage.setItem('myBiddingData',JSON.stringify(temp))
      localStorage.setItem('selectShiftLineForBidding',JSON.stringify(0))
      this.navCtrl.navigateForward([straightlines_io_apis.apis.selet_shift_line_bidding])
    }
    updateShiftLine(index){
      // if((<FormArray>this.selectShiftLineForm.controls['allShiftLine']).at(index).value.selectShiftLine==true){
      //   (<FormArray>this.selectShiftLineForm.controls['allShiftLine']).at(index).setValue({"selectShiftLine":true,"id":(<FormArray>this.selectShiftLineForm.controls['allShiftLine']).at(index).value.id,"shiftline":(<FormArray>this.selectShiftLineForm.controls['allShiftLine']).at(index).value.shiftline,"emp":this.empName});
      // }else{
      //   (<FormArray>this.selectShiftLineForm.controls['allShiftLine']).at(index).setValue({"selectShiftLine":false,"id":(<FormArray>this.selectShiftLineForm.controls['allShiftLine']).at(index).value.id,"shiftline":(<FormArray>this.selectShiftLineForm.controls['allShiftLine']).at(index).value.shiftline,"emp":""});
      // }
    }

  checkStatus(){
    var sName=this.selectBidScheduleNameForm.value.bid_schedule_name
    console.log(sName)
    var today,biddingStartDate
    for(var i=0;i<this.all_bid_schedule.length;i++){
      if(this.all_bid_schedule[i].bid_schedule_name==sName){
        var start =this.all_bid_schedule[i].shiftLineSchedulestartDate.split("-");
        today = new Date();
        biddingStartDate = new Date(start[0],Number(start[1])+ - +1, start[2],0 ,0, 0);
        if(today<biddingStartDate){
          this.bidding_status=0
        }else if(today>biddingStartDate){
          this.bidding_status=1
        }else{
          this.bidding_status=2
        }
      }
    }
  }

  changeBidScheduleNameForm(){
    console.log(this.selectBidScheduleNameForm.value)
    this.checkStatus()
    this.allBidRounds()
  }

  getAllBidSchedule(){
    this.bidSer.getAllBidSchedule(this.user_data.id).subscribe((res)=>{

      this.bid_schedule=this.multiDimensionalUnique(res);
      this.all_bid_schedule=this.bid_schedule
      var temp
      // console.log(this.all_bid_schedule)
      if(this.all_bid_schedule.length>0){
        this.selectBidScheduleNameForm.controls.bid_schedule_name.setValue(this.all_bid_schedule[0].bid_schedule_name)
        this.checkStatus()
        this.allBidRounds()
      }

      if(this.bid_schedule!==null){
      for(var i=0;i<this.bid_schedule.length;i++){
        temp=new Date(this.bid_schedule[i].schedule_start_date).getFullYear()
        this.years.push(temp)

      }
      this.years.sort()
      this.years= this.years.filter((y, index) => {
        return this.years.indexOf(y) === index;
    });}
      },(err)=>{
        console.log(err)
      },()=>{})
  }
  multiDimensionalUnique(arr) {
    var uniques = [];
    var itemsFound = {};
    for(var i = 0, l = arr.length; i < l; i++) {
        var stringified = JSON.stringify(arr[i]);
        if(itemsFound[stringified]) { continue; }
        uniques.push(arr[i]);
        itemsFound[stringified] = true;
    }
    var tempArr=[]
    for(var i=0;i<uniques.length;i++){
      var startDate=new Date(uniques[i].bidstartdate)
      startDate.setDate(startDate.getDate() + 1);
      var endDate=new Date(uniques[i].bidscheduleenddate)
      endDate.setDate(endDate.getDate() + 1);
      var finalObj={'bid_schedule_name':uniques[i].bidschedulename,'shiftLineSchedulestartDate':uniques[i].bidschedulestartdate,'schedule_start_date':uniques[i].bidstartdate,'schedule_end_date':endDate,'setUpBidParameter':uniques[i].paramsavestatus,'leaveSetUp':uniques[i].leavesavestatus,'bidRound':uniques[i].roundsavestatus}
      tempArr.push(finalObj)
    }
    var dates=[],tempFinalArr=[]
    for(var i=0;i<tempArr.length;i++){
      var dates=[]
      for(var j=0;j<tempArr.length;j++){
        if(tempArr[i].bid_schedule_name==tempArr[j].bid_schedule_name){
          dates.push(new Date(tempArr[j].schedule_end_date))
          var maxDate=new Date(Math.max.apply(null,dates));
        }
      }
      if(uniques[i].roundsavestatus==1 && uniques[i].leavesavestatus==1 && uniques[i].paramsavestatus==1)
      tempFinalArr.push({'bid_schedule_name':uniques[i].bidschedulename,'shiftLineSchedulestartDate':uniques[i].bidstartdate,'schedule_start_date':uniques[i].bidschedulestartdate,'schedule_end_date':maxDate,'setUpBidParameter':uniques[i].paramsavestatus,'leaveSetUp':uniques[i].leavesavestatus,'bidRound':uniques[i].roundsavestatus})
    }
    var finalArr=tempFinalArr.filter((v,i,a)=>a.findIndex(t=>(t.bid_schedule_name === v.bid_schedule_name))===i)
    return finalArr;
  }
  allBidRounds(){
    this.setUPbidRoundSer.getAllBidRoundBasedOnBidScheduleName(this.selectBidScheduleNameForm.value.bid_schedule_name).subscribe(
      (res)=>{
        // console.log(res)
        this.all_SBP_rounds=[]
        for(var i=0;i<res.length;i++){
          var startTime=String(res[i].daily_starttime)
           var temp1=startTime.substring(0, startTime.indexOf(":"));
            // var min=startTime.split(':').pop().split(':')[0]
            var min= startTime.substring(
              startTime.indexOf(":") + 1,
              startTime.lastIndexOf(":")
          );
           if(Number(temp1)==24){
             var sTime='00:'+min+' AM'
           }else if(Number(temp1)>12){
             if((Number(temp1)+ - +12)<10){
              var sTime='0'+(Number(temp1)+ - +12)+':'+min+' PM'
             }else{
              var sTime=Number(temp1)+ - +12+':'+min+' PM'
             }

          }
          else if(Number(temp1)==12){
            var sTime='12:'+min+' PM'
          }
           else{
             sTime=temp1+':'+min+' AM'
           }
           //end Time
           var endTime=String(res[i].daily_endttime)
           var temp2=endTime.substring(0, endTime.indexOf(":"));
            var e_min=endTime.substring(
              endTime.indexOf(":") + 1,
              endTime.lastIndexOf(":")
          );
           if(Number(temp2)==24){
             var eTime='00:'+e_min+' AM'
           }else if(Number(temp2)>12){
             if((Number(temp2)+ - +12)<10){
              var eTime='0'+(Number(temp2)+ - +12)+':'+e_min+' PM'
             }else{
              var eTime=Number(temp2)+ - +12+':'+e_min+' PM'
             }

          }
          else if(Number(temp2)==12){
            var eTime='12:'+e_min+' PM'
          }
           else{
             eTime=temp2+':'+e_min+' AM'
           }
           var minDuration=String(res[i].bid_duration).substring(
            String(res[i].bid_duration).indexOf(":") + 1,
            String(res[i].bid_duration).lastIndexOf(":")
        );
          var  temp ={
            "bidroundid":res[i].bidroundid,
            "bidschedulenameref":res[i].bidroundid,
            "bidroundstartdate": res[i].bidroundstartdate,
            "bid_duration": minDuration,
            "bidroundenddate": res[i].bidroundenddate,
            "daily_starttime":sTime,
            "daily_endttime":eTime,
            "bidleavereason": res[i].bidleavereason,
            "useridref":res[i].useridref
          }
          this.all_SBP_rounds.push(temp)

        }
        // console.log(this.all_SBP_rounds)
        if(this.all_SBP_rounds.length>0){
          this.displayRoundData(this.all_SBP_rounds[0])

        }

      },
      (err)=>{
        console.log(err)
      },
      ()=>{}
    )
  }
  displayRoundData(all_SBP_rounds){
    this.currentSelectedRound=all_SBP_rounds
    var start =this.currentSelectedRound.bidroundstartdate.split("-");

    var start_Date = new Date(start[0],start[1], start[2],0 ,0, 0);
    this.roundStartTime= this.currentSelectedRound.daily_starttime
    this.roundStartDate=start_Date
    this.roundDuration=this.currentSelectedRound.bid_duration
    this.roundStatus="Open"

    // console.log(this.currentSelectedRound)
  }
  myFunction() {
    this.showPopUp
    var popup = document.getElementById("myPopup");
    popup.classList.toggle("show");
  }
}
