import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { HeaderTitleService } from 'src/app/dashboard/nav-bar-footer/header-title.service';
import { MyBiddingService } from '../my-bidding.service';
import straightlines_io_apis from 'src/app/json/apis.json';
import { AddNewEmployeeService } from 'src/app/services/manage-bid-schedule/add-new-employee/add-new-employee.service';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-view-seniority-list',
  templateUrl: './view-seniority-list.component.html',
  styleUrls: ['./view-seniority-list.component.scss'],
})
export class ViewSeniorityListComponent implements OnInit {
  user_data: any;
  allEmployee=[]

  done = ['Get up', 'Brush teeth', 'Take a shower', 'Check e-mail', 'Walk dog'];

  constructor(public navCtrl: NavController,
    private myBiddingSer:MyBiddingService,
    private cdref: ChangeDetectorRef,
    public formBuilder: FormBuilder,
    private getAllEmp:AddNewEmployeeService,
    private headerTitleService: HeaderTitleService) { }

  ngOnInit() {
    this.user_data=JSON.parse(localStorage.getItem('userData'))
    this.headerTitleService.setTitle('Seniority List');
    this.headerTitleService.setDefaultHeader(true)
    this.headerTitleService.setBackUrl(straightlines_io_apis.apis.my_bidding);
      this.headerTitleService.setForwardUrl(null);

      this.allEmp()
  }
  allEmp(){
    this.getAllEmp.getAllEmployeeBasedOnUserId(this.user_data.id).subscribe(
      (res)=>{this.allEmployee=res
      console.log(this.allEmployee)},
      (err)=>{console.log(err)},()=>{})
}
drop(event: CdkDragDrop<string[]>) {
  if (event.previousContainer === event.container) {
    moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
  } else {
    transferArrayItem(
      event.previousContainer.data,
      event.container.data,
      event.previousIndex,
      event.currentIndex,
    );
  }
  console.log(event)
  console.log(event.previousIndex)
  console.log(event.currentIndex)
  console.log(event.container.data)
  console.log(event.previousContainer.data)
      var temp=[],tempArr=[],tempRankOne,tempRank
      temp=event.container.data
      for(var i=0;i<temp.length;i++){
        if(temp[i].rank==event.previousIndex){
        console.log(temp[i])
        }
       if(temp[i].rank==event.currentIndex){

          console.log(temp[i])
          }
        var tempObj={"email": temp[i].email,
        "fname": temp[i].fname,
        "id": temp[i].id,
        "initials": temp[i].initials,
        "lname": temp[i].lname,
        "phone": temp[i].phone,
        "qualification": temp[i].qualification,
        "rank": temp[i].rank,
        "role": temp[i].role,
        "userid":temp[i].userid,
        "vacation": temp[i].vacation
        // }
      }
        tempArr.push(tempObj)
      }
      console.log(tempArr)
  }
}
