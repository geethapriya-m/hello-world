import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { HeaderTitleService } from 'src/app/dashboard/nav-bar-footer/header-title.service';
import straightlines_io_apis from 'src/app/json/apis.json';
import { MyBiddingService } from '../my-bidding.service';
@Component({
  selector: 'app-view-bid-shiftlines',
  templateUrl: './view-bid-shiftlines.component.html',
  styleUrls: ['./view-bid-shiftlines.component.scss'],
})
export class ViewBidShiftlinesComponent implements OnInit {
  all_shift_lines=[]
  start_date
  end_date
  customPopoverOptions: any = {
   cssClass:'custom-popover'
  };
  data=[{"bid_schedule":"Area4CBid0 Schedule","from":"6/1/2022" ,"to":"6/30/2022"},
  {"bid_schedule":"Area4CBid1 Schedule","from":"6/1/2022" ,"to":"6/30/2022"},
  {"bid_schedule":"Area4CBid2 Schedule","from":"08/01/2021" ,"to":"6/30/2021"},
  {"bid_schedule":"Area4CBid3 Schedule","from":"6/12/2021" ,"to":"6/30/2021"},
  {"bid_schedule":"Area4CBid4 Schedule","from":"6/1/2022" ,"to":"6/30/2022"},
  {"bid_schedule":"Area4CBid5 Schedule","from":"6/1/2021" ,"to":"6/30/2022"},
  {"bid_schedule":"Area4CBid6 Schedule","from":"6/1/2021" ,"to":"6/30/2021"},
  {"bid_schedule":"Area4CBid7 Schedule","from":"11/12/2021" ,"to":"6/30/2021"},
  {"bid_schedule":"Area4CBid8 Schedule","from":"6/1/2022" ,"to":"6/30/2022"},
  {"bid_schedule":"Area4CBid9 Schedule","from":"6/1/2022" ,"to":"6/30/2022"},
  {"bid_schedule":"Area4CBid10 Schedule","from":"1/2/2022" ,"to":"6/30/2022"}
  ]
  selectBidScheduleNameForm: any;
  bid_schedule=[];
  all_bid_schedule: any;
  bid_schedule_shifline_name: any;
  bid_schedule_length: number;
  default_bid_schedule_name: any;
  constructor(public navCtrl: NavController,
    private myBiddingSer:MyBiddingService,
    private cdref: ChangeDetectorRef,
    public formBuilder: FormBuilder,
    private headerTitleService: HeaderTitleService) { }

  ngOnInit() {
    this.headerTitleService.setTitle('View Bid Shiftlines');
    this.headerTitleService.setDefaultHeader(true)
    this.headerTitleService.setBackUrl(straightlines_io_apis.apis.my_bidding);
      this.headerTitleService.setForwardUrl(null);
      this.all_shift_lines=JSON.parse(localStorage.getItem('all_shift_line'))
      this.all_bid_schedule=JSON.parse(localStorage.getItem('all_bid_schedule'))
      if(this.all_bid_schedule!==null && this.all_shift_lines!==null){
        this.bid_schedule_length=this.bid_schedule.length
      console.log(this.all_bid_schedule)
      this.data=this.all_bid_schedule[0].all_shift_line
      this.all_shift_lines=this.data
      console.log(this.all_shift_lines)
      this.bid_schedule=this.all_bid_schedule
      console.log(this.bid_schedule)
      this.default_bid_schedule_name=this.bid_schedule[0].bid_schedule_name
      this.start_date=this.bid_schedule[0].schedule_start_date
      this.end_date=this.bid_schedule[0].schedule_end_date
      this.all_shift_lines=this.bid_schedule[0].all_shift_line
      this.bid_schedule_shifline_name=this.bid_schedule[0].schedule_name
    }else{
      this.start_date=''
      this.default_bid_schedule_name='select bid schedule name'
      this.end_date=''
      this.all_shift_lines=[]
      this.bid_schedule_shifline_name=''
    }
      this.selectBidScheduleNameForm = this.formBuilder.group({
        bid_schedule_name:new FormControl(this.default_bid_schedule_name),
      })

  }
  get bid_schedule_name(){
    return  this.selectBidScheduleNameForm.get("bid_schedule_name")
    }
    changeBidScheduleNameForm(){
      console.log(this.selectBidScheduleNameForm.value)
      for(var i=0;i<this.bid_schedule.length;i++){
        if(String(this.bid_schedule[i].bid_schedule_name)==String(this.selectBidScheduleNameForm.value.bid_schedule_name)){
          console.log(this.bid_schedule[i])
          this.start_date=this.bid_schedule[i].schedule_start_date
          this.end_date=this.bid_schedule[i].schedule_end_date
          this.all_shift_lines=this.bid_schedule[i].all_shift_line
          this.bid_schedule_shifline_name=this.bid_schedule[i].schedule_name
        }
      }
    }
}
