import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { HeaderTitleService } from 'src/app/dashboard/nav-bar-footer/header-title.service';
import { SetUpBidParametersService } from '../../manage-bid-schedule/set-up-bid-parameters/service/set-up-bid-parameters.service';
import straightlines_io_apis from 'src/app/json/apis.json';
import { MyBiddingService } from '../my-bidding.service';
import { SetupBidRoundService } from 'src/app/services/manage-bid-schedule/bid-schedule/setup-bid-round.service';
import { BidScheduleService } from 'src/app/services/manage-bid-schedule/bid-schedule/bid-schedule.service';
import { GeneratedScheduleService } from 'src/app/services/schedule/generated-schedule.service';

@Component({
  selector: 'app-select-shift-line-for-bidding',
  templateUrl: './select-shift-line-for-bidding.component.html',
  styleUrls: ['./select-shift-line-for-bidding.component.scss'],
})
export class SelectShiftLineForBiddingComponent implements OnInit {

  all_shift_lines=[]
  customPopoverOptions: any = {
   cssClass:'custom-popover'
  };
  checkShiftLineScheduleId=0
  bid_schedule=[]
  bid_scheduleName=[]
  years=[]
  all_employee=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','P','Q','R']
  selectShiftLineForm
  schedule_id: number=0;
  step_form_name
  empName="VP"
    selectYearForm: FormGroup;
    selectBidScheduleNameForm: FormGroup;
  selected_schedule_for_bidding: any;
  Start_Date: any;
  Window_Start: any;
  Window_Duration: any;
  Schedule_Name: any;
  all_bid_schedule: any;
  count_emp_select_shiftLine: number=0;
  all_SBP_rounds=[];
  allScheduleData: any[];
  all_final_data: any[];
  current_shift_line_schedule: any;
  current_shift_line_schedule_startDate: any;
  current_shift_line_schedule_endDate: any;
  all_selected_schedule_shift_lines: any[];
  expand_id: any;
    constructor(
      public navCtrl: NavController,
      public formBuilder: FormBuilder,
      private cdref: ChangeDetectorRef,
      private bidService:BidScheduleService,
      private headerTitleService: HeaderTitleService,
      private setUPbidRoundSer:SetupBidRoundService,
      private myBiddingSer:MyBiddingService,
      private fb:FormBuilder,
      private scheduleService:GeneratedScheduleService,
    ) { }

    ngOnInit() {
      this.headerTitleService.setTitle('My Bidding');
      this.headerTitleService.setDefaultHeader(false)
      this.headerTitleService.setBackUrl(straightlines_io_apis.apis.my_bidding);
      this.headerTitleService.setForwardUrl(null);
      // this.myBiddingSer.setTitle('step-1')
      this.checkShiftLineScheduleId= JSON.parse(localStorage.getItem('selectShiftLineForBidding'))

      console.log(this.checkShiftLineScheduleId)
      if(this.checkShiftLineScheduleId==null){
        this.checkShiftLineScheduleId=0
      }
      console.log(this.checkShiftLineScheduleId)
      this.selected_schedule_for_bidding=JSON.parse(localStorage.getItem('myBiddingData'))
      console.log(this.selected_schedule_for_bidding)
      this.allBidRounds()
      this.allShceduleBasedOnBidScheduleName()
      console.log(this.all_SBP_rounds)
    }

      checkCSS(name){
        if(name!=this.empName &&  name!=''){
          return 'deactivate'
        }else{
          return 'active'
        }
      }

      displayRoundData(data){
        console.log(data)
      }
      allBidRounds(){
        this.setUPbidRoundSer.getAllBidRoundBasedOnBidScheduleName(this.selected_schedule_for_bidding.bid_schedule_name.bid_schedule_name).subscribe(
          (res)=>{
            // console.log(res)
            this.all_SBP_rounds=[]
            for(var i=0;i<res.length;i++){
              var startTime=String(res[i].daily_starttime)
               var temp1=startTime.substring(0, startTime.indexOf(":"));
                // var min=startTime.split(':').pop().split(':')[0]
                var min= startTime.substring(
                  startTime.indexOf(":") + 1,
                  startTime.lastIndexOf(":")
              );
               if(Number(temp1)==24){
                 var sTime='00:'+min+' AM'
               }else if(Number(temp1)>12){
                 if((Number(temp1)+ - +12)<10){
                  var sTime='0'+(Number(temp1)+ - +12)+':'+min+' PM'
                 }else{
                  var sTime=Number(temp1)+ - +12+':'+min+' PM'
                 }

              }
              else if(Number(temp1)==12){
                var sTime='12:'+min+' PM'
              }
               else{
                 sTime=temp1+':'+min+' AM'
               }
               //end Time
               var endTime=String(res[i].daily_endttime)
               var temp2=endTime.substring(0, endTime.indexOf(":"));
                var e_min=endTime.substring(
                  endTime.indexOf(":") + 1,
                  endTime.lastIndexOf(":")
              );
               if(Number(temp2)==24){
                 var eTime='00:'+e_min+' AM'
               }else if(Number(temp2)>12){
                 if((Number(temp2)+ - +12)<10){
                  var eTime='0'+(Number(temp2)+ - +12)+':'+e_min+' PM'
                 }else{
                  var eTime=Number(temp2)+ - +12+':'+e_min+' PM'
                 }

              }
              else if(Number(temp2)==12){
                var eTime='12:'+e_min+' PM'
              }
               else{
                 eTime=temp2+':'+e_min+' AM'
               }
               var minDuration=String(res[i].bid_duration).substring(
                String(res[i].bid_duration).indexOf(":") + 1,
                String(res[i].bid_duration).lastIndexOf(":")
            );
              var  temp ={
                "bidroundid":res[i].bidroundid,
                "bidschedulenameref":res[i].bidroundid,
                "bidroundstartdate": res[i].bidroundstartdate,
                "bid_duration": minDuration,
                "bidroundenddate": res[i].bidroundenddate,
                "daily_starttime":sTime,
                "daily_endttime":eTime,
                "bidleavereason": res[i].bidleavereason,
                "useridref":res[i].useridref
              }
              this.all_SBP_rounds.push(temp)

            }
            console.log(this.all_SBP_rounds)

          },
          (err)=>{
            console.log(err)
          },
          ()=>{}
        )
      }
      allShceduleBasedOnBidScheduleName(){
        var b_schedule_name=this.selected_schedule_for_bidding.bid_schedule_name.bid_schedule_name
        if(b_schedule_name!==''){
          this.bidService.getScheduleNameBasedOnBidScheduleName(b_schedule_name).subscribe(
            (res)=>{
              this.allScheduleData=[]
              this.allScheduleData=res
              this.multiDimensionalUnique(res)
          },
          (err)=>{console.log(err)},
          ()=>{})}
      }
      multiDimensionalUnique(data) {
        var resArr = [];
        data.filter(function(item){
          var i = resArr.findIndex(x => (x.bidschedulename == item.bidschedulename && x.schedulename == item.schedulename && x.bidschedulestartdate == item.bidschedulestartdate&& x.bidscheduleenddate == item.bidscheduleenddate&& x.bidstartdate == item.bidstartdate));
          if(i <= -1){
                resArr.push(item);
          }
          return null;
        });
        this.all_final_data=resArr
        if(this.all_final_data.length>0){

          localStorage.setItem('selectShiftLineForBidding',JSON.stringify(this.checkShiftLineScheduleId))
          this.currentShiftLineSchedule(this.all_final_data[this.checkShiftLineScheduleId])
        }

      }
      currentShiftLineSchedule(shiftLineScheduleData){
        this.current_shift_line_schedule=shiftLineScheduleData.schedulename
        var start =shiftLineScheduleData.bidschedulestartdate.split("-");
        var start_Date = new Date(start[0],start[1], start[2],0 ,0, 0);
        var end =shiftLineScheduleData.bidscheduleenddate.split("-");
        var end_Date = new Date(end[0],end[1], end[2],0 , 0, 0);
        this.current_shift_line_schedule_startDate=start_Date
        this.current_shift_line_schedule_endDate=end_Date
        console.log(this.current_shift_line_schedule)
        this.scheduleService.getSaveShiftDefintionDataBasedOnScheduleName(this.current_shift_line_schedule).subscribe((res)=>{

          var tempArr=[]
          tempArr=res
          console.log(tempArr)
          this.all_selected_schedule_shift_lines=[]
          var temp
          for(var i=0;i<tempArr.length;i++){
              temp={
                "id":tempArr[i].id,
                "sun":tempArr[i].sun,
                "mon":tempArr[i].mon,
                "tue":tempArr[i].tue,
                "wed":tempArr[i].wed,
                "thu":tempArr[i].thu,
                "fri":tempArr[i].fri,
                "sat":tempArr[i].sat,
                "pattern":tempArr[i].pattern,
                "shiftname":tempArr[i].shiftname,
                "seq_id":tempArr[i].seq_id,
                "selectedBy":''
              }
              this.all_selected_schedule_shift_lines.push(temp)
          }
console.log(this.all_selected_schedule_shift_lines)
        },(err)=>{console.log(err)},()=>{})
      }
      expand(index){
        if(this.expand_id==index){
          this.expand_id=null
        }else{
          this.expand_id=index
        }
      }
      expandlist(i){
        if(this.expand_id==i){
          return 'expand'
        }else{
          return 'default-expand'
        }
      }
      selectShiftLine(selectedShiftLine,index){
        console.log(selectedShiftLine)
        var tempArr=[]
        tempArr=this.all_selected_schedule_shift_lines
        this.all_selected_schedule_shift_lines=[]
        var temp
        for(var i=0;i<tempArr.length;i++){
          if(selectedShiftLine.id===tempArr[i].id){
            temp={
              "id":tempArr[i].id,
              "sun":tempArr[i].sun,
              "mon":tempArr[i].mon,
              "tue":tempArr[i].tue,
              "wed":tempArr[i].wed,
              "thu":tempArr[i].thu,
              "fri":tempArr[i].fri,
              "sat":tempArr[i].sat,
              "pattern":tempArr[i].pattern,
              "shiftname":tempArr[i].shiftname,
              "seq_id":tempArr[i].seq_id,
              "selectedBy":this.empName
            }
          }else{
            temp={
              "id":tempArr[i].id,
              "sun":tempArr[i].sun,
              "mon":tempArr[i].mon,
              "tue":tempArr[i].tue,
              "wed":tempArr[i].wed,
              "thu":tempArr[i].thu,
              "fri":tempArr[i].fri,
              "sat":tempArr[i].sat,
              "pattern":tempArr[i].pattern,
              "shiftname":tempArr[i].shiftname,
              "seq_id":tempArr[i].seq_id,
              "selectedBy":''
            }
          }
            this.all_selected_schedule_shift_lines.push(temp)
        }
        this.expand(index)
      }
      next(){
        console.log(this.all_final_data )
        console.log(this.all_final_data.length)
        console.log(this.checkShiftLineScheduleId)
        var tempArr= JSON.parse(localStorage.getItem('userSelectedShiftLine'))
        console.log(tempArr)
        var tempObj,temp,arr=[]
        for(var i=0;i<this.all_selected_schedule_shift_lines.length;i++){
          if(this.all_selected_schedule_shift_lines[i].selectedBy===this.empName){
            temp=this.all_selected_schedule_shift_lines[i]
          }
        }
        console.log(tempArr)
        if(tempArr==null){
          tempObj={
            "scheduleName":this.current_shift_line_schedule,"selectedShiftLine":temp
          }
          arr.push(tempObj)
          localStorage.setItem('userSelectedShiftLine',JSON.stringify(arr))
        }else{
          tempObj={
            "scheduleName":this.current_shift_line_schedule,"selectedShiftLine":temp
          }
          tempArr.push(tempObj)
          localStorage.setItem('userSelectedShiftLine',JSON.stringify(tempArr))
        }

        this.checkShiftLineScheduleId++
        console.log(this.checkShiftLineScheduleId)
        if(this.checkShiftLineScheduleId<this.all_final_data.length){
          localStorage.setItem('selectShiftLineForBidding',JSON.stringify(this.checkShiftLineScheduleId))
          this.ngOnInit()
        }else{
          // this.checkShiftLineScheduleId--
          // localStorage.setItem('selectShiftLineForBidding',JSON.stringify(this.checkShiftLineScheduleId))
          this.navCtrl.navigateBack(straightlines_io_apis.apis.my_bidding)
        }

      }
  }
