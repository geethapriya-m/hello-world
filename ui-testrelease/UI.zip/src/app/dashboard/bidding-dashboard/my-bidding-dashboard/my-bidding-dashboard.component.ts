import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { AlertController, NavController } from '@ionic/angular';
import { HeaderTitleService } from '../../nav-bar-footer/header-title.service';
import straightlines_io_apis from 'src/app/json/apis.json';
import { MyBiddingService } from './my-bidding.service';
import { BidScheduleService } from 'src/app/services/manage-bid-schedule/bid-schedule/bid-schedule.service';
@Component({
  selector: 'app-my-bidding-dashboard',
  templateUrl: './my-bidding-dashboard.component.html',
  styleUrls: ['./my-bidding-dashboard.component.scss'],
})
export class MyBiddingDashboardComponent implements OnInit {
  schedule_id: number=0;
  step_form_name
  user_data: any;
  constructor(public navCtrl: NavController,
    private myBiddingSer:MyBiddingService,
    public alertCtrl: AlertController,
    public alertController: AlertController,
    private cdref: ChangeDetectorRef,
    private bidSer:BidScheduleService,
    private headerTitleService: HeaderTitleService) { }

  ngOnInit() {
    this.headerTitleService.setTitle('My Bidding');
    this.headerTitleService.setDefaultHeader(true)
    this.headerTitleService.setBackUrl(straightlines_io_apis.apis.dashboard);
      this.headerTitleService.setForwardUrl(null);
      this.user_data=JSON.parse(localStorage.getItem('userData'))
      this.myBiddingSer.title.subscribe(title => {
        this.step_form_name = title;
        if(this.step_form_name=='step-1'){
          this.getColor()
        }
        if(this.step_form_name=='step-2'){
          this.getIndicatorClassOne()
        }
        if(this.step_form_name=='step-3'){
          this.getIndicatorClass()
        }
      });

      }
      ngAfterContentChecked() {
        this.cdref.detectChanges();
      }
      getColor(){
        return 'active ';
      }

      getIndicatorClassOne(){

           if(this.step_form_name=='step-2'){
            return 'active ';

          }
          else if(this.step_form_name=='step-3'){
            return 'active';
          }
          return'small'
      }
      getIndicatorClass(){
        if(this.step_form_name=='step-3'){
          return this.getIndicatorClassOne();
        }
        return'small'
    }
    myBidding(){
      this.navCtrl.navigateBack([straightlines_io_apis.apis.my_bidding])
    }
    viewBidShiftlines(){
      this.navCtrl.navigateForward([straightlines_io_apis.apis.view_bid_schedule])
    }
    viewSeniorityList(){
      this.navCtrl.navigateForward([straightlines_io_apis.apis.view_seniority_list])
    }
    manageBidSchedule(){
      this.bidSer.getAllBidSchedule(this.user_data.id).subscribe((res)=>{
        console.log(res.length)
        if(res.length<1 || res==null || res==undefined){
          this.navCtrl.navigateForward([straightlines_io_apis.apis.setUp_bid_parameters])
        }else{
          this.navCtrl.navigateForward([straightlines_io_apis.apis.manage_bid_schedule])
        }


       },async (err)=>{
         console.log(err)
         const alert = await this.alertController.create({
          cssClass: 'my-custom-class',
          header: 'Error',

          message: 'Please try again later.',
          buttons: ['Ok']
        });

        await alert.present();


       },()=>{})

    }
    calTest(){
      this.navCtrl.navigateForward([straightlines_io_apis.apis.cal_test])
    }
    calTest2(){
      this.navCtrl.navigateForward([straightlines_io_apis.apis.cal_test_one])
    }
}
