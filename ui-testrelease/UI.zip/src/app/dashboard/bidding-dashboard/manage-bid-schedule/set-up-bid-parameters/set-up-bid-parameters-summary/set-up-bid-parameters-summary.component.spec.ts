import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { SetUpBidParametersSummaryComponent } from './set-up-bid-parameters-summary.component';

describe('SetUpBidParametersSummaryComponent', () => {
  let component: SetUpBidParametersSummaryComponent;
  let fixture: ComponentFixture<SetUpBidParametersSummaryComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ SetUpBidParametersSummaryComponent ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SetUpBidParametersSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
