import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { SetUpBidParametersSectionTwoComponent } from './set-up-bid-parameters-section-two.component';

describe('SetUpBidParametersSectionTwoComponent', () => {
  let component: SetUpBidParametersSectionTwoComponent;
  let fixture: ComponentFixture<SetUpBidParametersSectionTwoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ SetUpBidParametersSectionTwoComponent ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SetUpBidParametersSectionTwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
