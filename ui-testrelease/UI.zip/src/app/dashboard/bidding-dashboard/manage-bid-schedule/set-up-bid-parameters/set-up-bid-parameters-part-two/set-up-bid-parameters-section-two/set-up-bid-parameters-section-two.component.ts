import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AlertController, NavController } from '@ionic/angular';
import { HeaderTitleService } from 'src/app/dashboard/nav-bar-footer/header-title.service';
import straightlines_io_apis from 'src/app/json/apis.json';
import { BidLeaveSetupService } from 'src/app/services/manage-bid-schedule/bid-schedule/bid-leave-setup.service';
import { BidScheduleService } from 'src/app/services/manage-bid-schedule/bid-schedule/bid-schedule.service';
import { PassBidScheduleNameService } from 'src/app/services/manage-bid-schedule/pass-bid-schedule-name.service';
import { SetUpBidParametersService } from '../../service/set-up-bid-parameters.service';

@Component({
  selector: 'app-set-up-bid-parameters-section-two',
  templateUrl: './set-up-bid-parameters-section-two.component.html',
  styleUrls: ['./set-up-bid-parameters-section-two.component.scss'],
})
export class SetUpBidParametersSectionTwoComponent implements OnInit {
  setUpBidParametersForm: FormGroup;
  select_shiftline_schedule=['Trimester1_Shiftline Schedule','Trimester2_Shiftline Schedule','Trimester3_Shiftline Schedule']
  select_qualification=['CPC','CPC1']
  select_employees=[{"employee_shortname":"MK","employee_name":"Mike Klupenger"},
  {"employee_shortname":"SS","employee_name":"Sushma Sharma"},
  {"employee_shortname":"RA","employee_name":"Ritu Arora"}]
 all_slots=[]
 ptl_periods
  currentBidScheduleName: any;
  allNptl_data=[];
  nptl_periods: any;
  user_data: any;
  constructor(
    public navCtrl: NavController,
    private headerTitleService: HeaderTitleService,
    private sbpHeaderService:SetUpBidParametersService,
    private bidLeaveSetupSer:BidLeaveSetupService,
    public alertController: AlertController,
    private bidSer:BidScheduleService,
    private curBidScheduleNameSer:PassBidScheduleNameService,
    private fb:FormBuilder
  ) { }

  ngOnInit() {

    this.headerTitleService.setTitle('Manage Bid Parameters');
    this.headerTitleService.setDefaultHeader(false)
    this.headerTitleService.setBackUrl(straightlines_io_apis.apis.setUp_bid_parameters_step_2);
    this.headerTitleService.setForwardUrl(null);

    this.sbpHeaderService.setTitle('step-2')
    this.user_data=JSON.parse(localStorage.getItem('userData'))
    this.all_slots=JSON.parse(localStorage.getItem('all_nptl_periods'))

    if(this.all_slots==null){
      this.ptl_periods=0

    }else{
      this.ptl_periods=this.all_slots.length
    }
    this.curBidScheduleNameSer.currentBidScheduleName.subscribe(bidScheduleName=>{
      this.currentBidScheduleName=bidScheduleName
    } )

    // this.currentBidScheduleName='B4'
    // this.getAllNPTLData()
    this.getAllNPTLDataBasedOnBidScheduleName()
    // console.log(this.currentBidScheduleName)
    this.setUpBidParametersForm = this.fb.group({
      SBP_start_date:new FormControl('',Validators.compose([Validators.required])),
      SBP_end_date:new FormControl('',Validators.compose([Validators.required])),
      SBP_remain_slots:new FormControl('',Validators.compose([Validators.required])),
      SBP_slots:new FormControl(''),
    })
  }

  get SBP_start_date(){
    return this.setUpBidParametersForm.get('SBP_start_date')
  }
  get SBP_end_date(){
    return this.setUpBidParametersForm.get('SBP_end_date')
  }
  get SBP_slots(){
    return this.setUpBidParametersForm.get('SBP_slots')
  }
  get SBP_remain_slots(){
    return this.setUpBidParametersForm.get('SBP_remain_slots')
  }
  getAllNPTLData(){
    this.bidLeaveSetupSer.getAllBidNptlLeave().subscribe(
      (res)=>{console.log(res)
        console.log(res)

      },
      (err)=>{console.log(err)},
      ()=>{},
    )
  }
getAllNPTLDataBasedOnBidScheduleName(){
console.log(this.currentBidScheduleName)
  this.bidLeaveSetupSer.getAllBidNptlLeaveBasedOnBSName(this.currentBidScheduleName).subscribe(
    (res)=>{console.log(res)

    // this.all_slots=res
    // this.ptl_periods=this.all_slots.length
    this.allNptl_data=res
    this.nptl_periods=this.allNptl_data.length
    },
    (err)=>{console.log(err)},
    ()=>{},
  )
  }
  scheduleShiftLine(){
    console.log(this.setUpBidParametersForm.value)
  }
  async submit(data){

    // console.log()
    var start_date=this.formatDate(this.setUpBidParametersForm.value.SBP_start_date)
    var end_date=this.formatDate(this.setUpBidParametersForm.value.SBP_end_date)

    // var new_ptl_periods={"id":this.all_slots.length+ + +1, "start_date":start_date,"end_date":end_date,"PTL_slots":this.setUpBidParametersForm.value.SBP_slots}
    // console.log(new_ptl_periods)


    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      // header: 'Confirm!',
      message: 'Do you want to add another NPTL (Non-Prime Time Leave) ?',
      buttons: [
        {
          text: 'No',

          // cssClass: 'secondary',
          handler: (blah) => {
            this.curBidScheduleNameSer.changeBidScheduleName( this.currentBidScheduleName )
            this.navCtrl.navigateForward([straightlines_io_apis.apis.setUp_bid_parameters_step_3])
          }
        }, {
          text: 'Yes',
          role: 'cancel',
          handler: () => {

          }
        }
      ]
    });

    await alert.present();
  }
  formatDate(date) {
    var d = new Date(date),

        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();
    if (month.length < 2){
        month = '0' + month;
    }
    if (day.length < 2)
    {
        day = '0' + day;
      }
    return [month,day,year].join('/');
}
  add(data){
    console.log(this.setUpBidParametersForm.value)
    // this.ngOnInit()
    var start_date=new Date(this.setUpBidParametersForm.value.SBP_start_date)
    var end_date=new Date(this.setUpBidParametersForm.value.SBP_end_date)

    var new_nptl_periods={"nptlstartdate":start_date,"nptlenddate":end_date,"nptlslots":this.setUpBidParametersForm.value.SBP_slots,"remaindayslot":this.setUpBidParametersForm.value.SBP_remain_slots,"bidschedulenameref":this.currentBidScheduleName,"useridref":this.user_data.id}
    // this.all_slots.push(new_ptl_periods)
console.log(new_nptl_periods)
this.bidLeaveSetupSer.addNewBidNptlLeave(new_nptl_periods).subscribe((res)=>{
  console.log(res)
  // this.ngOnInit()
  this.ngOnInit()
},(err)=>{
  console.log(err)
},()=>{})
    // localStorage.setItem('all_slots',JSON.stringify(this.all_slots))

  }
}
