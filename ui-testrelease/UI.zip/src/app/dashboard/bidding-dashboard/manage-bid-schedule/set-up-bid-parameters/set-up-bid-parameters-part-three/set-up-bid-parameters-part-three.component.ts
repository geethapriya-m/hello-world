import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { HeaderTitleService } from 'src/app/dashboard/nav-bar-footer/header-title.service';
import { SetUpBidParametersService } from '../service/set-up-bid-parameters.service';
import straightlines_io_apis from 'src/app/json/apis.json';
import { AlertController, NavController } from '@ionic/angular';
import { BidLeaveSetupService } from 'src/app/services/manage-bid-schedule/bid-schedule/bid-leave-setup.service';
import { PassBidScheduleNameService } from 'src/app/services/manage-bid-schedule/pass-bid-schedule-name.service';
import { SetupBidRoundService } from 'src/app/services/manage-bid-schedule/bid-schedule/setup-bid-round.service';
import { duration } from 'moment';
import { BidScheduleService } from 'src/app/services/manage-bid-schedule/bid-schedule/bid-schedule.service';
import { GeneratedScheduleService } from 'src/app/services/schedule/generated-schedule.service';
@Component({
  selector: 'app-set-up-bid-parameters-part-three',
  templateUrl: './set-up-bid-parameters-part-three.component.html',
  styleUrls: ['./set-up-bid-parameters-part-three.component.scss'],
})
export class SetUpBidParametersPartThreeComponent implements OnInit {
  setUpBidParametersForm: any;
  start_date
  start_time
  end_date
  dateValidation=false
  end_time
  tempArr=[]
  end: string;
  start: string;
  bid_duration
  total_SBP_rounds
  totalEmp=31
  minDateForBidRound=new Date(2021, 10, 4);
  leave_selection_list=['2 weeks NC','2 weeks C','5 days (1 Week) in 7','Up to 10 days NC','1 week','1 day']
  all_SBP_rounds=[
  //   {"id":1,"SBP_bidding_duration": 2,"SBP_end_date": "2021-09-15T12:15:23.279-04:00","SBP_end_time": "2021-09-15T12:17:23.280-04:00","SBP_leave_selection_rules": "Week-1","SBP_start_date": "2021-09-15T12:15:23.277-04:00","SBP_start_time": "2021-09-15T12:15:23.278-04:00"},
  // {"id":2,"SBP_bidding_duration": 2,"SBP_end_date": "2021-09-15T12:15:23.279-04:00","SBP_end_time": "2021-09-15T12:17:23.280-04:00","SBP_leave_selection_rules": "Week-1","SBP_start_date": "2021-09-15T12:15:23.277-04:00","SBP_start_time": "2021-09-15T12:15:23.278-04:00"},
  // {"id":3,"SBP_bidding_duration": 2,"SBP_end_date": "2021-09-15T12:15:23.279-04:00","SBP_end_time": "2021-09-15T12:17:23.280-04:00","SBP_leave_selection_rules": "Week-1","SBP_start_date": "2021-09-15T12:15:23.277-04:00","SBP_start_time": "2021-09-15T12:15:23.278-04:00"},
  // {"id":4,"SBP_bidding_duration": 2,"SBP_end_date": "2021-09-15T12:15:23.279-04:00","SBP_end_time": "2021-09-15T12:17:23.280-04:00","SBP_leave_selection_rules": "Week-1","SBP_start_date": "2021-09-15T12:15:23.277-04:00","SBP_start_time": "2021-09-15T12:15:23.278-04:00"},
  // {"id":5,"SBP_bidding_duration": 2,"SBP_end_date": "2021-09-15T12:15:23.279-04:00","SBP_end_time": "2021-09-15T12:17:23.280-04:00","SBP_leave_selection_rules": "Week-1","SBP_start_date": "2021-09-15T12:15:23.277-04:00","SBP_start_time": "2021-09-15T12:15:23.278-04:00"},
  // {"id":6,"SBP_bidding_duration": 2,"SBP_end_date": "2021-09-15T12:15:23.279-04:00","SBP_end_time": "2021-09-15T12:17:23.280-04:00","SBP_leave_selection_rules": "Week-1","SBP_start_date": "2021-09-15T12:15:23.277-04:00","SBP_start_time": "2021-09-15T12:15:23.278-04:00"}
  ]
  expand_id
  expand_id_validation
  items = []
  currentBidScheduleName: string;
  user_data: any;
  setUpBidScheduleOne: any;
  startDateForUpdateBidRound: any;
  allScheduleData: any[];
  all_final_data: any[];
  bidding_start_date: any;
  constructor(
    // public navCtrl: NavController,
    public navCtrl: NavController,
    private headerTitleService: HeaderTitleService,
    private sbpHeaderService:SetUpBidParametersService,
    private fb:FormBuilder,
    private bidService:BidScheduleService,
    public alertController: AlertController,
    public alertCtrl: AlertController,
    private scheduleService:GeneratedScheduleService,
    private curBidScheduleNameSer:PassBidScheduleNameService,
    private bidLeaveSetupSer:BidLeaveSetupService,
    private setUPbidRoundSer:SetupBidRoundService
  ) { }

  ngOnInit() {
    this.headerTitleService.setTitle('Manage Bid Parameters');
    this.headerTitleService.setDefaultHeader(false)
    this.headerTitleService.setBackUrl(straightlines_io_apis.apis.setUp_bid_parameters_step_2);
    this.headerTitleService.setForwardUrl(null);
    this.sbpHeaderService.setTitle('step-3')
    this.user_data=JSON.parse(localStorage.getItem('userData'))


    this.setUpBidScheduleOne=JSON.parse(localStorage.getItem('setUpBidScheduleOne'))
    if(this.setUpBidScheduleOne==null){
      this.navCtrl.navigateBack([straightlines_io_apis.apis.setUp_bid_parameters])
      // console.log(this.setUpBidScheduleOne)
    }else{
    this.currentBidScheduleName=this.setUpBidScheduleOne.SBP_schedule_name
    this.totalEmployees()

     this.getAllBidRoundBasedOnBidScheduleName()
      // console.log(this.totalEmp)
    this.setUpBidParametersForm = this.fb.group({
      id:new FormControl('newid'),
      SBP_start_date:new FormControl('',Validators.compose([Validators.required]),),
      SBP_start_time:new FormControl('08:00:00',Validators.compose([Validators.required])),
      SBP_end_time:new FormControl('16:00:00',Validators.compose([Validators.required])),
      SBP_bidding_duration:new FormControl('00:30:00',Validators.compose([Validators.required])),
      SBP_leave_selection_rules:new FormControl(this.leave_selection_list[0],Validators.compose([Validators.required])),
    })
    this.total_SBP_rounds=this.all_SBP_rounds.length
    for(var i=0;i<this.all_SBP_rounds.length;i++){
      this.items.push({expanded: false,"SBP_start_date":this.all_SBP_rounds[i].SBP_start_date,"SBP_start_time":this.all_SBP_rounds[i].SBP_start_time,"SBP_end_date":this.all_SBP_rounds[i].SBP_end_date,"SBP_end_time":this.all_SBP_rounds[i].SBP_end_time,"SBP_bidding_duration":this.all_SBP_rounds[i].SBP_bidding_duration,"SBP_leave_selection_rules":this.all_SBP_rounds[i].SBP_leave_selection_rules})
    }
  }
  }
  get newid(){
    return this.setUpBidParametersForm.get('newid')
  }
  get SBP_start_date(){
    return this.setUpBidParametersForm.get('SBP_start_date')
  }
  get SBP_start_time(){
    return this.setUpBidParametersForm.get('SBP_start_time')
  }

  get SBP_end_time(){
    return this.setUpBidParametersForm.get('SBP_end_time')
  }
  get SBP_bidding_duration(){
    return this.setUpBidParametersForm.get('SBP_bidding_duration')
  }
  get SBP_leave_selection_rules(){
    return this.setUpBidParametersForm.get('SBP_leave_selection_rules')
  }

  scheduleShiftLine(){
  }
  async submit(data){

     const alert = await this.alertController.create({
       cssClass: 'my-custom-class',
       // header: 'Confirm!',
       message: 'Do you want to add another bid round?',
       buttons: [
         {
           text: 'No',

          handler: () => {
            this.navCtrl.navigateForward([straightlines_io_apis.apis.setUp_bid_parameters_summary])
           }
         },{
          text: 'Yes',
          role: 'cancel',
          handler: () => {

          }
        }
       ]
     });

     await alert.present();

  }
  add(data){


    // console.log(this.setUpBidParametersForm.value)
    var startDate,endDate,startTime,endTime,duration,leaveRule
    startDate=this.setUpBidParametersForm.value.SBP_start_date
    startTime=this.setUpBidParametersForm.value.SBP_start_time
    endTime=this.setUpBidParametersForm.value.SBP_end_time
    duration=this.setUpBidParametersForm.value.SBP_bidding_duration
    leaveRule=this.setUpBidParametersForm.value.SBP_leave_selection_rules
   var start = startTime.split(":");
    var end = endTime.split(":");
    var start_Date = new Date(0, 0, 0, start[0], start[1], 0);
    var end_Date = new Date(0, 0, 0, end[0], end[1], 0);
    var diff = end_Date.getTime() - start_Date.getTime();
    var minutes = Math.floor(diff / 1000 / 60);

    var duration_1=duration.split(":")
    var timeDuration= new Date(0, 0, 0, 0, duration_1[1], 0);
    var diffDur=duration_1[1]
    minutes= Number(minutes)+Number(diffDur)
    var totalRequiredMInsForAllEmp=this.totalEmp*Number(diffDur)
    var totalRequiredDaysForAllEmp=Number(totalRequiredMInsForAllEmp)/minutes
    var finalEndDateCount=Math.ceil(totalRequiredDaysForAllEmp)

    var finalEndDate=(new Date(new Date(startDate).setDate(new Date(startDate).getDate()+ ( Number(finalEndDateCount)-1))))


    var bid_round_data={
      "bidschedulenameref":this.currentBidScheduleName,
      "bidroundstartdate": new Date(startDate),
      "bid_duration": duration,
      "daily_starttime": startTime,
      "daily_endttime":endTime,
      "bidroundenddate":finalEndDate,
      "bidleavereason": leaveRule,
      "useridref":this.user_data.id,
      "roundsavestatus":1
    }
    var minDate ,current_start_Date,differentTime,chc,count=0
      var maxDate ,current_end_Date,differentDays
      // console.log(startDate)


    if(this.startDateForUpdateBidRound!==undefined){
      if((startDate.getFullYear() === this.startDateForUpdateBidRound.getFullYear() &&startDate.getMonth() === this.startDateForUpdateBidRound.getMonth() &&startDate.getDate() === this.startDateForUpdateBidRound.getDate()) ){
      this.dateValidation=false
      }
    }else{
      var sDate,eDate
          for(var i=0;i<this.all_SBP_rounds.length;i++){
            sDate = this.all_SBP_rounds[i].bidroundstartdate.split("-")
            eDate = this.all_SBP_rounds[i].bidroundenddate.split("-")
            minDate=  new Date(sDate[0],Number(sDate[1])+ -+1,sDate[2],0,0,0)
            maxDate = new Date(eDate[0],Number(eDate[1])+ -+1,eDate[2],0,0,0)
            differentTime = Math.abs(maxDate - minDate);
            current_start_Date=new Date(bid_round_data.bidroundstartdate)
            current_end_Date=new Date(bid_round_data.bidroundenddate)
            if (current_end_Date >= minDate && current_start_Date <= maxDate){
              // console.log(true)
              this.dateValidation=true
            }else if(current_end_Date <= minDate && current_start_Date >= maxDate){
              this.dateValidation=true
            }
            else if(current_start_Date >= minDate && current_end_Date <= maxDate){
              this.dateValidation=true
            }
            else if(current_start_Date <= minDate && current_end_Date >= maxDate){
              this.dateValidation=true
            }
          }
        }
          if(this.dateValidation==false){
            var id=this.setUpBidParametersForm.value.id
            if(id=='newid'){
              // console.log(bid_round_data)
            this.addBidRound(bid_round_data)
            }else{
              this.update(bid_round_data)
            }
            // this.all_SBP_rounds.push(bid_round_data)
            this.getMaxDate()
            this.getAllBidRoundBasedOnBidScheduleName()
            return this.ngOnInit()
          }
      // console.log(this.all_SBP_rounds)
  }

  addBidRound(bid_round_data){
    this.setUPbidRoundSer.addNewBidRound(bid_round_data).subscribe((res)=>{
      this.setUpBidParametersForm.controls['SBP_start_date'].reset()
      this.bidService.getScheduleNameBasedOnBidScheduleName(this.currentBidScheduleName).subscribe((res)=>{

          var tempArr=[],temp
            tempArr=res
            for(var i=0;i<tempArr.length;i++){
              if(tempArr[i].roundsavestatus==0){
              temp={
                "bidid": tempArr[i].bidid,
                "bidscheduleenddate":tempArr[i].bidscheduleenddate,
                "bidschedulename": tempArr[i].bidschedulename,
                "bidschedulestartdate": tempArr[i].bidschedulestartdate,
                "bidstartdate": tempArr[i].bidstartdate,
                "employee":tempArr[i].employee,
                "leavesavestatus":tempArr[i].leavesavestatus,
                "paramsavestatus": tempArr[i].paramsavestatus,
                "qualifiction": tempArr[i].qualifiction,
                "roundsavestatus": 1,
                "schedulename": tempArr[i].schedulename,
                "userid": tempArr[i].userid
              }
              this.bidService.updateBidSchedule(this.currentBidScheduleName,temp).subscribe((res)=>{
                console.log(res)
              this.ngOnInit()},
              (err)=>{console.log(err)},()=>{})
            }
            }
          },(err)=>{console.log(err)},()=>{})
    },(err)=>{console.log(err)},()=>{})
  }
  getAllBidRoundBasedOnBidScheduleName(){
    this.setUPbidRoundSer.getAllBidRoundBasedOnBidScheduleName(this.currentBidScheduleName).subscribe(
      (res)=>{
        // console.log(res)
        this.all_SBP_rounds=[]
        for(var i=0;i<res.length;i++){
          var startTime=String(res[i].daily_starttime)
           var temp1=startTime.substring(0, startTime.indexOf(":"));
            // var min=startTime.split(':').pop().split(':')[0]
            var min= startTime.substring(
              startTime.indexOf(":") + 1,
              startTime.lastIndexOf(":")
          );
           if(Number(temp1)==24){
             var sTime='00:'+min+' AM'
           }else if(Number(temp1)>12){
             if((Number(temp1)+ - +12)<10){
              var sTime='0'+(Number(temp1)+ - +12)+':'+min+' PM'
             }else{
              var sTime=Number(temp1)+ - +12+':'+min+' PM'
             }

          }
          else if(Number(temp1)==12){
            var sTime='12:'+min+' PM'
          }
           else{
             sTime=temp1+':'+min+' AM'
           }
           //end Time
           var endTime=String(res[i].daily_endttime)
           var temp2=endTime.substring(0, endTime.indexOf(":"));
            var e_min=endTime.substring(
              endTime.indexOf(":") + 1,
              endTime.lastIndexOf(":")
          );
           if(Number(temp2)==24){
             var eTime='00:'+e_min+' AM'
           }else if(Number(temp2)>12){
             if((Number(temp2)+ - +12)<10){
              var eTime='0'+(Number(temp2)+ - +12)+':'+e_min+' PM'
             }else{
              var eTime=Number(temp2)+ - +12+':'+e_min+' PM'
             }

          }
          else if(Number(temp2)==12){
            var eTime='12:'+e_min+' PM'
          }
           else{
             eTime=temp2+':'+e_min+' AM'
           }
           var minDuration=String(res[i].bid_duration).substring(
            String(res[i].bid_duration).indexOf(":") + 1,
            String(res[i].bid_duration).lastIndexOf(":")
        );
          var  temp ={
            "bidroundid":res[i].bidroundid,
            "bidschedulenameref":res[i].bidroundid,
            "bidroundstartdate": res[i].bidroundstartdate,
            "bid_duration": minDuration,
            "bidroundenddate": res[i].bidroundenddate,
            "daily_starttime":sTime,
            "daily_endttime":eTime,
            "bidleavereason": res[i].bidleavereason,
            "useridref":res[i].useridref
          }
          this.all_SBP_rounds.push(temp)
        }

        if(this.all_SBP_rounds.length>0){
          this.setUpBidParametersForm.controls.SBP_bidding_duration.setValue('00:15:00')
          var start_Date_bid ,startDate,tempArr=[],bidDate

          for(var i=0;i<this.all_SBP_rounds.length;i++){
            startDate =this.all_SBP_rounds[i].bidroundstartdate.split("-");
            start_Date_bid = new Date(startDate[0],Number(startDate[1])+ - +1, startDate[2],0 ,0, 0);
            tempArr.push(start_Date_bid)
          bidDate=new Date(Math.min.apply(null,tempArr));
          }
          this.bidding_start_date=this.formatDate(bidDate)
        }
        // console.log(this.all_SBP_rounds)
        this.getMaxDate()
        if(this.all_SBP_rounds.length<1){
          this.minDateForBidRound=new Date(this.setUpBidScheduleOne.SBP_start_date)
        }
        this.total_SBP_rounds=this.all_SBP_rounds.length




this.bidService.getScheduleNameBasedOnBidScheduleName(this.currentBidScheduleName).subscribe(
  (res)=>{
    this.allScheduleData=[]
    this.allScheduleData=res
    var tempObj
    for(var i=0;i<this.allScheduleData.length;i++){
      tempObj={
        "bidid": this.allScheduleData[i].bidid,
        "bidscheduleenddate": this.allScheduleData[i].bidscheduleenddate,
        "bidschedulename": this.allScheduleData[i].bidschedulename,
        "bidschedulestartdate": this.allScheduleData[i].bidschedulestartdate,
        "bidstartdate": this.bidding_start_date,
        "employee":this.allScheduleData[i].employee,
        "leavesavestatus": this.allScheduleData[i].leavesavestatus,
        "paramsavestatus": this.allScheduleData[i].paramsavestatus,
        "qualifiction": this.allScheduleData[i].qualifiction,
        "roundsavestatus": this.allScheduleData[i].roundsavestatus,
        "schedulename": this.allScheduleData[i].schedulename,
        "userid": this.allScheduleData[i].userid
      }
      this.bidService.updateBidSchedule(this.currentBidScheduleName,tempObj).subscribe(
        (res)=>{},
        (err)=>{console.log(err)},
        ()=>{},
      )
    }
    // this.multiDimensionalUnique(res)
},
(err)=>{console.log(err)},
()=>{})
      },
      (err)=>{
        console.log(err)
      },
      ()=>{}
    )
  }
  formatDate(date) {
    var d = date,
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2)
        month = '0' + month;
    if (day.length < 2)
        day = '0' + day;

    return [year, month, day].join('-');
}

  getAllBidRound(){
      this.setUPbidRoundSer.getAllBidRound().subscribe(
        (res)=>{console.log(res)},
        (err)=>{console.log(err)},
        ()=>{}
      )
  }
  change(){
    this.dateValidation=false
    // console.log(this.setUpBidParametersForm.value)
    // this.startDate(this.setUpBidParametersForm.value.SBP_start_date)
    // this.startTime(this.setUpBidParametersForm.value.SBP_start_time)
    // // this.endDate(this.setUpBidParametersForm.value.SBP_end_date)
    // this.endTime(this.setUpBidParametersForm.value.SBP_end_time)
    this.end=this.end_date+'T'+this.end_time
    this.start=this.start_date+'T'+this.start_time
    if(this.end_date!=='' && this.end_time!=='' && this.start_date!=='' && this.start_time!==''){
      this.diff()
    //   this.setUpBidParametersForm.patchValue({
    //     SBP_bidding_duration: this.bid_duration
    //  });
    }
  }
  startDate(date) {
// console.log(date)
    this.start_date= date.substring(0, date.indexOf("T"));

  }
  startTime(date) {
    this.start_time = date.substring(date.indexOf("T")+1);
  }
  // endDate(date) {
  //     this.end_date= date.substring(0, date.indexOf("T"));
  // }
  endTime(date) {
    this.end_time = date.substring(date.indexOf("T")+1);
  }
  diff(){
    var fromTime = new Date(this.start);
    var toTime = new Date(this.end);
    var differenceTravel = toTime.getTime() - fromTime.getTime();
    var seconds = Math.floor((differenceTravel) / (1000));
    var mins=seconds/60
    this.bid_duration=mins
  }
  expand(index){
    if(this.expand_id==index){
      this.expand_id=null
    }else{
      this.expand_id=index
    }
  }
  expandlist(i){
    if(this.expand_id==i){
      return 'expand'
    }else{
      return 'default-expand'
    }
  }
  getMaxDate(){
    var tempArr=[]
    for(var i=0;i<this.all_SBP_rounds.length;i++){
      tempArr.push(new Date(new Date(this.all_SBP_rounds[i].bidroundstartdate).setDate(new Date(this.all_SBP_rounds[i].bidroundstartdate).getDate()+1 )))
      tempArr.push(new Date(new Date(this.all_SBP_rounds[i].bidroundenddate).setDate(new Date(this.all_SBP_rounds[i].bidroundenddate).getDate()+1 )))

    }
    var maxDate=new Date(Math.max.apply(null,tempArr));
    // console.log(maxDate)
    this.minDateForBidRound=new Date(new Date(maxDate).setDate(new Date(maxDate).getDate()+1 ))
    // console.log(this.minDateForBidRound)
  }
  async deleteBidRound(index){
    console.log(index)
  const confirm = await this.alertCtrl.create({
    header: 'Are you sure?',
    message: 'Are you sure you want to delete the record?',
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel',
        handler: () => {
          // console.log('Confirm Cancel');
        }
      },
      {
        text: 'Delete',
        role: 'delete',
        handler: () => {
          this.setUPbidRoundSer.deleteBidRoundBasedOnId(index.bidroundid).subscribe((res)=>{
            this.ngOnInit()
            console.log(res)},
          (err)=>{console.log(err)},()=>{})
        }
      }]
      })
      await confirm.present();



  }
  updateBidRound(index){
console.log(index)
    var startDate=new Date(new Date(index.bidroundstartdate).setDate(new Date(index.bidroundstartdate).getDate() + 1))
    this.startDateForUpdateBidRound=startDate
    var duration='00:'+index.bid_duration+':00'
   var startTime=this.convertTime12to24(index.daily_starttime)

   var endTime=this.convertTime12to24(index.daily_endttime)
    this.setUpBidParametersForm.setValue({
      id:index.bidroundid,
    SBP_start_date:startDate,
      SBP_start_time:startTime,
      SBP_end_time:endTime,
      SBP_bidding_duration:duration,
      SBP_leave_selection_rules:index.bidleavereason
    })
  }
  update(bidRoundData){
    var  id=this.setUpBidParametersForm.value.id
    var startDate= bidRoundData.bidroundstartdate
    var updateStartDate=startDate.getFullYear() +'-'+ new Date(startDate.setMonth(startDate.getMonth()+1)).getMonth()+'-'+startDate.getDate()
    var endDate= bidRoundData.bidroundenddate
    var updateendDate=endDate.getFullYear() +'-'+ new Date(endDate.setMonth(endDate.getMonth()+1)).getMonth()+'-'+endDate.getDate()
    var bid_round_data={
      "bidroundid":id,
      "bidschedulenameref":bidRoundData.bidschedulenameref,
      "bidroundstartdate":updateStartDate,
      "bid_duration": bidRoundData.bid_duration,
      "daily_starttime": bidRoundData.daily_starttime,
      "daily_endttime":bidRoundData.daily_endttime,
      "bidroundenddate":updateendDate,
      "bidleavereason": bidRoundData.bidleavereason,
      "useridref":this.user_data.id,
      "roundsavestatus":1
    }
    console.log(bid_round_data)
    this.setUPbidRoundSer.updateBidRound(id,bid_round_data).subscribe((res)=>{
      console.log(res)
      this.ngOnInit()
    },(err)=>{
      console.log(err)
    },()=>{})
  }
   convertTime12to24(time12h){
    const [time, modifier] = time12h.split(' ');

    let [hours, minutes] = time.split(':');

    if (hours === '12') {
      hours = '00';
    }

    if (modifier === 'PM') {
      hours = parseInt(hours, 10) + 12;
    }
    var updatedtime=hours+':'+minutes+':00'
    return updatedtime;
  }

  totalEmployees(){
    this.allShceduleBasedOnBidScheduleName()
  }
  allShceduleBasedOnBidScheduleName(){
    var b_schedule_name=this.currentBidScheduleName
    if(b_schedule_name!==''){
      this.bidService.getScheduleNameBasedOnBidScheduleName(b_schedule_name).subscribe(
        (res)=>{
          this.allScheduleData=[]
          this.allScheduleData=res
          this.multiDimensionalUnique(res)
      },
      (err)=>{console.log(err)},
      ()=>{})}
  }
  multiDimensionalUnique(data) {
    var resArr = [];
    data.filter(function(item){
      var i = resArr.findIndex(x => (x.bidschedulename == item.bidschedulename && x.schedulename == item.schedulename && x.bidschedulestartdate == item.bidschedulestartdate&& x.bidscheduleenddate == item.bidscheduleenddate&& x.bidstartdate == item.bidstartdate));
      if(i <= -1){
            resArr.push(item);
      }
      return null;
    });
    this.all_final_data=[]
    for(var i=0;i<resArr.length;i++){
      this.scheduleService.getSaveShiftDefintionDataBasedOnScheduleName(resArr[i].schedulename).subscribe((res)=>{
        var temp=Number(res.length)
        this.largestNumber(temp)
      },(err)=>{console.log(err)},()=>{})

    }



  }
  largestNumber(arr){
    this.all_final_data.push(arr)
    return this.totalEmp=Math.max(...this.all_final_data)
  }
}




















// this.tempArr=[]
// var minDate ,current_start_Date,differentTime,chc,count=0
// var maxDate ,current_end_Date,differentDays
// if(this.all_SBP_rounds.length==0){
//   this.tempArr=[]
//   this.tempArr.push(bid_round_data)
// }else{
//   this.tempArr=[]
// for(var i=0;i<this.all_SBP_rounds.length;i++){
//   minDate=  new Date(this.all_SBP_rounds[i].bidroundstartdate);
//   maxDate = new Date(this.all_SBP_rounds[i].bidroundenddate);
//   differentTime = Math.abs(maxDate - minDate);
//   differentDays = Math.ceil(differentTime / (1000 * 60 * 60 * 24));


// current_start_Date=new Date(bid_round_data.bidroundstartdate)
// current_end_Date=new Date(bid_round_data.bidroundenddate)
// if (current_end_Date >= minDate && current_start_Date <= maxDate){
//  this.dateValidation=true
// }else if(current_end_Date <= minDate && current_start_Date >= maxDate){
// this.dateValidation=true
// }
// else if(current_start_Date >= minDate && current_end_Date <= maxDate){
// this.dateValidation=true
// }
// else if(current_start_Date <= minDate && current_end_Date >= maxDate){
// this.dateValidation=true
// }
// else{
// this.dateValidation=false
// this.all_SBP_rounds.push(bid_round_data)

// }

//   }
// }


// if(count>0){
// this.tempArr.push(bid_round_data)
// }

// for(var i=0;i<this.tempArr.length;i++){
// this.all_SBP_rounds.push(this.tempArr[i])
// }
// var currentDate = new Date();
