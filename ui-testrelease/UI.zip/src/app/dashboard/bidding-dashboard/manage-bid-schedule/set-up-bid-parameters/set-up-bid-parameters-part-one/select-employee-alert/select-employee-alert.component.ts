import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { NavController, ModalController, AlertController, NavParams } from '@ionic/angular';
import { HeaderTitleService } from 'src/app/dashboard/nav-bar-footer/header-title.service';
import { AddNewEmployeeService } from 'src/app/services/manage-bid-schedule/add-new-employee/add-new-employee.service';
import { BidScheduleService } from 'src/app/services/manage-bid-schedule/bid-schedule/bid-schedule.service';
import { PassBidScheduleNameService } from 'src/app/services/manage-bid-schedule/pass-bid-schedule-name.service';
import { QualificationService } from 'src/app/services/manage-bid-schedule/qualification/qualification.service';
import { GeneratedScheduleService } from 'src/app/services/schedule/generated-schedule.service';
import { SetUpBidParametersService } from '../../service/set-up-bid-parameters.service';

@Component({
  selector: 'app-select-employee-alert',
  templateUrl: './select-employee-alert.component.html',
  styleUrls: ['./select-employee-alert.component.scss'],
})
export class SelectEmployeeAlertComponent implements OnInit {
  allEmployee=[]
  scheduleListForm : any;
  schedule_data=[];
  range
  all_schedule_list=[]
  constructor(
    public navCtrl: NavController,
    public modalCtrl: ModalController,
    private headerTitleService: HeaderTitleService,
    private sbpHeaderService:SetUpBidParametersService,
    private scheduleService:GeneratedScheduleService,
    private fb:FormBuilder,
    public navParams: NavParams,
    private curBidScheduleNameSer:PassBidScheduleNameService,
    private getAllEmp:AddNewEmployeeService,
    public alertController: AlertController,
    private qualifiaction_name:QualificationService,
    private bidService:BidScheduleService
  ) {
    this.schedule_data=navParams.get('schedule_list')
  }

  ngOnInit() {

    this.all_schedule_list=[]
    var temp

    this.scheduleListForm  = this.fb.group({
      allScheduleListData: this.fb.array([]) ,
  });

  for(var i=0;i<this.schedule_data.length;i++){
    this.allScheduleListData.push(this.newWorkLoadData());
     temp={"id":i,"startDate":'',"endDate":"","scheduleName":this.schedule_data[i]}
    this.all_schedule_list.push(temp)
  }
  this.allScheduleListData.setValue(this.all_schedule_list)
  console.log(this.scheduleListForm .value)
    this.allEmp()
  }
  get allScheduleListData() : FormArray {
    // console.log(this.scheduleListForm .get("allScheduleListData").value[0] )
    return this.scheduleListForm .get("allScheduleListData") as FormArray
   }
   newWorkLoadData(): FormGroup {
    return this.fb.group({
      id:new FormControl(),
      scheduleName:new FormControl(),

      startDate:new FormControl(),
      endDate:new FormControl(),
    })
  }
allEmp(){
  this.getAllEmp.getAllEmployee().subscribe(
    (res)=>{this.allEmployee=res},
    (err)=>{console.log(err)},()=>{
      // this.ngOnInit()
      // console.log(this.allEmployee)
    }
  )
}
updateWorkLoad(){
  console.log(this.scheduleListForm .value)
}
}
