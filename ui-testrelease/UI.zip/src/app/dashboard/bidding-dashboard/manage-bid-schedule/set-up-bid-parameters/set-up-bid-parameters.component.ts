import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { HeaderTitleService } from 'src/app/dashboard/nav-bar-footer/header-title.service';
import straightlines_io_apis from 'src/app/json/apis.json';
import { SetUpBidParametersService } from './service/set-up-bid-parameters.service';
@Component({
  selector: 'app-set-up-bid-parameters',
  templateUrl: './set-up-bid-parameters.component.html',
  styleUrls: ['./set-up-bid-parameters.component.scss'],
})
export class SetUpBidParametersComponent implements OnInit {
  schedule_id: number=0;
step_form_name
  constructor(
    public navCtrl: NavController,
    private cdref: ChangeDetectorRef,
    private headerTitleService: HeaderTitleService,
    private sbpHeaderService:SetUpBidParametersService,
    private formBuilder:FormBuilder

  ) { }

  ngOnInit() {
    // this.getIndicatorClass(this.schedule_id)
    this.sbpHeaderService.title.subscribe(title => {
      this.step_form_name = title;
      if(this.step_form_name=='step-1'){
        this.getColor()
      }
      if(this.step_form_name=='step-2'){
        this.getIndicatorClassOne()
      }
      if(this.step_form_name=='step-3'){
        this.getIndicatorClass()
      }
    });
  }
  ngAfterContentChecked() {
    this.cdref.detectChanges();
  }
  getColor(){
    return 'active ';
  }

  getIndicatorClassOne(){

       if(this.step_form_name=='step-2'){
        return 'active ';

      }
      else if(this.step_form_name=='step-3'){
        return 'active';
      }
      return'small'
  }
  getIndicatorClass(){
    if(this.step_form_name=='step-3'){
      return this.getIndicatorClassOne();
    }
    return'small'
}

  schedule(id){
    console.log(id)
    // if(id==0){
    //   this.step_form_name=0
    //   // this.ngOnInit()
    // }else if(id==1){
    //   this.step_form_name=1
    //   // this.ngOnInit()
    // }else if(id==2){

    //   this.step_form_name=2
    //   // this.ngOnInit()
    // }
}
}
