import { Component, HostListener, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ModalController, NavController, NavParams } from '@ionic/angular';
import { HeaderTitleService } from 'src/app/dashboard/nav-bar-footer/header-title.service';
import { AddNewEmployeeService } from 'src/app/services/manage-bid-schedule/add-new-employee/add-new-employee.service';
import { BidScheduleService } from 'src/app/services/manage-bid-schedule/bid-schedule/bid-schedule.service';
import { GeneratedScheduleService } from 'src/app/services/schedule/generated-schedule.service';
import Swal from 'sweetalert2';
import { SetUpBidParametersService } from '../../service/set-up-bid-parameters.service';

@Component({
  selector: 'app-part-one-step-two',
  templateUrl: './part-one-step-two.component.html',
  styleUrls: ['./part-one-step-two.component.scss'],
})
export class PartOneStepTwoComponent implements OnInit {
  setUpBidParametersForm: FormGroup;
  select_shiftline_schedule=['Trimester1_Shiftline Schedule','Trimester2_Shiftline Schedule','Trimester3_Shiftline Schedule']
  bid_schedule_data: any;
  all_schedule: any;
  selected_schedule_data: any;
  user_data: any;
  allShiftData=[];
  getAllScheduleName: any[];
  allEmployee=[]
  scheduleListForm : any;
  schedule_data=[];
  lastDate
  all_schedule_list=[]
  checkDate=[]
  dateValidation=false
  checkShiftLineSchedule=false
  setUpBidScheduleOne: any;
  updatedData: any[];
  allScheduleData=[]
  disable=true
  constructor(public navCtrl: NavController,
    public modalCtrl: ModalController,
    public navParams: NavParams,
    private getAllEmp:AddNewEmployeeService,
    private scheduleService:GeneratedScheduleService,
    private headerTitleService: HeaderTitleService,
    private sbpHeaderService:SetUpBidParametersService,
    private bidScheduleSer:BidScheduleService,
    private fb:FormBuilder) {
      this.bid_schedule_data=navParams.get('bid_schedule_data')
      this.allScheduleData=navParams.get('all_schedule_data')
   }
   ngOnInit() {
    this.user_data=JSON.parse(localStorage.getItem('userData'))
    this.schedule_data=this.bid_schedule_data.SBP_select_shiftline_schedule
    this.all_schedule_list=[]
    var temp
    // console.log(this.allScheduleData)
    this.checkShiftLineSchedule=this.bid_schedule_data.checkShiftLineScheduleForEdit
    // this.lastDate=new Date(this.bid_schedule_data.SBP_start_date)
    this.setUpBidScheduleOne=JSON.parse(localStorage.getItem('setUpBidScheduleOne'))
    this.scheduleListForm  = this.fb.group({
      allScheduleListData: this.fb.array([]) ,
    });
    this.updatedData=[]
  for(var i=0;i<this.schedule_data.length;i++){
    this.allScheduleListData.push(this.newWorkLoadData());
     temp={"id":i,"startDate":null,"endDate":null,"scheduleName":this.schedule_data[i],"active":false}
    this.all_schedule_list.push(temp)
    this.updatedData.push(temp)
  }
  this.allScheduleListData.setValue(this.all_schedule_list)
    this.allEmp()
  }
  get allScheduleListData() : FormArray {
    return this.scheduleListForm .get("allScheduleListData") as FormArray
   }
   newWorkLoadData(): FormGroup {
    return this.fb.group({
      id:new FormControl(),
      scheduleName:new FormControl(),
      startDate:new FormControl(),
      endDate:new FormControl(),
      active:new FormControl()
    })
  }
allEmp(){
  this.getAllEmp.getAllEmployee().subscribe(
    (res)=>{this.allEmployee=res},
    (err)=>{console.log(err)},()=>{
      // this.ngOnInit()
      // console.log(this.allEmployee)
    }
  )
}

updateWorkLoad(){
  // console.log(this.scheduleListForm.value)
}

dateRangeChange() {
  // console.log(dateRangeStart.value);
  // console.log(dateRangeEnd.value);
  // console.log(this.scheduleListForm.value)
  this.checkDate=[]
  var tempObj
  this.updatedData=[]
  var temp=this.scheduleListForm.value.allScheduleListData
  for(var i=0;i<temp.length;i++){
    if(temp[i].startDate!=null&&temp[i].endDate!=null){
      this.checkDate.push(temp[i])
      tempObj={"id":i,"startDate":temp[i].startDate,"endDate":temp[i].endDate,"scheduleName":temp[i].scheduleName,"active":true}
      this.updatedData.push(tempObj)
    }
    else{
      this.updatedData.push(temp[i])
    }
  }
  if(this.checkDate.length>0){
    this.multiDimensionalUnique(this.checkDate)
  }
  var count=0
  for(var i=0;i<this.updatedData.length;i++){
    if(this.updatedData[i].active==false){
      count++
    }
  }
  if(count>0){
    this.disable=true
  }else{
    for(var i=0;i<this.updatedData.length;i++){
      if(this.updatedData[i].startDate==null||this.updatedData[i].endDate==null){
        return this.disable=true
      }
    }
    this.disable=false
  }


}
submit(){
  var count=0

  for(var i=0;i<this.updatedData.length;i++){
    if(this.updatedData[i].active==false){
      count++
    }
  }
  if(count<1){
  var temp=[],tempObj
  temp=this.scheduleListForm.value.allScheduleListData
  // console.log(temp)
  // console.log(this.bid_schedule_data)
  for(var i=0;i<temp.length;i++){
    for(var j=0;j<this.bid_schedule_data.SBP_select_employees.length;j++){
      tempObj={
        "schedulename":temp[i].scheduleName,
        "bidschedulestartdate":temp[i].startDate,
        "bidscheduleenddate":temp[i].endDate,
        "bidschedulename":this.bid_schedule_data.SBP_schedule_name,
        "bidstartdate":this.bid_schedule_data.SBP_start_date,
        "qualifiction":this.bid_schedule_data.SBP_select_qualification,
        "employee":this.bid_schedule_data.SBP_select_employees[j],
        "userid": this.user_data.id,
        "paramsavestatus":1
      }
      // console.log(tempObj)
      this.bidScheduleSer.addNewBidSchedule(tempObj).subscribe(
                              (res)=>{console.log(res)},(err)=>{console.log(err)
                                Swal.fire({
                                  title: 'Error!',
                                  html: 'Please try again later!',
                                  icon: 'error',
                                  showCancelButton: false,
                                  confirmButtonColor:'#FF0000',
                                  imageHeight:'250px',
                                  heightAuto:false,
                                }).then((result) => {
                                })
                              },()=>{})


    }
  }
  this.modalCtrl.dismiss()
}else{
  console.log("Please enter a valid date range!")
}
}
multiDimensionalUnique(arr) {


  var uniques = [];
  var itemsFound = {};
  for(var i = 0, l = arr.length; i < l; i++) {
      var stringified = JSON.stringify(arr[i]);
      if(itemsFound[stringified]) { continue; }
      uniques.push(arr[i]);
      itemsFound[stringified] = true;
  }
  var tempArr=[]

  for(var i=0;i<uniques.length;i++){
    var startDate=new Date(uniques[i].startDate)
    startDate.setDate(startDate.getDate() );

    var endDate=new Date(uniques[i].endDate)
    endDate.setDate(endDate.getDate());
    var finalObj={'bid_schedule_name':uniques[i].scheduleName,'schedule_start_date':startDate,'schedule_end_date':endDate}
    tempArr.push(finalObj)
  }

  var dates=[],tempFinalArr=[]
  for(var i=0;i<tempArr.length;i++){
    var dates=[]
    for(var j=0;j<tempArr.length;j++){
      if(tempArr[i].bid_schedule_name==tempArr[j].bid_schedule_name){
        dates.push(new Date(tempArr[j].schedule_end_date))
        var maxDate=new Date(Math.max.apply(null,dates));
      }
    }
    tempFinalArr.push({'bid_schedule_name':uniques[i].bidschedulename,'schedule_start_date':startDate,'schedule_end_date':maxDate})
  }

  this.lastDate=new Date(new Date(maxDate).setDate(new Date(maxDate).getDate()+1 ))
  var finalArr=tempFinalArr.filter((v,i,a)=>a.findIndex(t=>(t.bid_schedule_name === v.bid_schedule_name))===i)
  // console.log(finalArr)
  return finalArr.reverse();;
}
close(){
  this.modalCtrl.dismiss()
}
update(){
  var count=0

  for(var i=0;i<this.updatedData.length;i++){
    if(this.updatedData[i].active==false){
      count++
    }
  }
  if(count<1){
  var temp=[],tempObj
  temp=this.scheduleListForm.value.allScheduleListData
  // console.log(temp)
  // console.log(this.bid_schedule_data)
  // console.log(this.allScheduleData)
  for(var i=0;i<temp.length;i++){
    for(var j=0;j<this.allScheduleData.length;j++){
      if(this.allScheduleData[j].schedulename===temp[i].scheduleName){
        tempObj={
          "bidid":this.allScheduleData[j].bidid,
          "schedulename":this.allScheduleData[j].schedulename,
          "bidschedulestartdate":temp[i].startDate.toISOString().slice(0, 10),
          "bidscheduleenddate":temp[i].endDate.toISOString().slice(0, 10),
          "bidschedulename":this.allScheduleData[j].bidschedulename,
          "bidstartdate":this.allScheduleData[j].bidstartdate,
          "qualifiction":this.allScheduleData[j].qualifiction,
          "employee":this.allScheduleData[j].employee,
          "userid": this.user_data.id,
          "paramsavestatus":1
        }

        // console.log(tempObj)
        this.bidScheduleSer.updateBidScheduleBasedOnId(this.allScheduleData[j].bidid,tempObj).subscribe(
          (res)=>{console.log(res)},(err)=>{console.log(err)
            Swal.fire({
              title: 'Error!',
              html: 'Please try again later!',
              icon: 'error',
              showCancelButton: false,
              confirmButtonColor:'#FF0000',
              imageHeight:'250px',
              heightAuto:false,
            }).then((result) => {
            })
          },()=>{})
      }
    }
  }
  this.modalCtrl.dismiss()
}else{
  console.log("Please enter a valid date range!")
}
}
}



























// ngOnInit() {

//   this.user_data=JSON.parse(localStorage.getItem('userData'))

//   this.getSchedule()
//   this.setUpBidParametersForm = this.fb.group({
//     SBP_Schedule_start_date:new FormControl('',Validators.compose([Validators.required])),
//     SBP_Schedule_end_date:new FormControl('',Validators.compose([Validators.required])),
//     SBP_select_shiftline_schedule:new FormControl(this.bid_schedule_data.select_shiftline_schedule_name,Validators.compose([Validators.required])),
//   })
// }
// get SBP_schedule_name(){
//   return this.setUpBidParametersForm.get('SBP_schedule_name')
// }
// get SBP_start_date(){
//   return this.setUpBidParametersForm.get('SBP_start_date')
// }
// get SBP_end_date(){
//   return this.setUpBidParametersForm.get('SBP_end_date')
// }
// get SBP_Schedule_start_date(){
//   return this.setUpBidParametersForm.get('SBP_Schedule_start_date')
// }
// get SBP_Schedule_end_date(){
//   return this.setUpBidParametersForm.get('SBP_Schedule_end_date')
// }
// get SBP_select_shiftline_schedule(){
//   return this.setUpBidParametersForm.get('SBP_select_shiftline_schedule')
// }
// get SBP_select_qualification(){
//   return this.setUpBidParametersForm.get('SBP_select_qualification')
// }
// get SBP_select_employees(){
//   return this.setUpBidParametersForm.get('SBP_select_employees')
// }
// scheduleShiftLine(){
//   var selected_schedule_name=this.setUpBidParametersForm.value.SBP_select_shiftline_schedule

// }
// submit(){
// var all_shiftline=[]
// var emp=this.bid_schedule_data.select_employess
//           for(var i=0;i<emp.length;i++){
//             var final_data={"schedulename":
//             this.bid_schedule_data.select_shiftline_schedule_name,"bidschedulestartdate":this.setUpBidParametersForm.value.SBP_Schedule_start_date,"bidscheduleenddate":this.setUpBidParametersForm.value.SBP_Schedule_end_date,
//            "bidschedulename":this.bid_schedule_data.bid_schedule_name,"bidstartdate":this.bid_schedule_data.bid_schedule_start_date,"qualifiction":this.bid_schedule_data.select_qualification,
//            "employee":emp[i],
//            "userid": this.user_data.id
//                     }
//                     // console.log(final_data)
//                     this.bidScheduleSer.addNewBidSchedule(final_data).subscribe(
//                       (res)=>{console.log(res)},(err)=>{console.log(err)},()=>{})
//           }
//           var all_final_data=[]
//           all_final_data=JSON.parse(localStorage.getItem('all_bid_schedule'))
//           // console.log(all_final_data)
//           if(all_final_data==null){
//             all_final_data=[final_data]
//           }else{
//             all_final_data.push(final_data)
//           }

//   this.modalCtrl.dismiss()

// }
// close(){
//   this.modalCtrl.dismiss()
// }
// getSchedule(){
//   var tempObj={}
//   var tempArr=[]
//   var all_shift_data=[]
//   for(var i=0;i<this.allShiftData.length;i++){

// all_shift_data.push({
// "id": this.allShiftData[i].id,
// "shiftCategory": this.allShiftData[i].shiftCategory,
// "shiftName": this.allShiftData[i].shiftName,
// "startTime": this.allShiftData[i].startTime})
// }
//   this.scheduleService.getAllSchedule().subscribe((res)=>{
//     for(var i=0;i<res.length;i++){
//       if(Number(this.user_data.id)===Number(res[i].userid)){

//         tempArr.push(res[i])
//       }
//     }
//     // console.log(tempArr)
//      this.getAllScheduleName=[]
//     for(var i=0;i<tempArr.length;i++){
//       for(var j=0;j<tempArr.length;j++){
//         if(this.getAllScheduleName[i]!==tempArr[j].schedulename){
//           this.getAllScheduleName.push(tempArr[j].schedulename)

//         }
//       }
//     }var unique = this.getAllScheduleName.filter(this.onlyUnique);
//     this.getAllScheduleName=unique
//     console.log(this.getAllScheduleName)
// // }
// })
// }
// onlyUnique(value, index, self) {
//   return self.indexOf(value) === index;
// }
// }
