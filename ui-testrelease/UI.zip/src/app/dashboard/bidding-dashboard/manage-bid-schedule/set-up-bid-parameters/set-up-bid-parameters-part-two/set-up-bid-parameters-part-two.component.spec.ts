import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { SetUpBidParametersPartTwoComponent } from './set-up-bid-parameters-part-two.component';

describe('SetUpBidParametersPartTwoComponent', () => {
  let component: SetUpBidParametersPartTwoComponent;
  let fixture: ComponentFixture<SetUpBidParametersPartTwoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ SetUpBidParametersPartTwoComponent ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SetUpBidParametersPartTwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
