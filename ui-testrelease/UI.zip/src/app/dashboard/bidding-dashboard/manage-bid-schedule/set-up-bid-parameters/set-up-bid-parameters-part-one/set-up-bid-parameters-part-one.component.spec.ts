import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { SetUpBidParametersPartOneComponent } from './set-up-bid-parameters-part-one.component';

describe('SetUpBidParametersPartOneComponent', () => {
  let component: SetUpBidParametersPartOneComponent;
  let fixture: ComponentFixture<SetUpBidParametersPartOneComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ SetUpBidParametersPartOneComponent ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SetUpBidParametersPartOneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
