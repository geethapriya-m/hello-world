import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActionSheetController, AlertController, ModalController, NavController } from '@ionic/angular';
import { AddNewEmployeeComponent } from 'src/app/dashboard/add-new-employee/add-new-employee.component';
import { HeaderTitleService } from 'src/app/dashboard/nav-bar-footer/header-title.service';
import straightlines_io_apis from 'src/app/json/apis.json';
import { AddNewEmployeeService } from 'src/app/services/manage-bid-schedule/add-new-employee/add-new-employee.service';
import { BidScheduleService } from 'src/app/services/manage-bid-schedule/bid-schedule/bid-schedule.service';
import { PassBidScheduleNameService } from 'src/app/services/manage-bid-schedule/pass-bid-schedule-name.service';
import { QualificationService } from 'src/app/services/manage-bid-schedule/qualification/qualification.service';
import { ScheduleDataService } from 'src/app/services/schedule-data.service';
import { GeneratedScheduleService } from 'src/app/services/schedule/generated-schedule.service';
import { SetUpBidParametersService } from '../service/set-up-bid-parameters.service';
import { CustomSchedulePopupComponent } from './custom-schedule-popup/custom-schedule-popup.component';
import { PartOneStepTwoComponent } from './part-one-step-two/part-one-step-two.component';
import { ChangeDetectorRef } from '@angular/core';
@Component({
  selector: 'app-set-up-bid-parameters-part-one',
  templateUrl: './set-up-bid-parameters-part-one.component.html',
  styleUrls: ['./set-up-bid-parameters-part-one.component.scss'],
})
export class SetUpBidParametersPartOneComponent implements OnInit {
  setUpBidParametersForm: FormGroup;
  select_shiftline_schedule
bidScheduleData={"bid_schedule_name":'',
"bid_schedule_start_date":'',
"select_qualification":'',
"select_shiftline_schedule_name":'',
"select_employess":''}
  message:string= 'secondChild';
  checkShiftLineSchedule=false
  checkShiftLineQualification=false
  checkShiftLineBidSchedule=false
  checkShiftLineStartDate=false
  all_slots=[{"id":1, "start_date":"03/27/2021","end_date":"04/24/2021","PTL_slots":3},{"id":2, "start_date":"03/27/2021","end_date":"04/24/2021","PTL_slots":3},
  {"id":3, "start_date":"03/27/2021","end_date":"04/24/2021","PTL_slots":3},{"id":4, "start_date":"03/27/2021","end_date":"04/24/2021","PTL_slots":3},
  {"id":5, "start_date":"03/27/2021","end_date":"04/24/2021","PTL_slots":3},{"id":6, "start_date":"03/27/2021","end_date":"04/24/2021","PTL_slots":3}]
  getAllScheduleName: any[];
  schedulename=''
  user_data: any;
  all_final_data: any;
  all_qualification=[]
  checkBidSchedule_Name=false;
  allEmployee=[]
  setUpBidScheduleOne
  disableSelectEmpOtion=true
  maxDate
  minDate
  bidScheduleName=false
  checkShiftLineScheduleForEdit=false
  allScheduleData: any[];
  checkForEditSchedule=false
  allBidScheduleNumbers=1;
  disableSelectEmpOption=false
  constructor(
    public navCtrl: NavController,
    public modalCtrl: ModalController,
    private headerTitleService: HeaderTitleService,
    private sbpHeaderService:SetUpBidParametersService,
    public actionSheetController: ActionSheetController,
    private scheduleService:GeneratedScheduleService,
    private fb:FormBuilder,
    private cdr: ChangeDetectorRef,
    private curBidScheduleNameSer:PassBidScheduleNameService,
    private getAllEmp:AddNewEmployeeService,
    public alertController: AlertController,
    private qualifiaction_name:QualificationService,
    private bidService:BidScheduleService,
    public alertCtrl: AlertController,
  ) { }

  ngOnInit() {
    this.user_data=JSON.parse(localStorage.getItem('userData'))
    this.bidService.getAllBidSchedule(this.user_data.id).subscribe((res)=>{

      if(res.length<1 || res==null || res==undefined){
        this.headerTitleService.setTitle('Manage Bid Parameters');
        this.headerTitleService.setDefaultHeader(false)
        this.headerTitleService.setBackUrl(straightlines_io_apis.apis.my_bidding);
        this.headerTitleService.setForwardUrl(null);
      }else{
        this.headerTitleService.setTitle('Manage Bid Parameters');
        this.headerTitleService.setDefaultHeader(false)
        this.headerTitleService.setBackUrl(straightlines_io_apis.apis.manage_bid_schedule);
        this.headerTitleService.setForwardUrl(null);
      }


     },(err)=>{
       console.log(err)
       this.headerTitleService.setTitle('Manage Bid Parameters');
    this.headerTitleService.setDefaultHeader(false)
    this.headerTitleService.setBackUrl(straightlines_io_apis.apis.manage_bid_schedule);
    this.headerTitleService.setForwardUrl(null);
     },()=>{})

    this.sbpHeaderService.setTitle('step-1')
    var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    var yyyy = today.getFullYear();
    this.minDate = String( yyyy + '-' +mm + '-' + dd );
    this.maxDate=String((yyyy+ + +3+ '-' +mm + '-' + dd ))
    this.getSchedule()
    this.allQualification()
    this.allEmp()
    this.setUpBidScheduleOne=JSON.parse(localStorage.getItem('setUpBidScheduleOne'))
    // console.log(this.setUpBidScheduleOne)
this.all_final_data=[]
this.getAllBidSchedule()
this.setUpBidParametersForm = this.fb.group({
  SBP_schedule_name:new FormControl('MySchedule',Validators.compose([Validators.required])),
  // SBP_start_date:new FormControl(this.bidScheduleData.bid_schedule_start_date),
  SBP_select_shiftline_schedule:new FormControl(this.bidScheduleData.select_shiftline_schedule_name,Validators.compose([Validators.required])),
  SBP_select_qualification:new FormControl('Fully Qualified',Validators.compose([Validators.required])),
  SBP_select_employees:new FormControl('',Validators.compose([Validators.required])),
})
console.log(this.setUpBidScheduleOne)
     if(this.setUpBidScheduleOne!=null){
      this.disableSelectEmpOption=true
      var tempArr=[],tempArrSchedule=[]
     for(var i=0;i<this.setUpBidScheduleOne.SBP_select_employees.length;i++){

       if(String(this.setUpBidScheduleOne.SBP_select_employees[i])!=='addnewemployee'){
         tempArr.push(this.setUpBidScheduleOne.SBP_select_employees[i])
       }
       if(String(this.setUpBidScheduleOne.SBP_select_shiftline_schedule[i])!=='Custom Schedule'){
        tempArrSchedule.push(this.setUpBidScheduleOne.SBP_select_shiftline_schedule[i])
       }

     }
     this.setUpBidParametersForm.controls.SBP_schedule_name.setValue(this.setUpBidScheduleOne.SBP_schedule_name)
    //  this.setUpBidParametersForm.controls.SBP_start_date.setValue(this.setUpBidScheduleOne.SBP_start_date)
    //  this.setUpBidParametersForm.controls.SBP_select_shiftline_schedule.setValue(this.setUpBidScheduleOne.SBP_select_shiftline_schedule)
     this.setUpBidParametersForm.controls.SBP_select_qualification.setValue('Fully Qualified')
     this.setUpBidParametersForm.controls.SBP_select_employees.setValue(tempArr)
     this.checkForEditSchedule=this.setUpBidScheduleOne.edit
        if(this.checkForEditSchedule===true){
          this.bidScheduleName=this.setUpBidScheduleOne.edit
          this.allShceduleBasedOnBidScheduleName()
        }else{
          this.bidScheduleName=false
        }

    }
    else{

    }
  }
  get SBP_schedule_name(){
    return this.setUpBidParametersForm.get('SBP_schedule_name')
  }
  get SBP_start_date(){
    return this.setUpBidParametersForm.get('SBP_start_date')
  }
  get SBP_end_date(){
    return this.setUpBidParametersForm.get('SBP_end_date')
  }
  // get SBP_Schedule_start_date(){
  //   return this.setUpBidParametersForm.get('SBP_Schedule_start_date')
  // }
  // get SBP_Schedule_end_date(){
  //   return this.setUpBidParametersForm.get('SBP_Schedule_end_date')
  // }
  get SBP_select_shiftline_schedule(){
    return this.setUpBidParametersForm.get('SBP_select_shiftline_schedule')
  }
  get SBP_select_qualification(){
    return this.setUpBidParametersForm.get('SBP_select_qualification')
  }
  get SBP_select_employees(){
    return this.setUpBidParametersForm.get('SBP_select_employees')
  }
  getAllBidSchedule(){
    this.bidService.getAllBidSchedule(this.user_data.id).subscribe((res)=>{
      // console.log(res)
      this.allBidScheduleNumbers=this.multiDimensionalUniqueForBidSchedule(res).length;
      this.allBidScheduleNumbers++
      if(this.setUpBidScheduleOne==null){
        this.setUpBidParametersForm.controls.SBP_schedule_name.setValue('MySchedule_'+this.user_data.id+0+this.allBidScheduleNumbers)
      }
      // console.log(this.allBidScheduleNumbers)
     },(err)=>{
       console.log(err)
     },()=>{})
  }
   multiDimensionalUniqueForBidSchedule(arr) {


    var uniques = [];
    var itemsFound = {};
    for(var i = 0, l = arr.length; i < l; i++) {
        var stringified = JSON.stringify(arr[i]);
        if(itemsFound[stringified]) { continue; }
        uniques.push(arr[i]);
        itemsFound[stringified] = true;
    }
    var tempArr=[]
    for(var i=0;i<uniques.length;i++){
      var startDate=new Date(uniques[i].bidstartdate)
      startDate.setDate(startDate.getDate() + 1);
      var endDate=new Date(uniques[i].bidscheduleenddate)
      endDate.setDate(endDate.getDate() + 1);
      var finalObj={'bid_schedule_name':uniques[i].bidschedulename,'schedule_start_date':startDate,'schedule_end_date':endDate,'setUpBidParameter':uniques[i].paramsavestatus,'leaveSetUp':uniques[i].leavesavestatus,'bidRound':uniques[i].roundsavestatus}
      tempArr.push(finalObj)
    }
    var dates=[],tempFinalArr=[]
    for(var i=0;i<tempArr.length;i++){
      var dates=[]
      for(var j=0;j<tempArr.length;j++){
        if(tempArr[i].bid_schedule_name==tempArr[j].bid_schedule_name){
          dates.push(new Date(tempArr[j].schedule_end_date))
          var maxDate=new Date(Math.max.apply(null,dates));
        }
      }
      tempFinalArr.push({'bid_schedule_name':uniques[i].bidschedulename,'schedule_start_date':startDate,'schedule_end_date':maxDate,'setUpBidParameter':uniques[i].paramsavestatus,'leaveSetUp':uniques[i].leavesavestatus,'bidRound':uniques[i].roundsavestatus})
    }
    var finalArr=tempFinalArr.filter((v,i,a)=>a.findIndex(t=>(t.bid_schedule_name === v.bid_schedule_name))===i)
    return finalArr.reverse();;
}
setUPBidParameterStepOne(){

}

  scheduleShiftLine(){
    // console.log(this.setUpBidParametersForm.value)
    this.checkDisable()
    if(this.setUpBidParametersForm.value.SBP_select_shiftline_schedule=="New Schedule"){
      console.log("New Schedule")
    }else if(this.setUpBidParametersForm.value.SBP_select_shiftline_schedule=="Import Schedule"){
      console.log("Import Schedule")
    }
  }

  // submit(data){
  //   console.log(this.setUpBidParametersForm.value)
  //   localStorage.setItem('all_slots',JSON.stringify(this.all_slots))
  //   this.navCtrl.navigateForward([straightlines_io_apis.apis.setUp_bid_parameters_step_2])
  // }
  async next(data){

    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      // header: 'Confirm!',
      message: 'Do you want to add another Shiftline Schedule?',
      buttons: [
        {
          text: 'No',

          // cssClass: 'secondary',
          handler: () => {
            this.curBidScheduleNameSer.changeBidScheduleName( this.setUpBidParametersForm.value.SBP_schedule_name )
            this.navCtrl.navigateForward([straightlines_io_apis.apis.setUp_bid_parameters_step_2])
            // this.navCtrl.navigateBack([straightlines_io_apis.apis.manage_bid_schedule])
          }
        }, {
          text: 'Yes',
          role: 'cancel',
          handler: () => {

          }
        }
      ]
    });

    await alert.present();
  }
  async submit(){
    var bid_schedule_data
    if(this.checkForEditSchedule==true){
       bid_schedule_data={"SBP_schedule_name":this.setUpBidParametersForm.value.SBP_schedule_name,
      // "SBP_start_date":this.setUpBidParametersForm.value.SBP_start_date,
      "SBP_select_qualification":this.setUpBidParametersForm.value.SBP_select_qualification,
      "SBP_select_shiftline_schedule":this.setUpBidParametersForm.value.SBP_select_shiftline_schedule,
      "SBP_select_employees":this.setUpBidParametersForm.value.SBP_select_employees,
      "edit":this.checkForEditSchedule,
      "checkShiftLineScheduleForEdit":this.checkShiftLineScheduleForEdit
    }
  }else{
    bid_schedule_data={"SBP_schedule_name":this.setUpBidParametersForm.value.SBP_schedule_name,
    // "SBP_start_date":this.setUpBidParametersForm.value.SBP_start_date,
    "SBP_select_qualification":this.setUpBidParametersForm.value.SBP_select_qualification,
    "SBP_select_shiftline_schedule":this.setUpBidParametersForm.value.SBP_select_shiftline_schedule,
    "SBP_select_employees":this.setUpBidParametersForm.value.SBP_select_employees,
    "checkShiftLineScheduleForEdit":false
  }
  }
    // this.navCtrl.navigateForward('add-new-shift-definition')
    // console.log(bid_schedule_data)
    if(bid_schedule_data.SBP_select_shiftline_schedule!='' &&this.setUpBidParametersForm.value.SBP_select_qualification!=''&&this.setUpBidParametersForm.value.SBP_start_date!=''&&this.setUpBidParametersForm.value.SBP_select_employees!=''){
    const modal = await this.modalCtrl.create({
      component: PartOneStepTwoComponent,
      componentProps: { bid_schedule_data:bid_schedule_data, all_schedule_data:this.allScheduleData},
      cssClass: 'setUpBidParametersPartOne',
      swipeToClose:true
    });
    modal.onDidDismiss()
    .then((data) => {
      // console.log(data)
      if(data.data==undefined){
        localStorage.setItem('setUpBidScheduleOne',JSON.stringify(bid_schedule_data))
        this.checkShiftLineScheduleForEdit=false
      // this.schedulename=this.setUpBidParametersForm.value.SBP_schedule_name
      // this.bidScheduleData={"bid_schedule_name":this.setUpBidParametersForm.value.SBP_schedule_name,
      // "bid_schedule_start_date":this.setUpBidParametersForm.value.SBP_start_date,
      // "select_qualification":this.setUpBidParametersForm.value.SBP_select_qualification,
      // "select_shiftline_schedule_name":this.setUpBidParametersForm.value.SBP_select_shiftline_schedule,
      // "select_employess":this.setUpBidParametersForm.value.SBP_select_employees}
      this.checkDisable()
      this.allShceduleBasedOnBidScheduleName()
      this.ngOnInit()
      }

  });

    return await modal.present();
}else{
    if(this.setUpBidParametersForm.value.SBP_schedule_name=='')
    {
      return this.checkShiftLineBidSchedule=true

    }else if(this.setUpBidParametersForm.value.SBP_select_employees==''){
        return this.checkShiftLineSchedule=true
    }else if(this.setUpBidParametersForm.value.SBP_start_date==''){
      return  this.checkShiftLineStartDate=true
    }
    // else if(this.setUpBidParametersForm.value.SBP_select_qualification==''){
    //   return this.checkShiftLineQualification=true
    // }
  }
}
  getSchedule(){
    var tempObj={}
    var tempArr=[]
    var all_shift_data=[]
    this.scheduleService.getScheduleNameBasedOnId(this.user_data.id).subscribe(
      (res)=>{
        // console.log(res)
      },(err)=>{},()=>{}
    )

    this.scheduleService.getAllSchedule().subscribe((res)=>{
      for(var i=0;i<res.length;i++){
        if(Number(this.user_data.id)===Number(res[i].userid)){

          tempArr.push(res[i])
        }
      }
       this.getAllScheduleName=[]
      for(var i=0;i<tempArr.length;i++){
        for(var j=0;j<tempArr.length;j++){
          if(this.getAllScheduleName[i]!==tempArr[j].schedulename){
            this.getAllScheduleName.push(tempArr[j].schedulename)

          }
        }
      }var unique = this.getAllScheduleName.filter(this.onlyUnique);
      this.select_shiftline_schedule=unique
      this.select_shiftline_schedule.push("Custom Schedule")

})
}
  onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
  }
  async addEmployee(){
    const modal = await this.modalCtrl.create({
      component: AddNewEmployeeComponent,
      cssClass: '',
      swipeToClose:true
    });
    modal.onDidDismiss()
    .then((data) => {
  });

  return await modal.present();
    // this.navCtrl.navigateForward([straightlines_io_apis.apis.add_new_employee])

  }
  checkBidScheduleName(){
    if(this.checkForEditSchedule!==true){
    var b_schedule_name=this.setUpBidParametersForm.value.SBP_schedule_name
    this.bidService.checkBidScheduleName(b_schedule_name).subscribe((res)=>{
      if(res['message']=="Bid Schedule name Exist") {
        return this.checkBidSchedule_Name=true
      }else{
          return this.checkBidSchedule_Name=false
      }
    },
    (err)=>{      console.log(err)},()=>{})
  }
  }
  updateBidScheduleName(){
    return this.checkBidSchedule_Name=false,this.checkShiftLineBidSchedule=false;
  }
  allQualification(){
    this.qualifiaction_name.getAllQualification().subscribe(
      (res)=>{this.all_qualification=res
      },
      (err)=>{console.log(err)},()=>{
      })

  }
  allEmp(){
      this.getAllEmp.getAllEmployeeBasedOnUserId(this.user_data.id).subscribe(
        (res)=>{this.allEmployee=res},
        (err)=>{console.log(err)},()=>{})
  }
  updateQualification(){
        var selectedQualification=this.setUpBidParametersForm.value.SBP_select_qualification
        if(this.setUpBidParametersForm.value.SBP_select_qualification==''||this.setUpBidParametersForm.value.SBP_select_qualification==null||this.setUpBidParametersForm.value.SBP_select_qualification==undefined){
          this.getAllEmp.getAllEmployee().subscribe(
            (res)=>{this.allEmployee=res},
            (err)=>{console.log(err)},()=>{
            }
          )}else{
            this.getAllEmp.getAllEmployeeBasedOnQualification(selectedQualification).subscribe(
              (res)=>{this.allEmployee=res},
              (err)=>{console.log(err)},()=>{
              })
          }
          this.checkDisable()
  }
  allShceduleBasedOnBidScheduleName(){
    var b_schedule_name=this.setUpBidParametersForm.value.SBP_schedule_name
    if(b_schedule_name!==''){
      this.bidService.getScheduleNameBasedOnBidScheduleName(b_schedule_name).subscribe(
        (res)=>{
          this.allScheduleData=[]
          this.allScheduleData=res
          this.multiDimensionalUnique(res)
      },
      (err)=>{console.log(err)},
      ()=>{})}
  }
  multiDimensionalUnique(data) {
    var resArr = [];
    data.filter(function(item){
      var i = resArr.findIndex(x => (x.bidschedulename == item.bidschedulename && x.schedulename == item.schedulename && x.bidschedulestartdate == item.bidschedulestartdate&& x.bidscheduleenddate == item.bidscheduleenddate&& x.bidstartdate == item.bidstartdate));
      if(i <= -1){
            resArr.push(item);
      }
      return null;
    });
    this.all_final_data=resArr
  }
  checkValuesforEmployee(e){
    var temp=[]
    this.checkShiftLineSchedule=false
    temp=e.value
    if(temp.length>0){
      this.checkT(temp)
    }
  }
  async checkT(data){
    for(var i=0;i<data.length;i++){
      if(String(data[i])=='addnewemployee'){
        if(this.checkForEditSchedule==true){
          var temp1={
          "SBP_schedule_name":this.setUpBidParametersForm.value.SBP_schedule_name,
          "SBP_start_date":this.setUpBidParametersForm.value.SBP_start_date,
          "SBP_select_shiftline_schedule":this.setUpBidParametersForm.value.SBP_select_shiftline_schedule,
          "SBP_select_qualification":this.setUpBidParametersForm.value.SBP_select_qualification,
          "SBP_select_employees":this.setUpBidParametersForm.value.SBP_select_employees,
          "edit":true}
          localStorage.setItem('setUpBidScheduleOne',JSON.stringify(temp1))
        }else{
          localStorage.setItem('setUpBidScheduleOne',JSON.stringify(this.setUpBidParametersForm.value))
        }
        return this.navCtrl.navigateForward([straightlines_io_apis.apis.add_new_employee])
      //   const modal = await this.modalCtrl.create({
      //     component: AddNewEmployeeComponent,
      //     cssClass: 'add-emp',
      //     swipeToClose:true
      //   });
      //   modal.onDidDismiss()
      //   .then((data) => {
      // });

      // return await modal.present();
      }
    }
  }

  checkDisable(){
    this.checkShiftLineSchedule=false
    this.checkShiftLineQualification=false
    this.checkShiftLineBidSchedule=false
    this.checkShiftLineStartDate=false
  }

  async checkSch(){
    var tempArr=[],temp=''
    tempArr=this.setUpBidParametersForm.value.SBP_select_shiftline_schedule
      for(var i=0;i<tempArr.length;i++){
        if(String(tempArr[i])==='Custom Schedule'){
            if(this.checkForEditSchedule==true){
              var temp1={
              "SBP_schedule_name":this.setUpBidParametersForm.value.SBP_schedule_name,
              "SBP_start_date":this.setUpBidParametersForm.value.SBP_start_date,
              "SBP_select_shiftline_schedule":this.setUpBidParametersForm.value.SBP_select_shiftline_schedule,
              "SBP_select_qualification":this.setUpBidParametersForm.value.SBP_select_qualification,
              "SBP_select_employees":this.setUpBidParametersForm.value.SBP_select_employees,
              "edit":true}
              localStorage.setItem('setUpBidScheduleOne',JSON.stringify(temp1))
            }else{
              localStorage.setItem('setUpBidScheduleOne',JSON.stringify(this.setUpBidParametersForm.value))
            }

            temp='Custom Schedule'
            const actionSheet = await this.actionSheetController.create({
            cssClass: 'my-custom-class',
            buttons: [{
              text: 'New Schedule',
              handler: () => {
                return this.navCtrl.navigateForward([straightlines_io_apis.apis.enter_Work_load])
              }
            },
            //  {
              // text: 'Import Schedule',
              // handler: () => {
              //   this.customSchedule()
              // }
            // },
            {
              text: 'Cancel',
              icon: 'close',
              role: 'cancel',
              handler: () => {
              }
            }]
          });
          await actionSheet.present();
          const { role } = await actionSheet.onDidDismiss();
        }
      }
      if(temp==''){
        return this.submit()
      }
  }
  async customSchedule(){
    const modal = await this.modalCtrl.create({
      component: CustomSchedulePopupComponent,
      cssClass: 'ImportScheduleModal',
      swipeToClose:true
    });
    modal.onDidDismiss()
    .then((data) => {
  });

  return await modal.present();
}
  customScheduleUsingStApp(){
      return this.navCtrl.navigateForward([straightlines_io_apis.apis.enter_Work_load_api])
  }

  async deleteBidSchedule(index){
    const confirm = await this.alertCtrl.create({
      header: 'Are you sure?',
      message: 'Are you sure you want to delete the record?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            // console.log('Confirm Cancel');
          }
        },
        {
          text: 'Delete',
          role: 'delete',
          handler: () => {
            this.bidService.deleteShiftLineScheduleInBidScheduleBasedOnShcedulenameNameAndBidScheduleName(index.schedulename,index.bidschedulename).subscribe((res)=>{
              // console.log(res),
              this.allShceduleBasedOnBidScheduleName()},
            (err)=>{console.log(err)},()=>{})
          }
        }]
        })
        await confirm.present();
  }

  updateBidSchedule(index){
    // console.log(index)
    // console.log(this.allScheduleData)
    var tempArr=[]
    this.checkShiftLineScheduleForEdit=true
    // this.getAllEmp.getAllEmployeeBasedOnShiftlineAndBidScheduleName(index.schedulename,index.bidschedulename).subscribe((res)=>{
    //   console.log(res)
    // },
    //   (err)=>{console.log(err)},
    //   ()=>{})
    for(var i=0;i<this.allScheduleData.length;i++){
      if(this.allScheduleData[i].schedulename===index.schedulename){
        tempArr.push(Number(this.allScheduleData[i].employee))
      }
    }

    this.setUpBidParametersForm.controls.SBP_select_employees.setValue(tempArr)
    this.setUpBidParametersForm.controls.SBP_select_shiftline_schedule.setValue([index.schedulename])
    this.submit()

  }
}
