import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { NavController, AlertController, ModalController } from '@ionic/angular';
import { HeaderTitleService } from 'src/app/dashboard/nav-bar-footer/header-title.service';
import { BidLeaveSetupService } from 'src/app/services/manage-bid-schedule/bid-schedule/bid-leave-setup.service';
import { SetupBidRoundService } from 'src/app/services/manage-bid-schedule/bid-schedule/setup-bid-round.service';
import { PassBidScheduleNameService } from 'src/app/services/manage-bid-schedule/pass-bid-schedule-name.service';
import { SetUpBidParametersService } from '../service/set-up-bid-parameters.service';
import straightlines_io_apis from 'src/app/json/apis.json';
import { BidScheduleService } from 'src/app/services/manage-bid-schedule/bid-schedule/bid-schedule.service';
import { SetUpBidLeaveService } from 'src/app/services/manage-bid-schedule/bid-schedule/set-up-bid-leave.service';
import { SelectedEmployeeModalComponent } from '../../selected-employee-modal/selected-employee-modal.component';
import { AddNewEmployeeService } from 'src/app/services/manage-bid-schedule/add-new-employee/add-new-employee.service';
import { SelectedShiftlineScheduleModalComponent } from '../../selected-shiftline-schedule-modal/selected-shiftline-schedule-modal.component';
@Component({
  selector: 'app-set-up-bid-parameters-summary',
  templateUrl: './set-up-bid-parameters-summary.component.html',
  styleUrls: ['./set-up-bid-parameters-summary.component.scss'],
})
export class SetUpBidParametersSummaryComponent implements OnInit {
  currentBidScheduleName: string;
  user_data: any;
  expand_id: any;
  totalLeave
  setUpBidScheduleOne: any;
  totalBidRound
bidPara
allSchedule=[]
allEmployee=[]
  all_slots: any[];
  all_SBP_rounds: any[];
  expand_id_data: any;
  bidding_start_date: any;
  constructor(
    public navCtrl: NavController,
    private headerTitleService: HeaderTitleService,
    private sbpHeaderService:SetUpBidParametersService,
    private fb:FormBuilder,
    private getAllEmp:AddNewEmployeeService,
    private bidService:BidScheduleService,
    private bidLeaveSer:SetUpBidLeaveService,
    public alertController: AlertController,
    private curBidScheduleNameSer:PassBidScheduleNameService,
    private bidLeaveSetupSer:BidLeaveSetupService,
    public modalCtrl: ModalController,
    private setUPbidRoundSer:SetupBidRoundService
  ) { }

  ngOnInit() {
    this.headerTitleService.setTitle('Manage Bid Parameters');
    this.headerTitleService.setDefaultHeader(false)
    this.headerTitleService.setBackUrl(straightlines_io_apis.apis.setUp_bid_parameters_step_3);
    this.headerTitleService.setForwardUrl(null);
    this.sbpHeaderService.setTitle('step-3')
    this.user_data=JSON.parse(localStorage.getItem('userData'))
    this.setUpBidScheduleOne=JSON.parse(localStorage.getItem('setUpBidScheduleOne'))
    if(this.setUpBidScheduleOne==null){
      this.navCtrl.navigateBack([straightlines_io_apis.apis.setUp_bid_parameters])
      console.log(this.setUpBidScheduleOne)
    }else{
      this.currentBidScheduleName=this.setUpBidScheduleOne.SBP_schedule_name
    this.allShceduleBasedOnBidScheduleName()
    this.getAllPTLDataBasedOnBidScheduleName()
    this.getAllBidRoundBasedOnBidScheduleName()

    }
  }
  expand(index){
    if(this.expand_id==index){
      this.expand_id=null
    }else{
      this.expand_id=index
    }
  }
  expandlist(i){
    if(this.expand_id==i){
      return 'expand'
    }else{
      return 'default-expand'
    }
  }
  confirm(){
    localStorage.removeItem('setUpBidScheduleOne')
    this.navCtrl.navigateForward([straightlines_io_apis.apis.manage_bid_schedule])
  }
  allShceduleBasedOnBidScheduleName(){

    this.getAllEmp.getAllEmployeeBasedOnUserId(this.user_data.id).subscribe(
      (res)=>{this.allEmployee=res
      // console.log(this.allEmployee)

    },
      (err)=>{console.log(err)},()=>{
        // this.ngOnInit()
        // console.log(this.allEmployee)
      }
    )
    // console.log(b_schedule_name)
    // console.log(this.schedulename)
    this.bidService.getScheduleNameBasedOnBidScheduleName(this.setUpBidScheduleOne.SBP_schedule_name).subscribe(
      (res)=>{
        // console.log(res)
        var resArr = [];
        res.filter(function(item){
  var i = resArr.findIndex(x => (x.schedulename == item.schedulename));
  if(i <= -1){
        resArr.push(item);
  }
  return null;
});
// console.log(resArr)
// console.log(resArr.length)
        var temp=this.multiDimensionalUnique(res)
        // console.log(temp)
        this.bidPara={
          "BidScheduleName":this.setUpBidScheduleOne.SBP_schedule_name,
          "startDate":temp[0].schedule_start_date,
          "endDate":temp[0].schedule_end_date,
          "selectedEmp":this.setUpBidScheduleOne.SBP_select_employees.length,
          "selectedShiftLineSchedule":resArr.length,

        }
        // console.log(this.bidPara)
        this.allSchedule=resArr
        // console.log(resArr)
      },
      (err)=>{console.log(err)},
      ()=>{}
    )
  }

  getAllPTLDataBasedOnBidScheduleName(){

    this.bidLeaveSer.getAllLeaveBasedOnScheduleName(this.setUpBidScheduleOne.SBP_schedule_name).subscribe(
        (res)=>{
      //  console.log(res)
          this.totalLeave=res.length
        this.all_slots=[]
        this.all_slots=res
        },
        (err)=>{console.log(err)},
        ()=>{},
      )

  }
  getAllBidRoundBasedOnBidScheduleName(){
    this.setUPbidRoundSer.getAllBidRoundBasedOnBidScheduleName(this.setUpBidScheduleOne.SBP_schedule_name).subscribe(
      (res)=>{
        this.totalBidRound=res.length
        this.all_SBP_rounds=[]
        this.all_SBP_rounds=res

        // console.log(this.all_SBP_rounds)
        // console.log(this.all_SBP_rounds)
        // var start_Date_bid ,startDate,tempArr=[],bidDate
        //       for(var i=0;i<this.all_SBP_rounds.length;i++){
        //         startDate =this.all_SBP_rounds[i].bidroundstartdate.split("-");
        //         start_Date_bid = new Date(startDate[0],Number(startDate[1])+ - +1, startDate[2],0 ,0, 0);
        //         tempArr.push(start_Date_bid)
        //       bidDate=new Date(Math.min.apply(null,tempArr));
        //       }
        //       console.log(bidDate)
        //       this.bidding_start_date=bidDate
      },
      (err)=>{console.log(err)},
      ()=>{},
    )

}
multiDimensionalUnique(arr) {


  var uniques = [];
  var itemsFound = {};
  for(var i = 0, l = arr.length; i < l; i++) {
      var stringified = JSON.stringify(arr[i]);
      if(itemsFound[stringified]) { continue; }
      uniques.push(arr[i]);
      itemsFound[stringified] = true;
  }
  var tempArr=[]
// console.log(uniques)
  for(var i=0;i<uniques.length;i++){
    var startUniques =uniques[i].bidstartdate.split("-");
    var start_Date_uniques = new Date(startUniques[0],Number(startUniques[1])+ - +1, startUniques[2],0 ,0, 0);
    // start_Date_uniques.setDate(startDate.getDate() + 1);
    var endUniques =uniques[i].bidscheduleenddate.split("-");
    var endDate = new Date(endUniques[0],Number(endUniques[1])+ - +1, endUniques[2],0 ,0, 0);
    // var endDate=new Date(uniques[i].bidscheduleenddate)
    // endDate.setDate(endDate.getDate() + 1);
    var finalObj={'bid_schedule_name':uniques[i].bidschedulename,'schedule_start_date':start_Date_uniques,'schedule_end_date':endDate}
    tempArr.push(finalObj)
  }
// console.log(tempArr)
  var dates=[],tempFinalArr=[]
  for(var i=0;i<tempArr.length;i++){
    var dates=[], startDates=[]
    for(var j=0;j<tempArr.length;j++){
      if(tempArr[i].bid_schedule_name==tempArr[j].bid_schedule_name){
        // var start =tempArr[j].schedule_start_date.split("-");
        // var start_Date = new Date(start[0],start[1], start[2],0 ,0, 0);
        dates.push(tempArr[j].schedule_end_date)
        startDates.push(tempArr[j].schedule_start_date)
        var maxDate=new Date(Math.max.apply(null,dates));
        var minDate=new Date(Math.min.apply(null,startDates));
      }
    }
    tempFinalArr.push({'bid_schedule_name':uniques[i].bidschedulename,'schedule_start_date':minDate,'schedule_end_date':maxDate})
  }
  var finalArr=tempFinalArr.filter((v,i,a)=>a.findIndex(t=>(t.bid_schedule_name === v.bid_schedule_name))===i)

  return finalArr.reverse();;
}
expandData(index){
  if(this.expand_id_data==index){
    this.expand_id_data=null
  }else{
    this.expand_id_data=index
  }
}
expandlistD(i){
  if(this.expand_id_data==i){
    return 'expand'
  }else{
    return 'default-expand'
  }
}
  async displayEmployee(){
    var tempArr=[]
    console.log(this.setUpBidScheduleOne.SBP_select_employees)
for(var i=0;i<this.allEmployee.length;i++){
  for(var j=0;j<this.setUpBidScheduleOne.SBP_select_employees.length;j++){
    if(this.setUpBidScheduleOne.SBP_select_employees[j]===this.allEmployee[i].id){
      tempArr.push(this.allEmployee[i])
    }
  }
}
console.log(tempArr)
const modal = await this.modalCtrl.create({
  component: SelectedEmployeeModalComponent,
  componentProps: {empList:tempArr},
  cssClass: 'ImportScheduleModal',
  swipeToClose:true
});
modal.onDidDismiss()
.then((data) => {
});

return await modal.present();
}
async displaySchedule(){

console.log(this.allSchedule)
const modal = await this.modalCtrl.create({
component: SelectedShiftlineScheduleModalComponent,
componentProps: {scheduleList:this.allSchedule},
cssClass: 'ImportScheduleModal',
swipeToClose:true
});
modal.onDidDismiss()
.then((data) => {
});

return await modal.present();
}
}
