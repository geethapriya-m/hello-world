import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatCalendarCellClassFunction } from '@angular/material/datepicker';
import { AlertController, NavController } from '@ionic/angular';
import { CalendarMode, Step } from 'ionic2-calendar/calendar';
import { HeaderTitleService } from 'src/app/dashboard/nav-bar-footer/header-title.service';
import straightlines_io_apis from 'src/app/json/apis.json';
import { BidLeaveSetupService } from 'src/app/services/manage-bid-schedule/bid-schedule/bid-leave-setup.service';
import { BidScheduleService } from 'src/app/services/manage-bid-schedule/bid-schedule/bid-schedule.service';
import { SetUpBidLeaveService } from 'src/app/services/manage-bid-schedule/bid-schedule/set-up-bid-leave.service';
import { PassBidScheduleNameService } from 'src/app/services/manage-bid-schedule/pass-bid-schedule-name.service';
import { SetUpBidParametersService } from '../service/set-up-bid-parameters.service';

@Component({
  selector: 'app-set-up-bid-parameters-part-two',
  templateUrl: './set-up-bid-parameters-part-two.component.html',
  styleUrls: ['./set-up-bid-parameters-part-two.component.scss'],
})
export class SetUpBidParametersPartTwoComponent implements OnInit {

  eventSource;
  viewTitle;
  dateValidation=false
  isToday:boolean;
  calendar = {
    mode: 'month' as CalendarMode,
    step: 25 as Step,
    currentDate: new Date(),
    dateFormatter: {
        formatMonthViewDay: function(date:Date) {
            return date.getDate().toString();
        },
        formatMonthViewDayHeader: function(date:Date) {
            return 'MonMH';
        },
        formatMonthViewTitle: function(date:Date) {
            return 'testMT';
        },
        formatWeekViewDayHeader: function(date:Date) {
            return 'MonWH';
        },
        formatWeekViewTitle: function(date:Date) {
            return 'testWT';
        },
        formatWeekViewHourColumn: function(date:Date) {
            return 'testWH';
        },
        formatDayViewHourColumn: function(date:Date) {
            return 'testDH';
        },
        formatDayViewTitle: function(date:Date) {
            return 'testDT';
        }
    }
};

currentBidScheduleName
  setUpBidParametersForm: FormGroup;
  // date: string;
  // type: 'string';
  // dateMulti: string[];
  select_shiftline_schedule=['Trimester1_Shiftline Schedule','Trimester2_Shiftline Schedule','Trimester3_Shiftline Schedule']
  select_qualification=['CPC','CPC1']
  select_employees=[{"employee_shortname":"MK","employee_name":"Mike Klupenger"},
  {"employee_shortname":"SS","employee_name":"Sushma Sharma"},
  {"employee_shortname":"RA","employee_name":"Ritu Arora"}]
 all_slots=[]
 ptl_periods
  user_data: any;
  setUpBidScheduleOne: any;
  minDateForBidRound: Date;
  maxDateForBidRound
//  optionsMulti: CalendarComponentOptions = {
//   pickMode: 'multi'
// };
// dateRange: { from: string; to: string; };
// optionsRange: CalendarComponentOptions = {
//   pickMode: 'range',
//         color:'danger'
// };
myHolidayDates = [
  new Date("12/1/2021"),
  new Date("12/20/2021"),
  new Date("12/17/2021"),
  new Date("12/25/2021"),
  new Date("12/4/2021"),
  new Date("12/7/2021"),
  new Date("12/12/2021"),
  new Date("12/11/2021"),
  new Date("12/26/2021"),
  new Date("12/25/2021")
];
dateClass: MatCalendarCellClassFunction<Date> = (cellDate, view) => {
  // Only highligh dates inside the month view.
  if (view === 'month') {
    const date = cellDate.getDate();

    // Highlight the 1st and 20th day of each month.
    return date === 1 || date === 20 ? 'example-custom-date-class' : '';
  }

  return '';
};
myFilter = (d: Date | null): boolean => {
  const day = (d || new Date()).getDay();
  // Prevent Saturday and Sunday from being selected.
  return day !== 0 && day !== 6;
};
myHolidayFilter = (d: Date): boolean => {
const time=d.getTime();
console.log(time)
return !this.myHolidayDates.find(x=>x.getTime()==time);
}
all_final_data=[]
  maxDateForBidLeave: Date;
  minDateForBidLeave: Date;
  constructor(
    public navCtrl: NavController,
    private headerTitleService: HeaderTitleService,
    private sbpHeaderService:SetUpBidParametersService,
    private fb:FormBuilder,
    private bidLeaveSer:SetUpBidLeaveService,
    public alertController: AlertController,
    private bidService:BidScheduleService,
    public alertCtrl: AlertController,
    private curBidScheduleNameSer:PassBidScheduleNameService,
    private bidLeaveSetupSer:BidLeaveSetupService
  ) { }

  ngOnInit() {

    this.headerTitleService.setTitle('Manage Bid Parameters');
    this.headerTitleService.setDefaultHeader(false)
    this.headerTitleService.setBackUrl(straightlines_io_apis.apis.setUp_bid_parameters);
    this.headerTitleService.setForwardUrl(null);
    this.sbpHeaderService.setTitle('step-2')
    this.user_data=JSON.parse(localStorage.getItem('userData'))

    this.setUpBidScheduleOne=JSON.parse(localStorage.getItem('setUpBidScheduleOne'))
    if(this.setUpBidScheduleOne==null){
     this.navCtrl.navigateBack([straightlines_io_apis.apis.setUp_bid_parameters])
      console.log(this.setUpBidScheduleOne)
    }else{
    this.currentBidScheduleName=this.setUpBidScheduleOne.SBP_schedule_name
    console.log(this.currentBidScheduleName)
    this.ptl_periods=0
    // this.getAllPTLData()
    this.getAllPTLDataBasedOnBidScheduleName()
    this.setUpBidParametersForm = this.fb.group({
      id:new FormControl("newid",Validators.compose([Validators.required])),
      SBP_start_date:new FormControl('',Validators.compose([Validators.required])),
      SBP_end_date:new FormControl('',Validators.compose([Validators.required])),
      SBP_slots:new FormControl('',Validators.compose([Validators.required, Validators.min(1), Validators.pattern('^[0-9]*$')])),
    })

  }
  }
get id(){
  return this.setUpBidParametersForm.get('id')
}
  get SBP_start_date(){
    return this.setUpBidParametersForm.get('SBP_start_date')
  }
  get SBP_end_date(){
    return this.setUpBidParametersForm.get('SBP_end_date')
  }
  get SBP_slots(){
    return this.setUpBidParametersForm.get('SBP_slots')
  }
  getAllPTLData(){
    this.bidLeaveSetupSer.getAllBidPtlLeave().subscribe(
      (res)=>{console.log(res)
        this.all_slots=[]
      this.all_slots=res
      this.ptl_periods=this.all_slots.length
      },
      (err)=>{console.log(err)},
      ()=>{},
    )
  }
  getAllPTLDataBasedOnBidScheduleName(){

    this.bidLeaveSer.getAllLeaveBasedOnScheduleName(this.currentBidScheduleName).subscribe(
        (res)=>{
          this.all_slots=[]
        this.all_slots=res
          console.log(this.all_slots)
        // if(this.all_slots.length<1){
          this.allShceduleBasedOnBidScheduleName()
        // }else{
          // this.getMaxDate()
        // }
        this.ptl_periods=this.all_slots.length
        },
        (err)=>{console.log(err)},
        ()=>{},
      )

  }
  scheduleShiftLine(){
  }
  async submit(data){

    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      // header: 'Confirm!',
      message: 'Do you want to add another Leave slots ?',
      buttons: [
        {
          text: 'No',

          // cssClass: 'secondary',
          handler: (blah) => {
            this.curBidScheduleNameSer.changeBidScheduleName( this.currentBidScheduleName)
            this.navCtrl.navigateForward([straightlines_io_apis.apis.setUp_bid_parameters_step_3])
          }
        }, {
          text: 'Yes',
          role: 'cancel',
          handler: () => {

          }
        }
      ]
    });

    await alert.present();
  }
  formatDate(date) {
    var d = new Date(date),

        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();
    if (month.length < 2){
        month = '0' + month;
    }
    if (day.length < 2)
    {
        day = '0' + day;
      }
    return [month,day,year].join('/');
}
  add(data){
    // console.log(this.setUpBidParametersForm.value)
    // this.ngOnInit()
    var start_date=this.setUpBidParametersForm.value.SBP_start_date
    var end_date=this.setUpBidParametersForm.value.SBP_end_date

    var new_ptl_periods={ "leavestartdate":start_date,"leaveenddate":end_date,"slots":this.setUpBidParametersForm.value.SBP_slots,"bidschedulenameref":this.currentBidScheduleName,"useridref":this.user_data.id,"leavesavestatus":1}
    var minDate ,current_start_Date,differentTime,chc,count=0
    var maxDate ,current_end_Date,differentDays
    this.dateValidation=false
          // for(var i=0;i<this.all_slots.length;i++){

          //   minDate= (new Date(new Date(this.all_slots[i].leavestartdate).setDate(new Date(this.all_slots[i].leavestartdate).getDate()+1 )))
          //   maxDate = (new Date(new Date(this.all_slots[i].leaveenddate).setDate(new Date(this.all_slots[i].leaveenddate).getDate()+1 )))
          //   differentTime = Math.abs(maxDate - minDate);
          //   current_start_Date=new Date(new_ptl_periods.leavestartdate)
          //   current_end_Date=new Date(new_ptl_periods.leaveenddate)
          //   if (current_end_Date >= minDate && current_start_Date <= maxDate){
          //     return this.dateValidation=true
          //   }else if(current_end_Date <= minDate && current_start_Date >= maxDate){
          //     return this.dateValidation=true
          //   }
          //   else if(current_start_Date >= minDate && current_end_Date <= maxDate){
          //     return this.dateValidation=true
          //   }
          //   else if(current_start_Date <= minDate && current_end_Date >= maxDate){
          //     return this.dateValidation=true
          //   }
          //   else if( current_start_Date == maxDate){
          //     return this.dateValidation=true
          //   }
          // }
          if(this.dateValidation==false){
            this.bidLeaveSer.addNewLeave(new_ptl_periods).subscribe((res)=>{
              this.ngOnInit()
              this.bidService.getScheduleNameBasedOnBidScheduleName(this.currentBidScheduleName).subscribe((res)=>{
                var tempArr=[],temp
                tempArr=res
                for(var i=0;i<tempArr.length;i++){
                  if(tempArr[i].leavesavestatus==0){
                  temp={
                    "bidid": tempArr[i].bidid,
                    "bidscheduleenddate":tempArr[i].bidscheduleenddate,
                    "bidschedulename": tempArr[i].bidschedulename,
                    "bidschedulestartdate": tempArr[i].bidschedulestartdate,
                    "bidstartdate": tempArr[i].bidstartdate,
                    "employee":tempArr[i].employee,
                    "leavesavestatus":1,
                    "paramsavestatus": tempArr[i].paramsavestatus,
                    "qualifiction": tempArr[i].qualifiction,
                    "roundsavestatus": tempArr[i].roundsavestatus,
                    "schedulename": tempArr[i].schedulename,
                    "userid": tempArr[i].userid
                  }
                  this.bidService.updateBidSchedule(this.currentBidScheduleName,temp).subscribe((res)=>{console.log(res)},
                  (err)=>{console.log(err)},()=>{})
                }
                }
              },(err)=>{console.log(err)},()=>{})
            },(err)=>{
              console.log(err)
            },()=>{})

          }









  }
  updateWorkLoad(){
    this.dateValidation=false
  }
  getMaxDate(){
    var tempArr=[],tempAr=[]
    for(var i=0;i<this.all_slots.length;i++){
      tempArr.push(new Date(this.all_slots[i].leavestartdate))
      tempArr.push(new Date(this.all_slots[i].leaveenddate))
      tempArr.push(new Date(new Date(this.all_slots[i].leavestartdate).setDate(new Date(this.all_slots[i].leavestartdate).getDate() + 1)))
      tempArr.push (new Date(new Date(this.all_slots[i].leaveenddate).setDate(new Date(this.all_slots[i].leaveenddate).getDate()+1 )))

    }
    var maxDate=new Date(Math.max.apply(null,tempArr));
    this.minDateForBidRound=(new Date(new Date(maxDate).setDate(new Date(maxDate).getDate() + 1)))
  }
  getMaxMinDefDate(){
    var tempArr=[]
    for(var i=0;i<this.all_final_data.length;i++){
      tempArr.push(new Date(new Date(this.all_final_data[i].bidschedulestartdate).setDate(new Date(this.all_final_data[i].bidschedulestartdate).getDate()+1 )))
      tempArr.push(new Date(new Date(this.all_final_data[i].bidscheduleenddate).setDate(new Date(this.all_final_data[i].bidscheduleenddate).getDate()+1 )))

    }
    var maxDate=new Date(Math.max.apply(null,tempArr));
    var minDate=new Date(Math.min.apply(null,tempArr));
    this.minDateForBidLeave=minDate
    this.maxDateForBidLeave=maxDate
  }
  allShceduleBasedOnBidScheduleName(){

    this.bidService.getScheduleNameBasedOnBidScheduleName(this.currentBidScheduleName).subscribe(
      (res)=>{
        // console.log(res)
        this.multiDimensionalUnique(res)

      },
      (err)=>{console.log(err)},
      ()=>{}
    )
  }
  multiDimensionalUnique(data) {
    var resArr = [];
data.filter(function(item){
  var i = resArr.findIndex(x => (x.bidschedulename == item.bidschedulename && x.schedulename == item.schedulename && x.bidschedulestartdate == item.bidschedulestartdate&& x.bidscheduleenddate == item.bidscheduleenddate&& x.bidstartdate == item.bidstartdate));
  if(i <= -1){
        resArr.push(item);
  }
  return null;
});

this.all_final_data=resArr
// console.log(this.all_final_data)
this.getMaxMinDefDate()
}
  async deleteBidLeave(index){
  console.log(index)
  const confirm = await this.alertCtrl.create({
    header: 'Are you sure?',
    message: 'Are you sure you want to delete the record?',
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel',
        handler: () => {
          // console.log('Confirm Cancel');
        }
      },
      {
        text: 'Delete',
        role: 'delete',
        handler: () => {

        this.bidLeaveSer.deleteBidLeaveBasedOnId(index.leavelid).subscribe((res)=>{
          console.log(res)
            this.ngOnInit()
        },(err)=>{console.log(err),
                  this.ngOnInit()},()=>{})


        }
      }]
      })
      await confirm.present();


}
    updateBidLeave(index){
      console.log(index)
      var startDate,start,endDate,end
      startDate = index.leavestartdate.split("-")
            startDate=new Date(startDate[0],Number(startDate[1])+ -+1,startDate[2],0,0,0)
            endDate = index.leaveenddate.split("-")
            endDate=new Date(endDate[0],Number(endDate[1])+ -+1,endDate[2],0,0,0)
      this.setUpBidParametersForm.setValue({
        id:index.leavelid,
      SBP_start_date:startDate,
      SBP_end_date:endDate,
      SBP_slots:index.slots
      })
    }
    update(){
      console.log(this.setUpBidParametersForm.value)
      var id=this.setUpBidParametersForm.value.id
      var start_date=this.setUpBidParametersForm.value.SBP_start_date
    var end_date=this.setUpBidParametersForm.value.SBP_end_date

    var new_ptl_periods={"leavelid":id, "leavestartdate":start_date,"leaveenddate":end_date,"slots":this.setUpBidParametersForm.value.SBP_slots,"bidschedulenameref":this.currentBidScheduleName,"useridref":this.user_data.id,"leavesavestatus":1}
      this.bidLeaveSer.updateBidLeave(id,new_ptl_periods).subscribe((res)=>{
        console.log(res)
        this.ngOnInit()
      },(err)=>{console.log(err),()=>{}})
    }
}
