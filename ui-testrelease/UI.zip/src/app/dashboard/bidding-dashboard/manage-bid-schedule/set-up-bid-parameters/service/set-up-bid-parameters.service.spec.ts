import { TestBed } from '@angular/core/testing';

import { SetUpBidParametersService } from './set-up-bid-parameters.service';

describe('SetUpBidParametersService', () => {
  let service: SetUpBidParametersService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SetUpBidParametersService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
