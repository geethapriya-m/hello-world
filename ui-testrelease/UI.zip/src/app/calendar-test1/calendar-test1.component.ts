import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { MyBiddingService } from '../dashboard/bidding-dashboard/my-bidding-dashboard/my-bidding.service';
import { HeaderTitleService } from '../dashboard/nav-bar-footer/header-title.service';
import straightlines_io_apis from 'src/app/json/apis.json';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-calendar-test1',
  templateUrl: './calendar-test1.component.html',
  styleUrls: ['./calendar-test1.component.scss'],
})
export class CalendarTest1Component implements OnInit {
value=1
  cal_id: any;
  constructor(
    public navCtrl: NavController,
    private myBiddingSer:MyBiddingService,
    private cdref: ChangeDetectorRef,
    private activaRouter: ActivatedRoute,
    private headerTitleService: HeaderTitleService
  ) {
   }

  ngOnInit() {
    this.headerTitleService.setTitle('Calendar');
    this.headerTitleService.setDefaultHeader(true)
    this.headerTitleService.setBackUrl(straightlines_io_apis.apis.my_bidding);
      this.headerTitleService.setForwardUrl(null);
  }
  changeValue(e){
    this.value=e.detail.value
    console.log(this.value)
  }
  next(){
    // console.log(straightlines_io_apis.apis.cal_test_two+'/'+this.value)
    this.navCtrl.navigateForward([straightlines_io_apis.apis.cal_test_two+'/'+this.value])
  }
}
