import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { RequiredWorkforce } from '../model/requiredWorkforce';
import { ScheduleData } from '../model/ScheduleData';
import straightlines_io_python_apis from 'src/app/json/apis.json';
@Injectable({
  providedIn: 'root'
})
export class RequiredWorkforceService {
  test:any []=[]
  test1:any []=[]


// private _url:string ="http://127.0.0.1:5000/schedule"
// private _url:string ="http://52.14.8.217:5000/schedule"

private _url:string =straightlines_io_python_apis.python_apis.url

  constructor(private http: HttpClient) { }
  postRequiredWorkforceData(row: number,requiredWorkforceData: any): Observable<RequiredWorkforce[]>{
  // postRequiredWorkforceData(requiredWorkforceData: any): Observable<RequiredWorkforce[]>{
    // console.log(requiredWorkforceData)
    // console.log(this._url+'/'+row)
    // return this.http.post<RequiredWorkforce[]>(this._url,requiredWorkforceData)
    return this.http.post<RequiredWorkforce[]>(this._url+'/schedule/'+row,requiredWorkforceData)

  }
  importExcelSheet(file){
      return this.http.post(this._url+'/parse_user_schedule',file, {
        // reportProgress: true,
        // observe: 'events'
      })}
  errorHandler(errorHandler: any): import("rxjs").OperatorFunction<RequiredWorkforce[], RequiredWorkforce[]> {
    throw new Error('Method not implemented.');
  }

      // getRequiredWorkforceDataById(row: number,requiredWorkforceData: any): Observable<RequiredWorkforce[]>{
      //   return this.http.post<RequiredWorkforce[]>(this._url+'/'+row,requiredWorkforceData)
      // }
      // addRequiredWorkforceData(requiredWorkforceData: any): Observable<RequiredWorkforce[]>{
      //   const body=JSON.stringify(requiredWorkforceData);
      //   console.log(requiredWorkforceData)
      //   return this.http.post<RequiredWorkforce[]>(this.url ,requiredWorkforceData)
      // }
      // updateRequiredWorkforceData(requiredWorkforceData: any): Observable<RequiredWorkforce[]>{
      //   return this.http.put<RequiredWorkforce[]>(this.url+'/',requiredWorkforceData)
      // }

  //     requiredWorkforceData(requiredWorkforceData: any): Observable<RequiredWorkforce[]>{
  //   return this.http.post<RequiredWorkforce[]>(this.url ,requiredWorkforceData)
  // }

}
