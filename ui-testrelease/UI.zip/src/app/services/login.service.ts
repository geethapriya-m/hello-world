import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CheckUserDetails } from '../model/checkUserDetails';
import { Login } from '../model/login';
import straightlines_io_java_apis from 'src/app/json/apis.json';
@Injectable({
  providedIn: 'root'
})
export class LoginService {

  // private _url:string =" http://52.14.8.217:2020/authenticate"
  // private _url:string ="http://localhost:2020/authenticate"
  // private url="http://localhost:2020/checkuserinfo"

  private url=straightlines_io_java_apis.java_apis.url
  // private url="http://52.14.8.217:2020/checkuserinfo"

  // private url="http://18.119.62.157:2020/checkuserinfo"
  // private _url:string =" http://18.119.62.157:2020/authenticate"
  constructor(private http: HttpClient) { }

  registerNewUser(user_data: any): Observable<Login[]>{
      return this.http.post<Login[]>(this.url+'/authenticate',user_data)
    }

    loginValidation(){
      return !!localStorage.getItem('token')
    }
    getUserAllDetails(check_user_data): Observable<CheckUserDetails[]>{
      // console.log(this.url,check_user_data)
      return this.http.post<CheckUserDetails[]>(this.url+'/checkuserinfo',check_user_data)
    }
}
