import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ShiftDefinition } from '../model/shiftDefinition';
import straightlines_io_java_apis from 'src/app/json/apis.json';
@Injectable({
  providedIn: 'root'
})
export class IncludeExcludeShiftService {
token
  // private url: string = 'http://52.14.8.217:2020/shiftdefinition'
  // private url: string = 'http://18.119.62.157:2020/shiftdefinition'

  public url: string = straightlines_io_java_apis.java_apis.url
  constructor(private http: HttpClient) {

  }

  includeExcludeService(shift_id: any,shift_data:any): Observable<ShiftDefinition[]>{
    this.token=JSON.parse(localStorage.getItem('token'))
    let header = new HttpHeaders().set(
      'Authorization', `Bearer ${this.token}`
    );
    return this.http.put<ShiftDefinition[]>(this.url+'/shiftdefinition/'+shift_id,shift_data,{headers:header})
  }
}
