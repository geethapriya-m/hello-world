import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { emailVerify } from '../model/emailVerify';
import straightlines_io_java_apis from 'src/app/json/apis.json';
@Injectable({
  providedIn: 'root'
})
export class ForgotPasswordService {
  // private _url:string ="http://18.119.62.157:2020"
  // private _url:string ="http://52.14.8.217:2020"
  private _url:string =straightlines_io_java_apis.java_apis.url
  // private _url:string ="http://localhost:2020"
  constructor(private http: HttpClient) { }

  emailVerify(email: any): Observable<emailVerify[]>{
    // console.log(this._url+'/forgot-password/'+email)
    return this.http.post<emailVerify[]>(this._url+'/forgot-password/'+email,'')
  }
  updatePass(url: any,pass): Observable<emailVerify[]>{
    // console.log(url+'&password='+pass)
    return this.http.put<emailVerify[]>(url+'&password='+pass,{})
  }
  emailVerificationForForgotPassword(email): Observable<emailVerify[]>{
    // console.log(this._url+'/forgotpasswordemailverify/'+email)
    return this.http.post<emailVerify[]>(this._url+'/forgotpasswordemailverify/'+email,'')

  }
  verifyEmailForFP(f_token): Observable<emailVerify[]>{
    // console.log(this._url+'/verifydone/'+f_token)
    return this.http.post<emailVerify[]>(this._url+'/verifydone/'+f_token,'')

  }
}
