import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Registration } from 'src/app/model/registration';
import straightlines_io_java_apis from 'src/app/json/apis.json';
@Injectable({
  providedIn: 'root'
})
export class PhoneVerificationService {


  // private _url:string ="http://localhost:2020/phoneexist"
  // private _url:string ="http://52.14.8.217:2020/phoneexist"
  private _url:string =straightlines_io_java_apis.java_apis.url

  constructor(private http: HttpClient) { }
  // phoneVerification(phone_number: any): Observable<Registration[]>{
  //   console.log(phone_number)
  //     return this.http.post<Registration[]>(this._url,phone_number)
  //   }
    phoneValidator(phone_number: any): Observable<Registration[]>{
      // console.log(phone_number)
        return this.http.post<Registration[]>(this._url+'/phoneexist',phone_number)
      }
}
