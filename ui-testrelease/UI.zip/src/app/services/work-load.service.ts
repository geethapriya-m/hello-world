import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, } from "@angular/common/http";
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { WorkLoad } from '../workLoad';
import { ShiftDefinition } from '../model/shiftDefinition';
import { Time } from '@angular/common';
import straightlines_io_java_apis from 'src/app/json/apis.json';
@Injectable({
  providedIn: 'root'
})
export class WorkLoadService {
  token
  //  httpOptions = {
  //   headers: new HttpHeaders({
  //     'Access-Control-Allow-Origin':'http://52.14.8.217:2020',
  //     'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, POST, DELETE, OPTIONS',
  //     'Content-Type': 'application/json'
  //     // 'Authorization':'authkey',
  //     // 'userid':'1'
  //   })
  // };
  // public _url: string = 'http://52.14.8.217:2020/shiftdefinitionbyuserid'
  private url:string=straightlines_io_java_apis.java_apis.url
  // private url:string=' http://18.119.62.157:2020/shiftdefinition'
  // private url: string = 'http://18.119.62.157:2020/userdata'
  // private url: string = 'http://52.14.8.217:2020/shiftdefinition'

  // public _url: string = 'http://3.13.254.87:2020'
  // public _url: string = 'http://52.14.8.217:2020/shiftdefbyuserid'
  // public _url: string = 'http://18.119.62.157:2020/shiftdefbyuserid'
  // private url:string=' http://localhost:2020/shiftdefinition'



  constructor(private http: HttpClient) {

  }

  addNewShiftDefinition(data: string): Observable<ShiftDefinition[]>{
    this.token=JSON.parse(localStorage.getItem('token'))
    let header = new HttpHeaders().set(
      'Authorization', `Bearer ${this.token}`
    );

// console.log(header)
    return this.http.post<ShiftDefinition[]>(this.url+'/shiftdefinition/',data,{headers:header})
  }

  getAllShiftDefinition(user_id):Observable<any>{
    this.token=JSON.parse(localStorage.getItem('token'))
    let header = new HttpHeaders().set(
      'Authorization', `Bearer ${this.token}`
    );
    // console.log(header)
     return this.http.get(this.url+'/shiftdefbyuserid/'+user_id,{headers:header})

      }
      deleteShiftDefinition(id: number){
        this.token=JSON.parse(localStorage.getItem('token'))
        let header = new HttpHeaders().set(
          'Authorization', `Bearer ${this.token}`
        );
        return this.http.delete(this.url+'/shiftdefinition/'+id,{headers:header});

      }
      errorHandler(_errorHandler: any): import("rxjs").OperatorFunction<WorkLoad[], WorkLoad[]> {
        console.log(_errorHandler)
    throw new Error('Method not implemented.');
  }
;
}
