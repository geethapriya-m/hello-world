import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Registration } from '../model/registration';
import straightlines_io_java_apis from 'src/app/json/apis.json';
@Injectable({
  providedIn: 'root'
})
export class EmailValidationService {

  private url:string =straightlines_io_java_apis.java_apis.url
  // private _url:string="http://localhost:2020/emailexist"

  // private _url:string ="http://18.119.62.157:2020/emailexist"
  // private url:string="http://localhost:2020"
  // private url:string="http://18.119.62.157:2020"
  // private _url:string ="http://52.14.8.217:2020/emailexist"
  // // private url:string="http://localhost:2020"
  // private url:string="http://52.14.8.217:2020"
  // private url:string="http://52.14.8.217:2020/letsverifybyusername/"
  constructor(private http: HttpClient) { }
  emailValidator(email: any): Observable<Registration[]>{
      return this.http.post<Registration[]>(this.url+'/emailexist',email)

    }
    emailVerification(email): Observable<Registration[]>{
      // console.log(this.url+'/letsverifybyusername/'+email)
        return this.http.post<Registration[]>(this.url+'/letsverifybyusername/'+email,'')

      }

      verifiedEmail(code): Observable<Registration[]>{
        // console.log(this.url+'/verifydoneforregister/'+code)
        return this.http.post<Registration[]>(this.url+'/verifydoneforregister/'+code,'')


      }
}
