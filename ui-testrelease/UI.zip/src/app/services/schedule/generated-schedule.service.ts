import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import straightlines_io_java_apis from 'src/app/json/apis.json';
import { SaveGeneratedSchedule } from 'src/app/model/saveGeneratedSchedule';
import { SaveShiftDefintionDataBasedOnScheduleName } from 'src/app/model/saveShiftDefintionDataBasedOnScheduleName';
@Injectable({
  providedIn: 'root'
})
export class GeneratedScheduleService {


  private url:string =straightlines_io_java_apis.java_apis.url
  token: any;
  constructor(private http: HttpClient) { }
  saveAllShiftLine(allShiftLine: any): Observable<SaveGeneratedSchedule[]>{
    this.token=JSON.parse(localStorage.getItem('token'))
    let header = new HttpHeaders().set(
      'Authorization', `Bearer ${this.token}`
    );
    return this.http.post<SaveGeneratedSchedule[]>(this.url+'/allshiftline',allShiftLine,{headers:header})
    }
    saveOneShiftLine(shiftLine: any): Observable<SaveGeneratedSchedule[]>{
      this.token=JSON.parse(localStorage.getItem('token'))
      let header = new HttpHeaders().set(
        'Authorization', `Bearer ${this.token}`
      );
      return this.http.post<SaveGeneratedSchedule[]>(this.url+'/shiftline ',shiftLine,{headers:header})
      }
    getAllSchedule():Observable<SaveGeneratedSchedule[]>{
      this.token=JSON.parse(localStorage.getItem('token'))
    let header = new HttpHeaders().set(
      'Authorization', `Bearer ${this.token}`
    );
    return this.http.get<SaveGeneratedSchedule[]>(this.url+'/shiftline',{headers:header})
    }
    updateSchedule(id,shiflineData):Observable<SaveGeneratedSchedule[]>{
      this.token=JSON.parse(localStorage.getItem('token'))
    let header = new HttpHeaders().set(
      'Authorization', `Bearer ${this.token}`
    );
    return this.http.put<SaveGeneratedSchedule[]>(this.url+'/shiftline/'+id,shiflineData,{headers:header})
    }
    deleteSchedule(id):Observable<SaveGeneratedSchedule[]>{
      this.token=JSON.parse(localStorage.getItem('token'))
    let header = new HttpHeaders().set(
      'Authorization', `Bearer ${this.token}`
    );
    return this.http.delete<SaveGeneratedSchedule[]>(this.url+'/shiftline/'+id,{headers:header})
    }
    checkScheduleName(scheduleName):Observable<SaveGeneratedSchedule[]>{
      this.token=JSON.parse(localStorage.getItem('token'))
    let header = new HttpHeaders().set(
      'Authorization', `Bearer ${this.token}`
    );
    return this.http.post<SaveGeneratedSchedule[]>(this.url+'/shiftlineschedulename',scheduleName,{headers:header})
    }
    deleteScheduleBasedOnName(scheduleName):Observable<SaveGeneratedSchedule[]>{
      this.token=JSON.parse(localStorage.getItem('token'))
    let header = new HttpHeaders().set(
      'Authorization', `Bearer ${this.token}`
    );
    return this.http.delete<SaveGeneratedSchedule[]>(this.url+'/deletebyschedulename/'+scheduleName,{headers:header})
    }
    getScheduleNameBasedOnId(id: number): Observable<SaveGeneratedSchedule[]>{
      this.token=JSON.parse(localStorage.getItem('token'))
      let header = new HttpHeaders().set(
        'Authorization', `Bearer ${this.token}`
      );
      return this.http.get<SaveGeneratedSchedule[]>(this.url + '/allschedulenamesforuserid/' + id)
    }

    saveShiftDefintionDataBasedOnScheduleName(shiftDefintionData):Observable<SaveShiftDefintionDataBasedOnScheduleName[]>{
      this.token=JSON.parse(localStorage.getItem('token'))
      let header = new HttpHeaders().set(
        'Authorization', `Bearer ${this.token}`
      );
      return this.http.post<SaveShiftDefintionDataBasedOnScheduleName[]>(this.url + '/mergemany' ,shiftDefintionData,{headers:header})
    }
    getSaveShiftDefintionDataBasedOnScheduleName(scheduleName):Observable<SaveShiftDefintionDataBasedOnScheduleName[]>{
      this.token=JSON.parse(localStorage.getItem('token'))
      let header = new HttpHeaders().set(
        'Authorization', `Bearer ${this.token}`
      );
      return this.http.get<SaveShiftDefintionDataBasedOnScheduleName[]>(this.url + '/shiftlinebasedonname/'+scheduleName,{headers:header})
    }
    deleteSaveShiftDefintionDataBasedOnScheduleName(scheduleName):Observable<SaveGeneratedSchedule[]>{
      this.token=JSON.parse(localStorage.getItem('token'))
    let header = new HttpHeaders().set(
      'Authorization', `Bearer ${this.token}`
    );
    return this.http.delete<SaveGeneratedSchedule[]>(this.url+'/mergedeletebyshname/'+scheduleName,{headers:header})
    }
}
