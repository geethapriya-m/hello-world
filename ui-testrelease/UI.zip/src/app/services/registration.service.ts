import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Registration } from '../model/registration';
import straightlines_io_java_apis from 'src/app/json/apis.json';
@Injectable({
  providedIn: 'root'
})
export class RegistrationService {
  // private _url:string =" http://52.14.8.217:2020/register"
  // private _url:string =" http://18.119.62.157:2020/register"
  // private _url:string ="http://localhost:2020/register"
  private _url:string =straightlines_io_java_apis.java_apis.url


  constructor(private http: HttpClient) { }

  registerNewUser(user_data: any): Observable<Registration[]>{
      return this.http.post<Registration[]>(this._url+'/register',user_data)

    }
}
