import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BusinessRulesValidation } from '../model/businessRulesValidation';
import straightlines_io_python_apis from 'src/app/json/apis.json';
@Injectable({
  providedIn: 'root'
})
export class BusinessRulesValidationService {


// private _url:string ="http://127.0.0.1:5000/schedule"
// private _url:string ="http://52.14.8.217:5000/check_shift_line"
private _url:string =straightlines_io_python_apis.python_apis.url
// private _url:string ="http://18.119.62.157:5000/schedule"

  constructor(private http: HttpClient) { }
  businessRulesCheck(shift_line: any): Observable<BusinessRulesValidation[]>{
  // postRequiredWorkforceData(requiredWorkforceData: any): Observable<RequiredWorkforce[]>{
    // console.log(requiredWorkforceData)
    // console.log(this._url+'/'+row)
    // return this.http.post<RequiredWorkforce[]>(this._url,requiredWorkforceData)
    return this.http.post<BusinessRulesValidation[]>(this._url+'/check_shift_line',shift_line)

  }
}
