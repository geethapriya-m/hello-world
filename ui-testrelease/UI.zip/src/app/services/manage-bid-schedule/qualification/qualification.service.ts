import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import straightlines_io_java_apis from 'src/app/json/apis.json';
import { Qualification } from 'src/app/model/qualification';
@Injectable({
  providedIn: 'root'
})
export class QualificationService {
  private url:string =straightlines_io_java_apis.java_apis.url
  constructor(private http: HttpClient) { }
  getAllQualification(): Observable<Qualification[]>{
    return this.http.get<Qualification[]>(this.url+'/getallqualification')
  }
}
