import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import straightlines_io_java_apis from 'src/app/json/apis.json';
import { BidNptlLeaveSetup } from 'src/app/model/bidNptlLeaveSetup';
import { BidPtlLeaveSetup } from 'src/app/model/bidPtlLeaveSetup';
@Injectable({
  providedIn: 'root'
})
export class BidLeaveSetupService {

  private url:string =straightlines_io_java_apis.java_apis.url
  constructor(private http: HttpClient) { }
  addNewBidPtlLeave(newBidPTLleave): Observable<BidPtlLeaveSetup[]>{
    return this.http.post<BidPtlLeaveSetup[]>(this.url+'/bidptlleave',newBidPTLleave)
  }
  addNewBidNptlLeave(newBidNPTLleave): Observable<BidNptlLeaveSetup[]>{
    return this.http.post<BidNptlLeaveSetup[]>(this.url+'/bidnptlleave',newBidNPTLleave)
  }
  getAllBidPtlLeave():Observable<BidPtlLeaveSetup[]>{
    return this.http.get<BidPtlLeaveSetup[]>(this.url+'/bitptlleaveget')
  }
  getAllBidNptlLeave():Observable<BidNptlLeaveSetup[]>{
    return this.http.get<BidNptlLeaveSetup[]>(this.url+'/bitnptlleaveget')
  }
  getAllBidPtlLeaveBasedOnBSName(bidScheduleName):Observable<BidPtlLeaveSetup[]>{
    return this.http.get<BidPtlLeaveSetup[]>(this.url+'/bidptlleavebasedonschedulename/'+bidScheduleName)
  }
  getAllBidNptlLeaveBasedOnBSName(bidScheduleName):Observable<BidNptlLeaveSetup[]>{
    return this.http.get<BidNptlLeaveSetup[]>(this.url+'/bidnptlleavebasedonschedulename/'+bidScheduleName)
  }
  deleteBidLeave(bidScheduleName){
    return this.http.delete(this.url+'/bidleavedeletebyshname/'+bidScheduleName);

  }
  deleteBidLeaveBasedOnId(id){
    return this.http.delete(this.url+'/bidleavedeletebyleaveid/'+id);

  }
}
