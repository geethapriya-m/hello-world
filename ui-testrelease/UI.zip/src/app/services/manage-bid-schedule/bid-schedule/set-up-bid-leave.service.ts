import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import straightlines_io_java_apis from 'src/app/json/apis.json';
import { BidLeaveSetUP } from 'src/app/model/bidLeaveSetUp';

@Injectable({
  providedIn: 'root'
})
export class SetUpBidLeaveService {
  private url:string =straightlines_io_java_apis.java_apis.url
  constructor(private http: HttpClient) { }
  addNewLeave(newBidleave): Observable<BidLeaveSetUP[]>{
    return this.http.post<BidLeaveSetUP[]>(this.url+'/bidleavesave',newBidleave)
  }
  getAllLeaveBasedOnScheduleName(scheduleName):Observable<BidLeaveSetUP[]>{
    return this.http.get<BidLeaveSetUP[]>(this.url+'/bidleavebasedonschedulename/'+scheduleName)
  }
  deleteBidLeaveBasedOnId(id){
    return this.http.delete(this.url+'/bidleavedeletebyleaveid/'+id);

  }
  updateBidLeave(id,leaveData):Observable<BidLeaveSetUP[]>{
    console.log(id, leaveData)
    return this.http.put<BidLeaveSetUP[]>(this.url+'/bidleavebyid/'+id,leaveData)
  }
}
