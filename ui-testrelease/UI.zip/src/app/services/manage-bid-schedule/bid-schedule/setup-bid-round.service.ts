import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import straightlines_io_java_apis from 'src/app/json/apis.json';
import { SetUpBidRound } from 'src/app/model/setUpBidRound';
@Injectable({
  providedIn: 'root'
})
export class SetupBidRoundService {

  private url:string =straightlines_io_java_apis.java_apis.url
  constructor(private http: HttpClient) { }
  getAllBidRound(): Observable<SetUpBidRound[]>{
    return this.http.get<SetUpBidRound[]>(this.url+'/bidroundget')
  }
  addNewBidRound(newBidRoundData): Observable<SetUpBidRound[]>{
    return this.http.post<SetUpBidRound[]>(this.url+'/bidroundsave',newBidRoundData)
  }
  getAllBidRoundBasedOnBidScheduleName(bidScheduleName): Observable<SetUpBidRound[]>{
    return this.http.get<SetUpBidRound[]>(this.url+'/bidroundbasedonschedulename/'+bidScheduleName)
  }
  updateBidRound(id,bidScheduleData): Observable<SetUpBidRound[]>{
    return this.http.put<SetUpBidRound[]>(this.url+'/bidroundbyid/'+id,bidScheduleData)
  }
  deleteBidRound(bidScheduleName){
    return this.http.delete(this.url+'/bidrounddeletebyshname/'+bidScheduleName);
  }
  deleteBidRoundBasedOnId(id){
    return this.http.delete(this.url+'/bidrounddeletebyroundid/'+id);
  }
}
