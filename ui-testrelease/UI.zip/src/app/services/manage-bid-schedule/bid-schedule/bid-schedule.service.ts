import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import straightlines_io_java_apis from 'src/app/json/apis.json';
import { BidSchedule } from 'src/app/model/bidSchedule';
@Injectable({
  providedIn: 'root'
})
export class BidScheduleService {

  private url:string =straightlines_io_java_apis.java_apis.url
  constructor(private http: HttpClient) { }
  checkBidScheduleName(bidScheduleName): Observable<BidSchedule[]>{
    return this.http.get<BidSchedule[]>(this.url+'/bidparamschedulenameexist/'+bidScheduleName)
  }

  addNewBidSchedule(bidScheduleName): Observable<BidSchedule[]>{
    return this.http.post<BidSchedule[]>(this.url+'/bidparamssave',bidScheduleName)
  }

  getAllBidSchedule(userId):Observable<BidSchedule[]>{
    return this.http.get<BidSchedule[]>(this.url+'/bidparamdatelist/'+userId)
  }
  getScheduleNameBasedOnBidScheduleName(bidScheduleName): Observable<BidSchedule[]>{
    return this.http.get<BidSchedule[]>(this.url+'/bidparamschedulenamelist/'+bidScheduleName)
  }
  get(bidScheduleName): Observable<BidSchedule[]>{
    return this.http.get<BidSchedule[]>(this.url+'/mergegetbyshname/'+bidScheduleName)
  }
  deleteBidSchedule(bidScheduleName){
    return this.http.delete(this.url+'/bidparamdeletebybidschedulename/'+bidScheduleName);

  }
  updateBidSchedule(bidScheduleName,bidScheduleData): Observable<BidSchedule[]>{
    return this.http.put<BidSchedule[]>(this.url+'/bidparamupdateone/'+bidScheduleName,bidScheduleData)
  }
  updateBidScheduleBasedOnShiftLineAndBidScheduleName(shiftLineScheduleName,bidScheduleName,data): Observable<BidSchedule[]>{
    return this.http.put<BidSchedule[]>(this.url+'/bidparamupdatebyschedulename/'+shiftLineScheduleName+'/'+bidScheduleName,data)
  }
  updateBidScheduleBasedOnId(id,data): Observable<BidSchedule[]>{
    return this.http.put<BidSchedule[]>(this.url+'/bidparamupdatbybidid/'+id,data)
  }

  deleteShiftLineScheduleInBidScheduleBasedOnId(id){
    return this.http.delete(this.url+'/bidparamupdatbybidid/'+id);
  }

  deleteShiftLineScheduleInBidSchedule(shiftlineScheduleName){
    return this.http.delete(this.url+'/bidparamdeletebyschedulename/'+shiftlineScheduleName);
  }
  deleteShiftLineScheduleInBidScheduleBasedOnShcedulenameNameAndBidScheduleName(shiftlineScheduleName,BidScheduleName){
    return this.http.delete(this.url+'/bidparamdeletebyschedulename?shedname='+shiftlineScheduleName+'&bidshname='+BidScheduleName );
  }
}
