import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import straightlines_io_java_apis from 'src/app/json/apis.json';
import { AddNewEmployee } from 'src/app/model/addNewEmployee';
@Injectable({
  providedIn: 'root'
})
export class AddNewEmployeeService {
  private url:string =straightlines_io_java_apis.java_apis.url
  constructor(private http: HttpClient) { }
  addNewEmployee(new_emp): Observable<AddNewEmployee[]>{
    return this.http.post<AddNewEmployee[]>(this.url+'/employeedetails',new_emp)
  }

  getAllEmployee():Observable<AddNewEmployee[]>{
    return this.http.get<AddNewEmployee[]>(this.url+'/employeeall')
  }
  getAllEmployeeBasedOnUserId(userid):Observable<AddNewEmployee[]>{
    return this.http.get<AddNewEmployee[]>(this.url+'/employeelistbasedonuserid/'+userid)
  }
  getAllEmployeeBasedOnShiftlineAndBidScheduleName(shiftlineScheduleName,BidScheduleName):Observable<AddNewEmployee[]>{
    return this.http.get<AddNewEmployee[]>(this.url+'/bidparamscheduleemployeelist/'+shiftlineScheduleName+'/'+BidScheduleName)
  }
  getAllEmployeeBasedOnQualification(selectedQualification):Observable<AddNewEmployee[]>{
    return this.http.get<AddNewEmployee[]>(this.url+'/employeeinitialslist/'+selectedQualification)
  }
  checkDuplicateInitialName(initialName):Observable<AddNewEmployee[]>{
    const requestOptions: Object = {
      /* other options here */
      responseType: 'text'
    }
    return this.http.get<AddNewEmployee[]>(this.url+'/employeeinitialexist/'+initialName,requestOptions)
  }
}
