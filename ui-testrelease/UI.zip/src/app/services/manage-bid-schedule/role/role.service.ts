import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import straightlines_io_java_apis from 'src/app/json/apis.json';
import { Role } from 'src/app/model/role';
@Injectable({
  providedIn: 'root'
})
export class RoleService {
  private url:string =straightlines_io_java_apis.java_apis.url
  constructor(private http: HttpClient) { }
  getAllRole(): Observable<Role[]>{
    return this.http.get<Role[]>(this.url+'/getallrole')
  }
}
