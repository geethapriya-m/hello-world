export class WorkLoad{
id!:number
  startTime:string;
  Sun!: string;
  Mon!:string;
  Tue!:string;
  Wed!:string;
  Thu!:string;
  Fri!:string;
  Sat!:string;




}
