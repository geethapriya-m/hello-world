import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { NavController } from '@ionic/angular';
import { ForgotPasswordService } from '../services/forgot-password.service';
import { LoginService } from '../services/login.service';
import straightlines_io_apis from 'src/app/json/apis.json';
import { EmailValidationService } from '../services/email-validation.service';
@Component({
  selector: 'app-registration-verification-landing',
  templateUrl: './registration-verification-landing.page.html',
  styleUrls: ['./registration-verification-landing.page.scss'],
})
export class RegistrationVerificationLandingPage implements OnInit {
  errorMsg: any;
  hidePassword=true
  hideConfirmPassword=true
  classId=0
  confirmClassId=0
  emailValid
  url_token
  email_id
  verification_code
  email_is_verfied: any;
  user_data: any;
  constructor(public navCtrl: NavController,
    private fb:FormBuilder,
    private actRoute: ActivatedRoute,
    private loginSer:LoginService,
    private ev:EmailValidationService,
    private forgot_pass:ForgotPasswordService,) {

    }

  ngOnInit() {
    this.actRoute.paramMap.subscribe((params: ParamMap)=> {
      this.email_id= (params.get('_email'))
      // this.email_id_for_reset_password="vrushang.patel@mercuriusinc.com"
      this.verification_code= (params.get('_code'))

      // this.token_for_reset_password= 'A9kh7o54atHKikCpPyvqofXJQmqrz14DLq0KhoYBUdqBjkb1KL0POCFxVzloy7S9'
      // console.log(this.email_id);
      // console.log(this.verification_code);


    })
this.getUserData(this.email_id,this.verification_code)

  }
  getUserData(email,code){
    var getUserData={"username":email}
    // console.log(code,getUserData)
    this.loginSer.getUserAllDetails(getUserData).subscribe(
       (data)=>{
         console.log(code)
         this.user_data=data
        console.log(this.user_data.verification_code)
        // if(this.user_data.verification_code==code){
          this.ev.verifiedEmail(code).subscribe(
            (respons)=>{

            }
          )
        // }
        // this.userDetails=
        // if(respons){
        // this.forgot_pass.verifyEmailForFP(this.token_for_reset_password).subscribe(
        //   async (res)=>{
        //     // console.log(res)
        //     this.email_is_verfied=res;
        //     console.log(this.email_is_verfied)

        //   }
        // )}


          },
            (error: any)=>{this.errorMsg=error
            console.log(this.errorMsg)},
            ()=>{
            }
            );

  }
login(){
  this.navCtrl.navigateBack([straightlines_io_apis.apis.login_api])
}
}

