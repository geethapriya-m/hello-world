import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LandingPagePageRoutingModule } from './landing-page-routing.module';

import { LandingPagePage } from './landing-page.page';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from '../app-routing.module';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  imports: [BrowserModule,
    FormsModule,
    HttpClientModule,

    IonicModule.forRoot(),

    LandingPagePageRoutingModule,

    // IonicModule.forRoot({
    //   navAnimation: fadeInAnimation // Add your animations!
    // }),
    // IonicModule.forRoot({
    //   navAnimation: enterAnimation // Add your animations!
    // }),
    BrowserAnimationsModule,


  ],
  // providers: [ScreenOrientation,{ provide: RouteReuseStrategy, useClass: IonicRouteStrategy }],
  bootstrap: [LandingPagePage],

  declarations: [LandingPagePage]
})
export class LandingPagePageModule {}
