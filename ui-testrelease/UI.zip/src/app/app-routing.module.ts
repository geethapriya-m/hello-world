import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './services/auth/auth.guard';
import straightlines_io_apis from 'src/app/json/apis.json';

import { DashboardComponent } from './dashboard/dashboard.component';
import { EnterWorkLoadComponent } from 'src/app/dashboard/work_load_data/enter-work-load/enter-work-load.component';
import { GeneratedSchedulesComponent } from 'src/app/dashboard/generated_schedule/generated-schedules/generated-schedules.component';
import { STLinesDashboardComponent } from './dashboard/s-t-lines-dashboard/s-t-lines-dashboard.component';
import { SelectOptionForWorkloadComponent } from './dashboard/select-option-for-workload/select-option-for-workload.component';
import { BiddingDashboardComponent } from './dashboard/bidding-dashboard/bidding-dashboard.component';
import { ManageBidScheduleComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/manage-bid-schedule.component';
import { ManageBidDashboardComponent } from './dashboard/bidding-dashboard/manage-bid-dashboard/manage-bid-dashboard.component';
import { SetUpBidParametersComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/set-up-bid-parameters/set-up-bid-parameters.component';
import { SetUpBidParametersPartOneComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/set-up-bid-parameters/set-up-bid-parameters-part-one/set-up-bid-parameters-part-one.component';
import { SetUpBidParametersPartTwoComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/set-up-bid-parameters/set-up-bid-parameters-part-two/set-up-bid-parameters-part-two.component';
import { SetUpBidParametersPartThreeComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/set-up-bid-parameters/set-up-bid-parameters-part-three/set-up-bid-parameters-part-three.component';
import { SetUpBidParametersSectionTwoComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/set-up-bid-parameters/set-up-bid-parameters-part-two/set-up-bid-parameters-section-two/set-up-bid-parameters-section-two.component';
import { MyBiddingDashboardComponent } from './dashboard/bidding-dashboard/my-bidding-dashboard/my-bidding-dashboard.component';
import { MyBiddingStepOneShiftLineComponent } from './dashboard/bidding-dashboard/my-bidding-dashboard/my-bidding-step-one-shift-line/my-bidding-step-one-shift-line.component';
import { SelectShiftLineForBiddingComponent } from './dashboard/bidding-dashboard/my-bidding-dashboard/select-shift-line-for-bidding/select-shift-line-for-bidding.component';
import { ViewBidShiftlinesComponent } from './dashboard/bidding-dashboard/my-bidding-dashboard/view-bid-shiftlines/view-bid-shiftlines.component';
import { ManageShiftLineSchedulesComponent } from './dashboard/manage-shift-line-schedules/manage-shift-line-schedules.component';
import { GeneratedScheduleListComponent } from './dashboard/manage-shift-line-schedules/generated-schedule-list/generated-schedule-list.component';
import { EditScheduleComponent } from './dashboard/manage-shift-line-schedules/edit-schedule/edit-schedule.component';
import { ImportExcelSheetForScheduleComponent } from './dashboard/select-option-for-workload/import-excel-sheet-for-schedule/import-excel-sheet-for-schedule.component';
import { ErrorPageComponent } from './error-page/error-page.component';
import { CalendarTestComponent } from './calendar-test/calendar-test.component';
import { CalendarTest1Component } from './calendar-test1/calendar-test1.component';
import { CalendarTest2Component } from './calendar-test2/calendar-test2.component';
import { AddNewEmployeeComponent } from './dashboard/add-new-employee/add-new-employee.component';
import { SetUpBidParametersSummaryComponent } from './dashboard/bidding-dashboard/manage-bid-schedule/set-up-bid-parameters/set-up-bid-parameters-summary/set-up-bid-parameters-summary.component';
import { ViewSeniorityListComponent } from './dashboard/bidding-dashboard/my-bidding-dashboard/view-seniority-list/view-seniority-list.component';
const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
    ,canActivate:[AuthGuard],
  },
  {
    path: '',
    redirectTo: 'welcome',
    pathMatch: 'full'
  },
  {
    path: 'feedback',
    loadChildren: () => import('./home/feedback/feedback.module').then( m => m.FeedbackPageModule),
    canActivate:[AuthGuard],
  },
  {
    path: 'edit-schedule-data',
    loadChildren: () => import('src/app/dashboard/generated_schedule/add-edit-shift-lines/edit-schedule-data/edit-schedule-data.module').then( m => m.EditScheduleDataPageModule),
    canActivate:[AuthGuard],
  },
  {
    path: 'edit-work-load-data',
    loadChildren: () => import('src/app/dashboard/work_load_data/edit-work-load-data/edit-work-load-data.module').then( m => m.EditWorkLoadDataPageModule),
    canActivate:[AuthGuard],
  },
  {
    path: 'required-vs-generated-workforce',
    loadChildren: () => import('src/app/dashboard/generated_schedule/required-vs-generated-workforce/required-vs-generated-workforce.module').then( m => m.RequiredVsGeneratedWorkforcePageModule)
    ,canActivate:[AuthGuard],
  },
  {
    path: 'add-new-shift-line',
    loadChildren: () => import('src/app/dashboard/generated_schedule/add-edit-shift-lines/add-new-shift-line/add-new-shift-line.module').then( m => m.AddNewShiftLinePageModule),
    canActivate:[AuthGuard],
  },

  {
    path: 'view-total-mid-shift-lines-data',
    loadChildren: () => import('src/app/dashboard/generated_schedule/summary/view-total-mid-shift-lines-data/view-total-mid-shift-lines-data.module').then( m => m.ViewTotalMidShiftLinesDataPageModule),
    canActivate:[AuthGuard],
  },
  {
    path: 'view-total-day-shift-lines-data',
    loadChildren: () => import('src/app/dashboard/generated_schedule/summary/view-total-day-shift-lines-data/view-total-day-shift-lines-data.module').then( m => m.ViewTotalDayShiftLinesDataPageModule)
    ,canActivate:[AuthGuard],
  },
  {
    path: 'view-total-eve-shift-lines-data',
    loadChildren: () => import('src/app/dashboard/generated_schedule/summary/view-total-eve-shift-lines-data/view-total-eve-shift-lines-data.module').then( m => m.ViewTotalEveShiftLinesDataPageModule),
    canActivate:[AuthGuard],
  },
  {
    path: 'summary-info-genereted-report-page',
    loadChildren: () => import('src/app/dashboard/generated_schedule/summary-info-genereted-report-page/summary-info-genereted-report-page.module').then( m => m.SummaryInfoGeneretedReportPagePageModule),
    canActivate:[AuthGuard],
  },
  {
    path: 'add-new-shift-definition',
    loadChildren: () => import('src/app/dashboard/work_load_data/add-new-shift-definition/add-new-shift-definition.module').then( m => m.AddNewShiftDefinitionPageModule),
    canActivate:[AuthGuard],

  },
  {
    path: 'time-picker',
    loadChildren: () => import('src/app/dashboard/work_load_data/add-new-shift-definition/time-picker/time-picker.module').then( m => m.TimePickerPageModule),
    canActivate:[AuthGuard],
  },
  {
    path: 'footer',
    loadChildren: () => import('src/app/dashboard/nav-bar-footer/footer/footer.module').then( m => m.FooterPageModule),
    canActivate:[AuthGuard],
  },

  {
    path: 'welcome',
    loadChildren: () => import('./welcome/welcome.module').then( m => m.WelcomePageModule)
  },
  {
    path: 'nav-bar',
    loadChildren: () => import('src/app/dashboard/nav-bar-footer/nav-bar/nav-bar.module').then( m => m.NavBarPageModule),
    canActivate:[AuthGuard],
  },

  {
    path: 'business-rules-pdf',
    loadChildren: () => import('src/app/dashboard/generated_schedule/add-edit-shift-lines/business-rules-pdf/business-rules-pdf.module').then( m => m.BusinessRulesPdfPageModule),
    canActivate:[AuthGuard],
  },
  {
    path: 'view-summary-day-category-wise',
    loadChildren: () => import('src/app/dashboard/generated_schedule/summary/view-summary-day-category-wise/view-summary-day-category-wise.module').then( m => m.ViewSummaryDayCategoryWisePageModule),
    canActivate:[AuthGuard],
  },
  {
    path: straightlines_io_apis.apis.register_api,
    loadChildren: () => import('./home/login-register/register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: straightlines_io_apis.apis.reset_password_api,
    loadChildren: () => import('./home/login-register/reset-password/reset-password.module').then( m => m.ResetPasswordPageModule)
  },
  {
    path: straightlines_io_apis.apis.password_changed_message_api,
    loadChildren: () => import('./home/login-register/reset-password/password-changed-message/password-changed-message.module').then( m => m.PasswordChangedMessagePageModule)
  },
  {path: 'sTlines-dashboard',component:DashboardComponent,canActivate:[AuthGuard],
    children:[
      {path:'',component:STLinesDashboardComponent,canActivate:[AuthGuard]},
      {path: 'select',component:SelectOptionForWorkloadComponent,canActivate:[AuthGuard]},
      {path: 'import-schedule',component:ImportExcelSheetForScheduleComponent,canActivate:[AuthGuard]},
        {path: 'manage-shift-line-schedules',component:ManageShiftLineSchedulesComponent,canActivate:[AuthGuard],
            children:[
              {path: '',component:GeneratedScheduleListComponent,canActivate:[AuthGuard]},
            {path: 'enter-work-load',component:EnterWorkLoadComponent,canActivate:[AuthGuard]},

            {path: 'generated-schedules',component:GeneratedSchedulesComponent,canActivate:[AuthGuard]},
            {path: 'edit-schedule/:_id',component:EditScheduleComponent,canActivate:[AuthGuard]},
      ]
    },

      // {path: 'bidding',component:BiddingDashboardComponent,canActivate:[AuthGuard],
      //   children:[
      //     // {path: '',component:ManageBidDashboardComponent,canActivate:[AuthGuard]},
          {path: 'bidding/bid-list',component:ManageBidScheduleComponent,canActivate:[AuthGuard]},
          {path: 'bidding/add-new-employee',component:AddNewEmployeeComponent,canActivate:[AuthGuard]},
          {path: 'bidding/generated-schedules',component:GeneratedSchedulesComponent,canActivate:[AuthGuard]},
          {path: 'bidding/enter-work',component:EnterWorkLoadComponent,canActivate:[AuthGuard]},
          {path: 'bidding/SBP',component:SetUpBidParametersComponent,canActivate:[AuthGuard],
            children:[
              {path: '', component:SetUpBidParametersPartOneComponent,canActivate:[AuthGuard]},
              {path: 'lbp', component:SetUpBidParametersPartTwoComponent,canActivate:[AuthGuard]},
              {path: 'lbp2', component:SetUpBidParametersSectionTwoComponent,canActivate:[AuthGuard]},
              {path: 'brs', component:SetUpBidParametersPartThreeComponent,canActivate:[AuthGuard]},
              {path: 'bid-summary', component:SetUpBidParametersSummaryComponent,canActivate:[AuthGuard]}
            ]},
            {path: 'bidding/my-bidding',component:MyBiddingDashboardComponent,canActivate:[AuthGuard],
            children:[
              {path: '', component:MyBiddingStepOneShiftLineComponent,canActivate:[AuthGuard]},
              {path: 'view-bid-schedule', component:ViewBidShiftlinesComponent,canActivate:[AuthGuard]},
              {path: 'view-seniority-list', component:ViewSeniorityListComponent,canActivate:[AuthGuard]},
              {path: 'cal-test', component:CalendarTestComponent,canActivate:[AuthGuard]},
              {path: 'cal-test-one', component:CalendarTest1Component,canActivate:[AuthGuard]},
              {path: 'cal-test-two/:_id', component:CalendarTest2Component,canActivate:[AuthGuard]},
              {path: 'SSB', component:SelectShiftLineForBiddingComponent,canActivate:[AuthGuard]},
            ]},
        // ]},
    ]
  },
  {
    path:straightlines_io_apis.apis.login_api,
    loadChildren: () => import('./home/login-register/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'landing-page',
    loadChildren: () => import('./landing-page/landing-page.module').then( m => m.LandingPagePageModule)
  },
  {
    path: 'fullscreen-chart',
    loadChildren: () => import('src/app/dashboard/generated_schedule/summary/view-summary-day-category-wise/fullscreen-chart/fullscreen-chart.module').then( m => m.FullscreenChartPageModule),
    canActivate:[AuthGuard]
  },
  {
    path: 'create-new-shift-defintion',
    loadChildren: () => import('src/app/dashboard/work_load_data/create-new-shift-defintion/create-new-shift-defintion.module').then( m => m.CreateNewShiftDefintionPageModule),
    canActivate:[AuthGuard]
  },
  {
    path: straightlines_io_apis.apis.registration_verification_landing_page_api,
    loadChildren: () => import('./registration-verification-landing/registration-verification-landing.module').then( m => m.RegistrationVerificationLandingPageModule)
  },
  { path: '**',component:ErrorPageComponent,canActivate:[AuthGuard]}

];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
