export class BusinessRulesValidation{


shift_line
shift_length

}
