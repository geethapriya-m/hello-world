export class AddNewEmployee{

  id
  fname
  lname
  initials
  rank
  phone
  email
  qualification
  role
  userid
  vacation
}
