export class ScheduleData{

  id!:Number;
  Sun!: String;
  Mon!:String;
  Tue!:String;
  Wed!:String;
  Thu!:String;
  Fri!:String;
  Sat!:String;
  BMLRule!:String;



}
