export class BidPtlLeaveSetup{

  ptlid
  ptlstartdate
  ptlenddate
  slots
  bidschedulenameref    
  useridref    
}
