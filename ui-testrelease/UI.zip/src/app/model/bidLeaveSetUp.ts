export class BidLeaveSetUP{

  leavelid
  leavestartdate
  leaveenddate
  slots
  leavesavestatus
  bidschedulenameref     
  remaindayslot  
  useridref 
}
