export class SaveShiftDefintionDataBasedOnScheduleName{
  mid
  schedulename
  userid
  shiftname
  starttime
  shiftCategory
}
