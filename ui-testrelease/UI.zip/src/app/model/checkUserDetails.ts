export class CheckUserDetails{

  id
  username
  password
  token
  tokenCreationDate
  phone
  verificationCode
  enabled
  fpverify

}
