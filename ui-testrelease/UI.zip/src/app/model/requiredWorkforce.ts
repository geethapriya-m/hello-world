export class RequiredWorkforce{

  id!:Number;
  SUN!: String;
  MON!:String;
  TUE!:String;
  WED!:String;
  THU!:String;
  FRI!:String;
  SAT!:String;
  DAY
  MID
  EVE

}
