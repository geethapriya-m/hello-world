export class Login{


  username
  password

}
