export class BidNptlLeaveSetup{

  nptlid
  nptlstartdate
  nptlenddate
  nptlslots
  bidschedulenameref     
  remaindayslot  
  useridref 
}
