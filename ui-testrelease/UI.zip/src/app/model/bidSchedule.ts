export class BidSchedule{

  bidid
  bidschedulename
  bidstartdate
  employee
  qualifiction
  schedulename
  userid
  bidschedulestartdate
  role
  bidscheduleenddate
        paramsavestatus
    leavesavestatus
    roundsavestatus

}
