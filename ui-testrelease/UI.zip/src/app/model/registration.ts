export class Registration{


    username
    fullname
    phone
    email
    password
    facilityid
    message
}
