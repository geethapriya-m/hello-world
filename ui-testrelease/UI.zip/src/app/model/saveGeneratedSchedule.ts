export class SaveGeneratedSchedule{

  seq_id
  mon
  tue
  wed
  thu
  fri
  sat
  sun
  schedulename
  shiftname
  areaid
  userid
  pattern
}
