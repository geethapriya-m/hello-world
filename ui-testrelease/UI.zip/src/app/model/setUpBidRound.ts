
export class SetUpBidRound{

  bidschedulenameref
  bidroundid
  bidroundstartdate
  bid_duration
  daily_starttime
  daily_endttime
  bidroundenddate
  bidleavereason
  useridref
}
