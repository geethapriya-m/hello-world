export class Qualification{
  id
  qual_name
  qual_description
}
