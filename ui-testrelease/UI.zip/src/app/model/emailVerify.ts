export class emailVerify{

username
code
}
