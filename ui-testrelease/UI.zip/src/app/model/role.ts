export class Role{
role_name
id


}
