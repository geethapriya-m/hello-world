(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-register-register-register-module"],{

/***/ "I3dt":
/*!*************************************************************************!*\
  !*** ./src/app/home/login-register/register/register-routing.module.ts ***!
  \*************************************************************************/
/*! exports provided: RegisterPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPageRoutingModule", function() { return RegisterPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./register.page */ "jdYH");




const routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_3__["RegisterPage"]
    },
];
let RegisterPageRoutingModule = class RegisterPageRoutingModule {
};
RegisterPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RegisterPageRoutingModule);



/***/ }),

/***/ "NVgD":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/login-register/register/register.page.html ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content style=\"--background: #D0E4E4;--height: 100%;\"  class=\"app-primary-background-color\">\n    <ion-grid id=\"top\" class=\"app-primary-background-color\">\n      <ion-row style=\"text-align: right;z-index: 1;\" class=\"ion-justify-content-center\">\n\n        <ion-col size=\"3\" style=\"text-align: right;z-index: 1;\">\n          <ion-img style=\"height: 50px;width: 50px;z-index: 1;margin-top:25% ;margin-left: 25%;\"  src=\"assets/img/mercurius-logo.png\"></ion-img>\n        </ion-col>\n        <ion-col size=\"9\"></ion-col>\n    </ion-row>\n\n    <div class=\"custom-shape-divider-top-1626283200\">\n      <svg data-name=\"Layer 1\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1200 120\" preserveAspectRatio=\"none\">\n          <path d=\"M985.66,92.83C906.67,72,823.78,31,743.84,14.19c-82.26-17.34-168.06-16.33-250.45.39-57.84,11.73-114,31.07-172,41.86A600.21,600.21,0,0,1,0,27.35V120H1200V95.8C1132.19,118.92,1055.71,111.31,985.66,92.83Z\" class=\"shape-fill\"></path>\n      </svg>\n  </div>\n\n\n\n\n    </ion-grid>\n    <ion-row     id=\"Sign-Up-title\" class=\"app-primary-background-color\" >\n      <ion-col size=\"4.5\"></ion-col>\n      <ion-col size=\"7.5\" style=\"text-align: right;\">\n        <p  style=\"text-align: right;\"><b class=\"app-font-primary-color app-title\">Sign-Up</b></p>\n      </ion-col>\n      </ion-row>\n    <ion-grid id=\"center\"  class=\"data app-primary-background-color app-font-primary-color ion-text-center ion-justify-content-center\" style=\"height: 100% auto;\">\n\n      <form [formGroup]=\"registrationForm\" class=\"app-primary-background-color\">\n        <!-- Username -->\n\n        <ion-grid class=\"ion-justify-content-center app-primary-background-color ion-text-center\" >\n        <!-- <ion-item id=\"register-input-ion-item\" class=\"app-font-primary-color \" >\n          <ion-label position=\"stacked\">Username</ion-label>\n          <ion-input type=\"text\" class=\"ion-no-margin ion-no-padding \" formControlName=\"username\" name=\"username\"\n          [class.is-invalid]=\"username?.invalid && username?.touched\"\n\n          required></ion-input>\n          <div class=\"content-data app-font-red-color\" style=\"text-align: left;\" *ngIf=\"username?.touched && username?.errors\">\n            <p class=\"app-font-red-color\" *ngIf=\"username?.errors?.required \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Username is required!</p>\n            <p class=\"app-font-red-color\" *ngIf=\"username?.errors?.minlength \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Username must be at least 4 characters long!</p>\n            <p class=\"app-font-red-color\" *ngIf=\"username?.errors?.maxlength \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Username can't be longer than 8 characters!</p>\n          </div>\n        </ion-item> -->\n\n        <!-- Fullname -->\n        <!-- <ion-item id=\"register-input-ion-item\" class=\"app-font-primary-color \" >\n          <ion-label position=\"stacked\">Fullname</ion-label>\n          <ion-input type=\"text\" class=\"ion-no-margin ion-no-padding\" formControlName=\"fullname\" name=\"fullname\"\n          [class.is-invalid]=\"fullname?.invalid && fullname?.touched\"\n          required></ion-input>\n          <div class=\"content-data app-font-red-color\" style=\"text-align: left;\" *ngIf=\"fullname?.touched && fullname?.errors\">\n            <p class=\"app-font-red-color\" *ngIf=\"fullname?.errors?.required \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Fullname is required!</p>\n            <p class=\"app-font-red-color\" *ngIf=\"fullname?.errors?.minlength \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Fullname must be at least 2 characters long!</p>\n            <p class=\"app-font-red-color\" *ngIf=\"fullname?.errors?.maxlength \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Fullname can't be longer than 64 characters!</p>\n          </div>\n        </ion-item> -->\n\n        <!-- Email -->\n        <ion-item id=\"register-input-ion-item\" lines=\"none\"   class=\"app-font-primary-color app-primary-background-color\" >\n          <ion-label position=\"stacked\">Email</ion-label>\n          <ion-input type=\"email\" (focusout)=\"emailFocusOut()\" style=\"border: 2px solid #57818A;border-radius: 5px;margin-top: 5px;\" class=\"form-control ion-no-margin ion-no-padding app-font-primary-color\" formControlName=\"email\" name=\"email\"\n          [class.is-invalid]=\"email?.invalid && email?.touched\"\n          required></ion-input>\n          <div class=\"content-data app-font-red-color\" style=\"text-align: left;\" *ngIf=\"email?.touched && email?.errors\">\n            <p class=\"app-font-red-color\" *ngIf=\"email?.errors?.required \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Email is required!</p>\n            <p class=\"app-font-red-color\" *ngIf=\"email?.errors?.minlength \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Email must be at least 6 characters long!</p>\n\n            <p class=\"app-font-red-color\" *ngIf=\"email?.errors?.pattern \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Enter a valid email!</p>\n          </div>\n        <div  class=\"content-data app-font-red-color\" style=\"text-align: left;\">\n          <p class=\"app-font-red-color\" *ngIf=\"emailValid==true\"><ion-icon name=\"alert-circle-outline\"></ion-icon>Account already exists!!</p>\n        </div>\n        </ion-item>\n        <!-- Phone -->\n        <ion-item lines=\"none\" id=\"register-input-ion-item\" class=\"app-font-primary-color \" >\n          <ion-label position=\"stacked\">Phone</ion-label>\n           <ion-input type=\"number\" (focusout)=\"phoneFocusOut()\" class=\"ion-no-margin ion-no-padding\" style=\"border: 2px solid #57818A;border-radius: 5px;margin-top: 5px;--background:white\" formControlName=\"phone\" name=\"phone\"\n           [class.is-invalid]=\"phone?.invalid \"></ion-input>\n           <div class=\"content-data app-font-red-color\" style=\"text-align: left;\" *ngIf=\" phone?.errors\">\n            <p class=\"app-font-red-color\" *ngIf=\"phone?.errors?.pattern \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Enter a valid phone!</p>\n             <p class=\"app-font-red-color\" *ngIf=\"phone?.errors?.minlength \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Phone must be at least 10 characters long!</p>\n             <p class=\"app-font-red-color\" *ngIf=\"phone?.errors?.maxlength \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Phone must be at least 10 characters long!</p>\n           </div>\n           <div  class=\"content-data app-font-red-color\" style=\"text-align: left;\">\n            <p class=\"app-font-red-color\" *ngIf=\"phoneValid==true\"><ion-icon name=\"alert-circle-outline\"></ion-icon>Phone number already exists!!</p>\n          </div>\n         </ion-item>\n        <!-- Password -->\n        <ion-item id=\"register-input-ion-item\" lines=\"none\" class=\"app-font-primary-color \" >\n          <ion-label position=\"stacked\">Password</ion-label>\n          <!-- <ion-label>Password</ion-label> -->\n\n          <!-- <ion-icon item-end class=\"hide-option\"  name=\"eye-off-outline\"> -->\n          <ion-input type=\"text\" [class]=\"passWordClass(classId) \" style=\"border: 2px solid #57818A;border-radius: 5px;margin-top: 5px;position: relative;z-index: -1;\" formControlName=\"password\" name=\"password\"\n          [class.is-invalid]=\"password?.invalid && password?.touched\"\n          required>\n\n        </ion-input>\n\n        <!-- <span style=\"position:absolute; right:8px;top:8px;\" class=\"fa fa-user \"></span> -->\n\n        <ion-icon *ngIf=\"hidePassword\" class=\"app-font-primary-color\" style=\"position:absolute; right:6%;font-size: 20px;bottom: 10px;z-index: 1;\" (click)=\"passWord()\"  name=\"eye-off-outline\"></ion-icon>\n        <ion-icon *ngIf=\"!hidePassword\" class=\"app-font-primary-color\" style=\"position:absolute; right:6%;font-size: 20px;bottom: 10px;z-index: 1;\" (click)=\"passWord()\" name=\"eye-outline\"></ion-icon>\n        <!-- <ion-label><ion-icon class=\"passwordIcon\" style=\"z-index: -1;position: absolute;\"  name=\"eye-off-outline\"></ion-icon></ion-label> -->\n        <!-- </ion-icon> -->\n\n\n    </ion-item>\n    <div class=\"content-data app-font-red-color\" style=\"text-align: left;margin-left:8%;\" *ngIf=\"password?.touched && password?.errors\">\n      <p class=\"app-font-red-color\" *ngIf=\"password?.errors?.required \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Password is required!</p>\n      <p class=\"app-font-red-color\" *ngIf=\"password?.errors?.minlength \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Password must be at 2 characters!</p>\n      <p class=\"app-font-red-color\" *ngIf=\"password?.errors?.maxlength \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Password must be at 64 characters!</p>\n    </div>\n        <!-- Confirm-Password -->\n        <ion-item id=\"register-input-ion-item\" lines=\"none\" class=\"app-font-primary-color \" >\n          <ion-label position=\"stacked\">Confirm Password</ion-label>\n          <ion-input type=\"text\" [class]=\"confirmPassWordClass(confirmClassId) \" style=\"border: 2px solid #57818A;border-radius: 5px;margin-top: 5px;position: relative;z-index: -1;\"   name=\"confirm-password\" formControlName=\"confirm_password\"\n          required></ion-input>\n          <ion-icon *ngIf=\"hideConfirmPassword\" class=\"app-font-primary-color\" style=\"position:absolute; right:6%;font-size: 20px;bottom: 10px;z-index: 1;\" (click)=\"confirm_Password()\"  name=\"eye-off-outline\"></ion-icon>\n          <ion-icon *ngIf=\"!hideConfirmPassword\" class=\"app-font-primary-color\" style=\"position:absolute; right:6%;font-size: 20px;bottom: 10px;z-index: 1;\" (click)=\"confirm_Password()\" name=\"eye-outline\"></ion-icon>\n\n      </ion-item>\n\n      <div class=\"content-data app-font-red-color\" style=\"text-align: left;margin-left:8%;\" *ngIf=\"confirm_password.touched && confirm_password.invalid\" >\n        <p class=\"app-font-red-color\" *ngIf=\"confirm_password.errors.required\"><ion-icon name=\"alert-circle-outline\"></ion-icon> Confirm Password is required.</p>\n        <p class=\"app-font-red-color\" *ngIf=\"confirm_password.errors.confirmedValidator\"><ion-icon name=\"alert-circle-outline\"></ion-icon> Password and Confirm Password must be match.</p>\n    </div>\n        <!-- Facility -->\n        <!-- <ion-item id=\"register-input-ion-item\" class=\"app-font-primary-color \" >\n          <ion-label position=\"stacked\">Facility</ion-label>\n          <ion-input  type=\"number\" class=\"ion-no-margin ion-no-padding\" formControlName=\"facilityid\" name=\"facilityid\"\n          [class.is-invalid]=\"facilityid?.invalid && facilityid?.touched\"\n          [readonly]=\"true\"\n          required></ion-input>\n          <div class=\"content-data app-font-red-color\" style=\"text-align: left;\" *ngIf=\"facilityid?.touched && facilityid?.errors\">\n            <p class=\"app-font-red-color\" *ngIf=\"facilityid?.errors?.required \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Facility is required!</p>\n          </div>\n        </ion-item> -->\n      </ion-grid>\n\n\n\n      <!-- Terms & Conditions -->\n<!-- <ion-row class=\"ion-justify-content-center\"  id=\"check-box-terms-and-conditions\">\n  <ion-checkbox style=\"--size:20px\" formControlName=\"terms\" > </ion-checkbox> <ion-label style=\"margin-left: 2%;\">  Agree with Terms and Conditions</ion-label>\n</ion-row> -->\n\n<ion-row  class=\"ion-justify-content-center\"  id=\"button\">\n  <ion-button shape=\"round\" (click)=\"onSubmit(registrationForm)\" class=\"app-button-primary\" id=\"get-start\" [disabled]=\"registrationForm?.invalid || emailValid==true || phoneValid==true\" >Submit</ion-button>\n</ion-row>\n<ion-row class=\"ion-justify-content-center\"  id=\"sign-in\">\n  <ion-label style=\"margin-left: 2%;\">Already have an account? <b (click)=\"signIn()\">Sign In</b></ion-label>\n</ion-row>\n\n      </form>\n    </ion-grid>\n    </ion-content>\n    <!-- <div class=\"custom-shape-divider-top-1626199019\">\n      <svg id=\"wave\"  viewBox=\"0 0 1440 490\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\"><defs><linearGradient id=\"sw-gradient-0\" x1=\"0\" x2=\"0\" y1=\"1\" y2=\"0\"><stop stop-color=\"rgba(243, 106, 62, 1)\" offset=\"0%\"></stop><stop stop-color=\"rgba(255, 179, 11, 1)\" offset=\"100%\"></stop></linearGradient></defs>\n        <path style=\" opacity:1\" fill=\"#0194E3\" d=\"M0,196L80,163.3C160,131,320,65,480,106.2C640,147,800,294,960,302.2C1120,310,1280,180,1440,122.5C1600,65,1760,82,1920,98C2080,114,2240,131,2400,155.2C2560,180,2720,212,2880,187.8C3040,163,3200,82,3360,49C3520,16,3680,33,3840,57.2C4000,82,4160,114,4320,106.2C4480,98,4640,49,4800,65.3C4960,82,5120,163,5280,196C5440,229,5600,212,5760,228.7C5920,245,6080,294,6240,269.5C6400,245,6560,147,6720,122.5C6880,98,7040,147,7200,163.3C7360,180,7520,163,7680,147C7840,131,8000,114,8160,98C8320,82,8480,65,8640,106.2C8800,147,8960,245,9120,285.8C9280,327,9440,310,9600,253.2C9760,196,9920,98,10080,73.5C10240,49,10400,98,10560,171.5C10720,245,10880,343,11040,351.2C11200,359,11360,278,11440,236.8L11520,196L11520,490L11440,490C11360,490,11200,490,11040,490C10880,490,10720,490,10560,490C10400,490,10240,490,10080,490C9920,490,9760,490,9600,490C9440,490,9280,490,9120,490C8960,490,8800,490,8640,490C8480,490,8320,490,8160,490C8000,490,7840,490,7680,490C7520,490,7360,490,7200,490C7040,490,6880,490,6720,490C6560,490,6400,490,6240,490C6080,490,5920,490,5760,490C5600,490,5440,490,5280,490C5120,490,4960,490,4800,490C4640,490,4480,490,4320,490C4160,490,4000,490,3840,490C3680,490,3520,490,3360,490C3200,490,3040,490,2880,490C2720,490,2560,490,2400,490C2240,490,2080,490,1920,490C1760,490,1600,490,1440,490C1280,490,1120,490,960,490C800,490,640,490,480,490C320,490,160,490,80,490L0,490Z\"></path></svg>\n    </div> -->\n");

/***/ }),

/***/ "eAfL":
/*!*****************************************************************!*\
  !*** ./src/app/home/login-register/register/register.module.ts ***!
  \*****************************************************************/
/*! exports provided: RegisterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPageModule", function() { return RegisterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _register_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./register-routing.module */ "I3dt");
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./register.page */ "jdYH");







let RegisterPageModule = class RegisterPageModule {
};
RegisterPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _register_routing_module__WEBPACK_IMPORTED_MODULE_5__["RegisterPageRoutingModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot({ scrollAssist: false }),
        ],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_6__["RegisterPage"]]
    })
], RegisterPageModule);



/***/ }),

/***/ "jdYH":
/*!***************************************************************!*\
  !*** ./src/app/home/login-register/register/register.page.ts ***!
  \***************************************************************/
/*! exports provided: RegisterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPage", function() { return RegisterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_register_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./register.page.html */ "NVgD");
/* harmony import */ var _register_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./register.page.scss */ "nU2W");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_services_email_validation_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/email-validation.service */ "+xEj");
/* harmony import */ var src_app_services_registration_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/registration.service */ "rMDH");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! sweetalert2 */ "PSD3");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var src_app_json_apis_json__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/json/apis.json */ "B+pZ");
var src_app_json_apis_json__WEBPACK_IMPORTED_MODULE_9___namespace = /*#__PURE__*/__webpack_require__.t(/*! src/app/json/apis.json */ "B+pZ", 1);
/* harmony import */ var src_app_services_phone_verification_phone_verification_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/phone-verification/phone-verification.service */ "mlEv");











let RegisterPage = class RegisterPage {
    constructor(navCtrl, fb, alertCtrl, register, PV, EV) {
        this.navCtrl = navCtrl;
        this.fb = fb;
        this.alertCtrl = alertCtrl;
        this.register = register;
        this.PV = PV;
        this.EV = EV;
        this.hidePassword = true;
        this.hideConfirmPassword = true;
        this.classId = 0;
        this.confirmClassId = 0;
    }
    ngOnInit() {
        this.registrationForm = this.fb.group({
            username: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](),
            fullname: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](),
            // phone:new FormControl('',Validators.compose([Validators.required,Validators.minLength(10),Validators.maxLength(10)])),
            // username:new FormControl('',Validators.compose([Validators.required,Validators.minLength(4),Validators.maxLength(8)])),
            // fullname:new FormControl('',Validators.compose([Validators.required,Validators.minLength(2),Validators.maxLength(64)])),
            phone: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].minLength(10), _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].maxLength(10), _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].pattern('^[0-9]*$')])),
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].pattern('^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$'), _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].minLength(6)])),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].minLength(2), _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].maxLength(64)])),
            confirm_password: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](),
            facilityid: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('198'),
        }, {
            validator: this.ConfirmedValidator('password', 'confirm_password')
        });
    }
    get username() {
        return this.registrationForm.get('username');
    }
    get fullname() {
        return this.registrationForm.get('fullname');
    }
    get email() {
        return this.registrationForm.get('email');
    }
    get phone() {
        return this.registrationForm.get('phone');
    }
    get password() {
        return this.registrationForm.get('password');
    }
    get confirm_password() {
        return this.registrationForm.get('confirm_password');
    }
    get facilityid() {
        return this.registrationForm.get('facilityid');
    }
    onSubmit(data) {
        var registerData = {
            "username": this.registrationForm.value.email,
            "password": this.registrationForm.value.password,
            "fullname": "",
            "email": "",
            "createdby": " ",
            "phone": this.registrationForm.value.phone,
            "facilityid": ""
        };
        // console.log(registerData)
        this.register.registerNewUser(registerData).subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.EV.emailVerification(this.registrationForm.value.email).subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                sweetalert2__WEBPACK_IMPORTED_MODULE_8___default.a.fire({
                    title: 'Success!',
                    html: 'Your account is created!<br> A verification link has been sent to your email account.',
                    icon: 'success',
                    showCancelButton: false,
                    imageHeight: '250px',
                    heightAuto: false,
                    confirmButtonText: 'Continue',
                    confirmButtonColor: '#57818A',
                }).then((result) => {
                    this.registrationForm.reset();
                    if (result.isConfirmed) {
                        this.navCtrl.navigateForward('login');
                        // console.log('Clicked Yes, File deleted!');
                    }
                });
            }), (error) => {
                sweetalert2__WEBPACK_IMPORTED_MODULE_8___default.a.fire({
                    title: 'Error!',
                    html: 'Something went wrong. Please try again later.',
                    icon: 'error',
                    showCancelButton: false,
                    imageHeight: '250px',
                    heightAuto: false,
                    // confirmButtonText: 'Continue',
                    confirmButtonColor: '#FF0000',
                }).then((result) => {
                    this.registrationForm.reset();
                });
            });
        }), (error) => {
            this.errorMsg = error;
            console.log(this.errorMsg);
            sweetalert2__WEBPACK_IMPORTED_MODULE_8___default.a.fire({
                title: 'Error!',
                html: 'Something went wrong. Please try again later.',
                icon: 'error',
                showCancelButton: false,
                imageHeight: '250px',
                heightAuto: false,
                // confirmButtonText: 'Continue',
                confirmButtonColor: '#FF0000',
            }).then((result) => {
                this.registrationForm.reset();
            });
        }, () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
        }));
    }
    test() {
        // Swal.fire('Congrats!', 'Your account is created!', 'success')
        sweetalert2__WEBPACK_IMPORTED_MODULE_8___default.a.fire({
            title: 'Success!',
            html: 'Your account is created!<br> A verification link has been sent to your email account.',
            icon: 'success',
            showCancelButton: false,
            imageHeight: '250px',
            heightAuto: false,
            confirmButtonText: 'Continue',
            confirmButtonColor: '#57818A',
        }).then((result) => {
            if (result.isConfirmed) {
                // console.log('Clicked Yes, File deleted!');
            }
        });
        // console.log(this.registrationForm.value)
    }
    ConfirmedValidator(controlName, matchingControlName) {
        return (formGroup) => {
            const control = formGroup.controls[controlName];
            const matchingControl = formGroup.controls[matchingControlName];
            if (matchingControl.errors && !matchingControl.errors.confirmedValidator) {
                return;
            }
            if (control.value !== matchingControl.value) {
                matchingControl.setErrors({ confirmedValidator: true });
            }
            else {
                matchingControl.setErrors(null);
            }
        };
    }
    emailFocusOut() {
        var email = { 'username': this.registrationForm.value.email };
        this.EV.emailValidator(email).subscribe((response) => {
            this.emailMessage = response;
            console.log(this.emailMessage.message);
            if (String(this.emailMessage.message) === "It's a new Email!") {
                return this.emailValid = false;
            }
            else if (String(this.emailMessage.message) === "Email Exists!") {
                return this.emailValid = true;
            }
        });
    }
    phoneFocusOut() {
        var phone = { 'phone': this.registrationForm.value.phone };
        if (this.registrationForm.value.phone !== null || this.registrationForm.value.phone !== '') {
            this.PV.phoneValidator(phone).subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                this.phoneMessage = response;
                if (String(this.phoneMessage.message) === "Phone no is null or empty") {
                    // console.log(phone)
                    if (this.registrationForm.value.phone == null || this.registrationForm.value.phone == '') {
                        return this.phoneValid = false;
                    }
                }
                else if (String(this.phoneMessage.message) === "Phone number Exists!") {
                    // console.log(phone)
                    return this.phoneValid = false;
                }
            }));
        }
    }
    signIn() {
        this.navCtrl.navigateBack(src_app_json_apis_json__WEBPACK_IMPORTED_MODULE_9__.apis.login_api);
    }
    confirm_Password() {
        if (this.hideConfirmPassword == true) {
            this.hideConfirmPassword = false, this.confirmClassId = 1;
        }
        else {
            this.hideConfirmPassword = true, this.confirmClassId = 0;
        }
        return this.hideConfirmPassword, this.confirmClassId;
    }
    passWord() {
        if (this.hidePassword == true) {
            return this.hidePassword = false, this.classId = 1;
        }
        else {
            return this.hidePassword = true, this.classId = 0;
        }
    }
    passWordClass(cId) {
        if (0 == cId) {
            return 'password  form-control app-font-primary-color ion-no-margin ion-no-padding';
        }
        else if (0 != cId) {
            return 'form-control app-font-primary-color ion-no-margin ion-no-padding';
        }
    }
    confirmPassWordClass(cId) {
        if (0 == cId) {
            return 'password  form-control app-font-primary-color ion-no-margin ion-no-padding';
        }
        else if (0 != cId) {
            return 'form-control app-font-primary-color ion-no-margin ion-no-padding';
        }
    }
};
RegisterPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
    { type: src_app_services_registration_service__WEBPACK_IMPORTED_MODULE_7__["RegistrationService"] },
    { type: src_app_services_phone_verification_phone_verification_service__WEBPACK_IMPORTED_MODULE_10__["PhoneVerificationService"] },
    { type: src_app_services_email_validation_service__WEBPACK_IMPORTED_MODULE_6__["EmailValidationService"] }
];
RegisterPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-register',
        template: _raw_loader_register_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_register_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], RegisterPage);



/***/ }),

/***/ "nU2W":
/*!*****************************************************************!*\
  !*** ./src/app/home/login-register/register/register.page.scss ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-item {\n  --background:#D0E4E4 ;\n}\n\n.password {\n  -webkit-text-security: disc;\n}\n\n.show-pass {\n  -webkit-text-security: none;\n}\n\n.hide-pass {\n  -webkit-text-security: disc;\n}\n\n.custom-shape-divider-top-1626283200 {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  overflow: hidden;\n  line-height: 0;\n  transform: rotate(180deg);\n}\n\n.custom-shape-divider-top-1626283200 svg {\n  position: relative;\n  display: block;\n  width: calc(154% + 1.3px);\n  height: 150px;\n}\n\n.custom-shape-divider-top-1626283200 .shape-fill {\n  fill: #57818A;\n}\n\n@media (max-device-height: 568px) {\n  .custom-shape-divider-top-1626283200 svg {\n    width: calc(146% + 1.3px);\n    height: 95px;\n  }\n\n  #top {\n    margin: 0;\n    padding: 0%;\n    width: 100%;\n    height: 20%;\n  }\n\n  #center {\n    margin: 0;\n    padding: 0%;\n    width: 100%;\n    height: 80%;\n    overflow-x: scroll;\n    overflow: hidden;\n    position: fixed;\n  }\n\n  #Sign-Up-title {\n    margin-top: -5%;\n    font-size: 16px;\n    text-align: right;\n  }\n\n  #sign-in {\n    margin-top: 0%;\n    margin-bottom: 5%;\n  }\n\n  #button {\n    margin-top: 0%;\n  }\n\n  #check-box-terms-and-conditions {\n    margin-top: 0%;\n  }\n}\n\n@media (max-device-height: 700px) {\n  .custom-shape-divider-top-1626283200 svg {\n    width: calc(146% + 1.3px);\n    height: 105px;\n  }\n\n  #top {\n    margin: 0;\n    padding: 0%;\n    width: 100%;\n    height: 20%;\n  }\n\n  #center {\n    margin: 0;\n    padding: 0%;\n    width: 100%;\n    height: 80%;\n    overflow: hidden;\n    overflow-x: scroll;\n    position: fixed;\n  }\n\n  #sign-in {\n    margin-top: 0%;\n    margin-bottom: 5%;\n  }\n\n  #button {\n    margin-top: 0%;\n  }\n\n  #check-box-terms-and-conditions {\n    margin-top: 0%;\n  }\n}\n\n#Sign-Up-title {\n  padding: 6%;\n  font-size: 38px;\n  text-align: right;\n}\n\n#sign-in {\n  margin-top: 5%;\n}\n\n#button {\n  margin-top: 5%;\n}\n\n#check-box-terms-and-conditions {\n  margin-top: 5%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxccmVnaXN0ZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0UscUJBQUE7QUFBRjs7QUFFQTtFQUNFLDJCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSwyQkFBQTtBQUVGOztBQUFBO0VBQ0UsMkJBQUE7QUFHRjs7QUFEQTtFQUNFLGtCQUFBO0VBQ0EsTUFBQTtFQUNBLE9BQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EseUJBQUE7QUFJRjs7QUFEQTtFQUNFLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLHlCQUFBO0VBQ0EsYUFBQTtBQUlGOztBQURBO0VBQ0UsYUFBQTtBQUlGOztBQURBO0VBQ0k7SUFDRSx5QkFBQTtJQUNBLFlBQUE7RUFJSjs7RUFESTtJQUNFLFNBQUE7SUFBUyxXQUFBO0lBQWEsV0FBQTtJQUFZLFdBQUE7RUFPeEM7O0VBTEk7SUFDRSxTQUFBO0lBQVMsV0FBQTtJQUFhLFdBQUE7SUFDdEIsV0FBQTtJQUNBLGtCQUFBO0lBQ0EsZ0JBQUE7SUFDQSxlQUFBO0VBVU47O0VBUkk7SUFDRSxlQUFBO0lBQ0EsZUFBQTtJQUFnQixpQkFBQTtFQVl0Qjs7RUFWSTtJQUNFLGNBQUE7SUFDQSxpQkFBQTtFQWFOOztFQVhJO0lBQ0UsY0FBQTtFQWNOOztFQVpJO0lBQ0UsY0FBQTtFQWVOO0FBQ0Y7O0FBYkE7RUFDRTtJQUNFLHlCQUFBO0lBQ0EsYUFBQTtFQWVGOztFQVpFO0lBQ0UsU0FBQTtJQUFTLFdBQUE7SUFBYSxXQUFBO0lBQVksV0FBQTtFQWtCdEM7O0VBZkU7SUFDRSxTQUFBO0lBQVMsV0FBQTtJQUFhLFdBQUE7SUFDdEIsV0FBQTtJQUNBLGdCQUFBO0lBQ0Esa0JBQUE7SUFDQSxlQUFBO0VBb0JKOztFQWpCRTtJQUNFLGNBQUE7SUFDQSxpQkFBQTtFQW9CSjs7RUFsQkU7SUFDRSxjQUFBO0VBcUJKOztFQW5CRTtJQUNFLGNBQUE7RUFzQko7QUFDRjs7QUFwQkE7RUFDRSxXQUFBO0VBQVksZUFBQTtFQUNaLGlCQUFBO0FBdUJGOztBQXJCQTtFQUNFLGNBQUE7QUF3QkY7O0FBdEJBO0VBQ0UsY0FBQTtBQXlCRjs7QUF2QkE7RUFDRSxjQUFBO0FBMEJGIiwiZmlsZSI6InJlZ2lzdGVyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuaW9uLWl0ZW17XG4gIC0tYmFja2dyb3VuZDojRDBFNEU0XG59XG4ucGFzc3dvcmR7XG4gIC13ZWJraXQtdGV4dC1zZWN1cml0eTogZGlzYztcbn1cbi5zaG93LXBhc3N7XG4gIC13ZWJraXQtdGV4dC1zZWN1cml0eTpub25lO1xufVxuLmhpZGUtcGFzc3tcbiAgLXdlYmtpdC10ZXh0LXNlY3VyaXR5OmRpc2M7XG59XG4uY3VzdG9tLXNoYXBlLWRpdmlkZXItdG9wLTE2MjYyODMyMDAge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgbGVmdDogMDtcbiAgd2lkdGg6IDEwMCU7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIGxpbmUtaGVpZ2h0OiAwO1xuICB0cmFuc2Zvcm06IHJvdGF0ZSgxODBkZWcpO1xufVxuXG4uY3VzdG9tLXNoYXBlLWRpdmlkZXItdG9wLTE2MjYyODMyMDAgc3ZnIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBkaXNwbGF5OiBibG9jaztcbiAgd2lkdGg6IGNhbGMoMTU0JSArIDEuM3B4KTtcbiAgaGVpZ2h0OiAxNTBweDtcbn1cblxuLmN1c3RvbS1zaGFwZS1kaXZpZGVyLXRvcC0xNjI2MjgzMjAwIC5zaGFwZS1maWxsIHtcbiAgZmlsbDogIzU3ODE4QTtcbn1cblxuQG1lZGlhIChtYXgtZGV2aWNlLWhlaWdodDogNTY4cHgpIHtcbiAgICAuY3VzdG9tLXNoYXBlLWRpdmlkZXItdG9wLTE2MjYyODMyMDAgc3ZnIHtcbiAgICAgIHdpZHRoOiBjYWxjKDE0NiUgKyAxLjNweCk7XG4gICAgICBoZWlnaHQ6IDk1cHg7XG4gICAgICB9XG5cbiAgICAgICN0b3B7XG4gICAgICAgIG1hcmdpbjowO3BhZGRpbmc6IDAlIDt3aWR0aDogMTAwJTtoZWlnaHQ6IDIwJTtcbiAgICAgIH1cbiAgICAgICNjZW50ZXJ7XG4gICAgICAgIG1hcmdpbjowO3BhZGRpbmc6IDAlIDt3aWR0aDogMTAwJTtcbiAgICAgICAgaGVpZ2h0OiA4MCU7XG4gICAgICAgIG92ZXJmbG93LXg6IHNjcm9sbDtcbiAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgICAgcG9zaXRpb246IGZpeGVkO1xuICAgICAgfVxuICAgICAgI1NpZ24tVXAtdGl0bGUge1xuICAgICAgICBtYXJnaW4tdG9wOiAtNSU7XG4gICAgICAgIGZvbnQtc2l6ZTogMTZweDt0ZXh0LWFsaWduOiByaWdodDtcbiAgICAgIH1cbiAgICAgICNzaWduLWlue1xuICAgICAgICBtYXJnaW4tdG9wOiAwJTtcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogNSU7XG4gICAgICB9XG4gICAgICAjYnV0dG9ue1xuICAgICAgICBtYXJnaW4tdG9wOiAwJTtcbiAgICAgIH1cbiAgICAgICNjaGVjay1ib3gtdGVybXMtYW5kLWNvbmRpdGlvbnN7XG4gICAgICAgIG1hcmdpbi10b3A6IDAlO1xuICAgICAgfVxufVxuQG1lZGlhIChtYXgtZGV2aWNlLWhlaWdodDogNzAwcHgpIHtcbiAgLmN1c3RvbS1zaGFwZS1kaXZpZGVyLXRvcC0xNjI2MjgzMjAwIHN2ZyB7XG4gICAgd2lkdGg6IGNhbGMoMTQ2JSArIDEuM3B4KTtcbiAgICBoZWlnaHQ6IDEwNXB4O1xuICAgIH1cblxuICAgICN0b3B7XG4gICAgICBtYXJnaW46MDtwYWRkaW5nOiAwJSA7d2lkdGg6IDEwMCU7aGVpZ2h0OiAyMCU7XG4gICAgICAvLyBvdmVyZmxvdzogaGlkZGVuO1xuICAgIH1cbiAgICAjY2VudGVye1xuICAgICAgbWFyZ2luOjA7cGFkZGluZzogMCUgO3dpZHRoOiAxMDAlO1xuICAgICAgaGVpZ2h0OiA4MCU7XG4gICAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgICAgb3ZlcmZsb3cteDogc2Nyb2xsO1xuICAgICAgcG9zaXRpb246IGZpeGVkO1xuICAgIH1cblxuICAgICNzaWduLWlue1xuICAgICAgbWFyZ2luLXRvcDogMCU7XG4gICAgICBtYXJnaW4tYm90dG9tOiA1JTtcbiAgICB9XG4gICAgI2J1dHRvbntcbiAgICAgIG1hcmdpbi10b3A6IDAlO1xuICAgIH1cbiAgICAjY2hlY2stYm94LXRlcm1zLWFuZC1jb25kaXRpb25ze1xuICAgICAgbWFyZ2luLXRvcDogMCU7XG4gICAgfVxufVxuI1NpZ24tVXAtdGl0bGUge1xuICBwYWRkaW5nOiA2JTtmb250LXNpemU6IDM4cHg7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xufVxuI3NpZ24taW57XG4gIG1hcmdpbi10b3A6IDUlO1xufVxuI2J1dHRvbntcbiAgbWFyZ2luLXRvcDogNSU7XG59XG4jY2hlY2stYm94LXRlcm1zLWFuZC1jb25kaXRpb25ze1xuICBtYXJnaW4tdG9wOiA1JTtcbn1cbiJdfQ== */");

/***/ })

}]);
//# sourceMappingURL=login-register-register-register-module.js.map