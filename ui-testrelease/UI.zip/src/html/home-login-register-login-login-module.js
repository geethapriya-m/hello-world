(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-login-register-login-login-module"],{

/***/ "BtGM":
/*!***********************************************************!*\
  !*** ./src/app/home/login-register/login/login.module.ts ***!
  \***********************************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./login-routing.module */ "VAwo");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "NoyM");
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/icon */ "Tj54");








let LoginPageModule = class LoginPageModule {
};
LoginPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_material_icon__WEBPACK_IMPORTED_MODULE_7__["MatIconModule"],
            _login_routing_module__WEBPACK_IMPORTED_MODULE_5__["LoginPageRoutingModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot({ scrollAssist: true, scrollPadding: false }),
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
    })
], LoginPageModule);



/***/ }),

/***/ "Jw5V":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/login-register/login/login.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<ion-content  id=\"content \" class=\"app-background-primary-color\" overflow-scroll=\"true\" style=\"--position: fixed;\">\n  <form [formGroup]=\"loginForm\" class=\"app-background-primary-color\" style=\"min-height: 100%;position: fixed;\">\n\n  <section  id=\"top\" class=\"app-background-primary-color\">\n<ion-grid class=\"app-background-primary-color\">\n  <ion-row class=\"ion-justify-content-center ion-text-center\">\n    <ion-img id=\"home-page-header mercurius-logo \" class=\"ion-no-padding ion-no-margin\" src=\"assets/img/mercurius-logo.png\"></ion-img>\n  </ion-row>\n\n</ion-grid>\n\n<ion-grid class=\"ion-no-padding-top ion-no-margin-top app-background-primary-color\">\n  <ion-row>\n  <ion-row  class=\"ion-justify-content-center straightline-font-size ion-no-padding-bottom ion-no-margin-bottom\" id=\"title-straightline\" >\n    <p class=\"app-title \"><b class=\"app-font-primary-color \">StraightLines</b><b class=\"app-font-primary-color\">.io</b></p>\n    <p style=\"color:#847D7D\" class=\"app-font-secondary-color content-data-14px \">Cyclical Scheduling powered by One Click</p>\n    <!-- <p style=\"color:#847D7D\" class=\"app-font-secondary-color content-data-14px \"><b>E</b>very <b>E</b>mployee <b>D</b>eserves <b>D</b>esirable <b>M</b>oves</p> -->\n  </ion-row>\n</ion-row>\n</ion-grid>\n  </section>\n<section id=\"center\" class=\"app-background-primary-color\" >\n  <!-- <form [formGroup]=\"loginForm\" > -->\n\n    <ion-grid style=\"height: 100%;\" class=\"app-background-primary-color\">\n\n    <ion-row id=\"login-form\" class=\" content-data app-font-primary-color app-background-primary-color ion-no-margin ion-no-padding\">\n      <ion-col size=\"1\"></ion-col>\n      <ion-col size=\"10\" class=\"app-font-primary-color ion-no-padding ion-no-margin\">\n      <ion-item lines=\"none\" style=\"--background:#D0E4E4\" id=\"register-input-ion-item\" class=\"app-font-primary-color app-background-primary-color ion-justify-content-center\" >\n\n      <ion-label position=\"stacked\" style=\"padding-left: 5px;margin-bottom: 5px; \" class=\"app-font-primary-color app-background-primary-color\" id=\"form-label\">Email  as username</ion-label>\n      <ion-input type=\"text\" (focusout)=\"usernameFocusOut()\" formControlName=\"username\"  id=\"pass-input\"  class=\"form-control app-font-primary-color  border-2px-solid ion-no-margin ion-no-padding\" style=\"border-radius: 5px;\"\n      ></ion-input>\n\n    </ion-item>\n    <p class=\"app-font-red-color content-data\" style=\"margin-left:8%;margin-bottom: -2%;padding-bottom:0%\" *ngIf=\"emailValid\"><ion-icon name=\"alert-circle-outline\"></ion-icon> Invalid username!!</p>\n    </ion-col>\n    <ion-col size=\"1\">\n\n    </ion-col>\n\n    <ion-col  class=\"ion-justify-content-center straightline-font-size ion-no-padding-bottom ion-no-margin-bottom \"  style=\"text-align: right;\">\n      <ion-label class=\"app-font-primary-color content-data-14px \" style=\"font-size:16px;\"><ion-checkbox style=\"--size:16px\" formControlName=\"remberMe\" ></ion-checkbox> Remember username </ion-label>\n    </ion-col>\n    <ion-col size=\"1\"></ion-col>\n</ion-row>\n<ion-row >\n      <ion-col size=\"1\"></ion-col>\n      <ion-col size=\"10\" class=\"ion-no-padding ion-no-margin\">\n        <ion-item lines=\"none\"style=\"--background:#D0E4E4\" id=\"register-input-ion-item\" class=\"app-font-primary-color ion-justify-content-center\" >\n        <ion-label position=\"stacked\" id=\"form-label\" style=\"padding-left: 5px;margin-bottom: 5px;\">Password</ion-label>\n      <ion-input type=\"text\" id=\"pass-input\" (ionChange)=\"passwordChange()\"  formControlName=\"password\" [class]=\"passWordClass(classId) \"  style=\"border-radius: 5px;position: relative;z-index: -1;\"></ion-input>\n      <ion-icon *ngIf=\"hidePassword\" class=\"app-font-primary-color\" style=\"position:absolute; right:6%;font-size: 20px;bottom: 10px;z-index: 1;\" (click)=\"passWord()\"  name=\"eye-off-outline\"></ion-icon>\n        <ion-icon *ngIf=\"!hidePassword\" class=\"app-font-primary-color\" style=\"position:absolute; right:6%;font-size: 20px;bottom: 10px;z-index: 1;\" (click)=\"passWord()\" name=\"eye-outline\"></ion-icon>\n\n    </ion-item>\n\n    <p class=\"app-font-red-color content-data\" style=\"margin-left:8%;margin-bottom: -2%;padding-bottom:0%\" *ngIf=\"invalid_email_password\"><ion-icon name=\"alert-circle-outline\"></ion-icon> Invalid username or password!!</p>\n  </ion-col><ion-col size=\"1\"></ion-col>\n    <!-- <ion-col size=\"2\"></ion-col>\n    <ion-col class=\"ion-no-margin ion-no-padding\">\n      <p *ngIf=\"invalid_username_password\"  class=\"app-font-primary-color content-data\" style=\"color: Red;\"><ion-icon name=\"alert-circle-outline\"></ion-icon> Invalid Email or Password </p>\n    </ion-col> -->\n\n  </ion-row>\n<!--\n</ion-grid>\n<ion-grid> -->\n  <ion-row  id=\"sign-up\" class=\"ion-justify-content-center straightline-font-size ion-no-padding-bottom ion-no-margin-bottom\" >\n    <p class=\"app-font-primary-color content-data-14px \" style=\"font-size:16px;\">Don't have an account? <b (click)=\"signUp()\">Sign Up</b></p>\n  </ion-row>\n<!-- </ion-grid>\n<ion-grid> -->\n  <ion-row  class=\"ion-justify-content-center\">\n    <ion-button shape=\"round\"  class=\"app-button-primary\" id=\"sign-in\"  (click)=\"signIn()\" >Sign In</ion-button>\n  </ion-row>\n<!-- </ion-grid>\n\n<ion-grid> -->\n  <ion-row  id=\"user-pass\" class=\"ion-justify-content-center straightline-font-size ion-no-padding-bottom ion-no-margin-bottom\"  >\n    <p class=\"app-font-primary-color content-data-14px \" (click)=\"passwordReset()\" style=\"font-size:16px;\">Forgot Username or Password? </p>\n  </ion-row>\n  <!-- <ion-row  id=\"save-username\" class=\"ion-justify-content-center straightline-font-size ion-no-padding-bottom ion-no-margin-bottom\"  >\n    <p class=\"app-font-primary-color content-data-14px \" style=\"font-size:16px;\"><ion-checkbox style=\"--size:16px\" formControlName=\"remberMe\" ></ion-checkbox> Remember username </p>\n  </ion-row> -->\n</ion-grid>\n\n\n</section>\n\n<section class=\"app-triangel-background-color \"  id=\"triangle-up-left\" style=\"margin-bottom: -1px !important;bottom: 0 !important;box-shadow: none;border: none !important;border-style: none !important;;\">\n  <ion-grid  style=\"padding-left: 3%;font-size: 20px;padding-top: 10px;margin-bottom: 0%;\">\n    <ion-row (click)=\"video()\" class=\"content-data ion-no-margin ion-no-padding\" id=\"info\" style=\"font-size: 18px;\">\n      <ion-col><ion-label  style=\"color: white;\">What is Straightlines.io?</ion-label></ion-col>\n    </ion-row>\n    <ion-row  class=\" content-data ion-no-margin ion-no-padding\" id=\"feedback\" style=\"font-size: 18px;\"\n                (click)=\"onClickFeedback()\">\n         <ion-col> <ion-label style=\"color: white;\">Send  Feedback </ion-label><ion-icon style=\"color: white;height: 16px;margin-left: 1%;\" name=\"mail-outline\"></ion-icon>\n         </ion-col>\n              </ion-row>\n\n</ion-grid>\n<ion-grid style=\"bottom: 0% !important;text-align: right;\">\n  <ion-row  style=\"text-align: right;\" class=\" content-data ion-no-margin ion-no-padding\">\n    <ion-col size=\"12\" style=\"text-align: right;padding-right: 4%;padding-top: 0px;\">\n      <!-- <ion-img style=\"height:100%;width:36px;float: right;\" class=\"ion-no-padding ion-no-margin\" src=\"assets/img/EEDDM.png\"></ion-img> -->\n      <ion-label style=\"font-size: 15px;\">E E D D M</ion-label>\n      <!-- <mat-icon class=\"app-font-primary-color\" style=\"font-size: 36px;\">person</mat-icon> -->\n  </ion-col>\n  <ion-col size=\"12\" class=\"ion-no-margin-top ion-no-padding-top\">\n  <ion-label class=\"app-font-primary-color ion-no-margin-top ion-no-padding-top\"   style=\"font-size: 15px;text-align: right;bottom:0 !important\">\n    Every Employee Deserves Desirable Moves\n</ion-label></ion-col>\n</ion-row>\n\n</ion-grid>\n</section>\n</form>\n\n</ion-content>\n");

/***/ }),

/***/ "NoyM":
/*!*********************************************************!*\
  !*** ./src/app/home/login-register/login/login.page.ts ***!
  \*********************************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./login.page.html */ "Jw5V");
/* harmony import */ var _login_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login.page.scss */ "Xy1A");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_services_work_load_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/work-load.service */ "FcOq");
/* harmony import */ var src_app_json_apis_json__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/json/apis.json */ "B+pZ");
var src_app_json_apis_json__WEBPACK_IMPORTED_MODULE_8___namespace = /*#__PURE__*/__webpack_require__.t(/*! src/app/json/apis.json */ "B+pZ", 1);
/* harmony import */ var src_app_json_work_load_data_json__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/json/work-load-data.json */ "V1zY");
var src_app_json_work_load_data_json__WEBPACK_IMPORTED_MODULE_9___namespace = /*#__PURE__*/__webpack_require__.t(/*! src/app/json/work-load-data.json */ "V1zY", 1);
/* harmony import */ var src_app_json_required_workforce_json__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/json/required-workforce.json */ "uMUc");
var src_app_json_required_workforce_json__WEBPACK_IMPORTED_MODULE_10___namespace = /*#__PURE__*/__webpack_require__.t(/*! src/app/json/required-workforce.json */ "uMUc", 1);
/* harmony import */ var src_app_services_login_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/login.service */ "EFyh");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! sweetalert2 */ "PSD3");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var src_app_services_email_validation_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/services/email-validation.service */ "+xEj");
/* harmony import */ var src_app_services_forgot_password_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/services/forgot-password.service */ "j8Zn");
















let LoginPage = class LoginPage {
    constructor(route, navCtrl, shiftDefSer, modalCtrl, loginSer, EV, FP, fb, _sanitizer) {
        this.route = route;
        this.navCtrl = navCtrl;
        this.shiftDefSer = shiftDefSer;
        this.modalCtrl = modalCtrl;
        this.loginSer = loginSer;
        this.EV = EV;
        this.FP = FP;
        this.fb = fb;
        this._sanitizer = _sanitizer;
        this.reqWorkForce = src_app_json_required_workforce_json__WEBPACK_IMPORTED_MODULE_10__;
        this.worData = src_app_json_work_load_data_json__WEBPACK_IMPORTED_MODULE_9__;
        this.hidePassword = true;
        this.classId = 0;
        this.checked = true;
        this.invalid_email_password = false;
        this.valueforngif = true;
        this.default_work_load_data = src_app_json_work_load_data_json__WEBPACK_IMPORTED_MODULE_9__;
        this.allll = [];
        this.allShiftName = [];
        this.arrangeShiftdefintionG = [];
        this.arrangeShiftdefintionL = [];
        this.isKeyboardHide = true;
        this.videoUrl = 'assets/video/straughtlines-io.mp4';
        this.invalid_username_password = false;
        this.safeURL = this.videoUrl;
        // this.initializeApp()
    }
    //   ionViewDidEnter(){
    //  this.ngOnInit()
    // }
    ngOnInit() {
        const loginData = JSON.parse(localStorage.getItem('userLoginData'));
        if (loginData !== null) {
            // console.log(loginData.username)
            if (loginData.saveUser == true) {
                this.loginForm = this.fb.group({
                    username: new _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormControl"](loginData.username, _angular_forms__WEBPACK_IMPORTED_MODULE_12__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_12__["Validators"].required])),
                    password: new _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_12__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_12__["Validators"].required])),
                    remberMe: new _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormControl"](true)
                });
                this.saveusername = this.fb.group({
                    checkBox: [true]
                });
            }
            else {
                this.loginForm = this.fb.group({
                    username: new _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_12__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_12__["Validators"].required])),
                    password: new _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_12__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_12__["Validators"].required])),
                    remberMe: new _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormControl"](false)
                });
                this.saveusername = this.fb.group({
                    checkBox: [false]
                });
            }
        }
        else {
            this.loginForm = this.fb.group({
                username: new _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_12__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_12__["Validators"].required])),
                password: new _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_12__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_12__["Validators"].required])),
                remberMe: new _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormControl"](false)
            });
            this.saveusername = this.fb.group({
                checkBox: [false]
            });
        }
    }
    get username() {
        return this.loginForm.get('username');
    }
    get password() {
        return this.loginForm.get('password');
    }
    signUp() {
        this.navCtrl.navigateForward(src_app_json_apis_json__WEBPACK_IMPORTED_MODULE_8__.apis.register_api);
    }
    passwordChange() {
        this.invalid_email_password = false;
    }
    usernameFocusOut() {
        console.log();
        var getUserData = { "username": this.loginForm.value.username };
        this.EV.emailValidator(getUserData).subscribe((response) => {
            this.emailMessage = response;
            //  console.log(this.emailMessage.message)
            if (String(this.emailMessage.message) === "It's a new Email!") {
                return this.emailValid = true;
            }
            else if (String(this.emailMessage.message) === "Email Exists!") {
                return this.emailValid = false;
            }
        });
        // this.loginSer.getUserAllDetails(getUserData).subscribe(
        //   async (response)=>{
        //     console.log(response)
        //     return this.userDetails=response
        //       },
        //         (error: any)=>{this.errorMsg=error
        //         console.log(this.errorMsg)},
        //         ()=>{
        //         }
        //         );
    }
    signIn() {
        var isChecked = this.loginForm.value.remberMe;
        // if(isChecked){
        // console.log(isChecked);
        //   console.log(this.loginForm.value.username)
        var userData = { 'saveUser': isChecked, 'username': this.loginForm.value.username };
        var loginData = { 'username': this.loginForm.value.username, 'password': this.loginForm.value.password };
        // console.log(this.userDetails)
        var getUserData = { "username": this.loginForm.value.username };
        this.loginSer.getUserAllDetails(getUserData).subscribe((response) => {
            this.userDetails = response;
            if (this.userDetails.enabled == true) {
                // console.log(this.userDetails.enabled)
                this.loginSer.registerNewUser(loginData).subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    localStorage.setItem('userLoginData', JSON.stringify(userData));
                    if (response !== null) {
                        // console.log(response)
                        localStorage.setItem('userData', JSON.stringify(response));
                        localStorage.setItem('token', JSON.stringify(response['accessToken']));
                        localStorage.setItem('PWP-PSO', JSON.stringify({ "PWP": ["EVE", "EVE", "DAY", "DAY", "MID"], "PSO": ["1500", "1300", "0700", "0600", "2300"] }));
                        this.user_data = { "user_id": JSON.stringify(response['id']), "email": JSON.stringify(response['email']) };
                        if (response) {
                            // console.log(this.user_data.user_id)
                            this.shiftDefSer.getAllShiftDefinition(this.user_data.user_id).subscribe((res) => {
                                this.allShift = res;
                                var user_all_shift = [];
                                // console.log(this.allShift)
                                for (var i = 0; i < this.allShift.length; i++) {
                                    if (Number(this.allShift[i].userid) == Number(this.user_data.user_id)) {
                                        user_all_shift.push(this.allShift[i]);
                                    }
                                }
                                localStorage.setItem('allShift', JSON.stringify(user_all_shift));
                                this.allShiftdata();
                            }, (error) => {
                                this.errorMsg = error;
                                // console.log(this.errorMsg)
                                this.allDefaultShiftdata();
                            }, () => {
                            });
                        }
                    }
                    else {
                        this.invalid_email_password = true;
                        console.log("Invalid username or password!");
                    }
                }), (error) => {
                    this.errorMsg = error;
                    if (this.errorMsg != null) {
                        // console.log(this.errorMsg)
                        this.invalid_email_password = true;
                    }
                }, () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                }));
                this.navCtrl.navigateForward(src_app_json_apis_json__WEBPACK_IMPORTED_MODULE_8__.apis.enter_Work_load_api);
            }
            else {
                sweetalert2__WEBPACK_IMPORTED_MODULE_13___default.a.fire({
                    title: 'Error!',
                    html: 'Your Email address could not be verified! Please check your email and verfiy your account.',
                    icon: 'error',
                    inputLabel: 'Resend verification link',
                    inputPlaceholder: 'Enter your email address',
                    input: 'email',
                    inputAttributes: {
                        autocapitalize: 'off'
                    },
                    showCancelButton: true,
                    showConfirmButton: true,
                    imageHeight: '200px',
                    heightAuto: false,
                    confirmButtonText: 'Send',
                    confirmButtonColor: '#57818A',
                    preConfirm: (d) => {
                        this.inputEmail = d;
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        // this.EV.emailValidator({'username':this.inputEmail}).subscribe(
                        //   async (response)=>{
                        // if(response!==null){
                        // return  this.emailValid=true
                        this.EV.emailVerification(this.inputEmail).subscribe((res) => {
                            // console.log(res)
                        }, (error) => {
                            // console.log(error)
                        }, () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                        }));
                        // }else{
                        //   return  this.emailValid=false
                        // }
                        // })
                    }
                });
            }
        }, (error) => {
            this.errorMsg = error;
            console.log(this.errorMsg);
        }, () => {
        });
    }
    verfiyEmail() {
        console.log("resend");
    }
    video() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            window.open('https://www.youtube.com/watch?v=3K6kMSg1xuQ', '_self', 'location=yes');
            // const modal = await this.modalCtrl.create({
            //   component: StraightlinesIoVideoPage,
            //   cssClass: 'straightlinesIoVideo',
            //   swipeToClose:true
            //   // componentProps: { scheduleData: scheduleShift }
            // });
            // // this.scheduleShift=EditScheduleDataPage.data5
            // // console.log(this.scheduleShift)
            // return await modal.present();
        });
    }
    focusIn() {
        if (/Android/i.test(navigator.userAgent)) {
            if (navigator.platform !== 'Win32' && navigator.platform !== 'Win16') {
                this.valueforngif = false;
            }
        }
        this.t = navigator.platform;
        // console.log(this.valueforngif)
    }
    focusOut() {
        if (/Android/i.test(navigator.userAgent)) {
            if (navigator.platform !== 'Win32' && navigator.platform !== 'Win16') {
                this.valueforngif = true;
            }
        }
        // console.log(this.valueforngif)
    }
    saveUsername() {
        console.log();
        var isChecked = this.saveusername.value.checkBox;
        // e.currentTarget.checked;
        // console.log(isChecked)
        if (!isChecked) {
            // console.log(!isChecked);
            // console.log(this.loginForm.value.username)
            var userData = { 'saveUser': !isChecked, 'username': this.loginForm.value.username };
            localStorage.setItem('userLoginData', JSON.stringify(userData));
        }
        else {
            // console.log(!isChecked);
            const userData = { 'saveUser': !isChecked, 'username': "" };
            localStorage.setItem('userLoginData', JSON.stringify(userData));
        }
        //  this.ngOnInit()
    }
    // }
    start() {
        // localStorage.setItem( 'workData',JSON.stringify(this.worData))
        // localStorage.setItem( 'totalCountSummary',JSON.stringify(this.worData))
        // this.route.navigateByUrl('workload-data-generate')
        this.navCtrl.navigateForward(src_app_json_apis_json__WEBPACK_IMPORTED_MODULE_8__.apis.dashboard);
    }
    passwordReset() {
        sweetalert2__WEBPACK_IMPORTED_MODULE_13___default.a.fire({
            title: 'Reset your password',
            html: "Enter your user account's verified email address and we will send you a verification link.",
            // inputLabel: 'Your email address',
            inputPlaceholder: 'Enter your email address',
            input: 'email',
            inputAttributes: {
                autocapitalize: 'off'
            },
            showCancelButton: true,
            showConfirmButton: true,
            imageHeight: '200px',
            heightAuto: false,
            confirmButtonText: 'Send',
            confirmButtonColor: '#57818A',
            preConfirm: (emailID) => {
                this.forgotPasswordEmail = emailID;
            }
        }).then((result) => {
            if (result.isConfirmed) {
                this.EV.emailValidator({ 'username': this.forgotPasswordEmail }).subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    if (response !== null) {
                        this.forgotPasswordEmailValid = true;
                        this.FP.emailVerificationForForgotPassword(this.forgotPasswordEmail).subscribe(() => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                            // this.navCtrl.navigateForward(['reset-password/','vrushang.patel@mercuriusinc.com'])
                        }));
                        // this.FP.emailVerify(this.forgotPasswordEmail).subscribe(
                        //   async (response)=>{
                        //     console.log(response)
                        //   },
                        //   (error: any)=>{
                        //     this.errorMsg=error.error.text;
                        //     this.url_token=this.errorMsg
                        //     // console.log(this.url_token)
                        //     // console.log(String(this.url_token).substr(0,45))
                        //     if(String(this.url_token).substr(0,45)=="http://52.14.8.217:2020/reset-password?token="){
                        //       this.emailValid=false
                        //       console.log(this.emailValid)
                        //       console.log(this.url_token)
                        //     }
                        //   },
                        //   async () => {
                        //   }
                        // )
                    }
                    else {
                        this.forgotPasswordEmailValid = false;
                    }
                }));
            }
        });
    }
    onClickFeedback() {
        // this.navCtrl.navigateForward('feedback')
        window.open('mailto:feedback@mercuriusinc.com?subject=Feedback: Straightlines.io');
    }
    allShiftdata() {
        this.allll = [];
        this.allShiftData = JSON.parse(localStorage.getItem('allShift'));
        // console.log(this.allShiftData)
        this.test1 = { "sh_name": null };
        localStorage.setItem('newSHiftDefinition', JSON.stringify(this.test1));
        this.work_load_data = [];
        for (var i = 0; i < this.default_work_load_data.length; i++) {
            this.work_load_data.push(this.default_work_load_data[i]);
        }
        // console.log(this.work_load_data)
        if (this.allShiftData != null) {
            // console.log(this.work_load_data)
            for (var i = 0; i < this.allShiftData.length; i++) {
                this.convertTimetoString = Array.from(this.allShiftData[i].sh_starttime);
                this.sh_startTime = this.convertTimetoString[0] + this.convertTimetoString[1] + this.convertTimetoString[3] + this.convertTimetoString[4];
                this.shift_name = this.allShiftData[i].sh_name;
                this.work_load_data.push({ "id": 9 + i,
                    "startTime": this.sh_startTime,
                    "Sun": "0",
                    "Mon": "0",
                    "Tue": "0",
                    "Wed": "0",
                    "Thu": "0",
                    "Fri": "0",
                    "Sat": "0",
                    "shiftName": this.shift_name,
                    "shiftCategory": this.allShiftData[i].sh_category_id,
                    "shift_created_by": this.allShiftData[i].sh_created_by,
                    "sh_include_exclude": this.allShiftData[i].sh_include_exclude
                });
                // this.allShift[i])
            }
        }
        this.arrangeShiftdefintionG = [];
        this.arrangeShiftdefintionL = [];
        for (var i = 0; i < this.work_load_data.length; i++) {
            if (Number(this.work_load_data[i].startTime) > 2200) {
                this.arrangeShiftdefintionG.push(this.work_load_data[i]);
            }
            else if (Number(this.work_load_data[i].startTime) <= 2200) {
                this.arrangeShiftdefintionL.push(this.work_load_data[i]);
            }
        }
        this.arrangeShiftdefintionG.sort((a, b) => a.startTime.localeCompare(b.startTime));
        this.arrangeShiftdefintionL.sort((a, b) => a.startTime.localeCompare(b.startTime));
        // console.log(this.arrangeShiftdefintionG)
        // console.log(this.arrangeShiftdefintionL)
        this.work_load_data = [];
        // this.work_load_data.push(this.arrangeShiftdefintionG)
        for (var i = 0; i < this.arrangeShiftdefintionG.length; i++) {
            this.work_load_data.push(this.arrangeShiftdefintionG[i]);
        }
        for (var i = 0; i < this.arrangeShiftdefintionL.length; i++) {
            this.work_load_data.push(this.arrangeShiftdefintionL[i]);
        }
        // console.log(this.work_load_data)
        for (var i = 0; i < this.work_load_data.length; i++) {
            // console.log()
            // this.shift_name=this.allShiftData[i].sh_name
            if (this.work_load_data[i].shiftName != null) {
                // this.allShiftName.push({"shift_name":this.work_load_data[i].shiftName,"startTime": this.work_load_data[i].startTime,"shiftPattern": 'M'+ this.work_load_data[i].startTime})
                if (Number(this.work_load_data[i].startTime) > 2200 || Number(this.work_load_data[i].startTime) < 600) {
                    this.allShiftName.push({ "id": i + 1, "shift_name": this.work_load_data[i].shiftName, "startTime": this.work_load_data[i].startTime, "shiftPattern": 'M' + this.work_load_data[i].startTime });
                }
                else if (Number(this.work_load_data[i].startTime) > 500 && Number(this.work_load_data[i].startTime) < 1300) {
                    this.allShiftName.push({ "id": i + 1, "shift_name": this.work_load_data[i].shiftName, "startTime": this.work_load_data[i].startTime, "shiftPattern": 'D' + this.work_load_data[i].startTime });
                }
                else if (Number(this.work_load_data[i].startTime) > 1200 && Number(this.work_load_data[i].startTime) < 2300) {
                    this.allShiftName.push({ "id": i + 1, "shift_name": this.work_load_data[i].shiftName, "startTime": this.work_load_data[i].startTime, "shiftPattern": 'E' + this.work_load_data[i].startTime });
                }
            }
        }
        // console.log(this.allShiftName)
        // console.log(this.work_load_data)
        localStorage.setItem('allShiftRequiredData', JSON.stringify(this.work_load_data));
        localStorage.setItem('updatedallShiftRequiredData', JSON.stringify(this.work_load_data));
        localStorage.setItem('outliers', JSON.stringify([]));
        this.loginForm.reset();
        this.navCtrl.navigateForward(src_app_json_apis_json__WEBPACK_IMPORTED_MODULE_8__.apis.dashboard);
    }
    allDefaultShiftdata() {
        this.allll = [];
        this.allShiftData = JSON.parse(localStorage.getItem('allShift'));
        // console.log(this.allShiftData)
        this.test1 = { "sh_name": null };
        localStorage.setItem('newSHiftDefinition', JSON.stringify(this.test1));
        this.work_load_data = [];
        for (var i = 0; i < this.default_work_load_data.length; i++) {
            this.work_load_data.push(this.default_work_load_data[i]);
        }
        // console.log(this.work_load_data)
        this.arrangeShiftdefintionG = [];
        this.arrangeShiftdefintionL = [];
        for (var i = 0; i < this.work_load_data.length; i++) {
            if (Number(this.work_load_data[i].startTime) > 2200) {
                this.arrangeShiftdefintionG.push(this.work_load_data[i]);
            }
            else if (Number(this.work_load_data[i].startTime) <= 2200) {
                this.arrangeShiftdefintionL.push(this.work_load_data[i]);
            }
        }
        this.arrangeShiftdefintionG.sort((a, b) => a.startTime.localeCompare(b.startTime));
        this.arrangeShiftdefintionL.sort((a, b) => a.startTime.localeCompare(b.startTime));
        // console.log(this.arrangeShiftdefintionG)
        // console.log(this.arrangeShiftdefintionL)
        this.work_load_data = [];
        // this.work_load_data.push(this.arrangeShiftdefintionG)
        for (var i = 0; i < this.arrangeShiftdefintionG.length; i++) {
            this.work_load_data.push(this.arrangeShiftdefintionG[i]);
        }
        for (var i = 0; i < this.arrangeShiftdefintionL.length; i++) {
            this.work_load_data.push(this.arrangeShiftdefintionL[i]);
        }
        // console.log(this.work_load_data)
        for (var i = 0; i < this.work_load_data.length; i++) {
            // console.log()
            // this.shift_name=this.allShiftData[i].sh_name
            if (this.work_load_data[i].shiftName != null) {
                // this.allShiftName.push({"shift_name":this.work_load_data[i].shiftName,"startTime": this.work_load_data[i].startTime,"shiftPattern": 'M'+ this.work_load_data[i].startTime})
                if (Number(this.work_load_data[i].startTime) > 2200 || Number(this.work_load_data[i].startTime) < 600) {
                    this.allShiftName.push({ "id": i + 1, "shift_name": this.work_load_data[i].shiftName, "startTime": this.work_load_data[i].startTime, "shiftPattern": 'M' + this.work_load_data[i].startTime });
                }
                else if (Number(this.work_load_data[i].startTime) > 500 && Number(this.work_load_data[i].startTime) < 1300) {
                    this.allShiftName.push({ "id": i + 1, "shift_name": this.work_load_data[i].shiftName, "startTime": this.work_load_data[i].startTime, "shiftPattern": 'D' + this.work_load_data[i].startTime });
                }
                else if (Number(this.work_load_data[i].startTime) > 1200 && Number(this.work_load_data[i].startTime) < 2300) {
                    this.allShiftName.push({ "id": i + 1, "shift_name": this.work_load_data[i].shiftName, "startTime": this.work_load_data[i].startTime, "shiftPattern": 'E' + this.work_load_data[i].startTime });
                }
            }
        }
        // console.log(this.allShiftName)
        // console.log(this.work_load_data)
        localStorage.setItem('allShiftRequiredData', JSON.stringify(this.work_load_data));
        localStorage.setItem('updatedallShiftRequiredData', JSON.stringify(this.work_load_data));
        localStorage.setItem('outliers', JSON.stringify([]));
        this.loginForm.reset();
        this.navCtrl.navigateForward(src_app_json_apis_json__WEBPACK_IMPORTED_MODULE_8__.apis.dashboard);
    }
    passWord() {
        if (this.hidePassword == true) {
            return this.hidePassword = false, this.classId = 1;
        }
        else {
            return this.hidePassword = true, this.classId = 0;
        }
    }
    passWordClass(cId) {
        if (0 == cId) {
            return 'password app-font-primary-color  border-2px-solid form-control ion-no-margin ion-no-padding';
        }
        else if (0 != cId) {
            return 'app-font-primary-color border-2px-solid form-control ion-no-margin ion-no-padding';
        }
    }
};
LoginPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
    { type: src_app_services_work_load_service__WEBPACK_IMPORTED_MODULE_7__["WorkLoadService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"] },
    { type: src_app_services_login_service__WEBPACK_IMPORTED_MODULE_11__["LoginService"] },
    { type: src_app_services_email_validation_service__WEBPACK_IMPORTED_MODULE_14__["EmailValidationService"] },
    { type: src_app_services_forgot_password_service__WEBPACK_IMPORTED_MODULE_15__["ForgotPasswordService"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormBuilder"] },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__["DomSanitizer"] }
];
LoginPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-login',
        template: _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_login_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], LoginPage);



/***/ }),

/***/ "VAwo":
/*!*******************************************************************!*\
  !*** ./src/app/home/login-register/login/login-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: LoginPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageRoutingModule", function() { return LoginPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login.page */ "NoyM");




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_3__["LoginPage"]
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ "Xy1A":
/*!***********************************************************!*\
  !*** ./src/app/home/login-register/login/login.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("#home-page-header-img {\n  height: 100px;\n  width: 100px;\n}\n\n.scroll-content {\n  padding-bottom: 0 !important;\n}\n\n#title-straightline {\n  padding-top: 7px 0px 0px 0px;\n  font-size: 40px;\n  text-shadow: 0px 8px 15px rgba(0, 0, 0, 0.1);\n}\n\n#content {\n  --min-height: 100% !important;\n  --overflow-x:scroll;\n  --overflow: scroll;\n}\n\n@media (min-width: 855px) and (max-width: 900px) and (orientation: landscape) {\n  #title-straightline {\n    padding-top: 7px 0px 0px 0px;\n    font-size: 44px;\n    text-shadow: 0px 8px 15px rgba(0, 0, 0, 0.1);\n  }\n\n  #top {\n    height: 30%;\n    padding-top: 25%;\n  }\n\n  #center {\n    padding-top: 8%;\n    height: 45%;\n  }\n\n  #title-straightline {\n    padding-top: 7%;\n  }\n\n  #sign-in {\n    margin: 5% 0% 5% 0%;\n  }\n\n  #sign-up {\n    padding-top: 9%;\n  }\n\n  #user-pass {\n    padding-top: 3%;\n  }\n\n  #save-username {\n    padding-top: 1%;\n  }\n\n  #triangle-up-left {\n    width: 102%;\n    height: 25%;\n    padding: 2% 0% 2% 0%;\n    margin: 6% 0% 0% -2%;\n    background-image: linear-gradient(to bottom left, transparent 100%, #D0E4E4 0), linear-gradient(to top left, #D0E4E4 50%, transparent 0);\n  }\n}\n\n@media (min-width: 901px) and (max-width: 999px) and (orientation: landscape) {\n  #title-straightline {\n    padding-top: 7px 0px 0px 0px;\n    font-size: 46px;\n    text-shadow: 0px 8px 15px rgba(0, 0, 0, 0.1);\n  }\n\n  #top {\n    height: 30%;\n    padding-top: 25%;\n  }\n\n  #center {\n    padding-top: 12%;\n    height: 45%;\n  }\n\n  #title-straightline {\n    padding-top: 7%;\n  }\n\n  #sign-in {\n    margin: 5% 0% 5% 0%;\n  }\n\n  #sign-up {\n    padding-top: 9%;\n  }\n\n  #user-pass {\n    padding-top: 4%;\n  }\n\n  #triangle-up-left {\n    width: 102%;\n    height: 30%;\n    padding: 5% 0% 5% 0%;\n    margin: 10% 0% 0% -2%;\n    background-image: linear-gradient(to bottom left, transparent 100%, #D0E4E4 0), linear-gradient(to top left, #D0E4E4 50%, transparent 0);\n  }\n}\n\n@media (min-width: 801px) and (max-width: 825px) and (orientation: landscape) {\n  #top {\n    height: 30%;\n    padding-top: 25%;\n  }\n\n  #center {\n    padding-top: 9%;\n    height: 45%;\n  }\n\n  #title-straightline {\n    padding-top: 7%;\n  }\n\n  #sign-in {\n    margin: 4% 0% 4% 0%;\n  }\n\n  #sign-up {\n    padding-top: 7%;\n  }\n\n  #user-pass {\n    padding-top: 3%;\n  }\n\n  #save-username {\n    padding-top: 1%;\n  }\n\n  #triangle-up-left {\n    width: 102%;\n    height: 25%;\n    padding: 2% 0% 2% 0%;\n    margin: 3% 0% 0% -2%;\n    background-image: linear-gradient(to bottom left, transparent 100%, #D0E4E4 0), linear-gradient(to top left, #D0E4E4 50%, transparent 0);\n  }\n}\n\n@media (min-width: 826px) and (max-width: 855px) and (orientation: landscape) {\n  #title-straightline {\n    padding-top: 7px 0px 0px 0px;\n    font-size: 44px;\n    text-shadow: 0px 8px 15px rgba(0, 0, 0, 0.1);\n  }\n\n  #top {\n    height: 30%;\n    padding-top: 25%;\n  }\n\n  #center {\n    padding-top: 8%;\n    height: 45%;\n  }\n\n  #title-straightline {\n    padding-top: 7%;\n  }\n\n  #sign-in {\n    margin: 5% 0% 5% 0%;\n  }\n\n  #sign-up {\n    padding-top: 8%;\n  }\n\n  #user-pass {\n    padding-top: 3%;\n  }\n\n  #save-username {\n    padding-top: 1%;\n  }\n\n  #triangle-up-left {\n    width: 102%;\n    height: 25%;\n    padding: 2% 0% 2% 0%;\n    margin: 6% 0% 0% -2%;\n    background-image: linear-gradient(to bottom left, transparent 100%, #D0E4E4 0), linear-gradient(to top left, #D0E4E4 50%, transparent 0);\n  }\n}\n\n@media (min-width: 700px) and (max-width: 800px) and (orientation: landscape) {\n  #top {\n    margin-top: 15%;\n    height: 25%;\n    padding-top: 7%;\n  }\n\n  #center {\n    height: 50%;\n    padding-top: 5%;\n  }\n\n  #title-straightline {\n    padding-top: 5%;\n  }\n\n  #sign-in {\n    margin: 4% 0% 4% 0%;\n  }\n\n  #sign-up {\n    padding-top: 7%;\n  }\n\n  #user-pass {\n    padding-top: 3%;\n  }\n\n  #save-username {\n    padding-top: 1%;\n  }\n\n  #triangle-up-left {\n    width: 102%;\n    height: 25%;\n    padding: 0%;\n    margin: 5% 0% 0% -2%;\n    background-image: linear-gradient(to bottom left, transparent 100%, #D0E4E4 0), linear-gradient(to top left, #D0E4E4 50%, transparent 0);\n  }\n}\n\n@media screen and (max-width: 700px) and (orientation: landscape) {\n  #top {\n    height: 25%;\n    padding-top: 3%;\n  }\n\n  #center {\n    height: 50%;\n    padding-top: 2%;\n  }\n\n  #title-straightline {\n    padding-top: 2%;\n  }\n\n  #sign-in {\n    margin: 2% 0% 2% 0%;\n  }\n\n  #sign-up {\n    padding-top: 7%;\n  }\n\n  #user-pass {\n    padding-top: 3%;\n  }\n\n  #save-username {\n    padding-top: 1%;\n  }\n\n  #triangle-up-left {\n    width: 102%;\n    height: 25%;\n    padding: 0%;\n    margin: 6% 0% 0% 0%;\n    bottom: 0 !important;\n    background-image: linear-gradient(to bottom left, transparent 100%, #D0E4E4 0), linear-gradient(to top left, #D0E4E4 50%, transparent 0);\n  }\n}\n\n@media screen and (max-height: 700px) and (orientation: portrait) {\n  #top {\n    height: 25%;\n    padding-top: 3%;\n  }\n\n  #center {\n    height: 50%;\n    padding-top: 2%;\n  }\n\n  #title-straightline {\n    padding-top: 2%;\n  }\n\n  #sign-in {\n    margin: 2% 0% 2% 0%;\n  }\n\n  #sign-up {\n    padding-top: 7%;\n  }\n\n  #user-pass {\n    padding-top: 3%;\n  }\n\n  #save-username {\n    padding-top: 1%;\n  }\n\n  #triangle-up-left {\n    width: 102%;\n    height: 25%;\n    padding: 0%;\n    margin: 5% 0% 0% -2%;\n    background-image: linear-gradient(to bottom left, transparent 100%, #D0E4E4 0), linear-gradient(to top left, #D0E4E4 50%, transparent 0);\n  }\n}\n\n@media (min-height: 700px) and (max-height: 800px) and (orientation: portrait) {\n  #top {\n    height: 25%;\n    padding-top: 12%;\n  }\n\n  #center {\n    height: 50%;\n    padding-top: 5%;\n  }\n\n  #title-straightline {\n    padding-top: 5%;\n  }\n\n  #sign-in {\n    margin: 4% 0% 4% 0%;\n  }\n\n  #sign-up {\n    padding-top: 7%;\n  }\n\n  #user-pass {\n    padding-top: 3%;\n  }\n\n  #save-username {\n    padding-top: 1%;\n  }\n\n  #triangle-up-left {\n    width: 102%;\n    height: 25%;\n    padding: 0%;\n    margin: 5% 0% 0% -2%;\n    background-image: linear-gradient(to bottom left, transparent 100%, #D0E4E4 0), linear-gradient(to top left, #D0E4E4 50%, transparent 0);\n  }\n}\n\n@media (min-height: 801px) and (max-height: 825px) and (orientation: portrait) {\n  #top {\n    height: 30%;\n    padding-top: 25%;\n  }\n\n  #center {\n    padding-top: 9%;\n    height: 45%;\n  }\n\n  #title-straightline {\n    padding-top: 7%;\n  }\n\n  #sign-in {\n    margin: 4% 0% 4% 0%;\n  }\n\n  #sign-up {\n    padding-top: 7%;\n  }\n\n  #user-pass {\n    padding-top: 3%;\n  }\n\n  #save-username {\n    padding-top: 1%;\n  }\n\n  #triangle-up-left {\n    width: 102%;\n    height: 25%;\n    padding: 2% 0% 2% 0%;\n    margin: 3% 0% 0% -2%;\n    border: none !important;\n    border-style: none;\n    background-image: linear-gradient(to bottom left, transparent 100%, #D0E4E4 0), linear-gradient(to top left, #D0E4E4 50%, transparent 0);\n  }\n}\n\n@media (min-height: 826px) and (max-height: 855px) and (orientation: portrait) {\n  #title-straightline {\n    padding-top: 7px 0px 0px 0px;\n    font-size: 44px;\n    text-shadow: 0px 8px 15px rgba(0, 0, 0, 0.1);\n  }\n\n  #top {\n    height: 30%;\n    padding-top: 25%;\n  }\n\n  #center {\n    padding-top: 8%;\n    height: 45%;\n  }\n\n  #title-straightline {\n    padding-top: 7%;\n  }\n\n  #sign-in {\n    margin: 5% 0% 5% 0%;\n  }\n\n  #sign-up {\n    padding-top: 8%;\n  }\n\n  #user-pass {\n    padding-top: 3%;\n  }\n\n  #save-username {\n    padding-top: 1%;\n  }\n\n  #triangle-up-left {\n    width: 102%;\n    height: 25%;\n    padding: 2% 0% 2% 0%;\n    margin: 6% 0% 0% -2%;\n    background-image: linear-gradient(to bottom left, transparent 100%, #D0E4E4 0), linear-gradient(to top left, #D0E4E4 50%, transparent 0);\n  }\n}\n\n@media (min-height: 855px) and (max-height: 900px) and (orientation: portrait) {\n  #title-straightline {\n    padding-top: 7px 0px 0px 0px;\n    font-size: 44px;\n    text-shadow: 0px 8px 15px rgba(0, 0, 0, 0.1);\n  }\n\n  #top {\n    height: 30%;\n    padding-top: 25%;\n  }\n\n  #center {\n    padding-top: 8%;\n    height: 45%;\n  }\n\n  #title-straightline {\n    padding-top: 7%;\n  }\n\n  #sign-in {\n    margin: 5% 0% 5% 0%;\n  }\n\n  #sign-up {\n    padding-top: 9%;\n  }\n\n  #user-pass {\n    padding-top: 3%;\n  }\n\n  #save-username {\n    padding-top: 1%;\n  }\n\n  #triangle-up-left {\n    width: 102%;\n    height: 25%;\n    padding: 2% 0% 2% 0%;\n    margin: 6% 0% 0% -2%;\n    background-image: linear-gradient(to bottom left, transparent 100%, #D0E4E4 0), linear-gradient(to top left, #D0E4E4 50%, transparent 0);\n  }\n}\n\n@media (min-height: 901px) and (max-height: 999px) and (orientation: portrait) {\n  #title-straightline {\n    padding-top: 7px 0px 0px 0px;\n    font-size: 46px;\n    text-shadow: 0px 8px 15px rgba(0, 0, 0, 0.1);\n  }\n\n  #top {\n    height: 30%;\n    padding-top: 25%;\n  }\n\n  #center {\n    padding-top: 12%;\n    height: 45%;\n  }\n\n  #title-straightline {\n    padding-top: 7%;\n  }\n\n  #sign-in {\n    margin: 5% 0% 5% 0%;\n  }\n\n  #sign-up {\n    padding-top: 9%;\n  }\n\n  #user-pass {\n    padding-top: 4%;\n  }\n\n  #triangle-up-left {\n    width: 102%;\n    height: 30%;\n    padding: 5% 0% 5% 0%;\n    margin: 10% 0% 0% -2%;\n    background-image: linear-gradient(to bottom left, transparent 100%, #D0E4E4 0), linear-gradient(to top left, #D0E4E4 50%, transparent 0);\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcbG9naW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUUsYUFBQTtFQUNBLFlBQUE7QUFBRjs7QUFFQTtFQUNFLDRCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSw0QkFBQTtFQUNBLGVBQUE7RUFDQSw0Q0FBQTtBQUVGOztBQWFBO0VBRUMsNkJBQUE7RUFHQSxtQkFBQTtFQUNBLGtCQUFBO0FBYkQ7O0FBZ0JBO0VBQ0U7SUFDRSw0QkFBQTtJQUNBLGVBQUE7SUFDQSw0Q0FBQTtFQWJGOztFQWdCQTtJQUNFLFdBQUE7SUFBWSxnQkFBQTtFQVpkOztFQWNBO0lBQ0UsZUFBQTtJQUNBLFdBQUE7RUFYRjs7RUFhQTtJQUNFLGVBQUE7RUFWRjs7RUFZQTtJQUNFLG1CQUFBO0VBVEY7O0VBWUE7SUFDRSxlQUFBO0VBVEY7O0VBV0E7SUFDRSxlQUFBO0VBUkY7O0VBVUE7SUFDRSxlQUFBO0VBUEY7O0VBU0E7SUFDRSxXQUFBO0lBQ0EsV0FBQTtJQUlBLG9CQUFBO0lBQ0Esb0JBQUE7SUFFQSx3SUFDRTtFQVhKO0FBQ0Y7O0FBZUE7RUFDRTtJQUNFLDRCQUFBO0lBQ0EsZUFBQTtJQUNBLDRDQUFBO0VBYkY7O0VBZ0JBO0lBQ0UsV0FBQTtJQUFZLGdCQUFBO0VBWmQ7O0VBY0E7SUFDRSxnQkFBQTtJQUNBLFdBQUE7RUFYRjs7RUFhQTtJQUNFLGVBQUE7RUFWRjs7RUFZQTtJQUNFLG1CQUFBO0VBVEY7O0VBWUE7SUFDRSxlQUFBO0VBVEY7O0VBV0E7SUFDRSxlQUFBO0VBUkY7O0VBVUE7SUFDRSxXQUFBO0lBQ0EsV0FBQTtJQUdBLG9CQUFBO0lBRUEscUJBQUE7SUFFQSx3SUFDQTtFQVpGO0FBQ0Y7O0FBZ0JBO0VBQ0U7SUFDRSxXQUFBO0lBQVksZ0JBQUE7RUFiZDs7RUFlQTtJQUNFLGVBQUE7SUFDQSxXQUFBO0VBWkY7O0VBY0E7SUFDRSxlQUFBO0VBWEY7O0VBYUE7SUFDRSxtQkFBQTtFQVZGOztFQWFBO0lBQ0UsZUFBQTtFQVZGOztFQVlBO0lBQ0UsZUFBQTtFQVRGOztFQVdBO0lBQ0UsZUFBQTtFQVJGOztFQVVBO0lBQ0UsV0FBQTtJQUNBLFdBQUE7SUFJQSxvQkFBQTtJQUNBLG9CQUFBO0lBRUEsd0lBQ0E7RUFaRjtBQUNGOztBQWVBO0VBQ0U7SUFDRSw0QkFBQTtJQUNBLGVBQUE7SUFDQSw0Q0FBQTtFQWJGOztFQWdCQTtJQUNFLFdBQUE7SUFBWSxnQkFBQTtFQVpkOztFQWNBO0lBQ0UsZUFBQTtJQUNBLFdBQUE7RUFYRjs7RUFhQTtJQUNFLGVBQUE7RUFWRjs7RUFZQTtJQUNFLG1CQUFBO0VBVEY7O0VBWUE7SUFDRSxlQUFBO0VBVEY7O0VBV0E7SUFDRSxlQUFBO0VBUkY7O0VBVUE7SUFDRSxlQUFBO0VBUEY7O0VBU0E7SUFDRSxXQUFBO0lBQ0EsV0FBQTtJQUdBLG9CQUFBO0lBQ0Esb0JBQUE7SUFHQSx3SUFDQTtFQVhGO0FBQ0Y7O0FBZUE7RUFDRTtJQUNFLGVBQUE7SUFDQSxXQUFBO0lBQVksZUFBQTtFQVpkOztFQWNBO0lBQ0UsV0FBQTtJQUFZLGVBQUE7RUFWZDs7RUFZQTtJQUNFLGVBQUE7RUFURjs7RUFXQTtJQUNFLG1CQUFBO0VBUkY7O0VBV0E7SUFDRSxlQUFBO0VBUkY7O0VBVUE7SUFDRSxlQUFBO0VBUEY7O0VBU0E7SUFDRSxlQUFBO0VBTkY7O0VBUUE7SUFDRSxXQUFBO0lBQ0EsV0FBQTtJQUdBLFdBQUE7SUFDQSxvQkFBQTtJQUVBLHdJQUNBO0VBVEY7QUFDRjs7QUFZQTtFQUNFO0lBQ0UsV0FBQTtJQUFZLGVBQUE7RUFUZDs7RUFXQTtJQUNFLFdBQUE7SUFBWSxlQUFBO0VBUGQ7O0VBU0E7SUFDRSxlQUFBO0VBTkY7O0VBUUE7SUFDRSxtQkFBQTtFQUxGOztFQVFBO0lBQ0UsZUFBQTtFQUxGOztFQU9BO0lBQ0UsZUFBQTtFQUpGOztFQU1BO0lBQ0UsZUFBQTtFQUhGOztFQUtBO0lBQ0UsV0FBQTtJQUNBLFdBQUE7SUFHQSxXQUFBO0lBQ0EsbUJBQUE7SUFDQSxvQkFBQTtJQUdBLHdJQUNBO0VBUEY7QUFDRjs7QUFVQTtFQUNFO0lBQ0UsV0FBQTtJQUFZLGVBQUE7RUFQZDs7RUFTQTtJQUNFLFdBQUE7SUFBWSxlQUFBO0VBTGQ7O0VBT0E7SUFDRSxlQUFBO0VBSkY7O0VBTUE7SUFDRSxtQkFBQTtFQUhGOztFQU1BO0lBQ0UsZUFBQTtFQUhGOztFQUtBO0lBQ0UsZUFBQTtFQUZGOztFQUlBO0lBQ0UsZUFBQTtFQURGOztFQUdBO0lBQ0UsV0FBQTtJQUNBLFdBQUE7SUFHQSxXQUFBO0lBQ0Esb0JBQUE7SUFHQSx3SUFDRTtFQUxKO0FBQ0Y7O0FBU0E7RUFDRTtJQUNFLFdBQUE7SUFBWSxnQkFBQTtFQU5kOztFQVFBO0lBQ0UsV0FBQTtJQUFZLGVBQUE7RUFKZDs7RUFNQTtJQUNFLGVBQUE7RUFIRjs7RUFLQTtJQUNFLG1CQUFBO0VBRkY7O0VBS0E7SUFDRSxlQUFBO0VBRkY7O0VBSUE7SUFDRSxlQUFBO0VBREY7O0VBR0E7SUFDRSxlQUFBO0VBQUY7O0VBRUE7SUFDRSxXQUFBO0lBQ0EsV0FBQTtJQUdBLFdBQUE7SUFDQSxvQkFBQTtJQUVBLHdJQUNBO0VBSEY7QUFDRjs7QUFNQTtFQUNFO0lBQ0UsV0FBQTtJQUFZLGdCQUFBO0VBSGQ7O0VBS0E7SUFDRSxlQUFBO0lBQ0EsV0FBQTtFQUZGOztFQUlBO0lBQ0UsZUFBQTtFQURGOztFQUdBO0lBQ0UsbUJBQUE7RUFBRjs7RUFHQTtJQUNFLGVBQUE7RUFBRjs7RUFFQTtJQUNFLGVBQUE7RUFDRjs7RUFDQTtJQUNFLGVBQUE7RUFFRjs7RUFBQTtJQUNFLFdBQUE7SUFDQSxXQUFBO0lBSUEsb0JBQUE7SUFDQSxvQkFBQTtJQUVBLHVCQUFBO0lBQ0Esa0JBQUE7SUFDQSx3SUFDRTtFQUZKO0FBQ0Y7O0FBS0E7RUFDRTtJQUNFLDRCQUFBO0lBQ0EsZUFBQTtJQUNBLDRDQUFBO0VBSEY7O0VBTUE7SUFDRSxXQUFBO0lBQVksZ0JBQUE7RUFGZDs7RUFJQTtJQUNFLGVBQUE7SUFDQSxXQUFBO0VBREY7O0VBR0E7SUFDRSxlQUFBO0VBQUY7O0VBRUE7SUFDRSxtQkFBQTtFQUNGOztFQUVBO0lBQ0UsZUFBQTtFQUNGOztFQUNBO0lBQ0UsZUFBQTtFQUVGOztFQUFBO0lBQ0UsZUFBQTtFQUdGOztFQURBO0lBQ0UsV0FBQTtJQUNBLFdBQUE7SUFHQSxvQkFBQTtJQUNBLG9CQUFBO0lBR0Esd0lBQ0U7RUFESjtBQUNGOztBQUlBO0VBQ0U7SUFDRSw0QkFBQTtJQUNBLGVBQUE7SUFDQSw0Q0FBQTtFQUZGOztFQUtBO0lBQ0UsV0FBQTtJQUFZLGdCQUFBO0VBRGQ7O0VBR0E7SUFDRSxlQUFBO0lBQ0EsV0FBQTtFQUFGOztFQUVBO0lBQ0UsZUFBQTtFQUNGOztFQUNBO0lBQ0UsbUJBQUE7RUFFRjs7RUFDQTtJQUNFLGVBQUE7RUFFRjs7RUFBQTtJQUNFLGVBQUE7RUFHRjs7RUFEQTtJQUNFLGVBQUE7RUFJRjs7RUFGQTtJQUNFLFdBQUE7SUFDQSxXQUFBO0lBSUEsb0JBQUE7SUFDQSxvQkFBQTtJQUVBLHdJQUNBO0VBQUY7QUFDRjs7QUFJQTtFQUNFO0lBQ0UsNEJBQUE7SUFDQSxlQUFBO0lBQ0EsNENBQUE7RUFGRjs7RUFLQTtJQUNFLFdBQUE7SUFBWSxnQkFBQTtFQURkOztFQUdBO0lBQ0UsZ0JBQUE7SUFDQSxXQUFBO0VBQUY7O0VBRUE7SUFDRSxlQUFBO0VBQ0Y7O0VBQ0E7SUFDRSxtQkFBQTtFQUVGOztFQUNBO0lBQ0UsZUFBQTtFQUVGOztFQUFBO0lBQ0UsZUFBQTtFQUdGOztFQURBO0lBQ0UsV0FBQTtJQUNBLFdBQUE7SUFHQSxvQkFBQTtJQUVBLHFCQUFBO0lBRUEsd0lBQ0E7RUFERjtBQUNGIiwiZmlsZSI6ImxvZ2luLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNob21lLXBhZ2UtaGVhZGVyLWltZ3tcblxuICBoZWlnaHQ6IDEwMHB4O1xuICB3aWR0aDogMTAwcHg7XG59XG4uc2Nyb2xsLWNvbnRlbnQge1xuICBwYWRkaW5nLWJvdHRvbTogMCAhaW1wb3J0YW50O1xufVxuI3RpdGxlLXN0cmFpZ2h0bGluZXtcbiAgcGFkZGluZy10b3A6N3B4IDBweCAwcHggMHB4O1xuICBmb250LXNpemU6IDQwcHg7XG4gIHRleHQtc2hhZG93OiAwcHggOHB4IDE1cHggcmdiYSgwLCAwLCAwLCAwLjEpO1xufVxuXG4vLyAjdHJpYW5nbGUtdXAtbGVmdCB7XG4vLyAgIHdpZHRoOiAxMDIlO1xuLy8gICBoZWlnaHQ6IDE1MHB4O1xuLy8gICAvLyBwb3NpdGlvbjogYWJzb2x1dGU7XG4vLyAgIC8vIHBvc2l0aW9uOiBmaXhlZDtcbi8vICAgcGFkZGluZzogMCU7XG4vLyAgIG1hcmdpbjogMCUgMCUgMCUgLTIlO1xuLy8gICAvLyBib3R0b206IDAlICFpbXBvcnRhbnQ7XG4vLyAgIGJhY2tncm91bmQtaW1hZ2U6XG4vLyAgICAgbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSBsZWZ0LCB0cmFuc3BhcmVudCAxMDAlLCB3aGl0ZSAwKSxcbi8vICAgICBsaW5lYXItZ3JhZGllbnQodG8gdG9wIGxlZnQsIHdoaXRlIDUwJSwgdHJhbnNwYXJlbnQgMCk7XG4vLyB9XG4jY29udGVudHtcbi8vICAtLWhlaWdodDogMTAwJSAhaW1wb3J0YW50O1xuIC0tbWluLWhlaWdodDogMTAwJSAhaW1wb3J0YW50O1xuLy8gIHBvc2l0aW9uOiBmaXhlZDtcbi8vICAtLW92ZXJmbG93LXk6IHNjcm9sbDtcbiAtLW92ZXJmbG93LXg6c2Nyb2xsO1xuIC0tb3ZlcmZsb3c6IHNjcm9sbDtcblxufVxuQG1lZGlhIChtaW4td2lkdGg6IDg1NXB4KSAgYW5kIChtYXgtd2lkdGg6IDkwMHB4KSBhbmQgKG9yaWVudGF0aW9uOiBsYW5kc2NhcGUpe1xuICAjdGl0bGUtc3RyYWlnaHRsaW5le1xuICAgIHBhZGRpbmctdG9wOjdweCAwcHggMHB4IDBweDtcbiAgICBmb250LXNpemU6IDQ0cHg7XG4gICAgdGV4dC1zaGFkb3c6IDBweCA4cHggMTVweCByZ2JhKDAsIDAsIDAsIDAuMSk7XG4gIH1cblxuICAjdG9we1xuICAgIGhlaWdodDogMzAlO3BhZGRpbmctdG9wOiAyNSU7XG4gIH1cbiAgI2NlbnRlcntcbiAgICBwYWRkaW5nLXRvcDogOCU7XG4gICAgaGVpZ2h0OiA0NSU7XG4gIH1cbiAgI3RpdGxlLXN0cmFpZ2h0bGluZXtcbiAgICBwYWRkaW5nLXRvcDogNyU7XG4gIH1cbiAgI3NpZ24taW57XG4gICAgbWFyZ2luOjUlIDAlIDUlIDAlO1xuXG4gIH1cbiAgI3NpZ24tdXB7XG4gICAgcGFkZGluZy10b3A6IDklO1xuICB9XG4gICN1c2VyLXBhc3N7XG4gICAgcGFkZGluZy10b3A6IDMlO1xuICB9XG4gICNzYXZlLXVzZXJuYW1le1xuICAgIHBhZGRpbmctdG9wOiAxJTtcbiAgfVxuICAjdHJpYW5nbGUtdXAtbGVmdCB7XG4gICAgd2lkdGg6IDEwMiU7XG4gICAgaGVpZ2h0OiAyNSU7XG5cbiAgICAvLyBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgLy8gcG9zaXRpb246IGZpeGVkO1xuICAgIHBhZGRpbmc6IDIlIDAlIDIlIDAlO1xuICAgIG1hcmdpbjogNiUgMCUgMCUgLTIlO1xuICAgIC8vIGJvdHRvbTogMCUgIWltcG9ydGFudDtcbiAgICBiYWNrZ3JvdW5kLWltYWdlOlxuICAgICAgbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSBsZWZ0LCB0cmFuc3BhcmVudCAxMDAlLCAjRDBFNEU0IDApLFxuICAgICAgbGluZWFyLWdyYWRpZW50KHRvIHRvcCBsZWZ0LCAjRDBFNEU0IDUwJSwgdHJhbnNwYXJlbnQgMCk7XG4gIH1cbn1cblxuQG1lZGlhIChtaW4td2lkdGg6IDkwMXB4KSAgYW5kIChtYXgtd2lkdGg6IDk5OXB4KSBhbmQgKG9yaWVudGF0aW9uOiBsYW5kc2NhcGUpe1xuICAjdGl0bGUtc3RyYWlnaHRsaW5le1xuICAgIHBhZGRpbmctdG9wOjdweCAwcHggMHB4IDBweDtcbiAgICBmb250LXNpemU6IDQ2cHg7XG4gICAgdGV4dC1zaGFkb3c6IDBweCA4cHggMTVweCByZ2JhKDAsIDAsIDAsIDAuMSk7XG4gIH1cblxuICAjdG9we1xuICAgIGhlaWdodDogMzAlO3BhZGRpbmctdG9wOiAyNSU7XG4gIH1cbiAgI2NlbnRlcntcbiAgICBwYWRkaW5nLXRvcDogMTIlO1xuICAgIGhlaWdodDogNDUlO1xuICB9XG4gICN0aXRsZS1zdHJhaWdodGxpbmV7XG4gICAgcGFkZGluZy10b3A6IDclO1xuICB9XG4gICNzaWduLWlue1xuICAgIG1hcmdpbjo1JSAwJSA1JSAwJTtcblxuICB9XG4gICNzaWduLXVwe1xuICAgIHBhZGRpbmctdG9wOiA5JTtcbiAgfVxuICAjdXNlci1wYXNze1xuICAgIHBhZGRpbmctdG9wOiA0JTtcbiAgfVxuICAjdHJpYW5nbGUtdXAtbGVmdCB7XG4gICAgd2lkdGg6IDEwMiU7XG4gICAgaGVpZ2h0OiAzMCU7XG4gICAgLy8gcG9zaXRpb246IGFic29sdXRlO1xuICAgIC8vIHBvc2l0aW9uOiBmaXhlZDtcbiAgICBwYWRkaW5nOiA1JSAwJSA1JSAwJTtcblxuICAgIG1hcmdpbjogMTAlIDAlIDAlIC0yJTtcbiAgICAvLyBib3R0b206IDAlICFpbXBvcnRhbnQ7XG4gICAgYmFja2dyb3VuZC1pbWFnZTpcbiAgICBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tIGxlZnQsIHRyYW5zcGFyZW50IDEwMCUsICNEMEU0RTQgMCksXG4gICAgbGluZWFyLWdyYWRpZW50KHRvIHRvcCBsZWZ0LCAjRDBFNEU0IDUwJSwgdHJhbnNwYXJlbnQgMCk7XG4gIH1cbn1cblxuQG1lZGlhIChtaW4td2lkdGg6IDgwMXB4KSAgYW5kIChtYXgtd2lkdGg6IDgyNXB4KSBhbmQgKG9yaWVudGF0aW9uOiBsYW5kc2NhcGUpe1xuICAjdG9we1xuICAgIGhlaWdodDogMzAlO3BhZGRpbmctdG9wOiAyNSU7XG4gIH1cbiAgI2NlbnRlcntcbiAgICBwYWRkaW5nLXRvcDogOSU7XG4gICAgaGVpZ2h0OiA0NSU7XG4gIH1cbiAgI3RpdGxlLXN0cmFpZ2h0bGluZXtcbiAgICBwYWRkaW5nLXRvcDogNyU7XG4gIH1cbiAgI3NpZ24taW57XG4gICAgbWFyZ2luOjQlIDAlIDQlIDAlO1xuXG4gIH1cbiAgI3NpZ24tdXB7XG4gICAgcGFkZGluZy10b3A6IDclO1xuICB9XG4gICN1c2VyLXBhc3N7XG4gICAgcGFkZGluZy10b3A6IDMlO1xuICB9XG4gICNzYXZlLXVzZXJuYW1le1xuICAgIHBhZGRpbmctdG9wOiAxJTtcbiAgfVxuICAjdHJpYW5nbGUtdXAtbGVmdCB7XG4gICAgd2lkdGg6IDEwMiU7XG4gICAgaGVpZ2h0OiAyNSU7XG4gICAgLy8gcG9zaXRpb246IGFic29sdXRlO1xuICAgIC8vIHBvc2l0aW9uOiBmaXhlZDtcblxuICAgIHBhZGRpbmc6IDIlIDAlIDIlIDAlO1xuICAgIG1hcmdpbjogMyUgMCUgMCUgLTIlO1xuICAgIC8vIGJvdHRvbTogMCUgIWltcG9ydGFudDtcbiAgICBiYWNrZ3JvdW5kLWltYWdlOlxuICAgIGxpbmVhci1ncmFkaWVudCh0byBib3R0b20gbGVmdCwgdHJhbnNwYXJlbnQgMTAwJSwgI0QwRTRFNCAwKSxcbiAgICBsaW5lYXItZ3JhZGllbnQodG8gdG9wIGxlZnQsICNEMEU0RTQgNTAlLCB0cmFuc3BhcmVudCAwKTtcbiAgfVxufVxuQG1lZGlhIChtaW4td2lkdGg6IDgyNnB4KSAgYW5kIChtYXgtd2lkdGg6IDg1NXB4KSBhbmQgKG9yaWVudGF0aW9uOiBsYW5kc2NhcGUpe1xuICAjdGl0bGUtc3RyYWlnaHRsaW5le1xuICAgIHBhZGRpbmctdG9wOjdweCAwcHggMHB4IDBweDtcbiAgICBmb250LXNpemU6IDQ0cHg7XG4gICAgdGV4dC1zaGFkb3c6IDBweCA4cHggMTVweCByZ2JhKDAsIDAsIDAsIDAuMSk7XG4gIH1cblxuICAjdG9we1xuICAgIGhlaWdodDogMzAlO3BhZGRpbmctdG9wOiAyNSU7XG4gIH1cbiAgI2NlbnRlcntcbiAgICBwYWRkaW5nLXRvcDogOCU7XG4gICAgaGVpZ2h0OiA0NSU7XG4gIH1cbiAgI3RpdGxlLXN0cmFpZ2h0bGluZXtcbiAgICBwYWRkaW5nLXRvcDogNyU7XG4gIH1cbiAgI3NpZ24taW57XG4gICAgbWFyZ2luOjUlIDAlIDUlIDAlO1xuXG4gIH1cbiAgI3NpZ24tdXB7XG4gICAgcGFkZGluZy10b3A6IDglO1xuICB9XG4gICN1c2VyLXBhc3N7XG4gICAgcGFkZGluZy10b3A6IDMlO1xuICB9XG4gICNzYXZlLXVzZXJuYW1le1xuICAgIHBhZGRpbmctdG9wOiAxJTtcbiAgfVxuICAjdHJpYW5nbGUtdXAtbGVmdCB7XG4gICAgd2lkdGg6IDEwMiU7XG4gICAgaGVpZ2h0OiAyNSU7XG4gICAgLy8gcG9zaXRpb246IGFic29sdXRlO1xuICAgIC8vIHBvc2l0aW9uOiBmaXhlZDtcbiAgICBwYWRkaW5nOiAyJSAwJSAyJSAwJTtcbiAgICBtYXJnaW46IDYlIDAlIDAlIC0yJTtcbiAgICAvLyBib3R0b206IDAlICFpbXBvcnRhbnQ7XG5cbiAgICBiYWNrZ3JvdW5kLWltYWdlOlxuICAgIGxpbmVhci1ncmFkaWVudCh0byBib3R0b20gbGVmdCwgdHJhbnNwYXJlbnQgMTAwJSwgI0QwRTRFNCAwKSxcbiAgICBsaW5lYXItZ3JhZGllbnQodG8gdG9wIGxlZnQsICNEMEU0RTQgNTAlLCB0cmFuc3BhcmVudCAwKTtcbiAgfVxuXG59XG5AbWVkaWEgKG1pbi13aWR0aDogNzAwcHgpIGFuZCAobWF4LXdpZHRoOiA4MDBweCkgYW5kIChvcmllbnRhdGlvbjogbGFuZHNjYXBlKXtcbiAgI3RvcHtcbiAgICBtYXJnaW4tdG9wOiAxNSU7XG4gICAgaGVpZ2h0OiAyNSU7cGFkZGluZy10b3A6IDclO1xuICB9XG4gICNjZW50ZXJ7XG4gICAgaGVpZ2h0OiA1MCU7cGFkZGluZy10b3A6IDUlO1xuICB9XG4gICN0aXRsZS1zdHJhaWdodGxpbmV7XG4gICAgcGFkZGluZy10b3A6IDUlO1xuICB9XG4gICNzaWduLWlue1xuICAgIG1hcmdpbjo0JSAwJSA0JSAwJTtcblxuICB9XG4gICNzaWduLXVwe1xuICAgIHBhZGRpbmctdG9wOiA3JTtcbiAgfVxuICAjdXNlci1wYXNze1xuICAgIHBhZGRpbmctdG9wOiAzJTtcbiAgfVxuICAjc2F2ZS11c2VybmFtZXtcbiAgICBwYWRkaW5nLXRvcDogMSU7XG4gIH1cbiAgI3RyaWFuZ2xlLXVwLWxlZnQge1xuICAgIHdpZHRoOiAxMDIlO1xuICAgIGhlaWdodDogMjUlO1xuICAgIC8vIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAvLyBwb3NpdGlvbjogZml4ZWQ7XG4gICAgcGFkZGluZzogMCU7XG4gICAgbWFyZ2luOiA1JSAwJSAwJSAtMiU7XG4gICAgLy8gYm90dG9tOiAwJSAhaW1wb3J0YW50O1xuICAgIGJhY2tncm91bmQtaW1hZ2U6XG4gICAgbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSBsZWZ0LCB0cmFuc3BhcmVudCAxMDAlLCAjRDBFNEU0IDApLFxuICAgIGxpbmVhci1ncmFkaWVudCh0byB0b3AgbGVmdCwgI0QwRTRFNCA1MCUsIHRyYW5zcGFyZW50IDApO1xuICB9XG59XG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3MDBweCkgYW5kIChvcmllbnRhdGlvbjogbGFuZHNjYXBlKXtcbiAgI3RvcHtcbiAgICBoZWlnaHQ6IDI1JTtwYWRkaW5nLXRvcDogMyU7XG4gIH1cbiAgI2NlbnRlcntcbiAgICBoZWlnaHQ6IDUwJTtwYWRkaW5nLXRvcDogMiU7XG4gIH1cbiAgI3RpdGxlLXN0cmFpZ2h0bGluZXtcbiAgICBwYWRkaW5nLXRvcDogMiU7XG4gIH1cbiAgI3NpZ24taW57XG4gICAgbWFyZ2luOjIlIDAlIDIlIDAlO1xuXG4gIH1cbiAgI3NpZ24tdXB7XG4gICAgcGFkZGluZy10b3A6IDclO1xuICB9XG4gICN1c2VyLXBhc3N7XG4gICAgcGFkZGluZy10b3A6IDMlO1xuICB9XG4gICNzYXZlLXVzZXJuYW1le1xuICAgIHBhZGRpbmctdG9wOiAxJTtcbiAgfVxuICAjdHJpYW5nbGUtdXAtbGVmdCB7XG4gICAgd2lkdGg6IDEwMiU7XG4gICAgaGVpZ2h0OiAyNSU7XG4gICAgLy8gcG9zaXRpb246IGFic29sdXRlO1xuICAgIC8vIHBvc2l0aW9uOiBmaXhlZDtcbiAgICBwYWRkaW5nOiAwJTtcbiAgICBtYXJnaW46IDYlIDAlIDAlIDAlO1xuICAgIGJvdHRvbTogMCAhaW1wb3J0YW50O1xuICAgIC8vIGJvdHRvbTogMCUgIWltcG9ydGFudDtcblxuICAgIGJhY2tncm91bmQtaW1hZ2U6XG4gICAgbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSBsZWZ0LCB0cmFuc3BhcmVudCAxMDAlLCAjRDBFNEU0IDApLFxuICAgIGxpbmVhci1ncmFkaWVudCh0byB0b3AgbGVmdCwgI0QwRTRFNCA1MCUsIHRyYW5zcGFyZW50IDApO1xuICB9XG59XG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LWhlaWdodDogNzAwcHgpIGFuZCAob3JpZW50YXRpb246IHBvcnRyYWl0KXtcbiAgI3RvcHtcbiAgICBoZWlnaHQ6IDI1JTtwYWRkaW5nLXRvcDogMyU7XG4gIH1cbiAgI2NlbnRlcntcbiAgICBoZWlnaHQ6IDUwJTtwYWRkaW5nLXRvcDogMiU7XG4gIH1cbiAgI3RpdGxlLXN0cmFpZ2h0bGluZXtcbiAgICBwYWRkaW5nLXRvcDogMiU7XG4gIH1cbiAgI3NpZ24taW57XG4gICAgbWFyZ2luOjIlIDAlIDIlIDAlO1xuXG4gIH1cbiAgI3NpZ24tdXB7XG4gICAgcGFkZGluZy10b3A6IDclO1xuICB9XG4gICN1c2VyLXBhc3N7XG4gICAgcGFkZGluZy10b3A6IDMlO1xuICB9XG4gICNzYXZlLXVzZXJuYW1le1xuICAgIHBhZGRpbmctdG9wOiAxJTtcbiAgfVxuICAjdHJpYW5nbGUtdXAtbGVmdCB7XG4gICAgd2lkdGg6IDEwMiU7XG4gICAgaGVpZ2h0OiAyNSU7XG4gICAgLy8gcG9zaXRpb246IGFic29sdXRlO1xuICAgIC8vIHBvc2l0aW9uOiBmaXhlZDtcbiAgICBwYWRkaW5nOiAwJTtcbiAgICBtYXJnaW46IDUlIDAlIDAlIC0yJTtcbiAgICAvLyBib3R0b206IDAlICFpbXBvcnRhbnQ7XG5cbiAgICBiYWNrZ3JvdW5kLWltYWdlOlxuICAgICAgbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSBsZWZ0LCB0cmFuc3BhcmVudCAxMDAlLCAjRDBFNEU0IDApLFxuICAgICAgbGluZWFyLWdyYWRpZW50KHRvIHRvcCBsZWZ0LCAjRDBFNEU0IDUwJSwgdHJhbnNwYXJlbnQgMCk7XG4gIH1cbn1cblxuQG1lZGlhIChtaW4taGVpZ2h0OiA3MDBweCkgIGFuZCAobWF4LWhlaWdodDogODAwcHgpIGFuZCAob3JpZW50YXRpb246IHBvcnRyYWl0KXtcbiAgI3RvcHtcbiAgICBoZWlnaHQ6IDI1JTtwYWRkaW5nLXRvcDogMTIlO1xuICB9XG4gICNjZW50ZXJ7XG4gICAgaGVpZ2h0OiA1MCU7cGFkZGluZy10b3A6IDUlO1xuICB9XG4gICN0aXRsZS1zdHJhaWdodGxpbmV7XG4gICAgcGFkZGluZy10b3A6IDUlO1xuICB9XG4gICNzaWduLWlue1xuICAgIG1hcmdpbjo0JSAwJSA0JSAwJTtcblxuICB9XG4gICNzaWduLXVwe1xuICAgIHBhZGRpbmctdG9wOiA3JTtcbiAgfVxuICAjdXNlci1wYXNze1xuICAgIHBhZGRpbmctdG9wOiAzJTtcbiAgfVxuICAjc2F2ZS11c2VybmFtZXtcbiAgICBwYWRkaW5nLXRvcDogMSU7XG4gIH1cbiAgI3RyaWFuZ2xlLXVwLWxlZnQge1xuICAgIHdpZHRoOiAxMDIlO1xuICAgIGhlaWdodDogMjUlO1xuICAgIC8vIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAvLyBwb3NpdGlvbjogZml4ZWQ7XG4gICAgcGFkZGluZzogMCU7XG4gICAgbWFyZ2luOiA1JSAwJSAwJSAtMiU7XG4gICAgLy8gYm90dG9tOiAwJSAhaW1wb3J0YW50O1xuICAgIGJhY2tncm91bmQtaW1hZ2U6XG4gICAgbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSBsZWZ0LCB0cmFuc3BhcmVudCAxMDAlLCAjRDBFNEU0IDApLFxuICAgIGxpbmVhci1ncmFkaWVudCh0byB0b3AgbGVmdCwgI0QwRTRFNCA1MCUsIHRyYW5zcGFyZW50IDApO1xuICB9XG59XG5AbWVkaWEgKG1pbi1oZWlnaHQ6IDgwMXB4KSAgYW5kIChtYXgtaGVpZ2h0OiA4MjVweCkgYW5kIChvcmllbnRhdGlvbjogcG9ydHJhaXQpe1xuICAjdG9we1xuICAgIGhlaWdodDogMzAlO3BhZGRpbmctdG9wOiAyNSU7XG4gIH1cbiAgI2NlbnRlcntcbiAgICBwYWRkaW5nLXRvcDogOSU7XG4gICAgaGVpZ2h0OiA0NSU7XG4gIH1cbiAgI3RpdGxlLXN0cmFpZ2h0bGluZXtcbiAgICBwYWRkaW5nLXRvcDogNyU7XG4gIH1cbiAgI3NpZ24taW57XG4gICAgbWFyZ2luOjQlIDAlIDQlIDAlO1xuXG4gIH1cbiAgI3NpZ24tdXB7XG4gICAgcGFkZGluZy10b3A6IDclO1xuICB9XG4gICN1c2VyLXBhc3N7XG4gICAgcGFkZGluZy10b3A6IDMlO1xuICB9XG4gICNzYXZlLXVzZXJuYW1le1xuICAgIHBhZGRpbmctdG9wOiAxJTtcbiAgfVxuICAjdHJpYW5nbGUtdXAtbGVmdCB7XG4gICAgd2lkdGg6IDEwMiU7XG4gICAgaGVpZ2h0OiAyNSU7XG4gICAgLy8gcG9zaXRpb246IGFic29sdXRlO1xuICAgIC8vIHBvc2l0aW9uOiBmaXhlZDtcblxuICAgIHBhZGRpbmc6IDIlIDAlIDIlIDAlO1xuICAgIG1hcmdpbjogMyUgMCUgMCUgLTIlO1xuICAgIC8vIGJvdHRvbTogMCUgIWltcG9ydGFudDtcbiAgICBib3JkZXI6IG5vbmUgIWltcG9ydGFudDtcbiAgICBib3JkZXItc3R5bGU6IG5vbmU7XG4gICAgYmFja2dyb3VuZC1pbWFnZTpcbiAgICAgIGxpbmVhci1ncmFkaWVudCh0byBib3R0b20gbGVmdCwgdHJhbnNwYXJlbnQgMTAwJSwgI0QwRTRFNCAwKSxcbiAgICAgIGxpbmVhci1ncmFkaWVudCh0byB0b3AgbGVmdCwgI0QwRTRFNCA1MCUsIHRyYW5zcGFyZW50IDApO1xuICB9XG59XG5AbWVkaWEgKG1pbi1oZWlnaHQ6IDgyNnB4KSAgYW5kIChtYXgtaGVpZ2h0OiA4NTVweCkgYW5kIChvcmllbnRhdGlvbjogcG9ydHJhaXQpe1xuICAjdGl0bGUtc3RyYWlnaHRsaW5le1xuICAgIHBhZGRpbmctdG9wOjdweCAwcHggMHB4IDBweDtcbiAgICBmb250LXNpemU6IDQ0cHg7XG4gICAgdGV4dC1zaGFkb3c6IDBweCA4cHggMTVweCByZ2JhKDAsIDAsIDAsIDAuMSk7XG4gIH1cblxuICAjdG9we1xuICAgIGhlaWdodDogMzAlO3BhZGRpbmctdG9wOiAyNSU7XG4gIH1cbiAgI2NlbnRlcntcbiAgICBwYWRkaW5nLXRvcDogOCU7XG4gICAgaGVpZ2h0OiA0NSU7XG4gIH1cbiAgI3RpdGxlLXN0cmFpZ2h0bGluZXtcbiAgICBwYWRkaW5nLXRvcDogNyU7XG4gIH1cbiAgI3NpZ24taW57XG4gICAgbWFyZ2luOjUlIDAlIDUlIDAlO1xuXG4gIH1cbiAgI3NpZ24tdXB7XG4gICAgcGFkZGluZy10b3A6IDglO1xuICB9XG4gICN1c2VyLXBhc3N7XG4gICAgcGFkZGluZy10b3A6IDMlO1xuICB9XG4gICNzYXZlLXVzZXJuYW1le1xuICAgIHBhZGRpbmctdG9wOiAxJTtcbiAgfVxuICAjdHJpYW5nbGUtdXAtbGVmdCB7XG4gICAgd2lkdGg6IDEwMiU7XG4gICAgaGVpZ2h0OiAyNSU7XG4gICAgLy8gcG9zaXRpb246IGFic29sdXRlO1xuICAgIC8vIHBvc2l0aW9uOiBmaXhlZDtcbiAgICBwYWRkaW5nOiAyJSAwJSAyJSAwJTtcbiAgICBtYXJnaW46IDYlIDAlIDAlIC0yJTtcbiAgICAvLyBib3R0b206IDAlICFpbXBvcnRhbnQ7XG5cbiAgICBiYWNrZ3JvdW5kLWltYWdlOlxuICAgICAgbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSBsZWZ0LCB0cmFuc3BhcmVudCAxMDAlLCAjRDBFNEU0IDApLFxuICAgICAgbGluZWFyLWdyYWRpZW50KHRvIHRvcCBsZWZ0LCAjRDBFNEU0IDUwJSwgdHJhbnNwYXJlbnQgMCk7XG4gIH1cbn1cbkBtZWRpYSAobWluLWhlaWdodDogODU1cHgpICBhbmQgKG1heC1oZWlnaHQ6IDkwMHB4KSBhbmQgKG9yaWVudGF0aW9uOiBwb3J0cmFpdCl7XG4gICN0aXRsZS1zdHJhaWdodGxpbmV7XG4gICAgcGFkZGluZy10b3A6N3B4IDBweCAwcHggMHB4O1xuICAgIGZvbnQtc2l6ZTogNDRweDtcbiAgICB0ZXh0LXNoYWRvdzogMHB4IDhweCAxNXB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcbiAgfVxuXG4gICN0b3B7XG4gICAgaGVpZ2h0OiAzMCU7cGFkZGluZy10b3A6IDI1JTtcbiAgfVxuICAjY2VudGVye1xuICAgIHBhZGRpbmctdG9wOiA4JTtcbiAgICBoZWlnaHQ6IDQ1JTtcbiAgfVxuICAjdGl0bGUtc3RyYWlnaHRsaW5le1xuICAgIHBhZGRpbmctdG9wOiA3JTtcbiAgfVxuICAjc2lnbi1pbntcbiAgICBtYXJnaW46NSUgMCUgNSUgMCU7XG5cbiAgfVxuICAjc2lnbi11cHtcbiAgICBwYWRkaW5nLXRvcDogOSU7XG4gIH1cbiAgI3VzZXItcGFzc3tcbiAgICBwYWRkaW5nLXRvcDogMyU7XG4gIH1cbiAgI3NhdmUtdXNlcm5hbWV7XG4gICAgcGFkZGluZy10b3A6IDElO1xuICB9XG4gICN0cmlhbmdsZS11cC1sZWZ0IHtcbiAgICB3aWR0aDogMTAyJTtcbiAgICBoZWlnaHQ6IDI1JTtcblxuICAgIC8vIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAvLyBwb3NpdGlvbjogZml4ZWQ7XG4gICAgcGFkZGluZzogMiUgMCUgMiUgMCU7XG4gICAgbWFyZ2luOiA2JSAwJSAwJSAtMiU7XG4gICAgLy8gYm90dG9tOiAwJSAhaW1wb3J0YW50O1xuICAgIGJhY2tncm91bmQtaW1hZ2U6XG4gICAgbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSBsZWZ0LCB0cmFuc3BhcmVudCAxMDAlLCAjRDBFNEU0IDApLFxuICAgIGxpbmVhci1ncmFkaWVudCh0byB0b3AgbGVmdCwgI0QwRTRFNCA1MCUsIHRyYW5zcGFyZW50IDApO1xuICB9XG59XG5cbkBtZWRpYSAobWluLWhlaWdodDogOTAxcHgpICBhbmQgKG1heC1oZWlnaHQ6IDk5OXB4KSBhbmQgKG9yaWVudGF0aW9uOiBwb3J0cmFpdCl7XG4gICN0aXRsZS1zdHJhaWdodGxpbmV7XG4gICAgcGFkZGluZy10b3A6N3B4IDBweCAwcHggMHB4O1xuICAgIGZvbnQtc2l6ZTogNDZweDtcbiAgICB0ZXh0LXNoYWRvdzogMHB4IDhweCAxNXB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcbiAgfVxuXG4gICN0b3B7XG4gICAgaGVpZ2h0OiAzMCU7cGFkZGluZy10b3A6IDI1JTtcbiAgfVxuICAjY2VudGVye1xuICAgIHBhZGRpbmctdG9wOiAxMiU7XG4gICAgaGVpZ2h0OiA0NSU7XG4gIH1cbiAgI3RpdGxlLXN0cmFpZ2h0bGluZXtcbiAgICBwYWRkaW5nLXRvcDogNyU7XG4gIH1cbiAgI3NpZ24taW57XG4gICAgbWFyZ2luOjUlIDAlIDUlIDAlO1xuXG4gIH1cbiAgI3NpZ24tdXB7XG4gICAgcGFkZGluZy10b3A6IDklO1xuICB9XG4gICN1c2VyLXBhc3N7XG4gICAgcGFkZGluZy10b3A6IDQlO1xuICB9XG4gICN0cmlhbmdsZS11cC1sZWZ0IHtcbiAgICB3aWR0aDogMTAyJTtcbiAgICBoZWlnaHQ6IDMwJTtcbiAgICAvLyBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgLy8gcG9zaXRpb246IGZpeGVkO1xuICAgIHBhZGRpbmc6IDUlIDAlIDUlIDAlO1xuXG4gICAgbWFyZ2luOiAxMCUgMCUgMCUgLTIlO1xuICAgIC8vIGJvdHRvbTogMCUgIWltcG9ydGFudDtcbiAgICBiYWNrZ3JvdW5kLWltYWdlOlxuICAgIGxpbmVhci1ncmFkaWVudCh0byBib3R0b20gbGVmdCwgdHJhbnNwYXJlbnQgMTAwJSwgI0QwRTRFNCAwKSxcbiAgICBsaW5lYXItZ3JhZGllbnQodG8gdG9wIGxlZnQsICNEMEU0RTQgNTAlLCB0cmFuc3BhcmVudCAwKTtcbiAgfVxufVxuIl19 */");

/***/ })

}]);
//# sourceMappingURL=home-login-register-login-login-module.js.map