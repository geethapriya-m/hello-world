(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["src-app-dashboard-work_load_data-create-new-shift-defintion-create-new-shift-defintion-module"],{

/***/ "B/Pg":
/*!**********************************************************************************************************!*\
  !*** ./src/app/dashboard/work_load_data/create-new-shift-defintion/create-new-shift-defintion.module.ts ***!
  \**********************************************************************************************************/
/*! exports provided: CreateNewShiftDefintionPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateNewShiftDefintionPageModule", function() { return CreateNewShiftDefintionPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _create_new_shift_defintion_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./create-new-shift-defintion-routing.module */ "oL8b");
/* harmony import */ var _create_new_shift_defintion_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./create-new-shift-defintion.page */ "j4BX");
/* harmony import */ var src_app_dashboard_nav_bar_footer_footer_footer_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/dashboard/nav-bar-footer/footer/footer.module */ "Gg1k");
/* harmony import */ var src_app_dashboard_nav_bar_footer_nav_bar_nav_bar_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/dashboard/nav-bar-footer/nav-bar/nav-bar.module */ "aiuM");









let CreateNewShiftDefintionPageModule = class CreateNewShiftDefintionPageModule {
};
CreateNewShiftDefintionPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            src_app_dashboard_nav_bar_footer_footer_footer_module__WEBPACK_IMPORTED_MODULE_7__["FooterPageModule"],
            src_app_dashboard_nav_bar_footer_nav_bar_nav_bar_module__WEBPACK_IMPORTED_MODULE_8__["NavBarPageModule"],
            _create_new_shift_defintion_routing_module__WEBPACK_IMPORTED_MODULE_5__["CreateNewShiftDefintionPageRoutingModule"]
        ],
        declarations: [_create_new_shift_defintion_page__WEBPACK_IMPORTED_MODULE_6__["CreateNewShiftDefintionPage"]]
    })
], CreateNewShiftDefintionPageModule);



/***/ }),

/***/ "oL8b":
/*!******************************************************************************************************************!*\
  !*** ./src/app/dashboard/work_load_data/create-new-shift-defintion/create-new-shift-defintion-routing.module.ts ***!
  \******************************************************************************************************************/
/*! exports provided: CreateNewShiftDefintionPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateNewShiftDefintionPageRoutingModule", function() { return CreateNewShiftDefintionPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _create_new_shift_defintion_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./create-new-shift-defintion.page */ "j4BX");




const routes = [
    {
        path: '',
        component: _create_new_shift_defintion_page__WEBPACK_IMPORTED_MODULE_3__["CreateNewShiftDefintionPage"]
    }
];
let CreateNewShiftDefintionPageRoutingModule = class CreateNewShiftDefintionPageRoutingModule {
};
CreateNewShiftDefintionPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CreateNewShiftDefintionPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=src-app-dashboard-work_load_data-create-new-shift-defintion-create-new-shift-defintion-module.js.map