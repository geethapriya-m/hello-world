(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["src-app-dashboard-generated_schedule-summary-view-total-eve-shift-lines-data-view-total-eve-shift-lines-data-module"],{

/***/ "DTev":
/*!********************************************************************************************************************************!*\
  !*** ./src/app/dashboard/generated_schedule/summary/view-total-eve-shift-lines-data/view-total-eve-shift-lines-data.module.ts ***!
  \********************************************************************************************************************************/
/*! exports provided: ViewTotalEveShiftLinesDataPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewTotalEveShiftLinesDataPageModule", function() { return ViewTotalEveShiftLinesDataPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _view_total_eve_shift_lines_data_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./view-total-eve-shift-lines-data-routing.module */ "gr0+");
/* harmony import */ var _view_total_eve_shift_lines_data_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./view-total-eve-shift-lines-data.page */ "B1pS");
/* harmony import */ var _angular_material_divider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/divider */ "f0Cb");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var src_app_dashboard_nav_bar_footer_nav_bar_nav_bar_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/dashboard/nav-bar-footer/nav-bar/nav-bar.module */ "aiuM");










let ViewTotalEveShiftLinesDataPageModule = class ViewTotalEveShiftLinesDataPageModule {
};
ViewTotalEveShiftLinesDataPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__["BrowserModule"],
            src_app_dashboard_nav_bar_footer_nav_bar_nav_bar_module__WEBPACK_IMPORTED_MODULE_9__["NavBarPageModule"],
            _angular_material_divider__WEBPACK_IMPORTED_MODULE_7__["MatDividerModule"],
            _view_total_eve_shift_lines_data_routing_module__WEBPACK_IMPORTED_MODULE_5__["ViewTotalEveShiftLinesDataPageRoutingModule"]
        ],
        declarations: [_view_total_eve_shift_lines_data_page__WEBPACK_IMPORTED_MODULE_6__["ViewTotalEveShiftLinesDataPage"]]
    })
], ViewTotalEveShiftLinesDataPageModule);



/***/ }),

/***/ "gr0+":
/*!****************************************************************************************************************************************!*\
  !*** ./src/app/dashboard/generated_schedule/summary/view-total-eve-shift-lines-data/view-total-eve-shift-lines-data-routing.module.ts ***!
  \****************************************************************************************************************************************/
/*! exports provided: ViewTotalEveShiftLinesDataPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewTotalEveShiftLinesDataPageRoutingModule", function() { return ViewTotalEveShiftLinesDataPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _view_total_eve_shift_lines_data_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./view-total-eve-shift-lines-data.page */ "B1pS");




const routes = [
    {
        path: '',
        component: _view_total_eve_shift_lines_data_page__WEBPACK_IMPORTED_MODULE_3__["ViewTotalEveShiftLinesDataPage"]
    }
];
let ViewTotalEveShiftLinesDataPageRoutingModule = class ViewTotalEveShiftLinesDataPageRoutingModule {
};
ViewTotalEveShiftLinesDataPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ViewTotalEveShiftLinesDataPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=src-app-dashboard-generated_schedule-summary-view-total-eve-shift-lines-data-view-total-eve-shift-lines-data-module.js.map