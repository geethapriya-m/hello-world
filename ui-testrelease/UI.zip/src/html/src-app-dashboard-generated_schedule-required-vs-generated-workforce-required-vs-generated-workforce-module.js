(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["src-app-dashboard-generated_schedule-required-vs-generated-workforce-required-vs-generated-workforce-module"],{

/***/ "+ooK":
/*!**********************************************************************************************************************!*\
  !*** ./src/app/dashboard/generated_schedule/required-vs-generated-workforce/required-vs-generated-workforce.page.ts ***!
  \**********************************************************************************************************************/
/*! exports provided: RequiredVsGeneratedWorkforcePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequiredVsGeneratedWorkforcePage", function() { return RequiredVsGeneratedWorkforcePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_required_vs_generated_workforce_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./required-vs-generated-workforce.page.html */ "vUzG");
/* harmony import */ var _required_vs_generated_workforce_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./required-vs-generated-workforce.page.scss */ "iM4U");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/dialog */ "0IaG");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! chart.js */ "MO+k");
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(chart_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var src_app_services_required_workforce_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/required-workforce.service */ "MEbr");








// import requiredWorkforceData  from '../json/required-workforce.json'

// import  RequiredVSgeneratedWorkforceData  from "v:/New folder (2)/work/stworks/generatedvsrequired.json";
let RequiredVsGeneratedWorkforcePage = class RequiredVsGeneratedWorkforcePage {
    constructor(modalCtrl, route, dataService, alertCtrl, dialogs) {
        this.modalCtrl = modalCtrl;
        this.route = route;
        this.dataService = dataService;
        this.alertCtrl = alertCtrl;
        this.dialogs = dialogs;
        this.isHiddenSun = true;
        this.isHiddenMon = true;
        this.isHiddenTue = true;
        this.isHiddenWed = true;
        this.isHiddenThu = true;
        this.isHiddenFri = true;
        this.isHiddenSat = true;
        this.SunDayRequired = [];
        this.SunDayGenerated = [];
        this.Run = [];
        this.MonDayRequired = [];
        this.MonDayGenerated = [];
        this.TueDayRequired = [];
        this.TueDayGenerated = [];
        this.WedDayRequired = [];
        this.WedDayGenerated = [];
        this.ThuDayRequired = [];
        this.ThuDayGenerated = [];
        this.FriDayRequired = [];
        this.FriDayGenerated = [];
        this.SatDayRequired = [];
        this.SatDayGenerated = [];
        // public chartClicked({ event, active }: { event: MouseEvent, active: {}[] }): void {
        //   console.log(event, active);
        // }
        // public chartHovered({ event, active }: { event: MouseEvent, active: {}[] }): void {
        //   console.log(event, active);
        // }
        this.barChartOptions = {
            responsive: true,
            // aspectRatio:2.32,
            maintainAspectRatio: true,
            title: {
                display: true,
            },
            layout: {
                padding: {
                    top: 0,
                    bottom: -30,
                }
            },
            scales: { xAxes: [{
                        gridLines: {
                            display: false,
                        },
                        ticks: {
                            beginAtZero: true,
                        },
                    }],
                yAxes: [{
                        gridLines: {
                            display: false,
                        },
                        ticks: {
                            beginAtZero: true,
                            stepSize: 5,
                            min: 0,
                            max: 25,
                        }
                    }] },
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                }
            },
            "animation": {
                "duration": 1,
                "onComplete": function () {
                    var chartInstance = this.chart, ctx = chartInstance.ctx;
                    ctx.font = chart_js__WEBPACK_IMPORTED_MODULE_7___default.a.helpers.fontString(chart_js__WEBPACK_IMPORTED_MODULE_7___default.a.defaults.global.defaultFontSize, chart_js__WEBPACK_IMPORTED_MODULE_7___default.a.defaults.global.defaultFontStyle, chart_js__WEBPACK_IMPORTED_MODULE_7___default.a.defaults.global.defaultFontFamily);
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'bottom';
                    this.data.datasets.forEach(function (dataset, i) {
                        var meta = chartInstance.controller.getDatasetMeta(i);
                        meta.data.forEach(function (bar, index) {
                            var data = dataset.data[index];
                            ctx.fillText(data, bar._model.x, bar._model.y - 5);
                        });
                    });
                }
            },
        };
        this.barChartLabels = ['', '', ''];
        this.barChartType = 'bar';
        this.barChartLegend = false;
        // public barChartPlugins = [pluginDataLabels];
        this.barChartData = [
            { data: this.SunDayRequired,
                backgroundColor: ["#246CA5", "#246CA5", "#246CA5"],
                hoverBackgroundColor: ["#246CA5", "#246CA5", "#246CA5",],
                barPercentage: 0.6,
            },
            { data: this.SunDayGenerated,
                backgroundColor: ["#0194E3", "#0194E3", "#0194E3",],
                hoverBackgroundColor: ["#0194E3", "#0194E3", "#0194E3",],
                barPercentage: 0.6,
            },
        ];
        this.barChartDataTest1 = [
            { data: [8, 7],
                backgroundColor: ["#246CA5", "#0194E3"],
                hoverBackgroundColor: ["#246CA5", "#0194E3"],
                barPercentage: 0.6,
            }
            // { data: [4],
            //   backgroundColor: ["#0194E3"],
            //   hoverBackgroundColor:["#0194E3"],
            //   barPercentage:0.6,
            //   },
        ];
        this.barChartDataIndex = [
            { data: [],
                backgroundColor: ["#246CA5", "#0194E3"],
                hoverBackgroundColor: ["#246CA5", "#0194E3"],
                barPercentage: 0.6,
            }
            // { data: [4],
            //   backgroundColor: ["#0194E3"],
            //   hoverBackgroundColor:["#0194E3"],
            //   barPercentage:0.6,
            //   },
        ];
        this.barChartDataTest2 = [
            { data: [3],
                backgroundColor: ["#246CA5"],
                hoverBackgroundColor: ["#246CA5"],
                barPercentage: 0.6,
            },
            { data: [4],
                backgroundColor: ["#0194E3"],
                hoverBackgroundColor: ["#0194E3"],
                barPercentage: 0.6,
            },
        ];
        this.barChartDataTest3 = [
            { data: [3],
                backgroundColor: ["#246CA5"],
                hoverBackgroundColor: ["#246CA5"],
                barPercentage: 0.6,
            },
            { data: [4],
                backgroundColor: ["#0194E3"],
                hoverBackgroundColor: ["#0194E3"],
                barPercentage: 0.6,
            },
        ];
        this.barChartDataMon = [
            { data: this.MonDayRequired,
                backgroundColor: ["#246CA5", "#246CA5", "#246CA5"],
                hoverBackgroundColor: ["#246CA5", "#246CA5", "#246CA5",],
                barPercentage: 0.6
            },
            { data: this.MonDayGenerated,
                backgroundColor: ["#0194E3", "#0194E3", "#0194E3",],
                hoverBackgroundColor: ["#0194E3", "#0194E3", "#0194E3",],
                barPercentage: 0.6
            }
        ];
        this.barChartDataTue = [
            { data: this.TueDayRequired,
                backgroundColor: ["#246CA5", "#246CA5", "#246CA5"],
                hoverBackgroundColor: ["#246CA5", "#246CA5", "#246CA5",],
                barPercentage: 0.6
            },
            { data: this.TueDayGenerated,
                backgroundColor: ["#0194E3", "#0194E3", "#0194E3",],
                hoverBackgroundColor: ["#0194E3", "#0194E3", "#0194E3",],
                barPercentage: 0.6
            }
        ];
        this.barChartDataWed = [
            { data: this.WedDayRequired,
                backgroundColor: ["#246CA5", "#246CA5", "#246CA5"],
                hoverBackgroundColor: ["#246CA5", "#246CA5", "#246CA5",],
                barPercentage: 0.6
            },
            { data: this.WedDayGenerated,
                backgroundColor: ["#0194E3", "#0194E3", "#0194E3",],
                hoverBackgroundColor: ["#0194E3", "#0194E3", "#0194E3",],
                barPercentage: 0.6
            }
        ];
        this.barChartDataThu = [
            { data: this.ThuDayRequired,
                backgroundColor: ["#246CA5", "#246CA5", "#246CA5"],
                hoverBackgroundColor: ["#246CA5", "#246CA5", "#246CA5",],
                barPercentage: 0.6
            },
            { data: this.ThuDayGenerated,
                backgroundColor: ["#0194E3", "#0194E3", "#0194E3",],
                hoverBackgroundColor: ["#0194E3", "#0194E3", "#0194E3",],
                barPercentage: 0.6
            }
        ];
        this.barChartDataFri = [
            { data: this.FriDayRequired,
                backgroundColor: ["#246CA5", "#246CA5", "#246CA5"],
                hoverBackgroundColor: ["#246CA5", "#246CA5", "#246CA5",],
                barPercentage: 0.6
            },
            { data: this.FriDayGenerated,
                backgroundColor: ["#0194E3", "#0194E3", "#0194E3",],
                hoverBackgroundColor: ["#0194E3", "#0194E3", "#0194E3",],
                barPercentage: 0.6
            }
        ];
        this.barChartDataSat = [
            { data: this.SatDayRequired,
                backgroundColor: ["#246CA5", "#246CA5", "#246CA5"],
                hoverBackgroundColor: ["#246CA5", "#246CA5", "#246CA5",],
                barPercentage: 0.6
            },
            { data: this.SatDayGenerated,
                backgroundColor: ["#0194E3", "#0194E3", "#0194E3",],
                hoverBackgroundColor: ["#0194E3", "#0194E3", "#0194E3",],
                barPercentage: 0.6
            }
        ];
    }
    ngOnInit() {
        // this.dataService.getRequiredWorkforceData().subscribe(
        //   (data) => {this.requiredWorkLoadData = data;
        //  console.log(this.sun.length)
        this.requiredEmpData = this.requiredVSgeneratedWorkforceData.Required;
        this.generatedEmpData = this.requiredVSgeneratedWorkforceData.Scheduled;
        //  console.log(this.requiredEmpData.SUN_MID)
        this.SunDayRequired.push(this.requiredEmpData.SUN_MID);
        this.SunDayRequired.push(this.requiredEmpData.SUN_DAY);
        this.SunDayRequired.push(this.requiredEmpData.SUN_EVE);
        this.SunDayGenerated.push(this.generatedEmpData.SUN_MID);
        this.SunDayGenerated.push(this.generatedEmpData.SUN_DAY);
        this.SunDayGenerated.push(this.generatedEmpData.SUN_EVE);
        this.diffSunMid = this.SunDayGenerated[0] + -+this.SunDayRequired[0];
        this.diffSunDay = this.SunDayGenerated[1] + -+this.SunDayRequired[1];
        this.diffSunEve = this.SunDayGenerated[2] + -+this.SunDayRequired[2];
        this.totalSunRequired = this.SunDayRequired[0] + + +this.SunDayRequired[1] + + +this.SunDayRequired[2];
        this.totalSunGenerated = this.SunDayGenerated[0] + + +this.SunDayGenerated[1] + + +this.SunDayGenerated[2];
        this.MonDayRequired.push(this.requiredEmpData.MON_MID);
        this.MonDayRequired.push(this.requiredEmpData.MON_DAY);
        this.MonDayRequired.push(this.requiredEmpData.MON_EVE);
        this.MonDayGenerated.push(this.generatedEmpData.MON_MID);
        this.MonDayGenerated.push(this.generatedEmpData.MON_DAY);
        this.MonDayGenerated.push(this.generatedEmpData.MON_EVE);
        this.diffMonMid = this.MonDayGenerated[0] + -+this.MonDayRequired[0];
        this.diffMonDay = this.MonDayGenerated[1] + -+this.MonDayRequired[1];
        this.diffMonEve = this.MonDayGenerated[2] + -+this.MonDayRequired[2];
        this.totalMonRequired = this.MonDayRequired[0] + + +this.MonDayRequired[1] + + +this.MonDayRequired[2];
        this.totalMonGenerated = this.MonDayGenerated[0] + + +this.MonDayGenerated[1] + + +this.MonDayGenerated[2];
        this.TueDayRequired.push(this.requiredEmpData.TUE_MID);
        this.TueDayRequired.push(this.requiredEmpData.TUE_DAY);
        this.TueDayRequired.push(this.requiredEmpData.TUE_EVE);
        this.TueDayGenerated.push(this.generatedEmpData.TUE_MID);
        this.TueDayGenerated.push(this.generatedEmpData.TUE_DAY);
        this.TueDayGenerated.push(this.generatedEmpData.TUE_EVE);
        this.diffTueMid = this.TueDayGenerated[0] + -+this.TueDayRequired[0];
        this.diffTueDay = this.TueDayGenerated[1] + -+this.TueDayRequired[1];
        this.diffTueEve = this.TueDayGenerated[2] + -+this.TueDayRequired[2];
        this.totalTueRequired = this.TueDayRequired[0] + + +this.TueDayRequired[1] + + +this.TueDayRequired[2];
        this.totalTueGenerated = this.TueDayGenerated[0] + + +this.TueDayGenerated[1] + + +this.TueDayGenerated[2];
        this.WedDayRequired.push(this.requiredEmpData.WED_MID);
        this.WedDayRequired.push(this.requiredEmpData.WED_DAY);
        this.WedDayRequired.push(this.requiredEmpData.WED_EVE);
        this.WedDayGenerated.push(this.generatedEmpData.WED_MID);
        this.WedDayGenerated.push(this.generatedEmpData.WED_DAY);
        this.WedDayGenerated.push(this.generatedEmpData.WED_EVE);
        this.diffWedMid = this.WedDayGenerated[0] + -+this.WedDayRequired[0];
        this.diffWedDay = this.WedDayGenerated[1] + -+this.WedDayRequired[1];
        this.diffWedEve = this.WedDayGenerated[2] + -+this.WedDayRequired[2];
        this.totalWedRequired = this.WedDayRequired[0] + + +this.WedDayRequired[1] + + +this.WedDayRequired[2];
        this.totalWedGenerated = this.WedDayGenerated[0] + + +this.WedDayGenerated[1] + + +this.WedDayGenerated[2];
        this.ThuDayRequired.push(this.requiredEmpData.THU_MID);
        this.ThuDayRequired.push(this.requiredEmpData.THU_DAY);
        this.ThuDayRequired.push(this.requiredEmpData.THU_EVE);
        this.ThuDayGenerated.push(this.generatedEmpData.THU_MID);
        this.ThuDayGenerated.push(this.generatedEmpData.THU_DAY);
        this.ThuDayGenerated.push(this.generatedEmpData.THU_EVE);
        this.diffThuMid = this.ThuDayGenerated[0] + -+this.ThuDayRequired[0];
        this.diffThuDay = this.ThuDayGenerated[1] + -+this.ThuDayRequired[1];
        this.diffThuEve = this.ThuDayGenerated[2] + -+this.ThuDayRequired[2];
        this.totalThuRequired = this.ThuDayRequired[0] + + +this.ThuDayRequired[1] + + +this.ThuDayRequired[2];
        this.totalThuGenerated = this.ThuDayGenerated[0] + + +this.ThuDayGenerated[1] + + +this.ThuDayGenerated[2];
        this.FriDayRequired.push(this.requiredEmpData.FRI_MID);
        this.FriDayRequired.push(this.requiredEmpData.FRI_DAY);
        this.FriDayRequired.push(this.requiredEmpData.FRI_EVE);
        this.FriDayGenerated.push(this.generatedEmpData.FRI_MID);
        this.FriDayGenerated.push(this.generatedEmpData.FRI_DAY);
        this.FriDayGenerated.push(this.generatedEmpData.FRI_EVE);
        this.diffFriMid = this.FriDayGenerated[0] + -+this.FriDayRequired[0];
        this.diffFriDay = this.FriDayGenerated[1] + -+this.FriDayRequired[1];
        this.diffFriEve = this.FriDayGenerated[2] + -+this.FriDayRequired[2];
        this.totalFriRequired = this.FriDayRequired[0] + + +this.FriDayRequired[1] + + +this.FriDayRequired[2];
        this.totalFriGenerated = this.FriDayGenerated[0] + + +this.FriDayGenerated[1] + + +this.FriDayGenerated[2];
        this.SatDayRequired.push(this.requiredEmpData.SAT_MID);
        this.SatDayRequired.push(this.requiredEmpData.SAT_DAY);
        this.SatDayRequired.push(this.requiredEmpData.SAT_EVE);
        this.SatDayGenerated.push(this.generatedEmpData.SAT_MID);
        this.SatDayGenerated.push(this.generatedEmpData.SAT_DAY);
        this.SatDayGenerated.push(this.generatedEmpData.SAT_EVE);
        this.diffSatMid = this.SatDayGenerated[0] + -+this.SatDayRequired[0];
        this.diffSatDay = this.SatDayGenerated[1] + -+this.SatDayRequired[1];
        this.diffSatEve = this.SatDayGenerated[2] + -+this.SatDayRequired[2];
        this.totalSatRequired = this.SatDayRequired[0] + + +this.SatDayRequired[1] + + +this.SatDayRequired[2];
        this.totalSatGenerated = this.SatDayGenerated[0] + + +this.SatDayGenerated[1] + + +this.SatDayGenerated[2];
        // },
        // (error) => this.errorMsg = error,
        // () => console.log('completed!')
        // )
        // this.barChart = new Chart(this.barCanvas.nativeElement, {
        //   type: "bar",
        //   data: {
        //     labels: ["Red", "Blue"],
        //     datasets: [
        //       {
        //         data: [12, 19],
        //         backgroundColor: [
        //           "rgba(255, 99, 132, 0.2)",
        //           "rgba(54, 162, 235, 0.2)",
        //         ],
        //         borderColor: [
        //           "rgba(255,99,132,1)",
        //           "rgba(54, 162, 235, 1)",
        //         ],
        //         borderWidth: 1
        //       }
        //     ]
        //   },
        //   options: {
        //     responsive:true,
        //     scales: {
        //       yAxes: [
        //         {
        //           ticks: {
        //             beginAtZero: true
        //           }
        //         }
        //       ]
        //     }
        //   }
        // });
    }
    goBack() {
        this.route.navigateByUrl('workload-data-report-generate');
    }
};
RequiredVsGeneratedWorkforcePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: src_app_services_required_workforce_service__WEBPACK_IMPORTED_MODULE_8__["RequiredWorkforceService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_4__["MatDialog"] }
];
RequiredVsGeneratedWorkforcePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-required-vs-generated-workforce',
        template: _raw_loader_required_vs_generated_workforce_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_required_vs_generated_workforce_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], RequiredVsGeneratedWorkforcePage);

// ngOnInit() {
//   //     this.barChart = new Chart(this.barCanvas.nativeElement, {
//   //       type: "bar",
//   //       data: {
//   //         labels: ["", ""],
//   //         datasets: [
//   //           {
//   //             data: [ this.totalSunDay , this.totalMonDay],
//   //             backgroundColor: [
//   //               "rgba(255, 99, 132 )",
//   //               "rgba(54, 162, 235)",
//   //             ],
//   //           }
//   //         ]
//   //       },
//   //       options: {
//   //         scales: {
//   //           yAxes: [
//   //             {
//   //               gridLines: {
//   //                 display: false,
//   //               },
//   //               ticks: {
//   //                 beginAtZero: true
//   //               }
//   //             }
//   //           ]
//   //         }
//   //       }
//   //     });
//   // },
//   //   (error) => this.errorMsg = error,
//   //   () => console.log('completed!')
//   //   )
// }
// goBack(){
// this.route.navigateByUrl('workload-data-report-generate')
// }
// import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
// import { MatDialog } from '@angular/material/dialog';
// import { Router } from '@angular/router';
// import { AlertController, ModalController } from '@ionic/angular';
// import Chart from 'chart.js';
// import  Highcharts from 'highcharts';
// import { WorkLoadService } from '../services/work-load.service';
// @Component({
//   selector: 'app-required-vs-generated-workforce',
//   templateUrl: './required-vs-generated-workforce.page.html',
//   styleUrls: ['./required-vs-generated-workforce.page.scss'],
// })
// export class RequiredVsGeneratedWorkforcePage implements OnInit {
//   // @ViewChild('barCanvas',{static: true}) barCanvas;
//   //  barChart: Chart;
//   @ViewChild('barCanvas') private barCanvas: ElementRef;
//   @ViewChild('barCanvasMon') private barCanvasMon: ElementRef;
//    workLoadData: any;
//    errorMsg: any;
//    wData: any;
//    totalSunDay=0;totalMonDay=0;totalTueDay=0;totalWedDay=0;totalThuDay=0;totalFriDay=0;totalSatDay=0;
//    totalSunEve=0;totalMonEve=0; totalTueEve=0;totalWedEve=0; totalThuEve=0;totalFriEve=0;totalSatEve=0;
//    totalSunMid=0;totalMonMid=0; totalTueMid=0;totalWedMid=0; totalThuMid=0;totalFriMid=0;totalSatMid=0;
//    totalSun=0;totalMon=0; totalTue=0;totalWed=0; totalThu=0;totalFri=0;totalSat=0;
//    workLoadId: number;
//    allMsgChangeLogs: any;
//    allEmployeeChangeLogs: any;
//   total: any[];
//   barChart: any;
//   doughnutChart: any;
//   lineChart: any;
//    constructor(public modalCtrl: ModalController,
//                private route:Router,
//                public dataService:WorkLoadService,
//                public alertCtrl: AlertController,
//                public dialogs: MatDialog) {
//    }
//    ngAfterViewInit() {
//     this.barChartMethod();
//     this.barChartMethodMon();
//   }
//    ngOnInit() {
//   }
//   goBack(){
//   this.route.navigateByUrl('workload-data-report-generate')
//   }
//   barChartMethod() {
//     this.barChart = new Chart(this.barCanvas.nativeElement, {
//       type: 'bar',
//       // backgroundColor:[],
//       data: {
//         labels: ['R', 'G','','R','G','','R','G'],
//         datasets: [{
//           label: 'MID',
//           data: [2, 3,0,5,7,0,5,8],
//           backgroundColor: [
//             // 'rgba(255, 99, 132, 0.2)',
//             // 'rgba(54, 162, 235, 0.2)',
//           ],
//           borderColor: [
//             // 'rgba(255,99,132,1)',
//             // 'rgba(54, 162, 235, 1)',
//           ],
//           borderWidth: 1
//         }]
//       },
//       options: {
//         scales: {
//           yAxes: [{
//             gridLines: {
//                     display: false,
//                   },
//                 ticks: {
//                   beginAtZero: true
//                 }
//           }],
//           xAxes: [{
//             gridLines: {
//                     display: false,
//                   },
//                 ticks: {
//                   beginAtZero: true
//                 }
//           }]
//         }
//       }
//     });
//   }
//   barChartMethodMon() {
//   }
// }
// ngOnInit() {
//   //     this.barChart = new Chart(this.barCanvas.nativeElement, {
//   //       type: "bar",
//   //       data: {
//   //         labels: ["", ""],
//   //         datasets: [
//   //           {
//   //             data: [ this.totalSunDay , this.totalMonDay],
//   //             backgroundColor: [
//   //               "rgba(255, 99, 132 )",
//   //               "rgba(54, 162, 235)",
//   //             ],
//   //           }
//   //         ]
//   //       },
//   //       options: {
//   //         scales: {
//   //           yAxes: [
//   //             {
//   //               gridLines: {
//   //                 display: false,
//   //               },
//   //               ticks: {
//   //                 beginAtZero: true
//   //               }
//   //             }
//   //           ]
//   //         }
//   //       }
//   //     });
//   // },
//   //   (error) => this.errorMsg = error,
//   //   () => console.log('completed!')
//   //   )
// console.log(this.sun)
// this.barChart = new Chart(this.barCanvas.nativeElement, {
//   type: 'bar',
//   // backgroundColor:[],
//   data: {
//     labels: ['R', 'G','','R','G','','R','G'],
//     datasets: [{
//       label: 'MID',
//       data: [4, 3,0,5,7,0,5,8],
//       backgroundColor: [
//         // 'rgba(255, 99, 132, 0.2)',
//         // 'rgba(54, 162, 235, 0.2)',
//       ],
//       borderWidth: 1
//     }]
//   },
//   options: {
//     scales: {
//       yAxes: [{
//         gridLines: {
//                 display: false,
//               },
//             ticks: {
//               beginAtZero: true
//             }
//       }],
//       xAxes: [{
//         gridLines: {
//                 display: false,
//               },
//             ticks: {
//               beginAtZero: true
//             }
//       }]
//     }
//   }
// });
// }
// goBack(){
// this.route.navigateByUrl('workload-data-report-generate')
// }


/***/ }),

/***/ "Fszm":
/*!********************************************************************************************************************************!*\
  !*** ./src/app/dashboard/generated_schedule/required-vs-generated-workforce/required-vs-generated-workforce-routing.module.ts ***!
  \********************************************************************************************************************************/
/*! exports provided: RequiredVsGeneratedWorkforcePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequiredVsGeneratedWorkforcePageRoutingModule", function() { return RequiredVsGeneratedWorkforcePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _required_vs_generated_workforce_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./required-vs-generated-workforce.page */ "+ooK");




const routes = [
    {
        path: '',
        component: _required_vs_generated_workforce_page__WEBPACK_IMPORTED_MODULE_3__["RequiredVsGeneratedWorkforcePage"]
    }
];
let RequiredVsGeneratedWorkforcePageRoutingModule = class RequiredVsGeneratedWorkforcePageRoutingModule {
};
RequiredVsGeneratedWorkforcePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RequiredVsGeneratedWorkforcePageRoutingModule);



/***/ }),

/***/ "iM4U":
/*!************************************************************************************************************************!*\
  !*** ./src/app/dashboard/generated_schedule/required-vs-generated-workforce/required-vs-generated-workforce.page.scss ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("#on-chart-card {\n  width: 100%;\n  position: absolute;\n  z-index: 1;\n}\n\n#on-chart-text {\n  width: 100%;\n  text-align: center;\n  margin-top: 2%;\n}\n\n#chart-background-color {\n  background-color: rgba(175, 173, 173, 0.4);\n  height: 100%;\n  border-radius: 3px;\n}\n\n#green-text {\n  color: green;\n  padding-top: 17%;\n}\n\n#red-text {\n  color: red;\n  padding-top: 17%;\n}\n\n@media (min-height: 568px) {\n  #chart-division {\n    margin-top: -1%;\n  }\n\n  #chart-height {\n    height: 9.2rem;\n  }\n\n  #chart-background-height {\n    height: 9.5rem;\n  }\n\n  #chart-division-height-left {\n    height: 100%;\n    margin-left: 1%;\n  }\n\n  #chart-division-height-center {\n    height: 100%;\n    margin-left: -1%;\n  }\n\n  #chart-division-height-right {\n    height: 100%;\n    margin-left: -1.5%;\n  }\n\n  #day-text-sun {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-mon {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-tue {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #day-text-wed {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -3%;\n    position: absolute;\n  }\n\n  #day-text-thu {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -1%;\n    position: absolute;\n  }\n\n  #day-text-fri {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 1.75%;\n    position: absolute;\n  }\n\n  #day-text-sat {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n}\n\n@media (min-height: 640px) {\n  #day-text-sun {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-mon {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-tue {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #day-text-wed {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -3%;\n    position: absolute;\n  }\n\n  #day-text-thu {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -1%;\n    position: absolute;\n  }\n\n  #day-text-fri {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 1.75%;\n    position: absolute;\n  }\n\n  #day-text-sat {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #chart-height {\n    height: 9.2rem;\n  }\n\n  #chart-background-height {\n    height: 9.5rem;\n  }\n\n  #chart-division-height-left {\n    height: 100%;\n    margin-left: 0%;\n  }\n\n  #chart-division-height-center {\n    height: 100%;\n    margin-left: -1%;\n  }\n\n  #chart-division-height-right {\n    height: 100%;\n    margin-left: -0.7%;\n  }\n}\n\n@media (min-width: 280px) and (max-width: 281px) and (max-height: 654px) and (min-height: 653px) {\n  #green-text {\n    color: green;\n    font-size: 16px;\n    padding-top: 17%;\n  }\n\n  #red-text {\n    color: red;\n    font-size: 16px;\n    padding-top: 17%;\n  }\n\n  #day-text-sun {\n    float: left;\n    margin-left: 0%;\n    margin-right: -3%;\n    margin-top: 6%;\n    right: 0%;\n    font-size: 10px;\n    position: absolute;\n  }\n\n  #day-text-mon {\n    float: left;\n    margin-left: 0%;\n    margin-right: -3%;\n    margin-top: 6%;\n    right: 0%;\n    font-size: 10px;\n    position: absolute;\n  }\n\n  #day-text-tue {\n    float: left;\n    margin-left: 0%;\n    margin-right: -3%;\n    margin-top: 6%;\n    right: -0.5%;\n    font-size: 10px;\n    position: absolute;\n  }\n\n  #day-text-wed {\n    float: left;\n    margin-left: 0%;\n    margin-right: -3%;\n    margin-top: 6%;\n    right: -3%;\n    font-size: 10px;\n    position: absolute;\n  }\n\n  #day-text-thu {\n    float: left;\n    margin-left: 0%;\n    margin-right: -3%;\n    margin-top: 6%;\n    font-size: 10px;\n    right: -1%;\n    position: absolute;\n  }\n\n  #day-text-fri {\n    float: left;\n    margin-left: 0%;\n    margin-right: -3%;\n    margin-top: 6%;\n    font-size: 10px;\n    right: 1.75%;\n    position: absolute;\n  }\n\n  #day-text-sat {\n    float: left;\n    margin-left: 0%;\n    margin-right: -3%;\n    margin-top: 6%;\n    right: -0.5%;\n    font-size: 10px;\n    position: absolute;\n  }\n\n  #chart-height {\n    height: 9.2rem;\n  }\n\n  #chart-background-height {\n    height: 9.5rem;\n  }\n\n  #chart-division-height-left {\n    height: 100%;\n    margin-left: 2%;\n  }\n\n  #chart-division-height-center {\n    height: 100%;\n    margin-left: -1%;\n  }\n\n  #chart-division-height-right {\n    height: 100%;\n    margin-left: -2%;\n  }\n}\n\n@media (min-height: 667px) {\n  #day-text-sun {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-mon {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-tue {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #day-text-wed {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -3%;\n    position: absolute;\n  }\n\n  #day-text-thu {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -1%;\n    position: absolute;\n  }\n\n  #day-text-fri {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 1.75%;\n    position: absolute;\n  }\n\n  #day-text-sat {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #chart-height {\n    height: 9.2rem;\n  }\n\n  #chart-background-height {\n    height: 9.5rem;\n  }\n\n  #chart-division-height-left {\n    height: 100%;\n  }\n\n  #chart-division-height-center {\n    height: 100%;\n    margin-left: -1%;\n  }\n\n  #chart-division-height-right {\n    height: 100%;\n    margin-left: -1%;\n  }\n}\n\n@media (min-width: 540px) {\n  #chart-division {\n    margin-top: -3%;\n  }\n\n  #chart-division-height-left {\n    margin-left: -2.5%;\n  }\n\n  #chart-division-height-center {\n    margin-left: 0%;\n  }\n\n  #chart-division-height-right {\n    margin-left: 0%;\n  }\n}\n\n@media (min-height: 720px) {\n  #day-text-sun {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-mon {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-tue {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #day-text-wed {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -3%;\n    position: absolute;\n  }\n\n  #day-text-thu {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -1%;\n    position: absolute;\n  }\n\n  #day-text-fri {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 1.75%;\n    position: absolute;\n  }\n\n  #day-text-sat {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #chart-division {\n    margin-top: -1%;\n  }\n\n  #chart-height {\n    height: 9.2rem;\n  }\n\n  #chart-background-height {\n    height: 9.5rem;\n  }\n\n  #chart-division-height-left {\n    height: 100%;\n  }\n\n  #chart-division-height-center {\n    height: 100%;\n  }\n\n  #chart-division-height-right {\n    height: 100%;\n    margin-left: 0%;\n  }\n}\n\n@media (min-height: 731px) {\n  #day-text-sun {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-mon {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-tue {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #day-text-wed {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -3%;\n    position: absolute;\n  }\n\n  #day-text-thu {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -1%;\n    position: absolute;\n  }\n\n  #day-text-fri {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 1.75%;\n    position: absolute;\n  }\n\n  #day-text-sat {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #chart-division {\n    margin-top: -1%;\n  }\n\n  #chart-height {\n    height: 9.2rem;\n  }\n\n  #chart-background-height {\n    height: 9.5rem;\n  }\n\n  #chart-division-height-left {\n    height: 100%;\n  }\n\n  #chart-division-height-center {\n    height: 100%;\n    margin-left: -1%;\n  }\n\n  #chart-division-height-right {\n    height: 100%;\n    margin-left: -1%;\n  }\n}\n\n@media (min-height: 736px) {\n  #day-text-sun {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-mon {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-tue {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #day-text-wed {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -3%;\n    position: absolute;\n  }\n\n  #day-text-thu {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -1%;\n    position: absolute;\n  }\n\n  #day-text-fri {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 1.75%;\n    position: absolute;\n  }\n\n  #day-text-sat {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #chart-division {\n    margin-top: -1%;\n  }\n\n  #chart-height {\n    height: 9.2rem;\n  }\n\n  #chart-background-height {\n    height: 9.5rem;\n  }\n\n  #chart-division-height-left {\n    height: 100%;\n  }\n\n  #chart-division-height-center {\n    height: 100%;\n    margin-left: -1%;\n  }\n\n  #chart-division-height-right {\n    height: 100%;\n    margin-left: -1%;\n  }\n}\n\n@media (min-height: 812px) {\n  #day-text-sun {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-mon {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-tue {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #day-text-wed {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -3%;\n    position: absolute;\n  }\n\n  #day-text-thu {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -1%;\n    position: absolute;\n  }\n\n  #day-text-fri {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 1.75%;\n    position: absolute;\n  }\n\n  #day-text-sat {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #chart-division {\n    margin-top: -1%;\n  }\n\n  #chart-height {\n    height: 9.2rem;\n  }\n\n  #chart-background-height {\n    height: 9.5rem;\n  }\n\n  #chart-division-height-left {\n    height: 100%;\n  }\n\n  #chart-division-height-center {\n    height: 100%;\n    margin-left: -1%;\n  }\n\n  #chart-division-height-right {\n    height: 100%;\n    margin-left: -1%;\n  }\n}\n\n@media (min-height: 823px) {\n  #day-text-sun {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-mon {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-tue {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #day-text-wed {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -3%;\n    position: absolute;\n  }\n\n  #day-text-thu {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -1%;\n    position: absolute;\n  }\n\n  #day-text-fri {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 1.75%;\n    position: absolute;\n  }\n\n  #day-text-sat {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #chart-height {\n    height: 9.2rem;\n  }\n\n  #chart-background-height {\n    height: 9.5rem;\n  }\n\n  #chart-division {\n    margin-top: -1%;\n  }\n\n  #chart-division-height-left {\n    height: 100%;\n  }\n\n  #chart-division-height-center {\n    height: 100%;\n    margin-left: -1%;\n  }\n\n  #chart-division-height-right {\n    height: 100%;\n    margin-left: -1%;\n  }\n}\n\n@media (min-height: 844px) {\n  #day-text-sun {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-mon {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-tue {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #day-text-wed {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -3%;\n    position: absolute;\n  }\n\n  #day-text-thu {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -1%;\n    position: absolute;\n  }\n\n  #day-text-fri {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 1.75% !important;\n    position: absolute;\n  }\n\n  #day-text-sat {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5% !important;\n    position: absolute;\n  }\n\n  #chart-height {\n    height: 9.2rem;\n  }\n\n  #chart-background-height {\n    height: 9.5rem;\n  }\n\n  #chart-division {\n    margin-top: 0%;\n  }\n\n  #chart-division-height-left {\n    height: 100%;\n  }\n\n  #chart-division-height-center {\n    height: 100%;\n    margin-left: -1%;\n  }\n\n  #chart-division-height-right {\n    height: 100%;\n    margin-left: -1%;\n  }\n}\n\n@media (min-height: 914px) {\n  #day-text-sun {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-mon {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-tue {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #day-text-wed {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -3%;\n    position: absolute;\n  }\n\n  #day-text-thu {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -1%;\n    position: absolute;\n  }\n\n  #day-text-fri {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 1.75%;\n    position: absolute;\n  }\n\n  #day-text-sat {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #chart-division {\n    margin-top: 1%;\n  }\n\n  #chart-height {\n    height: 9.2rem;\n  }\n\n  #chart-background-height {\n    height: 9.5rem;\n  }\n\n  #chart-division-height-center {\n    height: 100%;\n    margin-left: -1%;\n  }\n\n  #chart-division-height-right {\n    height: 100%;\n    margin-left: -1%;\n  }\n}\n\n@media (min-width: 768px) {\n  #chart-division {\n    margin-top: -3%;\n  }\n\n  #chart-division-height-left {\n    margin-left: -4%;\n  }\n\n  #chart-division-height-center {\n    margin-left: 0.5%;\n  }\n\n  #chart-division-height-right {\n    margin-left: 5%;\n  }\n}\n\n@media (min-height: 1024px) {\n  #day-text-sun {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-mon {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-tue {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #day-text-wed {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -3%;\n    position: absolute;\n  }\n\n  #day-text-thu {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -1%;\n    position: absolute;\n  }\n\n  #day-text-fri {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 1.75%;\n    position: absolute;\n  }\n\n  #day-text-sat {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #chart-division {\n    margin-top: -1%;\n  }\n\n  #chart-height {\n    height: 9.2rem;\n  }\n\n  #chart-background-height {\n    height: 9.5rem;\n  }\n\n  #chart-division-height-left {\n    height: 100%;\n  }\n\n  #chart-division-height-center {\n    height: 100%;\n  }\n\n  #chart-division-height-right {\n    height: 100%;\n    margin-left: 1%;\n  }\n}\n\n@media (min-width: 800px) {\n  #chart-division {\n    margin-top: -3%;\n  }\n\n  #chart-division-height-left {\n    margin-left: -4%;\n  }\n\n  #chart-division-height-center {\n    margin-left: 0.5%;\n  }\n\n  #chart-division-height-right {\n    margin-left: 5%;\n  }\n}\n\n@media (min-height: 1280px) {\n  #day-text-sun {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-mon {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-tue {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #day-text-wed {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -3%;\n    position: absolute;\n  }\n\n  #day-text-thu {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -1%;\n    position: absolute;\n  }\n\n  #day-text-fri {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 1.75%;\n    position: absolute;\n  }\n\n  #day-text-sat {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #chart-division {\n    margin-top: -1%;\n  }\n\n  #chart-height {\n    height: 9.2rem;\n  }\n\n  #chart-background-height {\n    height: 9.5rem;\n  }\n\n  #chart-division-height-left {\n    height: 100%;\n  }\n\n  #chart-division-height-center {\n    height: 100%;\n  }\n\n  #chart-division-height-right {\n    height: 20.5rem;\n    margin-left: 0.6%;\n  }\n}\n\n@media (min-width: 1024px) {\n  #chart-division {\n    margin-top: -3%;\n  }\n\n  #chart-division-height-left {\n    margin-left: -4%;\n  }\n\n  #chart-division-height-center {\n    margin-left: 0.5%;\n  }\n\n  #chart-division-height-right {\n    margin-left: 5%;\n  }\n}\n\n@media (min-height: 1366px) {\n  #day-text-sun {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-mon {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 0%;\n    position: absolute;\n  }\n\n  #day-text-tue {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #day-text-wed {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -3%;\n    position: absolute;\n  }\n\n  #day-text-thu {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -1%;\n    position: absolute;\n  }\n\n  #day-text-fri {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: 1.75%;\n    position: absolute;\n  }\n\n  #day-text-sat {\n    float: left;\n    margin-left: 0%;\n    margin-right: 0%;\n    margin-top: 8%;\n    right: -0.5%;\n    position: absolute;\n  }\n\n  #chart-division {\n    margin-top: -1%;\n  }\n\n  #chart-height {\n    height: 9.2rem;\n  }\n\n  #chart-background-height {\n    height: 9.5rem;\n  }\n\n  #chart-division-height-left {\n    height: 100%;\n  }\n\n  #chart-division-height-center {\n    height: 100%;\n  }\n\n  #chart-division-height-right {\n    height: 100%;\n    margin-left: 0%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxccmVxdWlyZWQtdnMtZ2VuZXJhdGVkLXdvcmtmb3JjZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDRSxXQUFBO0VBRUEsa0JBQUE7RUFDRSxVQUFBO0FBREo7O0FBSUE7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBREY7O0FBR0E7RUFDRSwwQ0FBQTtFQUVBLFlBQUE7RUFDQSxrQkFBQTtBQURGOztBQUdBO0VBQ0UsWUFBQTtFQUNBLGdCQUFBO0FBQUY7O0FBR0E7RUFDRSxVQUFBO0VBQ0EsZ0JBQUE7QUFBRjs7QUFFQTtFQUNFO0lBQ0UsZUFBQTtFQUNGOztFQUNBO0lBQ0UsY0FBQTtFQUVGOztFQUFBO0lBQ0UsY0FBQTtFQUdGOztFQURBO0lBQ0UsWUFBQTtJQUNBLGVBQUE7RUFJRjs7RUFGQTtJQUNFLFlBQUE7SUFDQSxnQkFBQTtFQUtGOztFQUhBO0lBQ0UsWUFBQTtJQUNBLGtCQUFBO0VBTUY7O0VBSkE7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFNBQUE7SUFDQSxrQkFBQTtFQU9GOztFQUxBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxTQUFBO0lBQ0Esa0JBQUE7RUFRRjs7RUFOQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBU0Y7O0VBUEE7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFVBQUE7SUFDQSxrQkFBQTtFQVVGOztFQVJBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxVQUFBO0lBQ0Esa0JBQUE7RUFXRjs7RUFUQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBWUY7O0VBVkE7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFlBQUE7SUFDQSxrQkFBQTtFQWFGO0FBQ0Y7O0FBVkE7RUFDRTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsU0FBQTtJQUNBLGtCQUFBO0VBWUY7O0VBVkE7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFNBQUE7SUFDQSxrQkFBQTtFQWFGOztFQVhBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxZQUFBO0lBQ0Esa0JBQUE7RUFjRjs7RUFaQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsVUFBQTtJQUNBLGtCQUFBO0VBZUY7O0VBYkE7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFVBQUE7SUFDQSxrQkFBQTtFQWdCRjs7RUFkQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBaUJGOztFQWZBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxZQUFBO0lBQ0Esa0JBQUE7RUFrQkY7O0VBaEJBO0lBQ0UsY0FBQTtFQW1CRjs7RUFqQkE7SUFDRSxjQUFBO0VBb0JGOztFQWxCQTtJQUNFLFlBQUE7SUFDQSxlQUFBO0VBcUJGOztFQW5CQTtJQUNFLFlBQUE7SUFDQSxnQkFBQTtFQXNCRjs7RUFwQkE7SUFDRSxZQUFBO0lBQ0Esa0JBQUE7RUF1QkY7QUFDRjs7QUFsQks7RUFDQztJQUNFLFlBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7RUFvQk47O0VBakJJO0lBQ0UsVUFBQTtJQUNELGVBQUE7SUFDQyxnQkFBQTtFQW9CTjs7RUFsQkk7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGlCQUFBO0lBQ0EsY0FBQTtJQUNBLFNBQUE7SUFDQSxlQUFBO0lBQ0Esa0JBQUE7RUFxQk47O0VBbkJJO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxpQkFBQTtJQUNBLGNBQUE7SUFDQSxTQUFBO0lBQ0EsZUFBQTtJQUNBLGtCQUFBO0VBc0JOOztFQXBCSTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsaUJBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGVBQUE7SUFDQSxrQkFBQTtFQXVCTjs7RUFyQkk7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGlCQUFBO0lBQ0EsY0FBQTtJQUNBLFVBQUE7SUFDQSxlQUFBO0lBQ0Esa0JBQUE7RUF3Qk47O0VBdEJJO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxpQkFBQTtJQUNBLGNBQUE7SUFDQSxlQUFBO0lBQ0EsVUFBQTtJQUNBLGtCQUFBO0VBeUJOOztFQXZCSTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsaUJBQUE7SUFDQSxjQUFBO0lBQ0EsZUFBQTtJQUNBLFlBQUE7SUFDQSxrQkFBQTtFQTBCTjs7RUF4Qkk7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGlCQUFBO0lBQ0EsY0FBQTtJQUNBLFlBQUE7SUFDQSxlQUFBO0lBQ0Esa0JBQUE7RUEyQk47O0VBekJJO0lBQ0UsY0FBQTtFQTRCTjs7RUExQkk7SUFDRSxjQUFBO0VBNkJOOztFQTNCRTtJQUNFLFlBQUE7SUFDQSxlQUFBO0VBOEJKOztFQTVCRTtJQUNFLFlBQUE7SUFDQSxnQkFBQTtFQStCSjs7RUE3QkU7SUFDRSxZQUFBO0lBQ0EsZ0JBQUE7RUFnQ0o7QUFDRjs7QUExQkE7RUFDRTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsU0FBQTtJQUNBLGtCQUFBO0VBNEJGOztFQTFCQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsU0FBQTtJQUNBLGtCQUFBO0VBNkJGOztFQTNCQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBOEJGOztFQTVCQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsVUFBQTtJQUNBLGtCQUFBO0VBK0JGOztFQTdCQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsVUFBQTtJQUNBLGtCQUFBO0VBZ0NGOztFQTlCQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBaUNGOztFQS9CQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBa0NGOztFQTdCQTtJQUNFLGNBQUE7RUFnQ0Y7O0VBOUJBO0lBQ0UsY0FBQTtFQWlDRjs7RUEvQkE7SUFDRSxZQUFBO0VBa0NGOztFQWhDQTtJQUNFLFlBQUE7SUFDQSxnQkFBQTtFQW1DRjs7RUFqQ0E7SUFDRSxZQUFBO0lBQ0EsZ0JBQUE7RUFvQ0Y7QUFDRjs7QUFsQ0E7RUFFRTtJQUNFLGVBQUE7RUFtQ0Y7O0VBakNBO0lBRUUsa0JBQUE7RUFtQ0Y7O0VBakNBO0lBRUUsZUFBQTtFQW1DRjs7RUFqQ0E7SUFFRSxlQUFBO0VBbUNGO0FBQ0Y7O0FBakNBO0VBQ0U7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFNBQUE7SUFDQSxrQkFBQTtFQW1DRjs7RUFqQ0E7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFNBQUE7SUFDQSxrQkFBQTtFQW9DRjs7RUFsQ0E7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFlBQUE7SUFDQSxrQkFBQTtFQXFDRjs7RUFuQ0E7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFVBQUE7SUFDQSxrQkFBQTtFQXNDRjs7RUFwQ0E7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFVBQUE7SUFDQSxrQkFBQTtFQXVDRjs7RUFyQ0E7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFlBQUE7SUFDQSxrQkFBQTtFQXdDRjs7RUF0Q0E7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFlBQUE7SUFDQSxrQkFBQTtFQXlDRjs7RUF2Q0E7SUFDRSxlQUFBO0VBMENGOztFQXhDQTtJQUNFLGNBQUE7RUEyQ0Y7O0VBekNBO0lBQ0UsY0FBQTtFQTRDRjs7RUExQ0E7SUFDRSxZQUFBO0VBNkNGOztFQTFDQTtJQUNFLFlBQUE7RUE2Q0Y7O0VBMUNBO0lBQ0UsWUFBQTtJQUNBLGVBQUE7RUE2Q0Y7QUFDRjs7QUEzQ0E7RUFFRTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsU0FBQTtJQUNBLGtCQUFBO0VBNENGOztFQTFDQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsU0FBQTtJQUNBLGtCQUFBO0VBNkNGOztFQTNDQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBOENGOztFQTVDQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsVUFBQTtJQUNBLGtCQUFBO0VBK0NGOztFQTdDQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsVUFBQTtJQUNBLGtCQUFBO0VBZ0RGOztFQTlDQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBaURGOztFQS9DQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBa0RGOztFQWhEQTtJQUNFLGVBQUE7RUFtREY7O0VBakRBO0lBQ0UsY0FBQTtFQW9ERjs7RUFsREE7SUFDRSxjQUFBO0VBcURGOztFQW5EQTtJQUNFLFlBQUE7RUFzREY7O0VBcERBO0lBQ0UsWUFBQTtJQUNBLGdCQUFBO0VBdURGOztFQXJEQTtJQUNFLFlBQUE7SUFDQSxnQkFBQTtFQXdERjtBQUNGOztBQXREQTtFQUNFO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxTQUFBO0lBQ0Esa0JBQUE7RUF3REY7O0VBdERBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxTQUFBO0lBQ0Esa0JBQUE7RUF5REY7O0VBdkRBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxZQUFBO0lBQ0Esa0JBQUE7RUEwREY7O0VBeERBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxVQUFBO0lBQ0Esa0JBQUE7RUEyREY7O0VBekRBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxVQUFBO0lBQ0Esa0JBQUE7RUE0REY7O0VBMURBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxZQUFBO0lBQ0Esa0JBQUE7RUE2REY7O0VBM0RBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxZQUFBO0lBQ0Esa0JBQUE7RUE4REY7O0VBNURBO0lBQ0UsZUFBQTtFQStERjs7RUE3REE7SUFDRSxjQUFBO0VBZ0VGOztFQTlEQTtJQUNFLGNBQUE7RUFpRUY7O0VBL0RBO0lBQ0UsWUFBQTtFQWtFRjs7RUFoRUE7SUFDRSxZQUFBO0lBQ0EsZ0JBQUE7RUFtRUY7O0VBakVBO0lBQ0UsWUFBQTtJQUNBLGdCQUFBO0VBb0VGO0FBQ0Y7O0FBbEVBO0VBQ0U7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFNBQUE7SUFDQSxrQkFBQTtFQW9FRjs7RUFsRUE7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFNBQUE7SUFDQSxrQkFBQTtFQXFFRjs7RUFuRUE7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFlBQUE7SUFDQSxrQkFBQTtFQXNFRjs7RUFwRUE7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFVBQUE7SUFDQSxrQkFBQTtFQXVFRjs7RUFyRUE7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFVBQUE7SUFDQSxrQkFBQTtFQXdFRjs7RUF0RUE7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFlBQUE7SUFDQSxrQkFBQTtFQXlFRjs7RUF2RUE7SUFDRSxXQUFBO0lBQ0EsZUFBQTtJQUNBLGdCQUFBO0lBQ0EsY0FBQTtJQUNBLFlBQUE7SUFDQSxrQkFBQTtFQTBFRjs7RUF4RUE7SUFDRSxlQUFBO0VBMkVGOztFQXpFQTtJQUNFLGNBQUE7RUE0RUY7O0VBMUVBO0lBQ0UsY0FBQTtFQTZFRjs7RUEzRUE7SUFDRSxZQUFBO0VBOEVGOztFQTVFQTtJQUNFLFlBQUE7SUFDQSxnQkFBQTtFQStFRjs7RUE3RUE7SUFDRSxZQUFBO0lBQ0EsZ0JBQUE7RUFnRkY7QUFDRjs7QUE5RUE7RUFDRTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsU0FBQTtJQUNBLGtCQUFBO0VBZ0ZGOztFQTlFQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsU0FBQTtJQUNBLGtCQUFBO0VBaUZGOztFQS9FQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBa0ZGOztFQWhGQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsVUFBQTtJQUNBLGtCQUFBO0VBbUZGOztFQWpGQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsVUFBQTtJQUNBLGtCQUFBO0VBb0ZGOztFQWxGQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBcUZGOztFQW5GQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBc0ZGOztFQXBGQTtJQUNFLGNBQUE7RUF1RkY7O0VBckZBO0lBQ0UsY0FBQTtFQXdGRjs7RUF0RkE7SUFDRSxlQUFBO0VBeUZGOztFQXZGQTtJQUNFLFlBQUE7RUEwRkY7O0VBeEZBO0lBQ0UsWUFBQTtJQUNBLGdCQUFBO0VBMkZGOztFQXpGQTtJQUNFLFlBQUE7SUFDQSxnQkFBQTtFQTRGRjtBQUNGOztBQTFGQTtFQUVFO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxTQUFBO0lBQ0Esa0JBQUE7RUEyRkY7O0VBekZBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxTQUFBO0lBQ0Esa0JBQUE7RUE0RkY7O0VBMUZBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxZQUFBO0lBQ0Esa0JBQUE7RUE2RkY7O0VBM0ZBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxVQUFBO0lBQ0Esa0JBQUE7RUE4RkY7O0VBNUZBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxVQUFBO0lBQ0Esa0JBQUE7RUErRkY7O0VBN0ZBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSx1QkFBQTtJQUNBLGtCQUFBO0VBZ0dGOztFQTlGQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsdUJBQUE7SUFDQSxrQkFBQTtFQWlHRjs7RUE5RkE7SUFDRSxjQUFBO0VBaUdGOztFQS9GQTtJQUNFLGNBQUE7RUFrR0Y7O0VBaEdBO0lBQ0UsY0FBQTtFQW1HRjs7RUFqR0E7SUFDRSxZQUFBO0VBb0dGOztFQWxHQTtJQUNFLFlBQUE7SUFDQSxnQkFBQTtFQXFHRjs7RUFuR0E7SUFDRSxZQUFBO0lBQ0EsZ0JBQUE7RUFzR0Y7QUFDRjs7QUFuR0E7RUFFSTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsU0FBQTtJQUNBLGtCQUFBO0VBb0dKOztFQWxHRTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsU0FBQTtJQUNBLGtCQUFBO0VBcUdKOztFQW5HRTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBc0dKOztFQXBHRTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsVUFBQTtJQUNBLGtCQUFBO0VBdUdKOztFQXJHRTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsVUFBQTtJQUNBLGtCQUFBO0VBd0dKOztFQXRHRTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBeUdKOztFQXZHRTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBMEdKOztFQXZHRTtJQUNFLGNBQUE7RUEwR0o7O0VBeEdFO0lBQ0UsY0FBQTtFQTJHSjs7RUF6R0U7SUFDRSxjQUFBO0VBNEdKOztFQTFHRTtJQUNFLFlBQUE7SUFDQSxnQkFBQTtFQTZHSjs7RUEzR0U7SUFDRSxZQUFBO0lBQ0EsZ0JBQUE7RUE4R0o7QUFDRjs7QUEzR0E7RUFFRTtJQUNFLGVBQUE7RUE0R0Y7O0VBMUdBO0lBRUUsZ0JBQUE7RUE0R0Y7O0VBMUdBO0lBRUUsaUJBQUE7RUE0R0Y7O0VBMUdBO0lBRUUsZUFBQTtFQTRHRjtBQUNGOztBQXhGQTtFQUNFO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxTQUFBO0lBQ0Esa0JBQUE7RUEwRkY7O0VBeEZBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxTQUFBO0lBQ0Esa0JBQUE7RUEyRkY7O0VBekZBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxZQUFBO0lBQ0Esa0JBQUE7RUE0RkY7O0VBMUZBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxVQUFBO0lBQ0Esa0JBQUE7RUE2RkY7O0VBM0ZBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxVQUFBO0lBQ0Esa0JBQUE7RUE4RkY7O0VBNUZBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxZQUFBO0lBQ0Esa0JBQUE7RUErRkY7O0VBN0ZBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxZQUFBO0lBQ0Esa0JBQUE7RUFnR0Y7O0VBOUZBO0lBQ0UsZUFBQTtFQWlHRjs7RUEvRkE7SUFDRSxjQUFBO0VBa0dGOztFQWhHQTtJQUNFLGNBQUE7RUFtR0Y7O0VBakdBO0lBQ0UsWUFBQTtFQW9HRjs7RUFqR0E7SUFDRSxZQUFBO0VBb0dGOztFQWpHQTtJQUNFLFlBQUE7SUFDQSxlQUFBO0VBb0dGO0FBQ0Y7O0FBbEdBO0VBQ0U7SUFDRSxlQUFBO0VBb0dGOztFQWxHQTtJQUVFLGdCQUFBO0VBb0dGOztFQWxHQTtJQUVFLGlCQUFBO0VBb0dGOztFQWxHQTtJQUVFLGVBQUE7RUFvR0Y7QUFDRjs7QUFsR0E7RUFDRTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsU0FBQTtJQUNBLGtCQUFBO0VBb0dGOztFQWxHQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsU0FBQTtJQUNBLGtCQUFBO0VBcUdGOztFQW5HQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBc0dGOztFQXBHQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsVUFBQTtJQUNBLGtCQUFBO0VBdUdGOztFQXJHQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsVUFBQTtJQUNBLGtCQUFBO0VBd0dGOztFQXRHQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBeUdGOztFQXZHQTtJQUNFLFdBQUE7SUFDQSxlQUFBO0lBQ0EsZ0JBQUE7SUFDQSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGtCQUFBO0VBMEdGOztFQXhHQTtJQUNFLGVBQUE7RUEyR0Y7O0VBekdBO0lBQ0UsY0FBQTtFQTRHRjs7RUExR0E7SUFDRSxjQUFBO0VBNkdGOztFQTNHQTtJQUNFLFlBQUE7RUE4R0Y7O0VBM0dBO0lBQ0UsWUFBQTtFQThHRjs7RUEzR0E7SUFDRSxlQUFBO0lBQ0EsaUJBQUE7RUE4R0Y7QUFDRjs7QUE1R0E7RUFDRTtJQUNFLGVBQUE7RUE4R0Y7O0VBNUdBO0lBRUUsZ0JBQUE7RUE4R0Y7O0VBNUdBO0lBRUUsaUJBQUE7RUE4R0Y7O0VBNUdBO0lBRUUsZUFBQTtFQThHRjtBQUNGOztBQTVHQTtFQUNFO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxTQUFBO0lBQ0Esa0JBQUE7RUE4R0Y7O0VBNUdBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxTQUFBO0lBQ0Esa0JBQUE7RUErR0Y7O0VBN0dBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxZQUFBO0lBQ0Esa0JBQUE7RUFnSEY7O0VBOUdBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxVQUFBO0lBQ0Esa0JBQUE7RUFpSEY7O0VBL0dBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxVQUFBO0lBQ0Esa0JBQUE7RUFrSEY7O0VBaEhBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxZQUFBO0lBQ0Esa0JBQUE7RUFtSEY7O0VBakhBO0lBQ0UsV0FBQTtJQUNBLGVBQUE7SUFDQSxnQkFBQTtJQUNBLGNBQUE7SUFDQSxZQUFBO0lBQ0Esa0JBQUE7RUFvSEY7O0VBbEhBO0lBQ0UsZUFBQTtFQXFIRjs7RUFuSEE7SUFDRSxjQUFBO0VBc0hGOztFQXBIQTtJQUNFLGNBQUE7RUF1SEY7O0VBckhBO0lBQ0UsWUFBQTtFQXdIRjs7RUFySEE7SUFDRSxZQUFBO0VBd0hGOztFQXJIQTtJQUNFLFlBQUE7SUFDQSxlQUFBO0VBd0hGO0FBQ0YiLCJmaWxlIjoicmVxdWlyZWQtdnMtZ2VuZXJhdGVkLXdvcmtmb3JjZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbiNvbi1jaGFydC1jYXJke1xuICB3aWR0aDogMTAwJTtcbiAgLy8gbWFyZ2luLXRvcDogNyU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB6LWluZGV4OiAxO1xufVxuXG4jb24tY2hhcnQtdGV4dHtcbiAgd2lkdGg6IDEwMCU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDogMiU7XG59XG4jY2hhcnQtYmFja2dyb3VuZC1jb2xvcntcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE3NSwgMTczLCAxNzMsMC40KTtcblxuICBoZWlnaHQ6MTAwJTtcbiAgYm9yZGVyLXJhZGl1czogM3B4O1xufVxuI2dyZWVuLXRleHR7XG4gIGNvbG9yOiBncmVlbjtcbiAgcGFkZGluZy10b3A6IDE3JTtcbn1cblxuI3JlZC10ZXh0e1xuICBjb2xvcjogcmVkO1xuICBwYWRkaW5nLXRvcDogMTclO1xufVxuQG1lZGlhKG1pbi1oZWlnaHQ6NTY4cHgpIHtcbiAgI2NoYXJ0LWRpdmlzaW9ue1xuICAgIG1hcmdpbi10b3A6IC0xJTtcbiAgfVxuICAjY2hhcnQtaGVpZ2h0e1xuICAgIGhlaWdodDogOS4ycmVtO1xuICB9XG4gICNjaGFydC1iYWNrZ3JvdW5kLWhlaWdodHtcbiAgICBoZWlnaHQ6IDkuNXJlbTtcbiAgfVxuICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LWxlZnR7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG1hcmdpbi1sZWZ0OiAxJTtcbiAgfVxuICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LWNlbnRlcntcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWFyZ2luLWxlZnQ6LTElXG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1yaWdodHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWFyZ2luLWxlZnQ6LTEuNSVcbiAgfVxuICAjZGF5LXRleHQtc3Vue1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogMCU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC1tb257XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAwJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LXR1ZXtcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IC0wLjUlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtd2Vke1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTMlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtdGh1e1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTElO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtZnJpe1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogMS43NSU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC1zYXR7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAtMC41JTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbn1cblxuQG1lZGlhKG1pbi1oZWlnaHQ6NjQwcHgpIHtcbiAgI2RheS10ZXh0LXN1bntcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IDAlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtbW9ue1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogMCU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC10dWV7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAtMC41JTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LXdlZHtcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IC0zJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LXRodXtcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IC0xJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LWZyaXtcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IDEuNzUlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtc2F0e1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTAuNSU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNjaGFydC1oZWlnaHR7XG4gICAgaGVpZ2h0OiA5LjJyZW07XG4gIH1cbiAgI2NoYXJ0LWJhY2tncm91bmQtaGVpZ2h0e1xuICAgIGhlaWdodDogOS41cmVtO1xuICB9XG4gICNjaGFydC1kaXZpc2lvbi1oZWlnaHQtbGVmdHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICB9XG4gICNjaGFydC1kaXZpc2lvbi1oZWlnaHQtY2VudGVye1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBtYXJnaW4tbGVmdDotMSVcbiAgfVxuICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LXJpZ2h0e1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBtYXJnaW4tbGVmdDotMC43JVxuICB9XG59XG5AbWVkaWEgKG1pbi13aWR0aDoyODBweCkge1xuQG1lZGlhKG1heC13aWR0aDoyODFweCl7XG4gIEBtZWRpYShtYXgtaGVpZ2h0OjY1NHB4KSB7XG4gICAgIEBtZWRpYShtaW4taGVpZ2h0OjY1M3B4KSB7XG4gICAgICAjZ3JlZW4tdGV4dHtcbiAgICAgICAgY29sb3I6IGdyZWVuO1xuICAgICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICAgIHBhZGRpbmctdG9wOiAxNyU7XG4gICAgICB9XG5cbiAgICAgICNyZWQtdGV4dHtcbiAgICAgICAgY29sb3I6IHJlZDtcbiAgICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICAgIHBhZGRpbmctdG9wOiAxNyU7XG4gICAgICB9XG4gICAgICAjZGF5LXRleHQtc3Vue1xuICAgICAgICBmbG9hdDpsZWZ0O1xuICAgICAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgICAgIG1hcmdpbi1yaWdodDogLTMlO1xuICAgICAgICBtYXJnaW4tdG9wOjYlO1xuICAgICAgICByaWdodDogMCU7XG4gICAgICAgIGZvbnQtc2l6ZTogMTBweDtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgfVxuICAgICAgI2RheS10ZXh0LW1vbntcbiAgICAgICAgZmxvYXQ6bGVmdDtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IC0zJTtcbiAgICAgICAgbWFyZ2luLXRvcDo2JTtcbiAgICAgICAgcmlnaHQ6IDAlO1xuICAgICAgICBmb250LXNpemU6IDEwcHg7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgIH1cbiAgICAgICNkYXktdGV4dC10dWV7XG4gICAgICAgIGZsb2F0OmxlZnQ7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAtMyU7XG4gICAgICAgIG1hcmdpbi10b3A6NiU7XG4gICAgICAgIHJpZ2h0OiAtMC41JTtcbiAgICAgICAgZm9udC1zaXplOiAxMHB4O1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICB9XG4gICAgICAjZGF5LXRleHQtd2Vke1xuICAgICAgICBmbG9hdDpsZWZ0O1xuICAgICAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgICAgIG1hcmdpbi1yaWdodDogLTMlO1xuICAgICAgICBtYXJnaW4tdG9wOjYlO1xuICAgICAgICByaWdodDogLTMlO1xuICAgICAgICBmb250LXNpemU6IDEwcHg7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgIH1cbiAgICAgICNkYXktdGV4dC10aHV7XG4gICAgICAgIGZsb2F0OmxlZnQ7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAtMyU7XG4gICAgICAgIG1hcmdpbi10b3A6NiU7XG4gICAgICAgIGZvbnQtc2l6ZTogMTBweDtcbiAgICAgICAgcmlnaHQ6IC0xJTtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgfVxuICAgICAgI2RheS10ZXh0LWZyaXtcbiAgICAgICAgZmxvYXQ6bGVmdDtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IC0zJTtcbiAgICAgICAgbWFyZ2luLXRvcDo2JTtcbiAgICAgICAgZm9udC1zaXplOiAxMHB4O1xuICAgICAgICByaWdodDogMS43NSU7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgIH1cbiAgICAgICNkYXktdGV4dC1zYXR7XG4gICAgICAgIGZsb2F0OmxlZnQ7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAtMyU7XG4gICAgICAgIG1hcmdpbi10b3A6NiU7XG4gICAgICAgIHJpZ2h0OiAtMC41JTtcbiAgICAgICAgZm9udC1zaXplOiAxMHB4O1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICB9XG4gICAgICAjY2hhcnQtaGVpZ2h0e1xuICAgICAgICBoZWlnaHQ6IDkuMnJlbTtcbiAgICAgIH1cbiAgICAgICNjaGFydC1iYWNrZ3JvdW5kLWhlaWdodHtcbiAgICAgICAgaGVpZ2h0OiA5LjVyZW07XG4gICAgICB9XG4gICAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1sZWZ0e1xuICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgbWFyZ2luLWxlZnQ6MiVcbiAgICB9XG4gICAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1jZW50ZXJ7XG4gICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICBtYXJnaW4tbGVmdDotMSVcbiAgICB9XG4gICAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1yaWdodHtcbiAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgIG1hcmdpbi1sZWZ0Oi0yJVxuICAgIH19XG4gIH1cblxufVxufVxuXG5AbWVkaWEobWluLWhlaWdodDo2NjdweCkge1xuICAjZGF5LXRleHQtc3Vue1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogMCU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC1tb257XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAwJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LXR1ZXtcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IC0wLjUlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtd2Vke1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTMlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtdGh1e1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTElO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtZnJpe1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogMS43NSU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC1zYXR7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAtMC41JTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgLy8gI2NoYXJ0LWRpdmlzaW9ue1xuICAvLyAgIG1hcmdpbi10b3A6IDE7XG4gIC8vIH1cbiAgI2NoYXJ0LWhlaWdodHtcbiAgICBoZWlnaHQ6IDkuMnJlbTtcbiAgfVxuICAjY2hhcnQtYmFja2dyb3VuZC1oZWlnaHR7XG4gICAgaGVpZ2h0OiA5LjVyZW07XG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1sZWZ0e1xuICAgIGhlaWdodDogMTAwJTtcbiAgfVxuICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LWNlbnRlcntcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWFyZ2luLWxlZnQ6LTElXG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1yaWdodHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWFyZ2luLWxlZnQ6LTElXG4gIH1cbn1cbkBtZWRpYShtaW4td2lkdGg6NTQwcHgpIHtcblxuICAjY2hhcnQtZGl2aXNpb257XG4gICAgbWFyZ2luLXRvcDogLTMlO1xuICB9XG4gICNjaGFydC1kaXZpc2lvbi1oZWlnaHQtbGVmdHtcblxuICAgIG1hcmdpbi1sZWZ0OiAtMi41JTtcbiAgfVxuICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LWNlbnRlcntcblxuICAgIG1hcmdpbi1sZWZ0OjAlXG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1yaWdodHtcblxuICAgIG1hcmdpbi1sZWZ0OjAlXG4gIH1cbn1cbkBtZWRpYShtaW4taGVpZ2h0OjcyMHB4KSB7XG4gICNkYXktdGV4dC1zdW57XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAwJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LW1vbntcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IDAlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtdHVle1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTAuNSU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC13ZWR7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAtMyU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC10aHV7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAtMSU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC1mcml7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAxLjc1JTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LXNhdHtcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IC0wLjUlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjY2hhcnQtZGl2aXNpb257XG4gICAgbWFyZ2luLXRvcDogLTElO1xuICB9XG4gICNjaGFydC1oZWlnaHR7XG4gICAgaGVpZ2h0OiA5LjJyZW07XG4gIH1cbiAgI2NoYXJ0LWJhY2tncm91bmQtaGVpZ2h0e1xuICAgIGhlaWdodDogOS41cmVtO1xuICB9XG4gICNjaGFydC1kaXZpc2lvbi1oZWlnaHQtbGVmdHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgLy8gbWFyZ2luLWxlZnQ6IC0yLjUlO1xuICB9XG4gICNjaGFydC1kaXZpc2lvbi1oZWlnaHQtY2VudGVye1xuICAgIGhlaWdodDogMTAwJTtcbiAgICAvLyBtYXJnaW4tbGVmdDowJVxuICB9XG4gICNjaGFydC1kaXZpc2lvbi1oZWlnaHQtcmlnaHR7XG4gICAgaGVpZ2h0OjEwMCU7XG4gICAgbWFyZ2luLWxlZnQ6MCVcbiAgfVxufVxuQG1lZGlhKG1pbi1oZWlnaHQ6NzMxcHgpIHtcblxuICAjZGF5LXRleHQtc3Vue1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogMCU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC1tb257XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAwJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LXR1ZXtcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IC0wLjUlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtd2Vke1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTMlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtdGh1e1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTElO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtZnJpe1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogMS43NSU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC1zYXR7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAtMC41JTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9ue1xuICAgIG1hcmdpbi10b3A6IC0xJTtcbiAgfVxuICAjY2hhcnQtaGVpZ2h0e1xuICAgIGhlaWdodDogOS4ycmVtO1xuICB9XG4gICNjaGFydC1iYWNrZ3JvdW5kLWhlaWdodHtcbiAgICBoZWlnaHQ6IDkuNXJlbTtcbiAgfVxuICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LWxlZnR7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICB9XG4gICNjaGFydC1kaXZpc2lvbi1oZWlnaHQtY2VudGVye1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBtYXJnaW4tbGVmdDotMSVcbiAgfVxuICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LXJpZ2h0e1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBtYXJnaW4tbGVmdDotMSVcbiAgfVxufVxuQG1lZGlhKG1pbi1oZWlnaHQ6NzM2cHgpIHtcbiAgI2RheS10ZXh0LXN1bntcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IDAlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtbW9ue1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogMCU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC10dWV7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAtMC41JTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LXdlZHtcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IC0zJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LXRodXtcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IC0xJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LWZyaXtcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IDEuNzUlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtc2F0e1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTAuNSU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNjaGFydC1kaXZpc2lvbntcbiAgICBtYXJnaW4tdG9wOiAtMSU7XG4gIH1cbiAgI2NoYXJ0LWhlaWdodHtcbiAgICBoZWlnaHQ6IDkuMnJlbTtcbiAgfVxuICAjY2hhcnQtYmFja2dyb3VuZC1oZWlnaHR7XG4gICAgaGVpZ2h0OiA5LjVyZW07XG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1sZWZ0e1xuICAgIGhlaWdodDogMTAwJTtcbiAgfVxuICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LWNlbnRlcntcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWFyZ2luLWxlZnQ6LTElXG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1yaWdodHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWFyZ2luLWxlZnQ6LTElXG4gIH1cbn1cbkBtZWRpYShtaW4taGVpZ2h0OjgxMnB4KSB7XG4gICNkYXktdGV4dC1zdW57XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAwJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LW1vbntcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IDAlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtdHVle1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTAuNSU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC13ZWR7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAtMyU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC10aHV7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAtMSU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC1mcml7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAxLjc1JTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LXNhdHtcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IC0wLjUlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjY2hhcnQtZGl2aXNpb257XG4gICAgbWFyZ2luLXRvcDogLTElO1xuICB9XG4gICNjaGFydC1oZWlnaHR7XG4gICAgaGVpZ2h0OiA5LjJyZW07XG4gIH1cbiAgI2NoYXJ0LWJhY2tncm91bmQtaGVpZ2h0e1xuICAgIGhlaWdodDogOS41cmVtO1xuICB9XG4gICNjaGFydC1kaXZpc2lvbi1oZWlnaHQtbGVmdHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1jZW50ZXJ7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG1hcmdpbi1sZWZ0Oi0xJVxuICB9XG4gICNjaGFydC1kaXZpc2lvbi1oZWlnaHQtcmlnaHR7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG1hcmdpbi1sZWZ0Oi0xJVxuICB9XG59XG5AbWVkaWEobWluLWhlaWdodDo4MjNweCkge1xuICAjZGF5LXRleHQtc3Vue1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogMCU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC1tb257XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAwJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LXR1ZXtcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IC0wLjUlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtd2Vke1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTMlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtdGh1e1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTElO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtZnJpe1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogMS43NSU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC1zYXR7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAtMC41JTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2NoYXJ0LWhlaWdodHtcbiAgICBoZWlnaHQ6IDkuMnJlbTtcbiAgfVxuICAjY2hhcnQtYmFja2dyb3VuZC1oZWlnaHR7XG4gICAgaGVpZ2h0OiA5LjVyZW07XG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9ue1xuICAgIG1hcmdpbi10b3A6IC0xJTtcbiAgfVxuICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LWxlZnR7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICB9XG4gICNjaGFydC1kaXZpc2lvbi1oZWlnaHQtY2VudGVye1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBtYXJnaW4tbGVmdDotMSVcbiAgfVxuICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LXJpZ2h0e1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBtYXJnaW4tbGVmdDotMSVcbiAgfVxufVxuQG1lZGlhKG1pbi1oZWlnaHQ6ODQ0cHgpIHtcbi8vICBAbWVkaWEobWluLXdpZHRoOjM5MHB4KSB7XG4gICNkYXktdGV4dC1zdW57XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAwJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LW1vbntcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IDAlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtdHVle1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTAuNSU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC13ZWR7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAtMyU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC10aHV7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAtMSU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC1mcml7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAxLjc1JSAhaW1wb3J0YW50O1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtc2F0e1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTAuNSUgIWltcG9ydGFudDtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cblxuICAjY2hhcnQtaGVpZ2h0e1xuICAgIGhlaWdodDogOS4ycmVtO1xuICB9XG4gICNjaGFydC1iYWNrZ3JvdW5kLWhlaWdodHtcbiAgICBoZWlnaHQ6IDkuNXJlbTtcbiAgfVxuICAjY2hhcnQtZGl2aXNpb257XG4gICAgbWFyZ2luLXRvcDogMCU7XG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1sZWZ0e1xuICAgIGhlaWdodDogMTAwJTtcbiAgfVxuICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LWNlbnRlcntcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWFyZ2luLWxlZnQ6LTElXG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1yaWdodHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWFyZ2luLWxlZnQ6LTElXG4gIH1cbi8vIH1cbn1cbkBtZWRpYShtaW4taGVpZ2h0OjkxNHB4KSB7XG4gIC8vICBAbWVkaWEobWluLXdpZHRoOjM5MHB4KSB7XG4gICAgI2RheS10ZXh0LXN1bntcbiAgICAgIGZsb2F0OmxlZnQ7XG4gICAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgICAgbWFyZ2luLXRvcDo4JTtcbiAgICAgIHJpZ2h0OiAwJTtcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB9XG4gICAgI2RheS10ZXh0LW1vbntcbiAgICAgIGZsb2F0OmxlZnQ7XG4gICAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgICAgbWFyZ2luLXRvcDo4JTtcbiAgICAgIHJpZ2h0OiAwJTtcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB9XG4gICAgI2RheS10ZXh0LXR1ZXtcbiAgICAgIGZsb2F0OmxlZnQ7XG4gICAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgICAgbWFyZ2luLXRvcDo4JTtcbiAgICAgIHJpZ2h0OiAtMC41JTtcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB9XG4gICAgI2RheS10ZXh0LXdlZHtcbiAgICAgIGZsb2F0OmxlZnQ7XG4gICAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgICAgbWFyZ2luLXRvcDo4JTtcbiAgICAgIHJpZ2h0OiAtMyU7XG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgfVxuICAgICNkYXktdGV4dC10aHV7XG4gICAgICBmbG9hdDpsZWZ0O1xuICAgICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICAgIG1hcmdpbi10b3A6OCU7XG4gICAgICByaWdodDogLTElO1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIH1cbiAgICAjZGF5LXRleHQtZnJpe1xuICAgICAgZmxvYXQ6bGVmdDtcbiAgICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgICBtYXJnaW4tdG9wOjglO1xuICAgICAgcmlnaHQ6IDEuNzUlO1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIH1cbiAgICAjZGF5LXRleHQtc2F0e1xuICAgICAgZmxvYXQ6bGVmdDtcbiAgICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgICBtYXJnaW4tdG9wOjglO1xuICAgICAgcmlnaHQ6IC0wLjUlO1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIH1cblxuICAgICNjaGFydC1kaXZpc2lvbntcbiAgICAgIG1hcmdpbi10b3A6IDElO1xuICAgIH1cbiAgICAjY2hhcnQtaGVpZ2h0e1xuICAgICAgaGVpZ2h0OiA5LjJyZW07XG4gICAgfVxuICAgICNjaGFydC1iYWNrZ3JvdW5kLWhlaWdodHtcbiAgICAgIGhlaWdodDogOS41cmVtO1xuICAgIH1cbiAgICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LWNlbnRlcntcbiAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgIG1hcmdpbi1sZWZ0Oi0xJVxuICAgIH1cbiAgICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LXJpZ2h0e1xuICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgbWFyZ2luLWxlZnQ6LTElXG4gICAgfVxuICAvLyB9XG4gIH1cbkBtZWRpYShtaW4td2lkdGg6NzY4cHgpIHtcblxuICAjY2hhcnQtZGl2aXNpb257XG4gICAgbWFyZ2luLXRvcDogLTMlO1xuICB9XG4gICNjaGFydC1kaXZpc2lvbi1oZWlnaHQtbGVmdHtcblxuICAgIG1hcmdpbi1sZWZ0OiAtNCU7XG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1jZW50ZXJ7XG5cbiAgICBtYXJnaW4tbGVmdDowLjUlXG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1yaWdodHtcblxuICAgIG1hcmdpbi1sZWZ0OjUlXG4gIH1cbn1cbi8vIEBtZWRpYShtaW4td2lkdGg6MzkwcHgpe1xuLy8gQG1lZGlhKG1pbi1oZWlnaHQ6ODQ0cHgpIHtcbi8vICAgI2NoYXJ0LWRpdmlzaW9ue1xuLy8gICAgIG1hcmdpbi10b3A6IC00LjUlO1xuLy8gICB9XG4vLyAgICNjaGFydC1kaXZpc2lvbi1oZWlnaHQtbGVmdHtcbi8vICAgICBoZWlnaHQ6IDE0M3B4O1xuLy8gICB9XG4vLyAgICNjaGFydC1kaXZpc2lvbi1oZWlnaHQtY2VudGVye1xuLy8gICAgIGhlaWdodDogMTQzcHg7XG4vLyAgICAgbWFyZ2luLWxlZnQ6LTElXG4vLyAgIH1cbi8vICAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1yaWdodHtcbi8vICAgICBoZWlnaHQ6IDE0M3B4O1xuLy8gICAgIG1hcmdpbi1sZWZ0Oi0xJVxuLy8gICB9XG4vLyB9XG4vLyB9XG5AbWVkaWEobWluLWhlaWdodDoxMDI0cHgpIHtcbiAgI2RheS10ZXh0LXN1bntcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IDAlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtbW9ue1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogMCU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC10dWV7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAtMC41JTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LXdlZHtcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IC0zJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LXRodXtcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IC0xJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LWZyaXtcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IDEuNzUlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtc2F0e1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTAuNSU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNjaGFydC1kaXZpc2lvbntcbiAgICBtYXJnaW4tdG9wOiAtMSU7XG4gIH1cbiAgI2NoYXJ0LWhlaWdodHtcbiAgICBoZWlnaHQ6IDkuMnJlbTtcbiAgfVxuICAjY2hhcnQtYmFja2dyb3VuZC1oZWlnaHR7XG4gICAgaGVpZ2h0OiA5LjVyZW07XG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1sZWZ0e1xuICAgIGhlaWdodDogMTAwJTtcbiAgICAvLyBtYXJnaW4tbGVmdDogLTIuNSU7XG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1jZW50ZXJ7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIC8vIG1hcmdpbi1sZWZ0OjAlXG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1yaWdodHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWFyZ2luLWxlZnQ6MSVcbiAgfVxufVxuQG1lZGlhKG1pbi13aWR0aDo4MDBweCkge1xuICAjY2hhcnQtZGl2aXNpb257XG4gICAgbWFyZ2luLXRvcDogLTMlO1xuICB9XG4gICNjaGFydC1kaXZpc2lvbi1oZWlnaHQtbGVmdHtcblxuICAgIG1hcmdpbi1sZWZ0OiAtNCU7XG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1jZW50ZXJ7XG5cbiAgICBtYXJnaW4tbGVmdDowLjUlXG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1yaWdodHtcblxuICAgIG1hcmdpbi1sZWZ0OjUlXG4gIH1cbn1cbkBtZWRpYShtaW4taGVpZ2h0OjEyODBweCkge1xuICAjZGF5LXRleHQtc3Vue1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogMCU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC1tb257XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAwJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LXR1ZXtcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IC0wLjUlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtd2Vke1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTMlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtdGh1e1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTElO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtZnJpe1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogMS43NSU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC1zYXR7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAtMC41JTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9ue1xuICAgIG1hcmdpbi10b3A6IC0xJTtcbiAgfVxuICAjY2hhcnQtaGVpZ2h0e1xuICAgIGhlaWdodDogOS4ycmVtO1xuICB9XG4gICNjaGFydC1iYWNrZ3JvdW5kLWhlaWdodHtcbiAgICBoZWlnaHQ6IDkuNXJlbTtcbiAgfVxuICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LWxlZnR7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIC8vIG1hcmdpbi1sZWZ0OiAtMi41JTtcbiAgfVxuICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LWNlbnRlcntcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgLy8gbWFyZ2luLWxlZnQ6MCVcbiAgfVxuICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LXJpZ2h0e1xuICAgIGhlaWdodDogMjAuNXJlbTtcbiAgICBtYXJnaW4tbGVmdDowLjYlXG4gIH1cbn1cbkBtZWRpYShtaW4td2lkdGg6MTAyNHB4KSB7XG4gICNjaGFydC1kaXZpc2lvbntcbiAgICBtYXJnaW4tdG9wOiAtMyU7XG4gIH1cbiAgI2NoYXJ0LWRpdmlzaW9uLWhlaWdodC1sZWZ0e1xuXG4gICAgbWFyZ2luLWxlZnQ6IC00JTtcbiAgfVxuICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LWNlbnRlcntcblxuICAgIG1hcmdpbi1sZWZ0OjAuNSVcbiAgfVxuICAjY2hhcnQtZGl2aXNpb24taGVpZ2h0LXJpZ2h0e1xuXG4gICAgbWFyZ2luLWxlZnQ6NSVcbiAgfVxufVxuQG1lZGlhKG1pbi1oZWlnaHQ6MTM2NnB4KSB7XG4gICNkYXktdGV4dC1zdW57XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAwJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LW1vbntcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IDAlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjZGF5LXRleHQtdHVle1xuICAgIGZsb2F0OmxlZnQ7XG4gICAgbWFyZ2luLWxlZnQ6IDAlO1xuICAgIG1hcmdpbi1yaWdodDogMCU7XG4gICAgbWFyZ2luLXRvcDo4JTtcbiAgICByaWdodDogLTAuNSU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC13ZWR7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAtMyU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC10aHV7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAtMSU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICB9XG4gICNkYXktdGV4dC1mcml7XG4gICAgZmxvYXQ6bGVmdDtcbiAgICBtYXJnaW4tbGVmdDogMCU7XG4gICAgbWFyZ2luLXJpZ2h0OiAwJTtcbiAgICBtYXJnaW4tdG9wOjglO1xuICAgIHJpZ2h0OiAxLjc1JTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIH1cbiAgI2RheS10ZXh0LXNhdHtcbiAgICBmbG9hdDpsZWZ0O1xuICAgIG1hcmdpbi1sZWZ0OiAwJTtcbiAgICBtYXJnaW4tcmlnaHQ6IDAlO1xuICAgIG1hcmdpbi10b3A6OCU7XG4gICAgcmlnaHQ6IC0wLjUlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgfVxuICAjY2hhcnQtZGl2aXNpb257XG4gICAgbWFyZ2luLXRvcDogLTElO1xuICB9XG4gICNjaGFydC1oZWlnaHR7XG4gICAgaGVpZ2h0OiA5LjJyZW07XG4gIH1cbiAgI2NoYXJ0LWJhY2tncm91bmQtaGVpZ2h0e1xuICAgIGhlaWdodDogOS41cmVtO1xuICB9XG4gICNjaGFydC1kaXZpc2lvbi1oZWlnaHQtbGVmdHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgLy8gbWFyZ2luLWxlZnQ6IC0yLjUlO1xuICB9XG4gICNjaGFydC1kaXZpc2lvbi1oZWlnaHQtY2VudGVye1xuICAgIGhlaWdodDogMTAwJTtcbiAgICAvLyBtYXJnaW4tbGVmdDowJVxuICB9XG4gICNjaGFydC1kaXZpc2lvbi1oZWlnaHQtcmlnaHR7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG1hcmdpbi1sZWZ0OjAlXG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "l/Nb":
/*!************************************************************************************************************************!*\
  !*** ./src/app/dashboard/generated_schedule/required-vs-generated-workforce/required-vs-generated-workforce.module.ts ***!
  \************************************************************************************************************************/
/*! exports provided: RequiredVsGeneratedWorkforcePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequiredVsGeneratedWorkforcePageModule", function() { return RequiredVsGeneratedWorkforcePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _required_vs_generated_workforce_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./required-vs-generated-workforce-routing.module */ "Fszm");
/* harmony import */ var ng2_charts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ng2-charts */ "LPYB");
/* harmony import */ var _required_vs_generated_workforce_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./required-vs-generated-workforce.page */ "+ooK");
/* harmony import */ var _angular_material_divider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/divider */ "f0Cb");









let RequiredVsGeneratedWorkforcePageModule = class RequiredVsGeneratedWorkforcePageModule {
};
RequiredVsGeneratedWorkforcePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            ng2_charts__WEBPACK_IMPORTED_MODULE_6__["ChartsModule"],
            _angular_material_divider__WEBPACK_IMPORTED_MODULE_8__["MatDividerModule"],
            _required_vs_generated_workforce_routing_module__WEBPACK_IMPORTED_MODULE_5__["RequiredVsGeneratedWorkforcePageRoutingModule"]
        ],
        declarations: [_required_vs_generated_workforce_page__WEBPACK_IMPORTED_MODULE_7__["RequiredVsGeneratedWorkforcePage"]]
    })
], RequiredVsGeneratedWorkforcePageModule);



/***/ }),

/***/ "vUzG":
/*!**************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/dashboard/generated_schedule/required-vs-generated-workforce/required-vs-generated-workforce.page.html ***!
  \**************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"header\" style=\"height: 5%;\">\n\n\n\n  <ion-row style=\"margin-top: 3%;\">\n    <div style=\"float: left;padding-left:4%\">\n      <ion-img class=\"go-back\" alt=\"Go Back\" src=\"assets/img/go-back.png\" (click)=\"goBack()\"></ion-img>\n    </div>\n    <div class=\"ion-text-center ion-justify-content-center\" style=\"width:90%;\">\n      <p class=\"ion-header-title app-font-style app-font-primary-color\" style=\"text-align: center;\">\n        Required Vs Generated Workforce\n      </p>\n    </div>\n\n</ion-row>\n</ion-header>\n<ion-content>\n        <ion-grid>\n          <ion-row style=\"padding:0%;margin-bottom: -2%;\">\n            <ion-col size=\"1\"></ion-col>\n            <ion-col size=\"3.3\" style=\"padding-top: 2%;\">\n              <ion-img  alt=\"Night\" style=\"height: 20%;width: 20%;\" src=\"assets/img/night.png\" style=\"float: left;\"></ion-img><small class=\"ion-no-padding ion-no-margin\" style=\"font-size: 12px;\">MID</small>\n            </ion-col >\n            <ion-col size=\"3.3\" style=\"padding-top: 2%;\">\n              <ion-img alt=\"Day\" style=\"height: 30%;width: 30%;\" src=\"assets/img/morning.png\" style=\"float: left;\"></ion-img><small class=\"ion-no-padding ion-no-margin\" style=\"font-size: 12px;\">DAY</small>\n            </ion-col>\n            <ion-col size=\"3.3\" style=\"padding-top: 2%;\">\n              <ion-img alt=\"Evening\" style=\"height: 100%;width: 100%;\" src=\"assets/img/evening.png\" style=\"float: left;\"></ion-img><small class=\"ion-no-padding ion-no-margin\" style=\"font-size: 12px;\">EVE</small>\n            </ion-col>\n            <ion-col size=\"1\"></ion-col>\n          </ion-row>\n        </ion-grid>\n\n\n\n        <!-- <ion-grid id=\"chart-division\">\n          <ion-row class=\"ion-no-padding ion-no-margin\">\n            <ion-col size=\"1\">\n              <canvas baseChart\n              height=\"160\"\n              width=\"50\"\n              [datasets]=\"barChartDataIndex\"\n              [labels]=\"barChartLabels\"\n              [options]=\"barChartOptions\"\n              [legend]=\"barChartLegend\"\n              [chartType]=\"barChartType\"style=\"height:100%;width:100%;padding-bottom: 0%;bottom: 0%;border: 1px solid black;\">\n            </canvas>\n            </ion-col>\n            <ion-col size=\"3\">\n              <canvas baseChart\n              height=\"160\"\n              width=\"100\"\n              [datasets]=\"barChartDataTest1\"\n              [labels]=\"barChartLabels\"\n              [options]=\"barChartOptions\"\n              [legend]=\"barChartLegend\"\n              [chartType]=\"barChartType\" id=\"chart-background-color\" style=\"width:100%;padding-bottom: 0%;bottom: 0%;border: 1px solid black;\">\n            </canvas>\n            </ion-col>\n            <ion-col size=\"3\">\n              <canvas baseChart\n              height=\"160\"\n              width=\"100\"\n              [datasets]=\"barChartDataTest1\"\n              [labels]=\"barChartLabels\"\n              [options]=\"barChartOptions\"\n              [legend]=\"barChartLegend\"\n              [chartType]=\"barChartType\" id=\"chart-background-color\" style=\"width:100%;padding-bottom: 0%;bottom: 0%;border: 1px solid black;\">\n            </canvas>\n            </ion-col>\n            <ion-col size=\"3\">\n              <canvas baseChart\n              height=\"160\"\n              width=\"100\"\n              [datasets]=\"barChartDataTest1\"\n              [labels]=\"barChartLabels\"\n              [options]=\"barChartOptions\"\n              [legend]=\"barChartLegend\"\n              [chartType]=\"barChartType\" id=\"chart-background-color\" style=\"width:100%;padding-bottom: 0%;bottom: 0%;border: 1px solid black;\">\n            </canvas>\n            </ion-col>\n          </ion-row>\n\n        </ion-grid> -->\n        <!-- <ion-grid id=\"chart-division\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n\n          <ion-row id=\"on-chart-card\" style=\"padding-top: 1%;\">\n            <ion-col size=\"1.2\"></ion-col>\n            <ion-col  size=\"3.1\">\n              <div >\n              <div id=\"on-chart-text\">\n              <p *ngIf=\"diffSunMid >0;else elseSunMid\" id=\"green-text\" >{{diffSunMid}}</p>\n              <ng-template #elseSunMid>\n                <p id=\"red-text\" *ngIf=\"diffSunMid <0\">{{diffSunMid}}</p>\n              </ng-template>\n              </div>\n              </div>\n            </ion-col>\n            <ion-col size=\"3.1\">\n              <div >\n              <div id=\"on-chart-text\">\n              <p *ngIf=\"diffSunDay>0;else elseSunDay\" id=\"green-text\">{{diffSunDay}}</p>\n              <ng-template #elseSunDay>\n                <p  id=\"red-text\" *ngIf=\"diffSunDay <0\">{{diffSunDay}}</p>\n              </ng-template>\n            </div>\n            </div></ion-col>\n\n            <ion-col  size=\"3.1\">\n              <div >\n              <div id=\"on-chart-text\">\n              <p *ngIf=\"diffSunEve>0;else elseSunEve\" id=\"green-text\">{{diffSunMid}}</p>\n              <ng-template #elseSunEve>\n                <p  id=\"red-text\" *ngIf=\"diffSunEve <0\">{{diffSunEve}}</p>\n              </ng-template>\n            </div>\n            </div></ion-col>\n            <ion-col size=\"1\"></ion-col>\n          </ion-row>\n\n          <ion-row   class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n            <ion-col  class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n              <ion-grid class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\"  style=\"padding: 0%;margin: 1%;width:84%;float: left;\">\n                <div class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n                <canvas id=\"testing\"  baseChart\n            [datasets]=\"barChartData\"\n            [labels]=\"barChartLabels\"\n            [options]=\"barChartOptions\"\n            [legend]=\"barChartLegend\"\n            [chartType]=\"barChartType\" style=\"padding-bottom: 0%;bottom: 0%;background: linear-gradient(to right,  white 0%,white 11.9%, rgb(175, 173, 173,0.4) 12%, rgb(175, 173, 173,0.4) 38.5%, white 38.6%, white 40.9%, rgb(175, 173, 173,0.4) 41%, rgb(175, 173, 173,0.4) 68.5%, white 68.6%,white 70%, rgb(175, 173, 173,0.4) 71%, rgb(175, 173, 173,0.4) 97.5%, white 97.6%, white 100%);\">\n          </canvas></div></ion-grid>\n          <div  style=\"float: right;padding: 0%;margin: 0%;width:14%;height:100%;padding-top: 8%;padding-right: 0%;padding-left: 0%;\">\n            <p class=\"text-rotate-270-degree\" id=\"day-text-sun\" >\n          <b>Sunday </b><b style=\"color: #246CA5;\"> {{totalSunGenerated}}</b>/<b style=\"color: #0194E3;\">{{totalSunRequired}}</b>\n            </p>\n          </div>\n            </ion-col >\n          </ion-row>\n\n\n        </ion-grid>\n\n -->\n\n\n\n    <ion-grid id=\"chart-division\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n        <ion-row  id=\"on-chart-card\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n          <ion-col  class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n            <ion-grid class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\"  style=\"padding: 0%;margin: 1%;width:84%;float: left;\">\n              <div class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\" id=\"chart-height\" id=\"chart-height\">\n              <canvas baseChart\n          [datasets]=\"barChartData\"\n          [labels]=\"barChartLabels\"\n          [options]=\"barChartOptions\"\n          [legend]=\"barChartLegend\"\n          [chartType]=\"barChartType\" style=\"padding-bottom: 0%;bottom: 0%;height: 100vh;position: absolute;\" >\n        </canvas></div></ion-grid>\n        <div  style=\"float: right;padding: 0%;margin: 0%;width:14%;height:100%;padding-top: 8%;padding-right: 0%;padding-left: 0%;\">\n          <p class=\"text-rotate-270-degree\" id=\"day-text-sun\" >\n        <b>Sunday </b><b style=\"color: #246CA5;\"> {{totalSunGenerated}}</b>/<b style=\"color: #0194E3;\">{{totalSunRequired}}</b>\n          </p>\n        </div>\n          </ion-col >\n        </ion-row>\n\n        <ion-row id=\"chart-background-height\" >\n          <ion-col size=\"1.2\"></ion-col>\n          <ion-col id=\"chart-division-height-left\" size=\"3.1\">\n            <div id=\"chart-background-color\" >\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffSunMid >0;else elseSunMid\" id=\"green-text\" >{{diffSunMid}}</p>\n            <ng-template #elseSunMid>\n              <p id=\"red-text\" *ngIf=\"diffSunMid <0\">{{diffSunMid}}</p>\n            </ng-template>\n            </div>\n            </div>\n          </ion-col>\n          <ion-col id=\"chart-division-height-center\" size=\"3.1\">\n            <div id=\"chart-background-color\">\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffSunDay>0;else elseSunDay\" id=\"green-text\">{{diffSunDay}}</p>\n            <ng-template #elseSunDay>\n              <p  id=\"red-text\" *ngIf=\"diffSunDay <0\">{{diffSunDay}}</p>\n            </ng-template>\n          </div>\n          </div></ion-col>\n\n          <ion-col id=\"chart-division-height-right\" size=\"3.1\">\n            <div id=\"chart-background-color\">\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffSunEve>0;else elseSunEve\" id=\"green-text\">{{diffSunMid}}</p>\n            <ng-template #elseSunEve>\n              <p  id=\"red-text\" *ngIf=\"diffSunEve <0\">{{diffSunEve}}</p>\n            </ng-template>\n          </div>\n          </div></ion-col>\n          <ion-col size=\"1\"></ion-col>\n        </ion-row>\n\n\n      </ion-grid>\n      <ion-grid id=\"chart-division\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n        <ion-row  id=\"on-chart-card\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\" >\n          <ion-col class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\" >\n            <ion-grid style=\"padding: 0%;margin: 1%;width:84%;float: left;\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n              <div class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\" id=\"chart-height\">\n              <canvas baseChart\n          [datasets]=\"barChartDataMon\"\n          [labels]=\"barChartLabels\"\n          [options]=\"barChartOptions\"\n          [legend]=\"barChartLegend\"\n          [chartType]=\"barChartType\" style=\"padding-bottom: 0%;bottom: 0%;height: 100vh;position: absolute;\">\n        </canvas></div></ion-grid>\n        <div  style=\"float: right;padding: 0%;margin: 0%;width:14%;height:100%;padding-top: 8%;padding-right: 0%;padding-left: 0%;\">\n          <p class=\"text-rotate-270-degree\" id=\"day-text-mon\">\n        <b>Monday </b><b style=\"color: #246CA5;\"> {{totalMonGenerated}}</b>/<b style=\"color: #0194E3;\">{{totalMonRequired}}</b>\n          </p>\n        </div>\n          </ion-col >\n        </ion-row>\n\n        <ion-row  id=\"chart-background-height\">\n          <ion-col size=\"1.2\"></ion-col>\n          <ion-col id=\"chart-division-height-left\" size=\"3.1\">\n            <div id=\"chart-background-color\" >\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffMonMid >0;else elseMonMid\" id=\"green-text\" >{{diffMonMid}}</p>\n            <ng-template #elseMonMid>\n              <p id=\"red-text\" *ngIf=\"diffMonMid <0\">{{diffMonMid}}</p>\n            </ng-template>\n            </div>\n            </div>\n          </ion-col>\n          <ion-col  id=\"chart-division-height-center\" size=\"3.1\">\n            <div id=\"chart-background-color\">\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffMonDay>0;else elseMonDay\" id=\"green-text\">{{diffMonDay}}</p>\n            <ng-template #elseMonDay>\n              <p  id=\"red-text\" *ngIf=\"diffMonDay <0\">{{diffMonDay}}</p>\n            </ng-template>\n          </div>\n          </div></ion-col>\n\n          <ion-col id=\"chart-division-height-right\" size=\"3.1\">\n            <div id=\"chart-background-color\">\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffMonEve>0;else elseMonEve\" id=\"green-text\">{{diffMonMid}}</p>\n            <ng-template #elseMonEve>\n              <p  id=\"red-text\" *ngIf=\"diffMonEve <0\">{{diffMonEve}}</p>\n            </ng-template>\n          </div>\n          </div></ion-col>\n          <ion-col size=\"1\"></ion-col>\n        </ion-row>\n\n\n      </ion-grid>\n\n      <ion-grid id=\"chart-division\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n        <ion-row  id=\"on-chart-card\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n          <ion-col  class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n            <ion-grid style=\"padding: 0%;margin: 1%;width:84%;float: left;\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n              <div class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\" id=\"chart-height\">\n              <canvas baseChart\n          [datasets]=\"barChartDataTue\"\n          [labels]=\"barChartLabels\"\n          [options]=\"barChartOptions\"\n          [legend]=\"barChartLegend\"\n          [chartType]=\"barChartType\" style=\"padding-bottom: 0%;bottom: 0%;height: 100vh;position: absolute;\">\n        </canvas></div></ion-grid>\n        <div  style=\"float: right;padding: 0%;margin: 0%;width:14%;height:100%;padding-top: 8%;padding-right: 0%;padding-left: 0%;\">\n          <p class=\"text-rotate-270-degree\" id=\"day-text-tue\" >\n        <b>Tuesday </b><b style=\"color: #246CA5;\"> {{totalTueGenerated}}</b>/<b style=\"color: #0194E3;\">{{totalTueRequired}}</b>\n          </p>\n        </div>\n          </ion-col >\n        </ion-row>\n\n        <ion-row  id=\"chart-background-height\">\n          <ion-col size=\"1.2\"></ion-col>\n          <ion-col id=\"chart-division-height-left\" size=\"3.1\">\n            <div id=\"chart-background-color\" >\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffTueMid >0;else elseTueMid\" id=\"green-text\" >{{diffTueMid}}</p>\n            <ng-template #elseTueMid>\n              <p id=\"red-text\" *ngIf=\"diffTueMid <0\">{{diffTueMid}}</p>\n            </ng-template>\n            </div>\n            </div>\n          </ion-col>\n          <ion-col  id=\"chart-division-height-center\" size=\"3.1\">\n            <div id=\"chart-background-color\">\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffTueDay>0;else elseTueDay\" id=\"green-text\">{{diffTueDay}}</p>\n            <ng-template #elseTueDay>\n              <p  id=\"red-text\" *ngIf=\"diffTueDay <0\">{{diffTueDay}}</p>\n            </ng-template>\n          </div>\n          </div></ion-col>\n\n          <ion-col id=\"chart-division-height-right\" size=\"3.1\">\n            <div id=\"chart-background-color\">\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffTueEve>0;else elseTueEve\" id=\"green-text\">{{diffTueMid}}</p>\n            <ng-template #elseTueEve>\n              <p  id=\"red-text\" *ngIf=\"diffTueEve <0\">{{diffTueEve}}</p>\n            </ng-template>\n          </div>\n          </div></ion-col>\n          <ion-col size=\"1\"></ion-col>\n        </ion-row>\n\n\n      </ion-grid>\n\n      <ion-grid id=\"chart-division\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n        <ion-row  id=\"on-chart-card\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n          <ion-col  class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n            <ion-grid style=\"padding: 0%;margin: 1%;width:84%;float: left;\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n              <div class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\" id=\"chart-height\">\n              <canvas baseChart\n          [datasets]=\"barChartDataWed\"\n          [labels]=\"barChartLabels\"\n          [options]=\"barChartOptions\"\n          [legend]=\"barChartLegend\"\n          [chartType]=\"barChartType\" style=\"padding-bottom: 0%;bottom: 0%;height: 100vh;position: absolute;\">\n        </canvas></div></ion-grid>\n        <div  style=\"float: right;padding: 0%;margin: 0%;width:14%;height:100%;padding-top: 8%;padding-right: 0%;padding-left: 0%;\">\n          <p class=\"text-rotate-270-degree\" id=\"day-text-wed\" >\n        <b>Wednesday </b>  <b style=\"color: #246CA5;\"> {{totalWedGenerated}}</b>/<b style=\"color: #0194E3;\">{{totalWedRequired}}</b>\n          </p>\n\n        </div>\n          </ion-col >\n        </ion-row>\n\n        <ion-row  id=\"chart-background-height\">\n          <ion-col size=\"1.2\"></ion-col>\n          <ion-col id=\"chart-division-height-left\" size=\"3.1\">\n            <div id=\"chart-background-color\" >\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffWedMid >0;else elseWedMid\" id=\"green-text\" >{{diffWedMid}}</p>\n            <ng-template #elseWedMid>\n              <p id=\"red-text\" *ngIf=\"diffWedMid <0\">{{diffWedMid}}</p>\n            </ng-template>\n            </div>\n            </div>\n          </ion-col>\n          <ion-col  id=\"chart-division-height-center\" size=\"3.1\">\n            <div id=\"chart-background-color\">\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffWedDay>0;else elseWedDay\" id=\"green-text\">{{diffWedDay}}</p>\n            <ng-template #elseWedDay>\n              <p  id=\"red-text\" *ngIf=\"diffWedDay <0\">{{diffWedDay}}</p>\n            </ng-template>\n          </div>\n          </div></ion-col>\n\n          <ion-col id=\"chart-division-height-right\" size=\"3.1\">\n            <div id=\"chart-background-color\">\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffWedEve>0;else elseWedEve\" id=\"green-text\">{{diffWedMid}}</p>\n            <ng-template #elseWedEve>\n              <p  id=\"red-text\" *ngIf=\"diffWedEve <0\">{{diffWedEve}}</p>\n            </ng-template>\n          </div>\n          </div></ion-col>\n          <ion-col size=\"1\"></ion-col>\n        </ion-row>\n\n\n      </ion-grid>\n\n\n\n\n\n      <ion-grid id=\"chart-division\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n        <ion-row  id=\"on-chart-card\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n          <ion-col  class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n            <ion-grid style=\"padding: 0%;margin: 1%;width:84%;float: left;\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n              <div class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\" id=\"chart-height\">\n              <canvas baseChart\n          [datasets]=\"barChartDataThu\"\n          [labels]=\"barChartLabels\"\n          [options]=\"barChartOptions\"\n          [legend]=\"barChartLegend\"\n          [chartType]=\"barChartType\" style=\"padding-bottom: 0%;bottom: 0%;height: 100vh;position: absolute;\">\n        </canvas></div></ion-grid>\n        <div  style=\"float: right;padding: 0%;margin: 0%;width:14%;height:100%;padding-top: 8%;padding-right: 0%;padding-left: 0%;\">\n          <p class=\"text-rotate-270-degree\" id=\"day-text-thu\" >\n        <b>Thursday </b><b style=\"color: #246CA5;\"> {{totalThuGenerated}}</b>/<b style=\"color: #0194E3;\">{{totalThuRequired}}</b>\n          </p>\n\n        </div>\n          </ion-col >\n        </ion-row>\n\n        <ion-row  id=\"chart-background-height\">\n          <ion-col size=\"1.2\"></ion-col>\n          <ion-col id=\"chart-division-height-left\" size=\"3.1\">\n            <div id=\"chart-background-color\" >\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffThuMid >0;else elseThuMid\" id=\"green-text\" >{{diffThuMid}}</p>\n            <ng-template #elseThuMid>\n              <p id=\"red-text\" *ngIf=\"diffThuMid <0\">{{diffThuMid}}</p>\n            </ng-template>\n            </div>\n            </div>\n          </ion-col>\n          <ion-col  id=\"chart-division-height-center\" size=\"3.1\">\n            <div id=\"chart-background-color\">\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffThuDay>0;else elseThuDay\" id=\"green-text\">{{diffThuDay}}</p>\n            <ng-template #elseThuDay>\n              <p  id=\"red-text\" *ngIf=\"diffThuDay <0\">{{diffThuDay}}</p>\n            </ng-template>\n          </div>\n          </div></ion-col>\n\n          <ion-col id=\"chart-division-height-right\" size=\"3.1\">\n            <div id=\"chart-background-color\">\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffThuEve>0;else elseThuEve\" id=\"green-text\">{{diffThuMid}}</p>\n            <ng-template #elseThuEve>\n              <p  id=\"red-text\" *ngIf=\"diffThuEve <0\">{{diffThuEve}}</p>\n            </ng-template>\n          </div>\n          </div></ion-col>\n          <ion-col size=\"1\"></ion-col>\n        </ion-row>\n\n\n      </ion-grid>\n\n      <ion-grid id=\"chart-division\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n        <ion-row  id=\"on-chart-card\"  class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n          <ion-col  class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n            <ion-grid style=\"padding: 0%;margin: 1%;width:84%;float: left;bottom: 0%   ;\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n              <div class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\" id=\"chart-height\">\n              <canvas baseChart\n          [datasets]=\"barChartDataFri\"\n          [labels]=\"barChartLabels\"\n          [options]=\"barChartOptions\"\n          [legend]=\"barChartLegend\"\n          [chartType]=\"barChartType\" style=\"padding-bottom: 0%;bottom: 0%;height: 100vh;position: absolute;\">\n        </canvas></div></ion-grid>\n        <div  style=\"float: right;padding: 0%;margin: 0%;width:14%;height:100%;padding-top: 8%;padding-right: 0%;padding-left: 0%;\">\n          <p class=\"text-rotate-270-degree\" id=\"day-text-fri\" >\n        <b>Friday </b><b style=\"color: #246CA5;\"> {{totalFriGenerated}}</b>/<b style=\"color: #0194E3;\">{{totalFriRequired}}</b>\n          </p>\n        </div>\n          </ion-col >\n        </ion-row>\n\n        <ion-row  id=\"chart-background-height\">\n          <ion-col size=\"1.2\"></ion-col>\n          <ion-col id=\"chart-division-height-left\" size=\"3.1\">\n            <div id=\"chart-background-color\" >\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffFriMid >0;else elseFriMid\" id=\"green-text\" >{{diffFriMid}}</p>\n            <ng-template #elseFriMid>\n              <p id=\"red-text\" *ngIf=\"diffFriMid <0\">{{diffFriMid}}</p>\n            </ng-template>\n            </div>\n            </div>\n          </ion-col>\n          <ion-col  id=\"chart-division-height-center\" size=\"3.1\">\n            <div id=\"chart-background-color\">\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffFriDay>0;else elseFriDay\" id=\"green-text\">{{diffFriDay}}</p>\n            <ng-template #elseFriDay>\n              <p  id=\"red-text\" *ngIf=\"diffFriDay <0\">{{diffFriDay}}</p>\n            </ng-template>\n          </div>\n          </div></ion-col>\n\n          <ion-col id=\"chart-division-height-right\" size=\"3.1\">\n            <div id=\"chart-background-color\">\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffFriEve>0;else elseFriEve\" id=\"green-text\">{{diffFriMid}}</p>\n            <ng-template #elseFriEve>\n              <p  id=\"red-text\" *ngIf=\"diffFriEve <0\">{{diffFriEve}}</p>\n            </ng-template>\n          </div>\n          </div></ion-col>\n          <ion-col size=\"1\">\n\n          </ion-col>\n        </ion-row>\n\n\n      </ion-grid>\n\n      <ion-grid id=\"chart-division\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n        <ion-row  id=\"on-chart-card\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n          <ion-col  class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n            <ion-grid style=\"padding: 0%;margin: 1%;width:84%;float: left;\" class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\">\n              <div class=\"ion-no-padding-top ion-no-padding-bottom ion-no-margin-top ion-no-margin-bottom\" id=\"chart-height\">\n              <canvas baseChart\n          [datasets]=\"barChartDataSat\"\n          [labels]=\"barChartLabels\"\n          [options]=\"barChartOptions\"\n          [legend]=\"barChartLegend\"\n          [chartType]=\"barChartType\" style=\"padding-bottom: 0%;bottom: 0%;height: 100vh;position: absolute;\">\n        </canvas></div></ion-grid>\n        <div  style=\"float: right;padding: 0%;margin: 0%;width:14%;height:100%;padding-top: 8%;padding-right: 0%;padding-left: 0%;\">\n          <p class=\"text-rotate-270-degree\" id=\"day-text-sat\">\n        <b>Saturday </b><b style=\"color: #246CA5;\"> {{totalSatGenerated}}</b>/<b style=\"color: #0194E3;\">{{totalFriRequired}}</b>\n          </p>\n        </div>\n          </ion-col >\n        </ion-row>\n\n        <ion-row  id=\"chart-background-height\" >\n          <ion-col size=\"1.2\"></ion-col>\n          <ion-col id=\"chart-division-height-left\" size=\"3.1\">\n            <div id=\"chart-background-color\" >\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffSatMid >0;else elseSatMid\" id=\"green-text\" >{{diffSatMid}}</p>\n            <ng-template #elseSatMid>\n              <p id=\"red-text\" *ngIf=\"diffSatMid <0\">{{diffSatMid}}</p>\n            </ng-template>\n            </div>\n            </div>\n          </ion-col>\n          <ion-col id=\"chart-division-height-center\" size=\"3.1\">\n            <div id=\"chart-background-color\">\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffSatDay>0;else elseSatDay\" id=\"green-text\">{{diffSatDay}}</p>\n            <ng-template #elseSatDay>\n              <p  id=\"red-text\" *ngIf=\"diffSatDay <0\">{{diffSatDay}}</p>\n            </ng-template>\n          </div>\n          </div></ion-col>\n\n          <ion-col id=\"chart-division-height-right\" size=\"3.1\">\n            <div id=\"chart-background-color\">\n            <div id=\"on-chart-text\">\n            <p *ngIf=\"diffSatEve>0;else elseSatEve\" id=\"green-text\">{{diffSatMid}}</p>\n            <ng-template #elseSatEve>\n              <p  id=\"red-text\" *ngIf=\"diffSatEve <0\">{{diffSatEve}}</p>\n            </ng-template>\n          </div>\n          </div></ion-col>\n          <ion-col size=\"1\"></ion-col>\n        </ion-row>\n\n\n      </ion-grid>\n</ion-content>\n\n\n\n\n<ion-footer>\n  <ion-row class=\"ion-text-center ion-justify-content-center ion-no-margin ion-no-padding\" style=\"margin: 0%;padding:0%;margin-bottom:1%;margin-top:2%\" >\n    <mat-divider class=\"ion-no-margin ion-no-padding\" style=\"width: 96%;\"></mat-divider>\n  </ion-row>\n<ion-row style=\"padding: 0%;\">\n  <ion-col size=\"1\"></ion-col>\n<ion-col style=\"padding: 0%;\" size=\"5\"><div style=\"margin-right:2%;height: 14px;width: 12px;background-color: #246CA5;float: left;\"></div>  <p class=\"content-data-black-color\"  style=\"margin: 0%;\"> Required Workforce</p></ion-col>\n\n<ion-col style=\"padding: 0%;\" size=\"5\"><div style=\"margin-right:2%;height: 14px;width: 12px;background-color:red;float: left;\"></div><p class=\"content-data-black-color\"  style=\"margin: 0%;float: left;\">Less Than Required </p></ion-col>\n<ion-col size=\"1\"></ion-col>\n<ion-col size=\"1\"></ion-col>\n<ion-col style=\"padding: 0%;\" size=\"5\"><div style=\"margin-right:2%;height: 14px;width: 12px;background-color: #0194E3;float: left;\"></div><p class=\"content-data-black-color\"  style=\"margin: 0%;\">Generated Workforce</p></ion-col>\n<ion-col style=\"padding: 0%;\" size=\"5\"><div style=\"margin-right:2%;height: 14px;width: 12px;background-color: green;float: left;\"></div><p class=\"content-data-black-color\" style=\"margin: 0%;\">Greater Than Required</p></ion-col>\n<ion-col size=\"1\"></ion-col>\n</ion-row>\n</ion-footer>\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<!--\n<ion-grid>\n  <ion-row>\n<ion-col>\n<canvas baseChart\n[datasets]=\"barChartData\"\n[labels]=\"barChartLabels\"\n[options]=\"barChartOptions\"\n\n[legend]=\"barChartLegend\"\n[chartType]=\"barChartType\" style=\"height: 100%;width:100%;\">\n\n</canvas>\n</ion-col>\n<ion-col>\n<canvas baseChart\n[datasets]=\"barChartData\"\n[labels]=\"barChartLabels\"\n[options]=\"barChartOptions\"\n\n[legend]=\"barChartLegend\"\n[chartType]=\"barChartType\" style=\"height: 100%;width:100%;\">\n\n</canvas>\n</ion-col>\n<ion-col>\n<canvas baseChart\n[datasets]=\"barChartData\"\n[labels]=\"barChartLabels\"\n[options]=\"barChartOptions\"\n\n[legend]=\"barChartLegend\"\n[chartType]=\"barChartType\" style=\"height: 100%;width:100%;\">\n\n</canvas>\n</ion-col>\n  </ion-row>\n\n</ion-grid> -->\n");

/***/ })

}]);
//# sourceMappingURL=src-app-dashboard-generated_schedule-required-vs-generated-workforce-required-vs-generated-workforce-module.js.map