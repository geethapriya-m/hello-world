(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-register-reset-password-reset-password-module"],{

/***/ "+xUH":
/*!*************************************************************************************!*\
  !*** ./src/app/home/login-register/reset-password/reset-password-routing.module.ts ***!
  \*************************************************************************************/
/*! exports provided: ResetPasswordPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResetPasswordPageRoutingModule", function() { return ResetPasswordPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _reset_password_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./reset-password.page */ "d0ti");




const routes = [
    {
        path: '',
        component: _reset_password_page__WEBPACK_IMPORTED_MODULE_3__["ResetPasswordPage"]
    }
];
let ResetPasswordPageRoutingModule = class ResetPasswordPageRoutingModule {
};
ResetPasswordPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ResetPasswordPageRoutingModule);



/***/ }),

/***/ "2aAE":
/*!*******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/login-register/reset-password/reset-password.page.html ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content style=\"background-color: #F7F0D0;\">\n  <ion-grid id=\"top\">\n    <ion-row style=\"text-align: right;z-index: 1;\" class=\"ion-justify-content-center\">\n      <!-- <div style=\"z-index: 1;position: absolute;\">\n\n        <ion-img style=\"height: 125px;width: 125px;margin-left: 25%;margin-top: 15%; \"  src=\"\"></ion-img>\n      </div> -->\n\n      <ion-col size=\"3\" style=\"text-align: right;z-index: 1;\">\n        <ion-img style=\"height: 125px;width: 125px;z-index: 1;margin-top:25% ;margin-left: 25%;\"  src=\"assets/img/reset-password.png\"></ion-img>\n      </ion-col>\n      <ion-col size=\"9\"></ion-col>\n  </ion-row>\n\n      <div class=\"custom-shape-divider-top-1626281823\">\n        <svg data-name=\"Layer 1\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1200 120\" preserveAspectRatio=\"none\">\n            <path d=\"M985.66,92.83C906.67,72,823.78,31,743.84,14.19c-82.26-17.34-168.06-16.33-250.45.39-57.84,11.73-114,31.07-172,41.86A600.21,600.21,0,0,1,0,27.35V120H1200V95.8C1132.19,118.92,1055.71,111.31,985.66,92.83Z\" class=\"shape-fill\"></path>\n        </svg>\n    </div>\n\n</ion-grid>\n<ion-grid id=\"center\"  class=\"content-data app-font-primary-color ion-text-center ion-justify-content-center\">\n\n        <form  [formGroup]=\"forgotPassword\" >\n          <!-- Username -->\n\n          <ion-grid class=\"ion-justify-content-center ion-text-center\" >\n            <ion-row lines=\"none\" class=\"app-font-primary-color ion-text-center ion-justify-content-center\" style=\"font-size: 20px;\">\n              <ion-label style=\"font-size: 20px;\">\n                It’s Okay ! Reset your Password.\n              </ion-label>\n            </ion-row>\n          <!-- Password -->\n          <ion-item id=\"register-input-ion-item\" lines=\"none\" class=\"app-font-primary-color \" >\n            <ion-label position=\"stacked\">Password</ion-label>\n            <!-- <ion-label>Password</ion-label> -->\n\n            <!-- <ion-icon item-end class=\"hide-option\"  name=\"eye-off-outline\"> -->\n            <ion-input type=\"text\" [class]=\"passWordClass(classId) \" style=\"border: 2px solid #0194e3;border-radius: 5px;margin-top: 5px;position: relative;z-index: -1;\" formControlName=\"password\" name=\"password\"\n            [class.is-invalid]=\"password?.invalid && password?.touched\"\n            required>\n\n          </ion-input>\n\n          <!-- <span style=\"position:absolute; right:8px;top:8px;\" class=\"fa fa-user \"></span> -->\n\n          <ion-icon *ngIf=\"hidePassword\" class=\"app-font-primary-color\" style=\"position:absolute; right:6%;font-size: 20px;bottom: 10px;z-index: 1;\" (click)=\"passWord()\"  name=\"eye-off-outline\"></ion-icon>\n          <ion-icon *ngIf=\"!hidePassword\" class=\"app-font-primary-color\" style=\"position:absolute; right:6%;font-size: 20px;bottom: 10px;z-index: 1;\" (click)=\"passWord()\" name=\"eye-outline\"></ion-icon>\n          <!-- <ion-label><ion-icon class=\"passwordIcon\" style=\"z-index: -1;position: absolute;\"  name=\"eye-off-outline\"></ion-icon></ion-label> -->\n          <!-- </ion-icon> -->\n\n\n      </ion-item>\n      <div class=\"content-data app-font-red-color\" style=\"text-align: left;margin-left:8%;\" *ngIf=\"password?.touched && password?.errors\">\n        <p class=\"app-font-red-color\" *ngIf=\"password?.errors?.required \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Password is required!</p>\n        <p class=\"app-font-red-color\" *ngIf=\"password?.errors?.minlength \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Password must be at 2 characters!</p>\n        <p class=\"app-font-red-color\" *ngIf=\"password?.errors?.maxlength \"><ion-icon name=\"alert-circle-outline\"></ion-icon> Password must be at 64 characters!</p>\n      </div>\n          <!-- Confirm-Password -->\n          <ion-item id=\"register-input-ion-item\" lines=\"none\" class=\"app-font-primary-color \" >\n            <ion-label position=\"stacked\">Confirm Password</ion-label>\n            <ion-input type=\"text\" [class]=\"confirmPassWordClass(confirmClassId) \" style=\"border: 2px solid #0194e3;border-radius: 5px;margin-top: 5px;position: relative;z-index: -1;\"   name=\"confirm-password\" formControlName=\"confirm_password\"\n            required></ion-input>\n            <ion-icon *ngIf=\"hideConfirmPassword\" class=\"app-font-primary-color\" style=\"position:absolute; right:6%;font-size: 20px;bottom: 10px;z-index: 1;\" (click)=\"confirm_Password()\"  name=\"eye-off-outline\"></ion-icon>\n            <ion-icon *ngIf=\"!hideConfirmPassword\" class=\"app-font-primary-color\" style=\"position:absolute; right:6%;font-size: 20px;bottom: 10px;z-index: 1;\" (click)=\"confirm_Password()\" name=\"eye-outline\"></ion-icon>\n\n        </ion-item>\n\n        <div class=\"content-data app-font-red-color\" style=\"text-align: left;margin-left:8%;\" *ngIf=\"confirm_password.touched && confirm_password.invalid\" >\n          <p class=\"app-font-red-color\" *ngIf=\"confirm_password.errors.required\"><ion-icon name=\"alert-circle-outline\"></ion-icon> Confirm Password is required.</p>\n          <p class=\"app-font-red-color\" *ngIf=\"confirm_password.errors.confirmedValidator\"><ion-icon name=\"alert-circle-outline\"></ion-icon> Password and Confirm Password must be match.</p>\n      </div>\n        </ion-grid>\n\n\n\n  <ion-row  class=\"ion-justify-content-center\"  id=\"button\">\n    <ion-button shape=\"round\"  class=\"app-button-primary \" id=\"get-start\"  *ngIf=\"forgotPassword?.invalid===false \" (click)=\"resetPass(forgotPassword)\" >Done</ion-button>\n  <ion-button shape=\"round\"  class=\"app-button-danger \" [disabled]=\"true\" id=\"get-start\"  *ngIf=\"forgotPassword?.invalid || emailValid==true  \" (click)=\"resetPass(forgotPassword)\" >Done</ion-button>\n  </ion-row>\n\n\n        </form>\n      </ion-grid>\n      </ion-content>\n      <!-- <div class=\"custom-shape-divider-top-1626199019\">\n        <svg id=\"wave\"  viewBox=\"0 0 1440 490\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\"><defs><linearGradient id=\"sw-gradient-0\" x1=\"0\" x2=\"0\" y1=\"1\" y2=\"0\"><stop stop-color=\"rgba(243, 106, 62, 1)\" offset=\"0%\"></stop><stop stop-color=\"rgba(255, 179, 11, 1)\" offset=\"100%\"></stop></linearGradient></defs>\n          <path style=\" opacity:1\" fill=\"#0194E3\" d=\"M0,196L80,163.3C160,131,320,65,480,106.2C640,147,800,294,960,302.2C1120,310,1280,180,1440,122.5C1600,65,1760,82,1920,98C2080,114,2240,131,2400,155.2C2560,180,2720,212,2880,187.8C3040,163,3200,82,3360,49C3520,16,3680,33,3840,57.2C4000,82,4160,114,4320,106.2C4480,98,4640,49,4800,65.3C4960,82,5120,163,5280,196C5440,229,5600,212,5760,228.7C5920,245,6080,294,6240,269.5C6400,245,6560,147,6720,122.5C6880,98,7040,147,7200,163.3C7360,180,7520,163,7680,147C7840,131,8000,114,8160,98C8320,82,8480,65,8640,106.2C8800,147,8960,245,9120,285.8C9280,327,9440,310,9600,253.2C9760,196,9920,98,10080,73.5C10240,49,10400,98,10560,171.5C10720,245,10880,343,11040,351.2C11200,359,11360,278,11440,236.8L11520,196L11520,490L11440,490C11360,490,11200,490,11040,490C10880,490,10720,490,10560,490C10400,490,10240,490,10080,490C9920,490,9760,490,9600,490C9440,490,9280,490,9120,490C8960,490,8800,490,8640,490C8480,490,8320,490,8160,490C8000,490,7840,490,7680,490C7520,490,7360,490,7200,490C7040,490,6880,490,6720,490C6560,490,6400,490,6240,490C6080,490,5920,490,5760,490C5600,490,5440,490,5280,490C5120,490,4960,490,4800,490C4640,490,4480,490,4320,490C4160,490,4000,490,3840,490C3680,490,3520,490,3360,490C3200,490,3040,490,2880,490C2720,490,2560,490,2400,490C2240,490,2080,490,1920,490C1760,490,1600,490,1440,490C1280,490,1120,490,960,490C800,490,640,490,480,490C320,490,160,490,80,490L0,490Z\"></path></svg>\n      </div> -->\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");

/***/ }),

/***/ "EBmS":
/*!*****************************************************************************!*\
  !*** ./src/app/home/login-register/reset-password/reset-password.module.ts ***!
  \*****************************************************************************/
/*! exports provided: ResetPasswordPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResetPasswordPageModule", function() { return ResetPasswordPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _reset_password_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./reset-password-routing.module */ "+xUH");
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/input */ "e6WT");
/* harmony import */ var _reset_password_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./reset-password.page */ "d0ti");








let ResetPasswordPageModule = class ResetPasswordPageModule {
};
ResetPasswordPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_material_input__WEBPACK_IMPORTED_MODULE_6__["MatInputModule"],
            _reset_password_routing_module__WEBPACK_IMPORTED_MODULE_5__["ResetPasswordPageRoutingModule"]
        ],
        declarations: [_reset_password_page__WEBPACK_IMPORTED_MODULE_7__["ResetPasswordPage"]]
    })
], ResetPasswordPageModule);



/***/ }),

/***/ "d0ti":
/*!***************************************************************************!*\
  !*** ./src/app/home/login-register/reset-password/reset-password.page.ts ***!
  \***************************************************************************/
/*! exports provided: ResetPasswordPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResetPasswordPage", function() { return ResetPasswordPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_reset_password_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./reset-password.page.html */ "2aAE");
/* harmony import */ var _reset_password_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./reset-password.page.scss */ "iBan");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_services_forgot_password_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/forgot-password.service */ "j8Zn");
/* harmony import */ var src_app_json_apis_json__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/json/apis.json */ "B+pZ");
var src_app_json_apis_json__WEBPACK_IMPORTED_MODULE_8___namespace = /*#__PURE__*/__webpack_require__.t(/*! src/app/json/apis.json */ "B+pZ", 1);
/* harmony import */ var src_app_services_login_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/login.service */ "EFyh");










let ResetPasswordPage = class ResetPasswordPage {
    // userDetails: import("v:/Mercurius/straightline-io/src/app/model/checkUserDetails").CheckUserDetails[];
    constructor(navCtrl, fb, actRoute, loginSer, forgot_pass) {
        this.navCtrl = navCtrl;
        this.fb = fb;
        this.actRoute = actRoute;
        this.loginSer = loginSer;
        this.forgot_pass = forgot_pass;
        this.hidePassword = true;
        this.hideConfirmPassword = true;
        this.classId = 0;
        this.confirmClassId = 0;
    }
    ngOnInit() {
        this.actRoute.paramMap.subscribe((params) => {
            this.email_id_for_reset_password = (params.get('_email'));
            // this.email_id_for_reset_password="vrushang.patel@mercuriusinc.com"
            this.token_for_reset_password = (params.get('_code'));
            // console.log(this.email_id_for_reset_password);
            // console.log(this.token_for_reset_password);
        });
        this.getUserData(this.email_id_for_reset_password);
        // console.log(this.userDetails)
        this.forgotPassword = this.fb.group({
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.email_id_for_reset_password, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].minLength(2), _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].maxLength(64)])),
            confirm_password: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](),
        }, {
            validator: this.ConfirmedValidator('password', 'confirm_password')
        });
        this.forgot_pass.emailVerify(this.email_id_for_reset_password).subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log(response)
        }), (error) => {
            console.log(error);
            this.errorMsg = error.error.text;
            this.url_token = this.errorMsg;
            // console.log(this.url_token)
            // console.log(String(this.url_token).substr(0,45))
            if (String(this.url_token) == "Invalid email id.") {
                this.emailValid = true;
                // console.log(this.url_token)
            }
            // if(String(this.url_token).substr(0,47)=="http://18.119.62.157:2020/reset-password?token="){
            if (String(this.url_token).substr(0, 45) == "http://52.14.8.217:2020/reset-password?token=") {
                // if(String(this.url_token).substr(0,45)=="http://3.13.254.87:2020/reset-password?token="){
                this.emailValid = false;
                // console.log(this.emailValid)
                // console.log(this.url_token)
            }
        }, () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
        }));
    }
    getUserData(email) {
        var getUserData = { "username": email };
        this.loginSer.getUserAllDetails(getUserData).subscribe((respons) => {
            // console.log(respons)
            // this.userDetails=
            if (respons) {
                this.forgot_pass.verifyEmailForFP(this.token_for_reset_password).subscribe((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    // console.log(res)
                    this.email_is_verfied = res;
                    if (this.email_is_verfied == false) {
                        this.navCtrl.navigateBack([src_app_json_apis_json__WEBPACK_IMPORTED_MODULE_8__.apis.login_api]);
                    }
                }), (error) => {
                    this.errorMsg = error;
                }, () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                }));
            }
        }, (error) => {
            this.errorMsg = error;
            console.log(this.errorMsg);
        }, () => {
        });
    }
    ConfirmedValidator(controlName, matchingControlName) {
        return (formGroup) => {
            const control = formGroup.controls[controlName];
            const matchingControl = formGroup.controls[matchingControlName];
            if (matchingControl.errors && !matchingControl.errors.confirmedValidator) {
                return;
            }
            if (control.value !== matchingControl.value) {
                matchingControl.setErrors({ confirmedValidator: true });
            }
            else {
                matchingControl.setErrors(null);
            }
        };
    }
    get email() {
        return this.forgotPassword.get('email');
    }
    get password() {
        return this.forgotPassword.get('password');
    }
    get confirm_password() {
        return this.forgotPassword.get('confirm_password');
    }
    focusOut() {
        // console.log(this.forgotPassword.value)
        // console.log(this.forgotPassword.value.email)
        var email = this.forgotPassword.value.email;
        this.forgot_pass.emailVerify(email).subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log(response)
        }), (error) => {
            this.errorMsg = error.error.text;
            this.url_token = this.errorMsg;
            // console.log(this.url_token)
            console.log(String(this.url_token).substr(0, 45));
            if (String(this.url_token) == "Invalid email id.") {
                this.emailValid = true;
                // console.log(this.url_token)
            }
            if (String(this.url_token).substr(0, 45) == "http://52.14.8.217:2020/reset-password?token=") {
                this.emailValid = false;
                // console.log(this.emailValid)
                // console.log(this.url_token)
            }
        }, () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
        }));
    }
    changeEmailID() {
        if (this.emailValid == true) {
            return this.emailValid = false;
        }
    }
    passwordChanged(pass) {
        // this.navCtrl.navigateForward('password-changed-message')
    }
    resetPass(pass) {
        // console.log(this.forgotPassword.value.password)
        this.forgot_pass.updatePass(this.url_token, this.forgotPassword.value.password).subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log(response)
        }), (error) => {
            this.errorMsg = error;
            // console.log(this.errorMsg)
        }, () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
        }));
        this.navCtrl.navigateForward('password-changed-message');
    }
    confirm_Password() {
        if (this.hideConfirmPassword == true) {
            this.hideConfirmPassword = false, this.confirmClassId = 1;
        }
        else {
            this.hideConfirmPassword = true, this.confirmClassId = 0;
        }
        return this.hideConfirmPassword, this.confirmClassId;
    }
    passWord() {
        if (this.hidePassword == true) {
            return this.hidePassword = false, this.classId = 1;
        }
        else {
            return this.hidePassword = true, this.classId = 0;
        }
    }
    passWordClass(cId) {
        if (0 == cId) {
            return 'password  form-control app-font-primary-color ion-no-margin ion-no-padding';
        }
        else if (0 != cId) {
            return 'form-control app-font-primary-color ion-no-margin ion-no-padding';
        }
    }
    confirmPassWordClass(cId) {
        if (0 == cId) {
            return 'password  form-control app-font-primary-color ion-no-margin ion-no-padding';
        }
        else if (0 != cId) {
            return 'form-control app-font-primary-color ion-no-margin ion-no-padding';
        }
    }
};
ResetPasswordPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: src_app_services_login_service__WEBPACK_IMPORTED_MODULE_9__["LoginService"] },
    { type: src_app_services_forgot_password_service__WEBPACK_IMPORTED_MODULE_7__["ForgotPasswordService"] }
];
ResetPasswordPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-reset-password',
        template: _raw_loader_reset_password_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_reset_password_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ResetPasswordPage);



/***/ }),

/***/ "iBan":
/*!*****************************************************************************!*\
  !*** ./src/app/home/login-register/reset-password/reset-password.page.scss ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".custom-shape-divider-top-1626281823 {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  overflow: hidden;\n  line-height: 0;\n  transform: rotate(180deg);\n}\n\n.custom-shape-divider-top-1626281823 svg {\n  position: relative;\n  display: block;\n  width: calc(145% + 1.3px);\n  height: 200px;\n}\n\n.custom-shape-divider-top-1626281823 .shape-fill {\n  fill: #0194E3;\n}\n\n#center {\n  margin-top: 20%;\n}\n\n/** For mobile devices **/\n\n@media (max-device-height: 568px) {\n  .custom-shape-divider-top-1626281823 svg {\n    width: calc(146% + 1.3px);\n    height: 95px;\n  }\n\n  #top {\n    margin: 0;\n    padding: 0%;\n    width: 100%;\n    height: 20%;\n  }\n\n  #center {\n    margin: 0;\n    padding: 0%;\n    width: 100%;\n    height: 80%;\n    overflow-x: scroll;\n    overflow: hidden;\n    position: fixed;\n  }\n\n  #Sign-Up-title {\n    margin-top: -5%;\n    font-size: 16px;\n    text-align: right;\n  }\n\n  #sign-in {\n    margin-top: 0%;\n    margin-bottom: 5%;\n  }\n\n  #button {\n    margin-top: 0%;\n  }\n\n  #check-box-terms-and-conditions {\n    margin-top: 0%;\n  }\n}\n\n@media (max-device-height: 700px) {\n  .custom-shape-divider-top-1626281823 svg {\n    width: calc(146% + 1.3px);\n    height: 105px;\n  }\n\n  #top {\n    margin: 0;\n    padding: 0%;\n    width: 100%;\n    height: 20%;\n  }\n\n  #center {\n    margin: 0;\n    padding: 0%;\n    width: 100%;\n    height: 80%;\n    overflow: hidden;\n    overflow-x: scroll;\n    position: fixed;\n  }\n\n  #sign-in {\n    margin-top: 0%;\n    margin-bottom: 5%;\n  }\n\n  #button {\n    margin-top: 0%;\n  }\n\n  #check-box-terms-and-conditions {\n    margin-top: 0%;\n  }\n}\n\n#Sign-Up-title {\n  padding: 6%;\n  font-size: 38px;\n  text-align: right;\n}\n\n#sign-in {\n  margin-top: 5%;\n}\n\n#button {\n  margin-top: 5%;\n}\n\n#check-box-terms-and-conditions {\n  margin-top: 5%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxccmVzZXQtcGFzc3dvcmQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSx5QkFBQTtBQUNGOztBQUVBO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0VBQ0EseUJBQUE7RUFDQSxhQUFBO0FBQ0Y7O0FBRUE7RUFDRSxhQUFBO0FBQ0Y7O0FBQ0E7RUFDQSxlQUFBO0FBRUE7O0FBQUEseUJBQUE7O0FBUUE7RUFDRTtJQUNFLHlCQUFBO0lBQ0EsWUFBQTtFQUpGOztFQU9FO0lBQ0UsU0FBQTtJQUFTLFdBQUE7SUFBYSxXQUFBO0lBQVksV0FBQTtFQUR0Qzs7RUFHRTtJQUNFLFNBQUE7SUFBUyxXQUFBO0lBQWEsV0FBQTtJQUN0QixXQUFBO0lBQ0Esa0JBQUE7SUFDQSxnQkFBQTtJQUNBLGVBQUE7RUFFSjs7RUFBRTtJQUNFLGVBQUE7SUFDQSxlQUFBO0lBQWdCLGlCQUFBO0VBSXBCOztFQUZFO0lBQ0UsY0FBQTtJQUNBLGlCQUFBO0VBS0o7O0VBSEU7SUFDRSxjQUFBO0VBTUo7O0VBSkU7SUFDRSxjQUFBO0VBT0o7QUFDRjs7QUFMQTtFQUNBO0lBQ0UseUJBQUE7SUFDQSxhQUFBO0VBT0E7O0VBSkE7SUFDRSxTQUFBO0lBQVMsV0FBQTtJQUFhLFdBQUE7SUFBWSxXQUFBO0VBVXBDOztFQVBBO0lBQ0UsU0FBQTtJQUFTLFdBQUE7SUFBYSxXQUFBO0lBQ3RCLFdBQUE7SUFDQSxnQkFBQTtJQUNBLGtCQUFBO0lBQ0EsZUFBQTtFQVlGOztFQVRBO0lBQ0UsY0FBQTtJQUNBLGlCQUFBO0VBWUY7O0VBVkE7SUFDRSxjQUFBO0VBYUY7O0VBWEE7SUFDRSxjQUFBO0VBY0Y7QUFDRjs7QUFaQTtFQUNBLFdBQUE7RUFBWSxlQUFBO0VBQ1osaUJBQUE7QUFlQTs7QUFiQTtFQUNBLGNBQUE7QUFnQkE7O0FBZEE7RUFDQSxjQUFBO0FBaUJBOztBQWZBO0VBQ0EsY0FBQTtBQWtCQSIsImZpbGUiOiJyZXNldC1wYXNzd29yZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY3VzdG9tLXNoYXBlLWRpdmlkZXItdG9wLTE2MjYyODE4MjMge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgbGVmdDogMDtcbiAgd2lkdGg6IDEwMCU7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIGxpbmUtaGVpZ2h0OiAwO1xuICB0cmFuc2Zvcm06IHJvdGF0ZSgxODBkZWcpO1xufVxuXG4uY3VzdG9tLXNoYXBlLWRpdmlkZXItdG9wLTE2MjYyODE4MjMgc3ZnIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBkaXNwbGF5OiBibG9jaztcbiAgd2lkdGg6IGNhbGMoMTQ1JSArIDEuM3B4KTtcbiAgaGVpZ2h0OiAyMDBweDtcbn1cblxuLmN1c3RvbS1zaGFwZS1kaXZpZGVyLXRvcC0xNjI2MjgxODIzIC5zaGFwZS1maWxsIHtcbiAgZmlsbDogIzAxOTRFMztcbn1cbiNjZW50ZXJ7XG5tYXJnaW4tdG9wOiAyMCU7XG59XG4vKiogRm9yIG1vYmlsZSBkZXZpY2VzICoqL1xuLy8gQG1lZGlhIChtYXgtd2lkdGg6IDM2NXB4KSB7XG4vLyAgIC5jdXN0b20tc2hhcGUtZGl2aWRlci10b3AtMTYyNjI4MTgyMyBzdmcge1xuLy8gICAgICAgd2lkdGg6IGNhbGMoMTQ1JSArIDEuM3B4KTtcbi8vICAgICAgIGhlaWdodDogMTgwcHg7XG4vLyAgIH1cbi8vIH1cblxuQG1lZGlhIChtYXgtZGV2aWNlLWhlaWdodDogNTY4cHgpIHtcbiAgLmN1c3RvbS1zaGFwZS1kaXZpZGVyLXRvcC0xNjI2MjgxODIzIHN2ZyB7XG4gICAgd2lkdGg6IGNhbGMoMTQ2JSArIDEuM3B4KTtcbiAgICBoZWlnaHQ6IDk1cHg7XG4gICAgfVxuXG4gICAgI3RvcHtcbiAgICAgIG1hcmdpbjowO3BhZGRpbmc6IDAlIDt3aWR0aDogMTAwJTtoZWlnaHQ6IDIwJTtcbiAgICB9XG4gICAgI2NlbnRlcntcbiAgICAgIG1hcmdpbjowO3BhZGRpbmc6IDAlIDt3aWR0aDogMTAwJTtcbiAgICAgIGhlaWdodDogODAlO1xuICAgICAgb3ZlcmZsb3cteDogc2Nyb2xsO1xuICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgIHBvc2l0aW9uOiBmaXhlZDtcbiAgICB9XG4gICAgI1NpZ24tVXAtdGl0bGUge1xuICAgICAgbWFyZ2luLXRvcDogLTUlO1xuICAgICAgZm9udC1zaXplOiAxNnB4O3RleHQtYWxpZ246IHJpZ2h0O1xuICAgIH1cbiAgICAjc2lnbi1pbntcbiAgICAgIG1hcmdpbi10b3A6IDAlO1xuICAgICAgbWFyZ2luLWJvdHRvbTogNSU7XG4gICAgfVxuICAgICNidXR0b257XG4gICAgICBtYXJnaW4tdG9wOiAwJTtcbiAgICB9XG4gICAgI2NoZWNrLWJveC10ZXJtcy1hbmQtY29uZGl0aW9uc3tcbiAgICAgIG1hcmdpbi10b3A6IDAlO1xuICAgIH1cbn1cbkBtZWRpYSAobWF4LWRldmljZS1oZWlnaHQ6IDcwMHB4KSB7XG4uY3VzdG9tLXNoYXBlLWRpdmlkZXItdG9wLTE2MjYyODE4MjMgc3ZnIHtcbiAgd2lkdGg6IGNhbGMoMTQ2JSArIDEuM3B4KTtcbiAgaGVpZ2h0OiAxMDVweDtcbiAgfVxuXG4gICN0b3B7XG4gICAgbWFyZ2luOjA7cGFkZGluZzogMCUgO3dpZHRoOiAxMDAlO2hlaWdodDogMjAlO1xuICAgIC8vIG92ZXJmbG93OiBoaWRkZW47XG4gIH1cbiAgI2NlbnRlcntcbiAgICBtYXJnaW46MDtwYWRkaW5nOiAwJSA7d2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiA4MCU7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICBvdmVyZmxvdy14OiBzY3JvbGw7XG4gICAgcG9zaXRpb246IGZpeGVkO1xuICB9XG5cbiAgI3NpZ24taW57XG4gICAgbWFyZ2luLXRvcDogMCU7XG4gICAgbWFyZ2luLWJvdHRvbTogNSU7XG4gIH1cbiAgI2J1dHRvbntcbiAgICBtYXJnaW4tdG9wOiAwJTtcbiAgfVxuICAjY2hlY2stYm94LXRlcm1zLWFuZC1jb25kaXRpb25ze1xuICAgIG1hcmdpbi10b3A6IDAlO1xuICB9XG59XG4jU2lnbi1VcC10aXRsZSB7XG5wYWRkaW5nOiA2JTtmb250LXNpemU6IDM4cHg7XG50ZXh0LWFsaWduOiByaWdodDtcbn1cbiNzaWduLWlue1xubWFyZ2luLXRvcDogNSU7XG59XG4jYnV0dG9ue1xubWFyZ2luLXRvcDogNSU7XG59XG4jY2hlY2stYm94LXRlcm1zLWFuZC1jb25kaXRpb25ze1xubWFyZ2luLXRvcDogNSU7XG59XG4iXX0= */");

/***/ })

}]);
//# sourceMappingURL=login-register-reset-password-reset-password-module.js.map