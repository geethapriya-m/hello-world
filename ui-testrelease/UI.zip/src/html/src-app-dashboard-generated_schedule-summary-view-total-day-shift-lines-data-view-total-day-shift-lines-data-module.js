(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["src-app-dashboard-generated_schedule-summary-view-total-day-shift-lines-data-view-total-day-shift-lines-data-module"],{

/***/ "svrt":
/*!********************************************************************************************************************************!*\
  !*** ./src/app/dashboard/generated_schedule/summary/view-total-day-shift-lines-data/view-total-day-shift-lines-data.module.ts ***!
  \********************************************************************************************************************************/
/*! exports provided: ViewTotalDayShiftLinesDataPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewTotalDayShiftLinesDataPageModule", function() { return ViewTotalDayShiftLinesDataPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _view_total_day_shift_lines_data_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./view-total-day-shift-lines-data-routing.module */ "vbiY");
/* harmony import */ var _view_total_day_shift_lines_data_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./view-total-day-shift-lines-data.page */ "BKeQ");
/* harmony import */ var _angular_material_divider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/divider */ "f0Cb");
/* harmony import */ var src_app_dashboard_nav_bar_footer_nav_bar_nav_bar_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/dashboard/nav-bar-footer/nav-bar/nav-bar.module */ "aiuM");









let ViewTotalDayShiftLinesDataPageModule = class ViewTotalDayShiftLinesDataPageModule {
};
ViewTotalDayShiftLinesDataPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_material_divider__WEBPACK_IMPORTED_MODULE_7__["MatDividerModule"],
            src_app_dashboard_nav_bar_footer_nav_bar_nav_bar_module__WEBPACK_IMPORTED_MODULE_8__["NavBarPageModule"],
            _view_total_day_shift_lines_data_routing_module__WEBPACK_IMPORTED_MODULE_5__["ViewTotalDayShiftLinesDataPageRoutingModule"]
        ],
        declarations: [_view_total_day_shift_lines_data_page__WEBPACK_IMPORTED_MODULE_6__["ViewTotalDayShiftLinesDataPage"]]
    })
], ViewTotalDayShiftLinesDataPageModule);



/***/ }),

/***/ "vbiY":
/*!****************************************************************************************************************************************!*\
  !*** ./src/app/dashboard/generated_schedule/summary/view-total-day-shift-lines-data/view-total-day-shift-lines-data-routing.module.ts ***!
  \****************************************************************************************************************************************/
/*! exports provided: ViewTotalDayShiftLinesDataPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewTotalDayShiftLinesDataPageRoutingModule", function() { return ViewTotalDayShiftLinesDataPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _view_total_day_shift_lines_data_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./view-total-day-shift-lines-data.page */ "BKeQ");




const routes = [
    {
        path: '',
        component: _view_total_day_shift_lines_data_page__WEBPACK_IMPORTED_MODULE_3__["ViewTotalDayShiftLinesDataPage"]
    }
];
let ViewTotalDayShiftLinesDataPageRoutingModule = class ViewTotalDayShiftLinesDataPageRoutingModule {
};
ViewTotalDayShiftLinesDataPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ViewTotalDayShiftLinesDataPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=src-app-dashboard-generated_schedule-summary-view-total-day-shift-lines-data-view-total-day-shift-lines-data-module.js.map