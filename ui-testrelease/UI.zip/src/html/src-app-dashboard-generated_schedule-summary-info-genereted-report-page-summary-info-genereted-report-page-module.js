(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["src-app-dashboard-generated_schedule-summary-info-genereted-report-page-summary-info-genereted-report-page-module"],{

/***/ "+20M":
/*!******************************************************************************************************************************!*\
  !*** ./src/app/dashboard/generated_schedule/summary-info-genereted-report-page/summary-info-genereted-report-page.page.scss ***!
  \******************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzdW1tYXJ5LWluZm8tZ2VuZXJldGVkLXJlcG9ydC1wYWdlLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "4ta9":
/*!******************************************************************************************************************************!*\
  !*** ./src/app/dashboard/generated_schedule/summary-info-genereted-report-page/summary-info-genereted-report-page.module.ts ***!
  \******************************************************************************************************************************/
/*! exports provided: SummaryInfoGeneretedReportPagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SummaryInfoGeneretedReportPagePageModule", function() { return SummaryInfoGeneretedReportPagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _summary_info_genereted_report_page_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./summary-info-genereted-report-page-routing.module */ "KrZT");
/* harmony import */ var _summary_info_genereted_report_page_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./summary-info-genereted-report-page.page */ "AlIt");







let SummaryInfoGeneretedReportPagePageModule = class SummaryInfoGeneretedReportPagePageModule {
};
SummaryInfoGeneretedReportPagePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _summary_info_genereted_report_page_routing_module__WEBPACK_IMPORTED_MODULE_5__["SummaryInfoGeneretedReportPagePageRoutingModule"]
        ],
        declarations: [_summary_info_genereted_report_page_page__WEBPACK_IMPORTED_MODULE_6__["SummaryInfoGeneretedReportPagePage"]]
    })
], SummaryInfoGeneretedReportPagePageModule);



/***/ }),

/***/ "AlIt":
/*!****************************************************************************************************************************!*\
  !*** ./src/app/dashboard/generated_schedule/summary-info-genereted-report-page/summary-info-genereted-report-page.page.ts ***!
  \****************************************************************************************************************************/
/*! exports provided: SummaryInfoGeneretedReportPagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SummaryInfoGeneretedReportPagePage", function() { return SummaryInfoGeneretedReportPagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_summary_info_genereted_report_page_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./summary-info-genereted-report-page.page.html */ "n6sA");
/* harmony import */ var _summary_info_genereted_report_page_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./summary-info-genereted-report-page.page.scss */ "+20M");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let SummaryInfoGeneretedReportPagePage = class SummaryInfoGeneretedReportPagePage {
    constructor() { }
    ngOnInit() {
    }
};
SummaryInfoGeneretedReportPagePage.ctorParameters = () => [];
SummaryInfoGeneretedReportPagePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-summary-info-genereted-report-page',
        template: _raw_loader_summary_info_genereted_report_page_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_summary_info_genereted_report_page_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SummaryInfoGeneretedReportPagePage);



/***/ }),

/***/ "KrZT":
/*!**************************************************************************************************************************************!*\
  !*** ./src/app/dashboard/generated_schedule/summary-info-genereted-report-page/summary-info-genereted-report-page-routing.module.ts ***!
  \**************************************************************************************************************************************/
/*! exports provided: SummaryInfoGeneretedReportPagePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SummaryInfoGeneretedReportPagePageRoutingModule", function() { return SummaryInfoGeneretedReportPagePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _summary_info_genereted_report_page_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./summary-info-genereted-report-page.page */ "AlIt");




const routes = [
    {
        path: '',
        component: _summary_info_genereted_report_page_page__WEBPACK_IMPORTED_MODULE_3__["SummaryInfoGeneretedReportPagePage"]
    }
];
let SummaryInfoGeneretedReportPagePageRoutingModule = class SummaryInfoGeneretedReportPagePageRoutingModule {
};
SummaryInfoGeneretedReportPagePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SummaryInfoGeneretedReportPagePageRoutingModule);



/***/ }),

/***/ "n6sA":
/*!********************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/dashboard/generated_schedule/summary-info-genereted-report-page/summary-info-genereted-report-page.page.html ***!
  \********************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- <ion-row     class=\"ion-justify-content-center  ion-no-margin ion-no-padding\" style=\"margin-bottom: 0%;padding-bottom: 0%;\">\n  <ion-col  class=\" ion-justify-content-center ion-no-margin-top  ion-no-padding\" size=\"2.5\"><div class=\"app-background-secondary-color\"style=\"margin-top:4%;height: 10px;width: 10px;border-radius:50%;float: left;margin-right: 1%;\"></div><p  class=\"app-font-black-color font-size-10\" style=\"margin-bottom: 0%;float: left;\">Required</p></ion-col>\n  <ion-col   class=\" ion-justify-content-center ion-no-margin-top ion-no-padding\" size=\"2.7\"><div class=\"app-background-primary-color\" style=\"height: 10px;margin-top:4%;width: 10px;float: left;border-radius:50%;margin-right: 1%;\"></div><p  class=\"app-font-black-color font-size-10\" style=\"margin-bottom: 0%;float: left;\">Generated</p></ion-col>\n  <ion-col   class=\" ion-justify-content-center ion-no-margin-top ion-no-padding\" size=\"2.8\"><div  style=\"height: 10px;margin-top:4%;width: 10px;float: left;border-radius:50%;margin-right: 1%;background-color: red;\"></div><p  class=\"app-font-black-color font-size-10\" style=\"margin-bottom: 0%;float: left;\">Less Than</p></ion-col>\n  <ion-col   class=\" ion-justify-content-center ion-no-margin-top ion-no-padding\" size=\"3.1\"><div  style=\"height: 10px;margin-top:4%;width: 10px;float: left;border-radius:50%;margin-right: 1%;background-color: green;\"></div><p  class=\"app-font-black-color font-size-10\" style=\"margin-bottom: 0%;float: left;\">Greater Than</p></ion-col>\n</ion-row> -->\n<ion-row>\n  <div class=\"app-background-secondary-color\"style=\"margin-top:4%;height: 10px;width: 10px;border-radius:50%;float: left;margin-right: 1%;\"></div><p  class=\"app-font-black-color font-size-10\" style=\"margin-bottom: 0%;float: left;\">Required</p>\n</ion-row>\n<ion-row>\n  <div class=\"app-background-primary-color\" style=\"height: 10px;margin-top:4%;width: 10px;float: left;border-radius:50%;margin-right: 1%;\"></div><p  class=\"app-font-black-color font-size-10\" style=\"margin-bottom: 0%;float: left;\">Generated</p>\n</ion-row>\n<ion-row>\n  <div  style=\"height: 10px;margin-top:4%;width: 10px;float: left;border-radius:50%;margin-right: 1%;background-color: red;\"></div><p  class=\"app-font-black-color font-size-10\" style=\"margin-bottom: 0%;float: left;\">Less Than</p>\n</ion-row>\n<ion-row>\n  <div  style=\"height: 10px;margin-top:4%;width: 10px;float: left;border-radius:50%;margin-right: 1%;background-color: green;\"></div><p  class=\"app-font-black-color font-size-10\" style=\"margin-bottom: 0%;float: left;\">Greater Than</p>\n</ion-row>\n\n");

/***/ })

}]);
//# sourceMappingURL=src-app-dashboard-generated_schedule-summary-info-genereted-report-page-summary-info-genereted-report-page-module.js.map