(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-register-reset-password-password-changed-message-password-changed-message-module"],{

/***/ "2FNE":
/*!******************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/login-register/reset-password/password-changed-message/password-changed-message.page.html ***!
  \******************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n  <ion-content style=\"background-color: #F7F0D0;position: fixed;\">\n\n    <ion-grid   id=\"top\" >\n\n      <ion-row  class=\"ion-justify-content-center\" id=\"top-woo-hoo\"  >\n\n        <div class=\"custom-shape-divider-top-1626199019\">\n          <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"164.127\"  id=\"wo\" viewBox=\"0 0 164.127 297.183\">\n            <g id=\"Path_961\" data-name=\"Path 961\" fill=\"#0194e3\">\n              <path d=\"M 163.6269836425781 293.7049560546875 C 162.6239471435547 290.3355102539062 160.8894653320312 284.6212463378906 158.5999450683594 277.5073852539062 C 155.1582183837891 266.8134765625 149.7216339111328 250.6763458251953 143.3669891357422 234.5289611816406 C 136.2194519042969 216.3669586181641 129.3896331787109 201.89111328125 123.067253112793 191.5036163330078 C 119.2997894287109 185.3138122558594 115.6679458618164 180.5181579589844 112.2726364135742 177.2498779296875 C 108.4754867553711 173.5948028564453 104.8575210571289 171.7415466308594 101.5192947387695 171.7415466308594 C 95.98078918457031 171.7415466308594 90.16898345947266 171.1239166259766 84.24536895751953 169.9058074951172 C 78.45659637451172 168.7154693603516 72.55982971191406 166.9521484375 66.71883392333984 164.6648864746094 C 55.10398483276367 160.1166534423828 43.81744384765625 153.5213012695312 34.07944488525391 145.5919647216797 C 29.11336898803711 141.5481872558594 24.56056022644043 137.1714172363281 20.54744529724121 132.5831909179688 C 16.40994644165039 127.8526916503906 12.83517646789551 122.8834991455078 9.922484397888184 117.8136520385742 C 6.89329195022583 112.5410385131836 4.558638095855713 107.1197280883789 2.983368873596191 101.7003860473633 C 1.335561156272888 96.03138732910156 0.5000226497650146 90.29592132568359 0.5000226497650146 84.65326690673828 C 0.5000226497650146 78.94223022460938 1.057753443717957 73.23496246337891 2.15771484375 67.68996429443359 C 3.22963809967041 62.28630828857422 4.829061031341553 56.97111511230469 6.911599636077881 51.8920783996582 C 8.956253051757812 46.9053840637207 11.48698425292969 42.09577178955078 14.43344593048096 37.59677124023438 C 17.35182952880859 33.14069366455078 20.70333099365234 28.95042419433594 24.39483070373535 25.14238548278809 C 28.08609962463379 21.33461570739746 32.14775466918945 17.87773132324219 36.4669075012207 14.86765480041504 C 40.82706069946289 11.82903957366943 45.48809814453125 9.219231605529785 50.32063674926758 7.110770225524902 C 55.24209976196289 4.963462352752686 60.39229202270508 3.314308643341064 65.62809753417969 2.209077835083008 C 71.00056457519531 1.075000882148743 76.53021240234375 0.5000008940696716 82.06348419189453 0.5000008940696716 C 87.59675598144531 0.5000008940696716 93.12640380859375 1.075000882148743 98.49887084960938 2.209077835083008 C 103.7346801757812 3.314308643341064 108.8848724365234 4.963462352752686 113.8063278198242 7.110770225524902 C 118.6388320922852 9.219231605529785 123.2999038696289 11.82903957366943 127.6600646972656 14.86765480041504 C 131.9792175292969 17.87773132324219 136.0408630371094 21.33461570739746 139.7321319580078 25.14238548278809 C 143.4236755371094 28.95042419433594 146.7751770019531 33.14069366455078 149.6935272216797 37.59677124023438 C 152.6400299072266 42.09577178955078 155.1707153320312 46.9053840637207 157.2154083251953 51.8920783996582 C 159.2979431152344 56.97111511230469 160.8973693847656 62.28630828857422 161.9692993164062 67.68996429443359 C 163.0692596435547 73.23496246337891 163.6269836425781 78.94223022460938 163.6269836425781 84.65326690673828 L 163.6269836425781 293.7049560546875 Z\" stroke=\"none\"/>\n              <path d=\"M 82.06348419189453 1 C 76.56486511230469 1 71.0699462890625 1.571380615234375 65.73136901855469 2.69830322265625 C 60.52867889404297 3.7965087890625 55.41102600097656 5.435272216796875 50.52056121826172 7.56903076171875 C 45.7181396484375 9.664398193359375 41.08598327636719 12.25802612304688 36.75275421142578 15.27789306640625 C 32.45986938476562 18.26962280273438 28.42283630371094 21.70562744140625 24.75382995605469 25.49041748046875 C 21.08428955078125 29.27572631835938 17.75274658203125 33.44107055664062 14.85171508789062 37.87069702148438 C 11.92259216308594 42.34315490722656 9.406829833984375 47.12446594238281 7.374176025390625 52.08177185058594 C 5.303863525390625 57.13104248046875 3.713790893554688 62.4151611328125 2.648101806640625 67.78727722167969 C 1.554489135742188 73.30030822753906 0.9999847412109375 78.974853515625 0.9999847412109375 84.65327453613281 C 0.9999847412109375 90.2486572265625 1.828826904296875 95.93719482421875 3.463485717773438 101.5608520507812 C 5.027633666992188 106.9420013427734 7.346603393554688 112.3264312744141 10.35598754882812 117.5645751953125 C 13.25233459472656 122.60595703125 16.807861328125 127.5481872558594 20.92379760742188 132.2539978027344 C 24.91841125488281 136.8211212158203 29.45083618164062 141.1781921386719 34.3951416015625 145.2042388916016 C 44.09348297119141 153.1013031005859 55.33386993408203 159.6697387695312 66.90113830566406 164.1993103027344 C 72.71571350097656 166.4762268066406 78.58506011962891 168.2314300537109 84.34606170654297 169.4160766601562 C 90.23664093017578 170.6273498535156 96.01456451416016 171.2415466308594 101.519287109375 171.2415466308594 C 104.9912567138672 171.2415466308594 108.7258682250977 173.141845703125 112.6193695068359 176.8896484375 C 116.0456771850586 180.1877288818359 119.7045593261719 185.0171203613281 123.4943313598633 191.24365234375 C 129.8316040039062 201.6555786132812 136.6742553710938 216.1572723388672 143.8322143554688 234.3458862304688 C 150.1917114257812 250.5054626464844 155.6319427490234 266.6533508300781 159.0758666992188 277.3541870117188 C 160.7428588867188 282.5337524414062 162.1159210205078 286.9722595214844 163.126953125 290.3049926757812 L 163.126953125 84.65327453613281 C 163.126953125 78.974853515625 162.5724487304688 73.30030822753906 161.4788360595703 67.78727722167969 C 160.4131317138672 62.4151611328125 158.8230590820312 57.13104248046875 156.7527465820312 52.08177185058594 C 154.7200927734375 47.12446594238281 152.2043304443359 42.34315490722656 149.2752075195312 37.87069702148438 C 146.3741760253906 33.44107055664062 143.0426330566406 29.27572631835938 139.3731079101562 25.49041748046875 C 135.7041015625 21.70562744140625 131.6670989990234 18.26962280273438 127.3741760253906 15.27789306640625 C 123.0409469604492 12.25802612304688 118.4087905883789 9.664398193359375 113.6063690185547 7.56903076171875 C 108.7159423828125 5.435272216796875 103.5982971191406 3.7965087890625 98.39559936523438 2.69830322265625 C 93.05702209472656 1.571380615234375 87.56210327148438 1 82.06348419189453 1 M 82.06348419189453 0 C 127.3858642578125 0 164.126953125 37.90057373046875 164.126953125 84.65327453613281 C 164.126953125 103.6816101074219 164.126953125 297.1826171875 164.126953125 297.1826171875 C 164.126953125 297.1826171875 128.3954772949219 172.2415466308594 101.519287109375 172.2415466308594 C 56.19686889648438 172.2415466308594 -1.52587890625e-05 131.4059600830078 -1.52587890625e-05 84.65327453613281 C -1.52587890625e-05 37.90057373046875 36.74105834960938 0 82.06348419189453 0 Z\" stroke=\"none\" fill=\"#0194e3\"/>\n            </g>\n          </svg>\n\n        </div>\n        <div style=\"z-index: 1;margin-top:25px;position: absolute;\">\n\n          <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"120.554\" height=\"160.084\" viewBox=\"0 0 120.554 87.084\">\n            <text id=\"WOO_\" data-name=\"WOO \" transform=\"translate(14.707 30.687) rotate(-20)\" fill=\"#fff\" font-size=\"40\" font-family=\"SegoeUI, Segoe UI\"><tspan x=\"0\" y=\"0\">WOO </tspan></text>\n            <text id=\"HOO_\" data-name=\"HOO \" transform=\"translate(28.707 70.609) rotate(-20)\" fill=\"#fffeff\" font-size=\"40\" font-family=\"SegoeUI, Segoe UI\"><tspan x=\"0\" y=\"0\">HOO! </tspan></text>\n          </svg>\n\n          <!-- <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"112.096\" height=\"84.006\" viewBox=\"0 0 112.096 84.006\" style=\"padding: 0%;margin:0%\">\n\n          </svg> -->\n\n\n        </div>\n  </ion-row>\n\n\n\n\n    </ion-grid>\n<ion-grid id=\"center\" >\n  <ion-row class=\"ion-justify-content-center\"><p style=\"font-size: 22px;\" class=\"app-font-primary-color content-data\">Password changed successfully!</p></ion-row>\n\n\n<ion-row  class=\"ion-justify-content-center\" style=\"margin-top: 5%;\">\n<ion-button shape=\"round\"  class=\"app-button-primary \" id=\"get-start\" (click)=\"signIn()\" >Sign In</ion-button>\n</ion-row>\n\n\n\n</ion-grid>\n<ion-grid id=\"bottom\"  >\n  <div class=\"custom-shape-divider-bottom-1626277749\">\n    <svg data-name=\"Layer 1\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 1200 120\" preserveAspectRatio=\"none\">\n        <path d=\"M985.66,92.83C906.67,72,823.78,31,743.84,14.19c-82.26-17.34-168.06-16.33-250.45.39-57.84,11.73-114,31.07-172,41.86A600.21,600.21,0,0,1,0,27.35V120H1200V95.8C1132.19,118.92,1055.71,111.31,985.66,92.83Z\" class=\"shape-fill\"></path>\n    </svg>\n</div>\n  </ion-grid>\n    <!-- <ion-grid  style=\"margin:0;padding: 0% 0% 0% 0%;width: 100%;bottom:0% !important;height: 175px;\" >\n    <div class=\"custom-shape-divider-bottom-1626199019\">\n      <svg id=\"wave\"   viewBox=\"0 0 1440 490\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\">\n        <path style=\" opacity:1\" fill=\"#0194E3\" d=\"M0,196L80,163.3C160,131,320,65,480,106.2C640,147,800,294,960,302.2C1120,310,1280,180,1440,122.5C1600,65,1760,82,1920,98C2080,114,2240,131,2400,155.2C2560,180,2720,212,2880,187.8C3040,163,3200,82,3360,49C3520,16,3680,33,3840,57.2C4000,82,4160,114,4320,106.2C4480,98,4640,49,4800,65.3C4960,82,5120,163,5280,196C5440,229,5600,212,5760,228.7C5920,245,6080,294,6240,269.5C6400,245,6560,147,6720,122.5C6880,98,7040,147,7200,163.3C7360,180,7520,163,7680,147C7840,131,8000,114,8160,98C8320,82,8480,65,8640,106.2C8800,147,8960,245,9120,285.8C9280,327,9440,310,9600,253.2C9760,196,9920,98,10080,73.5C10240,49,10400,98,10560,171.5C10720,245,10880,343,11040,351.2C11200,359,11360,278,11440,236.8L11520,196L11520,490L11440,490C11360,490,11200,490,11040,490C10880,490,10720,490,10560,490C10400,490,10240,490,10080,490C9920,490,9760,490,9600,490C9440,490,9280,490,9120,490C8960,490,8800,490,8640,490C8480,490,8320,490,8160,490C8000,490,7840,490,7680,490C7520,490,7360,490,7200,490C7040,490,6880,490,6720,490C6560,490,6400,490,6240,490C6080,490,5920,490,5760,490C5600,490,5440,490,5280,490C5120,490,4960,490,4800,490C4640,490,4480,490,4320,490C4160,490,4000,490,3840,490C3680,490,3520,490,3360,490C3200,490,3040,490,2880,490C2720,490,2560,490,2400,490C2240,490,2080,490,1920,490C1760,490,1600,490,1440,490C1280,490,1120,490,960,490C800,490,640,490,480,490C320,490,160,490,80,490L0,490Z\"></path></svg>\n    </div>\n    </ion-grid> -->\n    <!-- <ion-img style=\"bottom: 0; height: 25%;width: 100%;\"  src=\"assets/img/c-foo.png\"></ion-img> -->\n    </ion-content>\n    <!-- <div class=\"custom-shape-divider-top-1626199019\">\n      <svg id=\"wave\"  viewBox=\"0 0 1440 490\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\"><defs><linearGradient id=\"sw-gradient-0\" x1=\"0\" x2=\"0\" y1=\"1\" y2=\"0\"><stop stop-color=\"rgba(243, 106, 62, 1)\" offset=\"0%\"></stop><stop stop-color=\"rgba(255, 179, 11, 1)\" offset=\"100%\"></stop></linearGradient></defs>\n        <path style=\" opacity:1\" fill=\"#0194E3\" d=\"M0,196L80,163.3C160,131,320,65,480,106.2C640,147,800,294,960,302.2C1120,310,1280,180,1440,122.5C1600,65,1760,82,1920,98C2080,114,2240,131,2400,155.2C2560,180,2720,212,2880,187.8C3040,163,3200,82,3360,49C3520,16,3680,33,3840,57.2C4000,82,4160,114,4320,106.2C4480,98,4640,49,4800,65.3C4960,82,5120,163,5280,196C5440,229,5600,212,5760,228.7C5920,245,6080,294,6240,269.5C6400,245,6560,147,6720,122.5C6880,98,7040,147,7200,163.3C7360,180,7520,163,7680,147C7840,131,8000,114,8160,98C8320,82,8480,65,8640,106.2C8800,147,8960,245,9120,285.8C9280,327,9440,310,9600,253.2C9760,196,9920,98,10080,73.5C10240,49,10400,98,10560,171.5C10720,245,10880,343,11040,351.2C11200,359,11360,278,11440,236.8L11520,196L11520,490L11440,490C11360,490,11200,490,11040,490C10880,490,10720,490,10560,490C10400,490,10240,490,10080,490C9920,490,9760,490,9600,490C9440,490,9280,490,9120,490C8960,490,8800,490,8640,490C8480,490,8320,490,8160,490C8000,490,7840,490,7680,490C7520,490,7360,490,7200,490C7040,490,6880,490,6720,490C6560,490,6400,490,6240,490C6080,490,5920,490,5760,490C5600,490,5440,490,5280,490C5120,490,4960,490,4800,490C4640,490,4480,490,4320,490C4160,490,4000,490,3840,490C3680,490,3520,490,3360,490C3200,490,3040,490,2880,490C2720,490,2560,490,2400,490C2240,490,2080,490,1920,490C1760,490,1600,490,1440,490C1280,490,1120,490,960,490C800,490,640,490,480,490C320,490,160,490,80,490L0,490Z\"></path></svg>\n    </div> -->\n");

/***/ }),

/***/ "OyB1":
/*!****************************************************************************************************************!*\
  !*** ./src/app/home/login-register/reset-password/password-changed-message/password-changed-message.module.ts ***!
  \****************************************************************************************************************/
/*! exports provided: PasswordChangedMessagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PasswordChangedMessagePageModule", function() { return PasswordChangedMessagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _password_changed_message_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./password-changed-message-routing.module */ "wc1o");
/* harmony import */ var _password_changed_message_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./password-changed-message.page */ "gcp/");







let PasswordChangedMessagePageModule = class PasswordChangedMessagePageModule {
};
PasswordChangedMessagePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _password_changed_message_routing_module__WEBPACK_IMPORTED_MODULE_5__["PasswordChangedMessagePageRoutingModule"]
        ],
        declarations: [_password_changed_message_page__WEBPACK_IMPORTED_MODULE_6__["PasswordChangedMessagePage"]]
    })
], PasswordChangedMessagePageModule);



/***/ }),

/***/ "gcp/":
/*!**************************************************************************************************************!*\
  !*** ./src/app/home/login-register/reset-password/password-changed-message/password-changed-message.page.ts ***!
  \**************************************************************************************************************/
/*! exports provided: PasswordChangedMessagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PasswordChangedMessagePage", function() { return PasswordChangedMessagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_password_changed_message_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./password-changed-message.page.html */ "2FNE");
/* harmony import */ var _password_changed_message_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./password-changed-message.page.scss */ "hMsI");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_json_apis_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/json/apis.json */ "B+pZ");
var src_app_json_apis_json__WEBPACK_IMPORTED_MODULE_5___namespace = /*#__PURE__*/__webpack_require__.t(/*! src/app/json/apis.json */ "B+pZ", 1);






let PasswordChangedMessagePage = class PasswordChangedMessagePage {
    constructor(navCtrl) {
        this.navCtrl = navCtrl;
    }
    ngOnInit() {
    }
    signIn() {
        this.navCtrl.navigateBack(src_app_json_apis_json__WEBPACK_IMPORTED_MODULE_5__.apis.login_api);
    }
};
PasswordChangedMessagePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] }
];
PasswordChangedMessagePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-password-changed-message',
        template: _raw_loader_password_changed_message_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_password_changed_message_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PasswordChangedMessagePage);



/***/ }),

/***/ "hMsI":
/*!****************************************************************************************************************!*\
  !*** ./src/app/home/login-register/reset-password/password-changed-message/password-changed-message.page.scss ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".custom-shape-divider-bottom-1626277749 {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  width: 100%;\n  overflow: hidden;\n  line-height: 0;\n}\n\n.custom-shape-divider-bottom-1626277749 svg {\n  position: relative;\n  display: block;\n  width: calc(170% + 1.3px);\n  height: 227px;\n}\n\n.custom-shape-divider-bottom-1626277749 .shape-fill {\n  fill: #0194E3;\n}\n\n@media (min-device-height: 700px) {\n  #wo {\n    height: 300px;\n  }\n\n  #top {\n    margin: 0;\n    padding: 0% 0% 0% 0%;\n    width: 100%;\n    height: 40%;\n  }\n\n  #top-woo-hoo {\n    margin-top: 25%;\n  }\n\n  #center {\n    height: 25%;\n  }\n\n  #bottom {\n    margin: 0;\n    padding: 0% 0% 0% 0%;\n    width: 100%;\n    bottom: 0% !important;\n    height: 25%;\n    position: fixed;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXHBhc3N3b3JkLWNoYW5nZWQtbWVzc2FnZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxPQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQUNGOztBQUVBO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0VBQ0EseUJBQUE7RUFDQSxhQUFBO0FBQ0Y7O0FBRUE7RUFDRSxhQUFBO0FBQ0Y7O0FBNkNBO0VBR0k7SUFFTSxhQUFBO0VBN0NSOztFQStDSTtJQUNFLFNBQUE7SUFBUyxvQkFBQTtJQUFxQixXQUFBO0lBQVksV0FBQTtFQXpDaEQ7O0VBMkNJO0lBQ0UsZUFBQTtFQXhDTjs7RUEwQ0k7SUFDRSxXQUFBO0VBdkNOOztFQXlDSTtJQUNFLFNBQUE7SUFBUyxvQkFBQTtJQUFxQixXQUFBO0lBQVkscUJBQUE7SUFBcUIsV0FBQTtJQUFZLGVBQUE7RUFqQ2pGO0FBQ0YiLCJmaWxlIjoicGFzc3dvcmQtY2hhbmdlZC1tZXNzYWdlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jdXN0b20tc2hhcGUtZGl2aWRlci1ib3R0b20tMTYyNjI3Nzc0OSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAwO1xuICBsZWZ0OiAwO1xuICB3aWR0aDogMTAwJTtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgbGluZS1oZWlnaHQ6IDA7XG59XG5cbi5jdXN0b20tc2hhcGUtZGl2aWRlci1ib3R0b20tMTYyNjI3Nzc0OSBzdmcge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICB3aWR0aDogY2FsYygxNzAlICsgMS4zcHgpO1xuICBoZWlnaHQ6IDIyN3B4O1xufVxuXG4uY3VzdG9tLXNoYXBlLWRpdmlkZXItYm90dG9tLTE2MjYyNzc3NDkgLnNoYXBlLWZpbGwge1xuICBmaWxsOiAjMDE5NEUzO1xufVxuXG4vLyBAbWVkaWEgc2NyZWVuIGFuZCAobWF4LWhlaWdodDo4MDBweCkge1xuLy8gICAjd297XG4vLyAgICAgLy8gIGhlaWdodDogMjkwLjE4Mztcbi8vICAgICBoZWlnaHQ6IDI5MHB4O1xuLy8gICAgIH1cbi8vICAgICAjdG9wLXdvby1ob297XG4vLyAgICAgICBtYXJnaW4tdG9wOiAwJTtcbi8vICAgICAgIGJvcmRlcjogMXB4IHNvbGlkO1xuLy8gICAgIH1cbi8vICN0b3B7XG4vLyAgIG1hcmdpbjowO3BhZGRpbmc6IDAlIDAlIDAlIDAlO3dpZHRoOiAxMDAlO2hlaWdodDogNDAlO1xuLy8gfVxuLy8gI2NlbnRlcntcbi8vICAgaGVpZ2h0OjI1JVxuLy8gfVxuLy8gI2JvdHRvbXtcbi8vICAgbWFyZ2luOjA7cGFkZGluZzogMCUgMCUgMCUgMCU7d2lkdGg6IDEwMCU7Ym90dG9tOjAlICFpbXBvcnRhbnQ7aGVpZ2h0OiAyMCU7XG4vLyB9XG5cbi8vIH1cblxuLy8gQG1lZGlhIChtaW4td2lkdGg6IDcwMHB4KSBhbmQgKG9yaWVudGF0aW9uOiBsYW5kc2NhcGUpICB7XG4vLyAgICN3b3tcbi8vICAgICAvLyAgaGVpZ2h0OiAyOTAuMTgzO1xuLy8gICAgIGhlaWdodDogMzAwcHg7XG4vLyAgICAgfVxuLy8gI3RvcHtcbi8vICAgbWFyZ2luOjA7cGFkZGluZzogMCUgMCUgMCUgMCU7d2lkdGg6IDEwMCU7aGVpZ2h0OiA0MCU7XG4vLyB9XG4vLyAjdG9wLXdvby1ob297XG4vLyAgIG1hcmdpbi10b3A6IDI1JTtcbi8vIH1cbi8vICNjZW50ZXJ7XG4vLyAgIGhlaWdodDoyNSVcbi8vIH1cbi8vICNib3R0b217XG4vLyAgIG1hcmdpbjowO3BhZGRpbmc6IDAlIDAlIDAlIDAlO3dpZHRoOiAxMDAlO2JvdHRvbTowJSAhaW1wb3J0YW50O2hlaWdodDogMjUlO3Bvc2l0aW9uOiBmaXhlZDtcbi8vIH1cblxuLy8gfVxuXG5cblxuQG1lZGlhXG5cbiAgKG1pbi1kZXZpY2UtaGVpZ2h0OiA3MDBweCkge1xuICAgICN3b3tcbiAgICAgICAgICAvLyAgaGVpZ2h0OiAyOTAuMTgzO1xuICAgICAgICAgIGhlaWdodDogMzAwcHg7XG4gICAgICAgICAgfVxuICAgICAgI3RvcHtcbiAgICAgICAgbWFyZ2luOjA7cGFkZGluZzogMCUgMCUgMCUgMCU7d2lkdGg6IDEwMCU7aGVpZ2h0OiA0MCU7XG4gICAgICB9XG4gICAgICAjdG9wLXdvby1ob297XG4gICAgICAgIG1hcmdpbi10b3A6IDI1JTtcbiAgICAgIH1cbiAgICAgICNjZW50ZXJ7XG4gICAgICAgIGhlaWdodDoyNSVcbiAgICAgIH1cbiAgICAgICNib3R0b217XG4gICAgICAgIG1hcmdpbjowO3BhZGRpbmc6IDAlIDAlIDAlIDAlO3dpZHRoOiAxMDAlO2JvdHRvbTowJSAhaW1wb3J0YW50O2hlaWdodDogMjUlO3Bvc2l0aW9uOiBmaXhlZDtcbiAgICAgIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "wc1o":
/*!************************************************************************************************************************!*\
  !*** ./src/app/home/login-register/reset-password/password-changed-message/password-changed-message-routing.module.ts ***!
  \************************************************************************************************************************/
/*! exports provided: PasswordChangedMessagePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PasswordChangedMessagePageRoutingModule", function() { return PasswordChangedMessagePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _password_changed_message_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./password-changed-message.page */ "gcp/");




const routes = [
    {
        path: '',
        component: _password_changed_message_page__WEBPACK_IMPORTED_MODULE_3__["PasswordChangedMessagePage"]
    }
];
let PasswordChangedMessagePageRoutingModule = class PasswordChangedMessagePageRoutingModule {
};
PasswordChangedMessagePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PasswordChangedMessagePageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=login-register-reset-password-password-changed-message-password-changed-message-module.js.map